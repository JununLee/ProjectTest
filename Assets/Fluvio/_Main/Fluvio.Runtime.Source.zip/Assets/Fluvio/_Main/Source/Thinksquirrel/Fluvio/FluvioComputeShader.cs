// FluvioComputeShader.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Cloo.Bindings;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;
using Cloo;

// ReSharper disable ParameterHidesMember
#pragma warning disable 649
namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Provides a proxy object for both Unity's native compute shaders and OpenCL compute programs.
    /// </summary>
    public sealed class FluvioComputeShader : FluvioScriptableObjectBase
    {
        [SerializeField, UsedImplicitly, HideInInspector] ComputeShader m_DirectComputeShader; // For backwards compatibility
        [SerializeField, UsedImplicitly] ComputeShader m_ComputeShader;
        [SerializeField, UsedImplicitly] TextAsset m_OpenCLShader;
        [SerializeField, HideInInspector] string m_OpenCLEditorIncludePath;
        [SerializeField, HideInInspector] string[] m_OpenCLIncludePaths = new string[0];
        [SerializeField, HideInInspector] string[] m_OpenCLIncludeSource = new string[0];

        [NonSerialized] int m_OpenCLSourceHash;
        [NonSerialized] readonly List<string> m_InspectorLog = new List<string>();

        [NonSerialized] ComputeAPI m_ComputeAPI;
        [NonSerialized] internal bool _shouldCompile = true;
        [NonSerialized] internal bool _displayedNotFoundKernel = false;
        [NonSerialized] internal bool _hadCompilerError = false;
        [NonSerialized] internal ComputeProgram _openCLComputeProgram;
        [NonSerialized] internal ComputeKernel[] _openCLComputeKernels = new ComputeKernel[0];
        [NonSerialized] readonly long[] m_LocalWorkSize = new long[3];
        [NonSerialized] readonly long[] m_GlobalWorkSize = new long[3];
        
        static readonly Dictionary<string, int> s_ArgToIndex = new Dictionary<string, int>();

        //! \cond PRIVATE
        public interface IComputeIncludeParser
        {
            void ParseIncludePathsRecursive(string source, string path, StringBuilder sb);
        }

        static IComputeIncludeParser s_IncludeParser;

        public static void SetIncludeParser(IComputeIncludeParser parser)
        {
            s_IncludeParser = parser;
        }
        //! \endcond

        static FluvioComputeShader()
        {
            // HACK: Due to a lack of support for named args in OpenCL without extensions

            // General arguments
            s_ArgToIndex.Add("fluvio_Count", 0);
            s_ArgToIndex.Add("fluvio_Stride", 1);
            s_ArgToIndex.Add("fluvio_KernelSize", 2);
            s_ArgToIndex.Add("fluvio_KernelFactors", 3);
            s_ArgToIndex.Add("fluvio_Time", 4);

            // Buffers
            s_ArgToIndex.Add("fluvio_Particle", 5);
            s_ArgToIndex.Add("fluvio_Neighbors", 6);

            // Buffers (except index grid)            
            s_ArgToIndex.Add("fluvio_Fluid", 7);

            // Plugins
            s_ArgToIndex.Add("fluvio_IncludeFluidGroup", 8);
            s_ArgToIndex.Add("fluvio_PluginFluidID", 9);

            for (var j = 0; j < FluvioSettings.kMaxPluginBuffers; ++j)
            {
                s_ArgToIndex.Add("fluvio_PluginData" + j, 10 + j); //10-19
            }
            
            // Buffers (except plugins)
            s_ArgToIndex.Add("fluvio_BoundaryParticle", 8);

            // Index grid
            s_ArgToIndex.Add("fluvio_IndexGridBoundaryParticle", 7);
            s_ArgToIndex.Add("fluvio_IndexGrid", 8);
            
            // Particle system
            s_ArgToIndex.Add("fluvio_ParticleSystem_FluidID", 8);
            s_ArgToIndex.Add("fluvio_ParticleSystem_ParticleCount", 9);
            s_ArgToIndex.Add("fluvio_ParticleSystem_Dimensions", 10);
            s_ArgToIndex.Add("fluvio_ParticleSystem_ParticleToWorldMatrix", 11);
            s_ArgToIndex.Add("fluvio_ParticleSystem_WorldToParticleMatrix", 12);
        }

        #region Public API
        /// <summary>
        ///     Finds a Fluvio compute shader by resource path.
        /// </summary>
        /// <param name="path">The resource path to search.</param>
        /// <returns>The Fluvio compute shader if found; otherwise null.</returns>
        public static FluvioComputeShader Find(string path)
        {
            return Resources.Load<FluvioComputeShader>(path + "/" + "_MainAsset");
        }
        #endregion

        internal void SetOpenCLIncludes(string[] includePaths, string[] includeSource)
        {
            m_OpenCLIncludePaths = includePaths;
            m_OpenCLIncludeSource = includeSource;
        }
        internal void SetOpenCLIncludePath(string editorPath)
        {
            m_OpenCLEditorIncludePath = editorPath;
            m_OpenCLIncludePaths = new string[0];
            m_OpenCLIncludeSource = new string[0];
        }
        internal IList<string> GetInspectorLog()
        {
            return m_InspectorLog;
        }

        internal int FindKernel(string name)
        {
            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader)
                    {
                        var kernel = m_ComputeShader.FindKernel(name);
                        if (kernel < 0 && !_hadCompilerError && !_displayedNotFoundKernel)
                        {
                            FluvioDebug.LogWarning(string.Format("Unable to find compute kernel named {0}.", name), this);
                            _displayedNotFoundKernel = true;
                        }
                        return kernel;
                    }
                    break;
                case ComputeAPI.OpenCL:
                    for (var i = 0; i < _openCLComputeKernels.Length; ++i)
                    {
                        if (_openCLComputeKernels[i].FunctionName == name)
                            return i;
                    }
                    if (!_hadCompilerError && !_displayedNotFoundKernel)
                    {
                        FluvioDebug.LogWarning(string.Format("Unable to find compute kernel named {0}.", name), this);
                        _displayedNotFoundKernel = true;
                    }
                    break;
            }
            return -1;
        }

        //! \cond PRIVATE
        [UsedImplicitly]
        protected override void OnEnable()
        {
            base.OnEnable();

            if (m_DirectComputeShader != null)
            {
                if (m_ComputeShader == null) m_ComputeShader = m_DirectComputeShader;
                m_DirectComputeShader = null;
            }
            FluvioOpenCL._computeShaders.Add(this);
            
            // Use PlayerPrefs for compilation log, to prevent unneccessary serialized debug data
            if (Application.isEditor)
            {
                IList<string> kernelNames;
                GetOpenCLSource(out kernelNames);
                var pathHash = Application.dataPath.GetHashCode();
                var logCount = PlayerPrefs.GetInt(string.Format("Thinksquirrel.FluvioEditor.{0}.{1}.ShaderLogCount", pathHash, m_OpenCLSourceHash), 0);
                for (var i = 0; i < logCount; ++i)
                {
                    m_InspectorLog.Add(PlayerPrefs.GetString(string.Format("Thinksquirrel.FluvioEditor.{0}.{1}.ShaderLog_{2}", pathHash, m_OpenCLSourceHash, i)));
                }
            }
        }

        [UsedImplicitly]
        protected override void OnDisable()
        {
            base.OnDisable();

            Cleanup();
            FluvioOpenCL.Cleanup();
            FluvioOpenCL._computeShaders.Remove(this);
            
            // Use PlayerPrefs for compilation log, to prevent unneccessary serialized debug data
            if (Application.isEditor)
            {
                var pathHash = Application.dataPath.GetHashCode();
                PlayerPrefs.SetInt(string.Format("Thinksquirrel.FluvioEditor.{0}.{1}.ShaderLogCount", pathHash, m_OpenCLSourceHash), m_InspectorLog.Count);
                for (var i = 0; i < m_InspectorLog.Count; ++i)
                {
                    PlayerPrefs.SetString(string.Format("Thinksquirrel.FluvioEditor.{0}.{1}.ShaderLog_{2}", pathHash, m_OpenCLSourceHash, i), m_InspectorLog[i]);
                }
            }
        }
        //! \endcond

        void Initialize()
        {
            m_ComputeAPI = FluvioSettings.GetCurrentComputeAPI();

            if (m_ComputeAPI != ComputeAPI.OpenCL)
                return;

            _shouldCompile |= _openCLComputeProgram == null || !Equals(FluvioOpenCL.GetComputeContext(), _openCLComputeProgram.Context);

            if (!_shouldCompile) return;

            CompileOpenCLProgram();
        }
        internal void Cleanup()
        {
            for (var i = 0; i < _openCLComputeKernels.Length; ++i)
            {
                var kernel = _openCLComputeKernels[i];
                if (kernel == null) continue;

                //FluvioDebug.Log("Disposing OpenCL compute kernel", "Fluvio", "FluvioComputeShader", this);
                kernel.Dispose();
            }

            _openCLComputeKernels = new ComputeKernel[0];

            if (_openCLComputeProgram != null)
            {
                //FluvioDebug.Log("Disposing OpenCL compute program", "Fluvio", "FluvioComputeShader", this);
                _openCLComputeProgram.Dispose();
            }

            _openCLComputeProgram = null;
            _shouldCompile = true;
        }
        //! \cond PRIVATE
        public static string RemoveComments(string input)
        {
            const string blockComments = @"/\*(.*?)\*/";
            const string lineComments = @"//(.*?)\r?\n";
            const string strings = @"""((\\[^\n]|[^""\n])*)""";
            const string verbatimStrings = @"@(""[^""]*"")+";

            return Regex.Replace(input,
                blockComments + "|" + lineComments + "|" + strings + "|" + verbatimStrings,
                matchStr =>
                {
                    if (matchStr.Value.StartsWith("/*") || matchStr.Value.StartsWith("//"))
                        return matchStr.Value.StartsWith("//") ? "\n" : "";
                    // Keep the literal strings
                    return matchStr.Value;
                },
                RegexOptions.Singleline);
        }
        public static string Minify(string input)
        {
            var sb = new StringBuilder();

            using (var stringReader = new StringReader(input))
            {
                var line = stringReader.ReadLine();
                bool inDirective = false;
                bool hadTrailingBackslash = false;
                bool firstLine = true;
                while (line != null)
                {
                    // Replace carriage returns
                    line = line.Replace("\r", "\n");

                    // Replace control characters
                    for (var i = line.Length - 1; i >= 0; --i)
                    {
                        if (char.IsControl(line[i]))
                        {
                            line = line.Remove(i, 1).Insert(i, " ");
                        }
                    }

                    // Trim leading and trailing spaces
                    line = line.Trim();

                    // Line is the start of a directive
                    var directive = line.StartsWith("#");
                    
                    if (!string.IsNullOrEmpty(line))
                    {
                        if (directive)
                        {
                            if (!firstLine) sb.Append("\n");
                            inDirective = true;
                        }
                        else if (inDirective && !hadTrailingBackslash)
                        {
                            sb.Append("\n");
                            inDirective = false;
                        }

                        hadTrailingBackslash = line.EndsWith("\\");

                        // Remove trailing backslash
                        if (hadTrailingBackslash)
                        {
                            line = line.Substring(0, line.Length - 1);
                        }

                        sb.Append(line);
                        if (line.EndsWith("else")) sb.Append(" "); // For lines that have "else" and no brackets
                        firstLine = false;                                     
                    }

                    line = stringReader.ReadLine();
                }
            }

            return sb.ToString();
        }        
        //! \endcond

        internal string AddIncludes(string input)
        {  
            var sb = new StringBuilder();

            if (Application.isEditor)
            {
                if (s_IncludeParser == null) FluvioSettings.InitializeRuntimeHelper();
                if (s_IncludeParser == null) return input;
                s_IncludeParser.ParseIncludePathsRecursive(input, m_OpenCLEditorIncludePath, sb);
                return sb.ToString();
            }

            using (var stringReader = new StringReader(input))
            {
                var line = stringReader.ReadLine();
                while (line != null)
                {
                    if (line.StartsWith("#include "))
                    {
                        // Include additional source files
                        var includeLocation = line.Substring(10, line.Length - 11);
                        var includeFound = false;
                        var includeError = false;

                        for (var i = 0; i < m_OpenCLIncludeSource.Length; ++i)
                        {
                            var includeName = m_OpenCLIncludePaths[i];
                            var includeSource = m_OpenCLIncludeSource[i];

                            if (string.IsNullOrEmpty(includeSource) || includeLocation != includeName) continue;

                            try
                            {
                                sb.Append(includeSource);
                                includeFound = true;
                            }
                            catch
                            {
                                includeFound = false;
                                includeError = true;
                            }

                            break;
                        }

                        if (!includeFound)
                        {
                            sb.Append(string.Format("#error \"{0} - {1}\"", includeError ? "Error processing include" : "Could not find include", includeLocation)).Append("\n");
                        }
                    }
                    else
                    {
                        sb.Append(line).Append("\n");
                    }

                    line = stringReader.ReadLine();
                }
            }

            return sb.ToString();
        }
        
        internal string GetOpenCLSource(out IList<string> kernelNames)
        {
            if (m_OpenCLShader == null)
            {
                kernelNames = null;
                return null;
            }

            var originalSource = m_OpenCLShader.text;
            //originalSource = RemoveComments(originalSource);
            //originalSource = Minify(originalSource);
            originalSource = AddIncludes(originalSource);
            //originalSource = Minify(originalSource);

            var builder = new StringBuilder();
            kernelNames = new List<string>();

            using (var stringReader = new StringReader(originalSource))
            {
                var line = stringReader.ReadLine();
                while (line != null)
                {
                    if (line.StartsWith("#pragma kernel "))
                    {
                        kernelNames.Add(line.Substring(15));
                    }
                    else
                    {
                        builder.Append(line).Append("\n");
                    }

                    line = stringReader.ReadLine();
                }
            }

            var clProgramSource = builder.ToString();
            m_OpenCLSourceHash = clProgramSource.GetHashCode();
            return clProgramSource;
        }
        internal void CompileOpenCLProgram()
        {
            if (!CLInterface.IsAvailable())
                return;

            if (_hadCompilerError) return;

            Cleanup();

            IList<string> kernelNames;
            var clProgramSource = GetOpenCLSource(out kernelNames);

            if (string.IsNullOrEmpty(clProgramSource)) return;

            try
            {
                var context = FluvioOpenCL.GetComputeContext();
                var platformName = FluvioOpenCL.GetComputePlatform().Name;
                var device = FluvioOpenCL.GetComputeDevice();

                _openCLComputeProgram = new ComputeProgram(context, clProgramSource);
                
                var platformDefine = 
                    platformName.Contains("APPLE") ? " -D FLUVIO_API_OPENCL_APPLE"
                    : platformName.Contains("NVIDIA") ? " -D FLUVIO_API_OPENCL_NVIDIA"
                    : platformName.Contains("AMD") ? " -D FLUVIO_API_OPENCL_AMD"
                    : platformName.Contains("Intel") ? " -D FLUVIO_API_OPENCL_INTEL" 
                    : platformName.Contains("ARM") ? " -D FLUVIO_API_OPENCL_ARM" : string.Empty;
                
                var gpuDefine =
                    device.Type == ComputeDeviceTypes.Gpu ? " -D FLUVIO_API_OPENCL_GPU"
                    : device.Type == ComputeDeviceTypes.Cpu ? " -D FLUVIO_API_OPENCL_CPU"
                    : device.Type == ComputeDeviceTypes.Accelerator ? " -D FLUVIO_API_OPENCL_ACCELERATOR" : string.Empty;

                _openCLComputeProgram.Build(new[] {device}, "-D FLUVIO_API_OPENCL" + platformDefine + gpuDefine, null, IntPtr.Zero);
                var deviceLog = _openCLComputeProgram.GetBuildLog(device);

                if (Application.isEditor)
                {
                    var logSplit = deviceLog.Split('\n');

                    foreach (var lineRaw in logSplit)
                    {
                        if (lineRaw.Contains("error: ") || lineRaw.Contains("warning: "))
                        {
                            var line = lineRaw.Substring(lineRaw.IndexOf(":", StringComparison.Ordinal) + 1);
                            var lineFormat = string.Format("{0} : {1} : {2}", line, device.Platform.Name, FluvioOpenCL.GetComputeDevice()).Trim();

                            if (!m_InspectorLog.Contains(lineFormat)) m_InspectorLog.Add(lineFormat);
                        }
                    }
                }
            }
            catch (Exception)
            {
                var logStringBuilder = new StringBuilder();
                logStringBuilder.Append("Failed to build OpenCL program");

                var device = FluvioOpenCL.GetComputeDevice();
                var status = _openCLComputeProgram != null ? _openCLComputeProgram.GetBuildStatus(device) : ComputeProgramBuildStatus.None;
                var deviceName = device != null ? device.Name : "Unknown Device";
                var deviceLog = "Unknown error";
                if (status == ComputeProgramBuildStatus.Error)
                {
                    deviceLog = _openCLComputeProgram.GetBuildLog(device);
                    logStringBuilder.Append(". Check the log for more details.\n");
                    logStringBuilder.Append("Device: ");
                    logStringBuilder.Append(deviceName).Append("\n");
                    logStringBuilder.Append("Log:\n\n");
                    logStringBuilder.Append(deviceLog).Append("\n");
                }
                else
                {
                    logStringBuilder.Append(" due to an unknown error.");
                }

                FluvioDebug.LogError(logStringBuilder.ToString(), this);

                _hadCompilerError = true;
                _displayedNotFoundKernel = true;

                if (Application.isEditor)
                {
                    var logSplit = deviceLog.Split('\n');

                    foreach (var lineRaw in logSplit)
                    {                        
                        if (lineRaw.Contains("error: ") || lineRaw.Contains("warning: "))
                        {
                            var line = lineRaw.Substring(lineRaw.IndexOf(":", StringComparison.Ordinal) + 1);
                            var lineFormat = string.Format("{0} : {1} : {2}", line, device.Platform.Name, deviceName).Trim();

                            if (!m_InspectorLog.Contains(lineFormat)) m_InspectorLog.Add(lineFormat);
                        }
                    }
                }
                return;
            }

            var kernelList = new List<ComputeKernel>();

            for (var i = 0; i < kernelNames.Count; ++i)
            {
                var kernelName = kernelNames[i];
                kernelList.Add(_openCLComputeProgram.CreateKernel(kernelName));
            }

            _openCLComputeKernels = kernelList.ToArray();

            m_InspectorLog.Clear();
            _hadCompilerError = false;
            _displayedNotFoundKernel = false;
            _shouldCompile = false;
        }       
        internal void Dispatch(int kernelIndex, int count)
        {
            Dispatch(kernelIndex, count, 1, 1);
        }

        internal void Dispatch(int kernelIndex, int x, int y, int z)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            var singleDimension = x != 1 && y == 1 && z == 1;

            int xSize;
            var ySize = 1;
            var zSize = 1;
          
            if (singleDimension)
            {
                xSize = FluvioSettings.kComputeThreadGroupSize;
                x = ToNextGroupSize(x, xSize);
            }
            else
            {
                xSize = FluvioSettings.kComputeThreadGroupSizeX;
                ySize = FluvioSettings.kComputeThreadGroupSizeY;
                zSize = FluvioSettings.kComputeThreadGroupSizeZ;

                x = ToNextGroupSize(x, xSize);
                y = ToNextGroupSize(y, ySize);
                z = ToNextGroupSize(z, zSize);
            }

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.Dispatch(kernelIndex, x / xSize, y / ySize, z / zSize);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex >= _openCLComputeKernels.Length) return;
                    var kernel = _openCLComputeKernels[kernelIndex];
                    var queue = FluvioOpenCL.GetCommandQueue();
                    if (!Equals(queue.Context, kernel.Context)) return;

                    m_GlobalWorkSize[0] = x;
                    m_GlobalWorkSize[1] = y;
                    m_GlobalWorkSize[2] = z;
                    m_LocalWorkSize[0] = queue.Device.Type == ComputeDeviceTypes.Gpu ? xSize : 1;
                    m_LocalWorkSize[1] = queue.Device.Type == ComputeDeviceTypes.Gpu ? ySize : 1;
                    m_LocalWorkSize[2] = queue.Device.Type == ComputeDeviceTypes.Gpu ? zSize : 1;

                    try
                    {
                        //FluvioDebug.Log("Executing kernel: " + kernel.FunctionName, "Fluvio", "FluvioComputeShader.Dispatch");
                        queue.Execute(kernel, null, m_GlobalWorkSize, queue.Device.Type == ComputeDeviceTypes.Gpu ? m_LocalWorkSize : null, null);
                    }
                    catch (Exception e)
                    {
                        FluvioDebug.LogException(e);
                        Cleanup();
                        FluvioOpenCL.Cleanup(true);
                    }
                    break;
            }
        }
        static int ToNextGroupSize(int value, int groupSize)
        {
            return groupSize * ((value + (groupSize - 1)) / groupSize);
        }

        int ArgToIndex(string name)
        {
            int ret;
            if (!s_ArgToIndex.TryGetValue(name, out ret))
            {
                FluvioDebug.LogWarning("Argument index not found: " + name, this);
                ret = -1;
            }
            return ret;
        }
        internal void SetPluginData(int kernelIndex, int pluginDataIndex, FluvioComputeBufferBase buffer)
        {
            if (buffer == null)
                return;

            if (pluginDataIndex < 0 || pluginDataIndex >= FluvioSettings.kMaxPluginBuffers)
                return;

            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader && buffer._computeBufferNative != null) m_ComputeShader.SetBuffer(kernelIndex, "fluvio_PluginData" + pluginDataIndex, buffer._computeBufferNative);
                    break;
                case ComputeAPI.OpenCL:
                    if (buffer._computeBufferOpenCL != null && kernelIndex < _openCLComputeKernels.Length && Equals(buffer._computeBufferOpenCL.Context, _openCLComputeProgram.Context))
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex("fluvio_PluginData" + pluginDataIndex);

                        try
                        {
                            kernel.SetMemoryArgument(argumentIndex, buffer._computeBufferOpenCL);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }
        internal void SetBuffer<T>(int kernelIndex, string name, FluvioComputeBuffer<T> buffer) where T : struct
        {
            if (buffer == null)
                return;

            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader && buffer._computeBufferNative != null) m_ComputeShader.SetBuffer(kernelIndex, name, buffer._computeBufferNative);
                    break;
                case ComputeAPI.OpenCL:
                    if (buffer._computeBufferOpenCL != null && kernelIndex < _openCLComputeKernels.Length && Equals(buffer._computeBufferOpenCL.Context, _openCLComputeProgram.Context))
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) return;

                        try
                        {
                            kernel.SetMemoryArgument(argumentIndex, buffer._computeBufferOpenCL);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }

                    }
                    break;
            }
        }
        internal void SetFloat(int kernelIndex, string name, float val)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.SetFloat(name, val);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex < _openCLComputeKernels.Length)
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) break;

                        try
                        {
                            kernel.SetValueArgument(argumentIndex, val);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }
        internal void SetFloats(int kernelIndex, string name, params float[] values)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.SetFloats(name, values);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex < _openCLComputeKernels.Length)
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) break;

                        var gcHandle = GCHandle.Alloc(values, GCHandleType.Pinned);
                        try
                        {
                            kernel.SetArgument(argumentIndex, new IntPtr(Marshal.SizeOf(typeof (float))*values.Length),
                                               gcHandle.AddrOfPinnedObject());
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                        finally
                        {
                            gcHandle.Free();
                        }
                    }
                    break;
            }
        }
        internal void SetInt(int kernelIndex, string name, int val)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.SetInt(name, val);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex < _openCLComputeKernels.Length)
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) break;

                        try
                        {
                            kernel.SetValueArgument(argumentIndex, val);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }
        internal void SetInts(int kernelIndex, string name, params int[] values)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.SetInts(name, values);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex < _openCLComputeKernels.Length)
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) break;

                        var gcHandle = GCHandle.Alloc(values, GCHandleType.Pinned);
                        try
                        {
                            kernel.SetArgument(argumentIndex, new IntPtr(Marshal.SizeOf(typeof (int))*values.Length),
                                               gcHandle.AddrOfPinnedObject());
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning(name + ": " + argumentIndex);
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                        finally
                        {
                            gcHandle.Free();
                        }
                    }
                    break;
            }
        }
        internal void SetVector(int kernelIndex, string name, Vector2 val)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.SetVector(name, val);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex < _openCLComputeKernels.Length)
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) break;

                        try
                        {
                            kernel.SetValueArgument(argumentIndex, val);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }
        internal void SetVector(int kernelIndex, string name, Vector3 val)
        {
            SetVector(kernelIndex, name, (Vector4)val);
        }
        internal void SetVector(int kernelIndex, string name, Vector4 val)
        {
            if (kernelIndex < 0)
                return;

            Initialize();

            switch (m_ComputeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (m_ComputeShader) m_ComputeShader.SetVector(name, val);
                    break;
                case ComputeAPI.OpenCL:
                    if (kernelIndex < _openCLComputeKernels.Length)
                    {
                        var kernel = _openCLComputeKernels[kernelIndex];
                        var argumentIndex = ArgToIndex(name);

                        if (argumentIndex < 0) break;

                        try
                        {
                            kernel.SetValueArgument(argumentIndex, val);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Cleanup();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }

        readonly float[] s_MatrixFloats = new float[16];

        internal void SetMatrix(int kernelIndex, string name, Matrix4x4 mat)
        {
            var matrixFloats = s_MatrixFloats;
            for (var i = 0; i < 16; ++i)
            {
                matrixFloats[i] = mat[i];
            }

            SetFloats(kernelIndex, name, matrixFloats);
        }
    }
}
