// FluidColliderBase.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Collections.Generic;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Represents a fluid collider.
    /// </summary>
    /// <remarks>
    ///     Fluid colliders are a special type of fluid that serve as collision boundaries for fluid simulation.
    /// </remarks>
    [ExecuteInEditMode]
    public abstract class FluidColliderBase : FluidBase
    {
        #region Serialized Fields
        [SerializeField]int m_ColliderResolution = 4;
        [SerializeField] FluidColliderBoundsType m_BoundsType;
        [SerializeField] Bounds[] m_ColliderBounds = { new Bounds(Vector3.zero, Vector3.one) };
        [SerializeField] bool m_FillCollider;
        [SerializeField] bool m_VisualizeCollider = true;
        #endregion
        #region Instance Fields
        [NonSerialized] internal bool _isUploaded;
        [NonSerialized] readonly List<Vector3> m_CollisionPoints = new List<Vector3>();
        [NonSerialized] bool m_ColliderIsDirty;
        [NonSerialized] Matrix4x4 m_LocalToWorldMatrix;
        [NonSerialized] float m_OldResolution;
        [NonSerialized] Vector3 m_OldPosition;
        [NonSerialized] Quaternion m_OldRotation;
        [NonSerialized] Vector3 m_OldScale;        
        [NonSerialized] Transform m_OldParent;
        [NonSerialized] FluidBase m_OldParentFluid;
        [NonSerialized] SimulationDimensions m_OldDimensions;
        [NonSerialized] float m_OldSmoothingDistance;
        [NonSerialized] bool m_OldFill;
        [NonSerialized] bool m_ShowedParticleCountWarning;
        #endregion

        #region Public API
        /// <summary>
        /// Minimum float value for collider distance calculation.
        /// </summary>
        public const float kEpsilon = Vector3.kEpsilon;
        /// <summary>
        ///     Controls the resolution of the collider.
        /// </summary>
        /// <remarks>
        ///     Higher values introduce more collider detail at the cost of performance.
        /// </remarks>
        public int colliderResolution
        {
            get { return m_ColliderResolution; }
            set { m_ColliderResolution = value; }
        }

        /// <summary>
        ///     Controls whether or not collider bounds are calculated automatically.
        /// </summary>
        /// <remarks>
        ///     If set to manual, a set of bounds can be used to voxelize the collider instead. This can be useful to decrease the amount of boundary particles generated.
        /// </remarks>
        public FluidColliderBoundsType boundsType
        {
            get { return m_BoundsType; }
            set { m_BoundsType = value; }
        }
        /// <summary>
        ///     Gets or sets a set of bounds for voxelizing the collider.
        /// </summary>
        /// <remarks>
        ///     These bounds are only used when manual bounds are enabled.
        /// </remarks>
        public Bounds[] colliderBounds
        {
            get {  return m_ColliderBounds; }
            set { m_ColliderBounds = value; }
        }
        /// <summary>
        ///     Controls whether or not the collider should be filled.
        /// </summary>
        /// <remarks>
        ///     Filled colliders provide better simulation for solid objects and higher velocity objects, but have a higher performance overhead (especially in 3D).
        ///     For edge and terrain colliders, this will always return false.
        /// </remarks>
        public virtual bool fillCollider
        {
            get { return m_FillCollider; }
            set { m_FillCollider = value; }
        }
        /// <summary>
        ///     Forces the collider to update during the next solver synchronization step.
        /// </summary>
        /// <param name="updateImmediately">If true, update the collider immediately.</param>
        /// <remarks>
        ///     In most cases, the collider will update automatically. However, colliders need to be manually updated in some situations.
        ///     Even when updating immediately, the boundary particles that make up the collider will still only be uploaded during the synchronization step.
        /// </remarks>
        public void ForceColliderUpdate(bool updateImmediately = false)
        {
            SetAsDirty();
            if (updateImmediately) DoVoxelize();
        }
        internal IList<Vector3> GetCollisionPoints()
        {
            return m_CollisionPoints;
        }        
        internal void SetMatrix(Matrix4x4 value)
        {
            m_LocalToWorldMatrix = value;
        }
        #endregion
        void SetAsDirty()
        {
            m_ColliderIsDirty = true;
            m_ShowedParticleCountWarning = false;
            if (_solver != null && fluidType == FluidType.Static) _solver.shouldUpdateBoundaries = true;
        }
        //! \cond PRIVATE
        protected internal override bool IsWorldSpace()
        {
            return false;
        }
        protected internal override Matrix4x4 GetLocalToWorldMatrix()
        {
            return m_LocalToWorldMatrix;
        }
        //! \endcond
        /// <summary>
        ///     Adds a collision point to the fluid collider.
        /// </summary>
        /// <param name="pt">The point to add to the collider. Collision points are represented by boundary particles in the fluid simulation.</param>
        /// <returns>True if the operation was successful; otherwise, false.</returns>
        protected bool AddCollisionPoint(Vector3 pt)
        {
            if (m_CollisionPoints.Count < FluvioSettings.kFluidColliderMaxParticleCount)
            {
                switch (m_BoundsType)
                {
                    case FluidColliderBoundsType.Automatic:
                        m_CollisionPoints.Add(pt);
                        return true;
                    case FluidColliderBoundsType.Manual:
                        for (var i = 0; i < m_ColliderBounds.Length; ++i)
                        {
                            if (m_ColliderBounds[i].Contains(pt))
                            {
                                m_CollisionPoints.Add(pt);
                                return true;
                            }
                        }
                        return true;
                }
            }
            if (!m_ShowedParticleCountWarning)
            {
                FluvioDebug.LogWarning("Object exceeds maximum collider particle count!", this);
                m_ShowedParticleCountWarning = false;
            }
            return false;
        }
        /// <summary>
        ///     Draws the collider in the editor scene view. Called during OnDrawGizmos.
        /// </summary>
        /// <remarks>
        ///     Colliders should implement this function to allow users to visualize the collider.
        /// </remarks>
        protected abstract void DrawCollider();
        
        #region Unity Methods
        //! \cond PRIVATE
        protected override sealed void Reset()
        {
            base.Reset();

            fluidType = gameObject.isStatic ? FluidType.Static : FluidType.Kinematic;
            particleMass = 100.0f;
            density = 10.0f;
            gasConstant = 0.01f;
            m_ColliderIsDirty = true;
        }
        protected override sealed void OnEnable()
        {
            base.OnEnable();

            SetAsDirty();
        }
        protected override sealed void OnDisable()
        {
            base.OnDisable();
            m_CollisionPoints.Clear();
        }
        void OnDrawGizmos()
        {
            var mat = Gizmos.matrix;
            Gizmos.matrix = m_LocalToWorldMatrix;
            Gizmos.color = FluvioColors.s_FluidColliderColor;

            if (m_BoundsType == FluidColliderBoundsType.Manual)
            {
                for (var i = 0; i < m_ColliderBounds.Length; ++i)
                {
                    var b = m_ColliderBounds[i];
                    Gizmos.DrawWireCube(b.center, b.size);
                }
            }
            
            if (!m_VisualizeCollider)
                return;

            Gizmos.matrix = mat;

            DrawCollider();
        }
        //! \endcond

        void Update()
        {
            // Clamp resolution
            m_ColliderResolution = Mathf.Clamp(m_ColliderResolution, 1, 16);

            Initialize();
            
            // Matrix
            SetColliderMatrix();

            GetDefaultCollider();

            if (!ColliderIsValid())
            {
                m_ColliderIsDirty = true;
                m_CollisionPoints.Clear();
                SetMaxParticles(0);
                return;
            }
            if (fluidType == FluidType.Static)
            {
                var dPos = m_OldPosition - transform.position;

                if (Vector3.Dot(dPos, dPos) > kEpsilon*kEpsilon ||
                    Quaternion.Angle(m_OldRotation, transform.rotation) > 0.1f)
                {
                    m_ColliderIsDirty = true;
                }
            }
            var dScale = m_OldScale - transform.lossyScale;
            if (m_ColliderIsDirty ||
                m_OldParent != transform.parent || 
                m_OldParentFluid != parentFluid || 
                m_OldDimensions != dimensions ||
                m_OldSmoothingDistance != smoothingDistance ||
                m_OldResolution != m_ColliderResolution ||
                m_OldFill != m_FillCollider ||               
                Vector3.Dot(dScale, dScale) > kEpsilon * kEpsilon ||
                ColliderHasChanged())
            {
                SetAsDirty();                
            }

            if (m_ColliderIsDirty)
            {
                DoVoxelize();
            }
            
            // Parent fluids are required for colliders
            if (!parentFluid)
            {
                SetMaxParticles(0);
                return;
            }

            // Max particles and gravity
            SetMaxParticles(m_CollisionPoints.Count);
            SetGravity(Vector3.zero);
            
            // Properties
            minimumDensity = density;
            viscosity = 0.0f;
            turbulence = 0.0f;
            surfaceTension = 0.0f;
            buoyancyCoefficient = 0.0f;
        }
        void DoVoxelize()
        {
            m_CollisionPoints.Clear();
            Voxelize();
            m_ColliderIsDirty = false;
            m_OldParent = transform.parent;
            m_OldParentFluid = parentFluid;
            m_OldDimensions = dimensions;
            m_OldSmoothingDistance = smoothingDistance;
            m_OldResolution = m_ColliderResolution;
            m_OldPosition = transform.position;            
            m_OldRotation = transform.rotation;
            m_OldScale = transform.lossyScale;
            m_OldFill = m_FillCollider;
        }
        #endregion

        #region Abstract, Virtual, and Override
        /// <summary>
        ///     Sets the matrix of the collider.
        /// </summary>
        /// <remarks>
        ///     Some colliders (wheel and terrain colliders) have a special collider matrix. This method is used to override the default matrix.
        /// </remarks>
        protected virtual void SetColliderMatrix()
        {
            m_LocalToWorldMatrix = transform.localToWorldMatrix;
        }
        /// <summary>
        ///     Determines whether or not the attached collider is valid (not destroyed or disabled).
        /// </summary>
        /// <returns>
        ///     True if the collider is valid; otherwise, false.
        /// </returns>
        protected abstract bool ColliderIsValid();
        /// <summary>
        ///     Determines whether or not any attached collider properties have been changed.
        /// </summary>
        /// <remarks>
        ///     The fluid collider is automatically set to dirty if its transform or base properties changes. 
        /// </remarks>
        /// <returns>
        ///     True if any attached collider properties have changed; otherwise, false.
        /// </returns>
        protected abstract bool ColliderHasChanged();
        /// <summary>
        ///     Voxelize the collider. This provides the actual entry point for collider generation.
        /// </summary>
        protected abstract void Voxelize();
        /// <summary>
        ///     Provides a method for obtaining a default base collider (when no base collider is selected).
        /// </summary>
        /// <remarks>
        ///      Base colliders should reside on the same GameObject as the fluid collider.
        /// </remarks>
        protected abstract void GetDefaultCollider();

        public override int GetActiveParticleCount()
        {
            return m_CollisionPoints.Count;
        }
        #endregion        
    }
}
