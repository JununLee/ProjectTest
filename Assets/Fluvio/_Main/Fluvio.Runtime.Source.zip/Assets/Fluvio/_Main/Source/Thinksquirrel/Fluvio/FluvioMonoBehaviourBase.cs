// FluvioMonoBehaviourBase.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine;

// ReSharper disable EmptyNamespace

//! This is the root namespace for all Thinksquirrel products.
namespace Thinksquirrel { }

//! This namespace contains all sample plugins.
namespace Thinksquirrel.Fluvio.SamplePlugins { }

//! This namespace contains all core Fluvio components.
namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     MonoBehavior base class for all Fluvio components.
    /// </summary>
    public abstract class FluvioMonoBehaviourBase : MonoBehaviour
    {
        #region Enabled test
        /// <summary>
        /// Returns true if the specified behavior is not destroyed or null, active, and enabled.
        /// </summary>
        /// <param name="b">The behavior to check.</param>
        /// <returns>True if the behavior is not destroyed or null, active within its hierarchy, and enabled. Otherwise; false.</returns>
        public static bool IsValid(Behaviour b)
        {
            #if UNITY_5_0_PLUS
            return b && b.gameObject && b.isActiveAndEnabled;
            #else
            return b && b.gameObject && b.enabled && b.gameObject.activeInHierarchy;
            #endif
        }
        /// <summary>
        /// Returns true if the specified component is not destroyed or null and active.
        /// </summary>
        /// <param name="c">The component to check.</param>
        /// <returns>True if the component is not destroyed or null and active within its hierarchy. Otherwise; false.</returns>
        public static bool IsValid(Component c)
        {
            return c && c.gameObject && c.gameObject.activeInHierarchy;
        }
        #endregion
        #region Awake, Destroy, Reset
        #if !UNITY_5_0_PLUS
        [NonSerialized] int m_UniqueID = int.MinValue;
        [NonSerialized] static int m_UniqueIDPtr = int.MinValue;
        [NonSerialized] static readonly HashSet<int> s_ActiveObjects = new HashSet<int>();
        [NonSerialized] static readonly object s_IdentifierLock = new object();
        #endif
        //! \cond PRIVATE
        [UsedImplicitly]
        protected virtual void OnEnable()
        {
            FluvioSettings.InitializeRuntimeHelper();
        }
        [UsedImplicitly]
        protected virtual void OnDisable() { }
        [UsedImplicitly]
        protected virtual void OnDestroy()
        {
            #if !UNITY_5_0_PLUS
            if (m_UniqueID != int.MinValue)
            {
                s_ActiveObjects.Remove(m_UniqueID);
            }
            #endif
        }
        [UsedImplicitly]
        protected virtual void Reset() { }
        //! \endcond

#if !UNITY_5_0_PLUS
        public static implicit operator bool (FluvioMonoBehaviourBase exists)
        {
            return !CompareBaseFluvioObjects(exists, null);
        }

        public static bool operator ==(FluvioMonoBehaviourBase x, FluvioMonoBehaviourBase y)
        {
            return CompareBaseFluvioObjects(x, y);
        }

        public static bool operator !=(FluvioMonoBehaviourBase x, FluvioMonoBehaviourBase y)
        {
            return !CompareBaseFluvioObjects(x, y);
        }
        public override bool Equals(object o)
        {
            return CompareBaseFluvioObjects(this, o as FluvioMonoBehaviourBase);
        }
        public override int GetHashCode()
        {
            
            if (m_UniqueID == int.MinValue)
            {
                lock (s_IdentifierLock)
                {
                    m_UniqueID = ++m_UniqueIDPtr;
                    s_ActiveObjects.Add(m_UniqueID);
                }
            }
            return m_UniqueID;
        }
    
        static bool CompareBaseFluvioObjects(FluvioMonoBehaviourBase lhs, FluvioMonoBehaviourBase rhs)
        {
            var lhsIsNull = ReferenceEquals(lhs, null);
            var rhsIsNull = ReferenceEquals(rhs, null);
            if (rhsIsNull && lhsIsNull) return true;
            if (rhsIsNull) return !s_ActiveObjects.Contains(lhs.GetHashCode());
            if (lhsIsNull) return !s_ActiveObjects.Contains(rhs.GetHashCode());
            return lhs.GetHashCode() == rhs.GetHashCode();
        }
#endif
        #endregion

        #region Cached objects        
#if !UNITY_5_0_PLUS
        //! \cond PRIVATE
        [SerializeField, HideInInspector] Transform m_CachedTransform;
        /// <summary>
        /// This property provides a cached version the component's transform for performance reasons.
        /// </summary>
        public new Transform transform
        {
            get
            {
                if (!m_CachedTransform)
                    m_CachedTransform = base.transform;
                
                return m_CachedTransform;
            }
        }
        //! \endcond
#endif
        #endregion

        #pragma warning disable 414
        [SerializeField, HideInInspector, UsedImplicitly] bool m_EditorFoldout = true;
        internal bool _editorFoldout { get { return m_EditorFoldout; } }
        #pragma warning restore 414

    }
}
