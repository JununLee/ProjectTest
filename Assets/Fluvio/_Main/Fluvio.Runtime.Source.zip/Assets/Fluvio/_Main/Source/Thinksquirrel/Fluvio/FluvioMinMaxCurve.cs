using System;
using Thinksquirrel.Fluvio.Plugins;
using UnityEngine;
using Keyframe = Thinksquirrel.Fluvio.Internal.Keyframe;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    /// Defines a min-max curve for fluid plugins.
    /// </summary>
    [Serializable]
    public class FluvioMinMaxCurve
    {
        [SerializeField] AnimationCurve m_MaxCurve;
        [SerializeField] AnimationCurve m_MinCurve;
        [SerializeField] float m_MinConstant;
        [SerializeField] float m_MaxConstant;
        [SerializeField] float m_Scalar = 1.0f;
        [SerializeField] FluvioMinMaxCurveState m_MinMaxState;
        [SerializeField, HideInInspector] bool m_IsSigned;
        
        /// <summary>
        /// Creates a new min-max curve.
        /// </summary>
        public FluvioMinMaxCurve()
        {
            m_MinCurve = new AnimationCurve();
            m_MaxCurve = new AnimationCurve();
            SetConstant(1.0f, 1.0f, FluvioMinMaxCurveState.Constant);
        }

        /// <summary>
        /// Returns true if the curve is signed (between -1 and 1).
        /// </summary>
        public bool isSigned
        {
            get { return m_IsSigned; }
            internal set { m_IsSigned = value; }
        }

        /// <summary>
        /// The maximum curve. Keyframe times must be between 0 and 1. Values must be between -1 and 1 for signed curves, or 0 and 1 for unsigned curves.
        /// </summary>
        public AnimationCurve maxCurve
        {
            get { return m_MaxCurve; }
            set
            {
                ValidateCurve(ref value, m_IsSigned);
                m_MaxCurve = value;
            }
        }

        /// <summary>
        /// The minimum curve. Keyframe times must be between 0 and 1. Values must be between -1 and 1 for signed curves, or 0 and 1 for unsigned curves.
        /// </summary>
        public AnimationCurve minCurve
        {
            get { return m_MinCurve; }
            set
            {
                ValidateCurve(ref value, m_IsSigned);
                m_MinCurve = value;
            }
        }

        /// <summary>
        /// The minimum constant value.
        /// </summary>
        public float minConstant
        {
            get { return m_MinConstant; }
            set { m_MinConstant = value; }
        }

        /// <summary>
        /// The maximum constant value.
        /// </summary>
        public float maxConstant
        {
            get { return m_MaxConstant; }
            set { m_MaxConstant = value; }
        }

        /// <summary>
        /// A scalar to multiply the curve's value by.
        /// </summary>
        public float scalar
        {
            get { return m_Scalar; }
            set { m_Scalar = value; }
        }

        /// <summary>
        /// The min-max state of the curve.
        /// </summary>
        public FluvioMinMaxCurveState minMaxState
        {
            get { return m_MinMaxState; }
            set { m_MinMaxState = value; }
        }

        /// <summary>
        /// Evaluate the min-max curve.
        /// </summary>
        /// <param name="seed">The random seed to use for curve evaluation.</param>
        /// <param name="time">The time to evaluate, between 0 and 1.</param>
        /// <returns>The evaluated min-max curve.</returns>
        public float Evaluate(uint seed, float time)
        {
            switch (minMaxState)
            {
                case FluvioMinMaxCurveState.Constant:
                    return m_MaxConstant;
                case FluvioMinMaxCurveState.Curve:
                    return m_Scalar * m_MaxCurve.Evaluate(time);
                case FluvioMinMaxCurveState.RandomBetweenTwoConstants:
                    return Mathf.Lerp(m_MinConstant, m_MaxConstant, FluidParticlePlugin.RandomFloat(seed));
                case FluvioMinMaxCurveState.RandomBetweenTwoCurves:
                    return m_Scalar * Mathf.Lerp(m_MinCurve.Evaluate(time), m_MaxCurve.Evaluate(time), FluidParticlePlugin.RandomFloat(seed));
            }

            return 0;
        }

        internal void SetConstant(float min, float max, FluvioMinMaxCurveState state)
        {
            var minVal = Mathf.InverseLerp(0.0f, max, min);
            m_MinCurve = AnimationCurve.Linear(0.0f, minVal, 1.0f, minVal);
            m_MaxCurve = AnimationCurve.Linear(0.0f, 1.0f, 1.0f, 1.0f);
            m_MinConstant = min;
            m_MaxConstant = max;
            m_Scalar = max;
            m_MinMaxState = state;
        }

        static void ValidateCurve(ref AnimationCurve curve, bool isSigned)
        {
            if (curve == null)
            {
                var val = isSigned ? 0.0f : 1.0f;
                curve = AnimationCurve.Linear(0.0f, val, 1.0f, val);
                return;
            }

            var min = isSigned ? -1.0f : 0.0f;
            const float max = 1.0f;

            if (curve.length == 1)
            {
                var newKeys = new UnityEngine.Keyframe[2];
                var oldKeys = curve.keys;

                var key = oldKeys[0];
                key.time = 0.0f;
                key.value = Mathf.Clamp(key.value, min, max);

                newKeys[0] = key;
                
                key.time = 1.0f;
                newKeys[1] = key;

                curve.keys = newKeys;
            }

            var keys = curve.keys;

            for (var i = 0; i < keys.Length; ++i)
            {
                var key = keys[i];

                key.time = Mathf.Clamp01(key.time);
                key.value = Mathf.Clamp(key.value, min, max);
            }

            curve.preWrapMode = WrapMode.ClampForever;
            curve.postWrapMode = WrapMode.ClampForever;
            curve.keys = keys;
        }

        static Keyframe[] s_KeyCache = new Keyframe[2];
        static Keyframe[] s_KeyCache2 = new Keyframe[2];

        internal void GetCachedCurvesForConstants(float k, float k2, out Keyframe[] keyframes, out Keyframe[] keyframes2)
        {
            s_KeyCache[0] = new Keyframe(0.0f, k);
            s_KeyCache[1] = new Keyframe(1.0f, k);

            s_KeyCache2[0] = new Keyframe(0.0f, k2);
            s_KeyCache2[1] = new Keyframe(1.0f, k2);

            keyframes = s_KeyCache;
            keyframes2 = s_KeyCache2;
        }
    }
}
