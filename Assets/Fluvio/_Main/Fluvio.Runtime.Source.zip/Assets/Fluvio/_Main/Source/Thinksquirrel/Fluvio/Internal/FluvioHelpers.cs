// FluvioHelpers.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Collections.Generic;
using Thinksquirrel.Fluvio.Plugins;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal
{
    static class FluvioHelpers
    {
        #region Public API
        public static bool FindAttachedFluid(FluidBase currentFluid, FluidPlugin plugin)
        {
            if (plugin == null)
                return false;

            if (currentFluid)
            {
                // We set the fluid again to populate any lists
                plugin.fluid = currentFluid;
                return true;
            }

            var f = plugin.GetComponent<FluidBase>();
            
            if (f)
            {
                plugin.fluid = f;
            }
            else
            {
                var t = plugin.transform;
                f = GetComponentUpwards<FluidBase>(t);

                if (f)
                {
                    plugin.fluid = f;
                }
                else
                {
                    var fluids = FluidBase.GetAllFluids();

                    foreach(var fluid in fluids)
                    {
                        if (!fluid) continue;
                        
                        // Default to parents when we fallback to GetAllFluids
                        plugin.fluid = fluid.parentFluid ? fluid.parentFluid : fluid;
                        break;
                    }
                }
            }

            if (plugin.fluid) return true;
            
            FluvioDebug.LogError("No associated fluid found. Have you created a fluid in the scene?", plugin);
            return false;
        }
        public static T GetComponentUpwards<T>(Component component) where T : Component
        {
            var t = component.transform;
            while (t)
            {
                var result = t.GetComponent<T>();

                if (result)
                    return result;

                t = t.transform.parent;
            }

            return null;
        }
        public static T[] GetComponentsUpwards<T>(Component component) where T : Component
        {
            var componentList = new List<T>();

            var t = component.transform;
            while (t)
            {
                var result = t.GetComponent<T>();

                if (result)
                    componentList.Add(result);

                t = t.transform.parent;
            }

            return componentList.ToArray();
        }
        public static FluidBase FindSubFluidParent(FluidBase fluid)
        {
            var fluidGroup = fluid.GetFluidGroup();

            if (fluidGroup)
            {
                return fluidGroup.parentFluid == fluid ? null : fluidGroup.parentFluid;
            }
            var current = fluid.transform;
            FluidBase candidate = null;

            while (current != null)
            {
                var f = current.GetComponent<FluidBase>();
                
                if (f && f != fluid && (f.GetType() == fluid.GetType() || fluid is FluidColliderBase) && !(f is FluidColliderBase))
                {
                    if (f.parentFluid)
                        return f.parentFluid;

                    candidate = f;
                }
            
                current = current.parent;
            }

            return candidate;
        }
        public static TOutput[] ConvertAll<TInput, TOutput>(TInput[] array, Converter<TInput, TOutput> converter)
        {
            if (array == null)
                throw new ArgumentNullException("array");
            if (converter == null)
                throw new ArgumentNullException("converter");
            TOutput[] outputArray = new TOutput[array.Length];
            for (int index = 0; index < array.Length; ++index)
                outputArray[index] = converter(array[index]);
            return outputArray;
        }
        #endregion
    }
}
