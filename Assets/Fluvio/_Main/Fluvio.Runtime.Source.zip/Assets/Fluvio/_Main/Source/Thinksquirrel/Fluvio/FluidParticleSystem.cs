// FluidParticleSystem.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
#if UNITY_5_0_PLUS && !UNITY_5_0 && !UNITY_5_1 && !UNITY_5_2
#define UNITY_5_3_PLUS
#endif
using System;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Internal.Solvers;
using UnityEngine;
using float4 = UnityEngine.Vector4;
using mat4x4 = UnityEngine.Matrix4x4;

#if !UNITY_5_0_PLUS
using ParticleCollisionEvent = UnityEngine.ParticleSystem.CollisionEvent;
#endif

#pragma warning disable 169
#pragma warning disable 649
namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Represents a fluid that integrates with the Shuriken particle system.
    /// </summary>
    /// <remarks>
    ///     Fluids are the main component for fluid simulation with Fluvio.
    /// </remarks>
    [AddComponentMenu("Fluvio/Fluid Particle System", -10)]
    [ExecuteInEditMode]
    public sealed class FluidParticleSystem : Fluid
    {
        class ParticleSystemData
        {
            // ReSharper disable InconsistentNaming
            public int _FluidID;
            public int _ParticleCount;
            public float4 _Dimensions;
            public mat4x4 _ParticleToWorldMatrix;
            public mat4x4 _WorldToParticleMatrix;
            
            public ParticleSystem.Particle[] _UnityParticles = new ParticleSystem.Particle[2];
            public float4[] _VorticityTurbulence = new float4[2];

            public ParticleCollisionEvent[] _CollisionEvents;
            // ReSharper restore InconsistentNaming
        }

        #region Serialized Fields
        // ReSharper disable once FieldCanBeMadeReadOnly.Local
        // ReSharper disable once ConvertToConstant.Local
        [SerializeField] float m_CollisionForceModifier = 1.0f;        
        [SerializeField, HideInInspector] ParticleSystem m_ParticleSystem;
        [SerializeField, HideInInspector] bool m_Prewarm;
#if !UNITY_5_3_PLUS
        [SerializeField, HideInInspector] ParticleSystem[] m_SubEmitters = new ParticleSystem[6];
        [SerializeField, HideInInspector] float m_SortingFudge;
#endif
        #endregion

        #region Instance Fields
        [NonSerialized] float m_StartDelay;
        [NonSerialized] float m_StartDelayTime;
        [NonSerialized] float m_StartDelayLastTime;
        [NonSerialized] int m_AppliedPrewarm;
        [NonSerialized] readonly ParticleSystemData m_ParticleSystemData = new ParticleSystemData();
        [NonSerialized] float m_EditorPlaybackSpeed = 1.0f;
#if !UNITY_5_3_PLUS
        [NonSerialized, UsedImplicitly] bool m_IsSubEmitterEditor;
#endif
        [NonSerialized] bool m_LastHWSolverState;
        [NonSerialized] int m_OverheadTimer;
        [NonSerialized] bool m_RewindParticles;
        [NonSerialized] bool m_ShouldGetSetParticles;
        [NonSerialized] int m_StaticFrameCount;
        [NonSerialized] FluvioComputeShader m_ComputeShader;
        [NonSerialized] int m_ParticleSystemToFluidKernel;
        [NonSerialized] int m_FluidToParticleSystemKernel;
        [NonSerialized] int m_FluidToParticleSystemFastKernel;
        [NonSerialized] bool m_IsWorldSpace;
#endregion

#region Public API
        /// <summary>
        ///     Gets the particle system associated with this fluid.
        /// </summary>
        /// <returns>
        ///     The particle system associated with this fluid.
        /// </returns>
        public ParticleSystem GetParticleSystem()
        {
            if (!m_ParticleSystem || m_ParticleSystem.gameObject != gameObject)
            {
                if (m_ParticleSystem) m_ParticleSystem.hideFlags &= ~HideFlags.HideInInspector;
                m_ParticleSystem = gameObject.GetComponent<ParticleSystem>();
            }

            if (!m_ParticleSystem)
                m_ParticleSystem = gameObject.AddComponent<ParticleSystem>();

            m_ParticleSystem.hideFlags |= HideFlags.HideInInspector;
            
            return m_ParticleSystem;
        }
        /// <summary>
        ///     If true, matrix multiplication is currently hardware accelerated.
        /// </summary>
        /// <returns>True if matrix multiplication is currently hardware accelerated; otherwise, false.</returns>
        /// <remarks>
        ///     Matrix multiplication cannot be hardware accelerated when using CPU-only plugins.
        /// </remarks>
        public bool IsUsingAcceleratedIntegrationPath()
        {
            return IsHardwareAccelerated() && _solver != null && _solver.canUseFastIntegrationPath;
        }

        /// <summary>
        ///     Gets the fluid particle system's world to particle matrix.
        /// </summary>
        /// <returns>The current world to particle matrix.</returns>
        /// <remarks>
        ///     This value is cached at the start of a solver frame.
        /// </remarks>
        public Matrix4x4 GetWorldToParticleMatrix()
        {
            return m_ParticleSystemData._WorldToParticleMatrix;
        }
        /// <summary>
        ///     gGets the fluid particle system's particle to world matrix.
        /// </summary>
        /// <returns>The current particle to world matrix.</returns>
        /// <remarks>
        ///     This value is cached at the start of a solver frame.
        /// </remarks>
        public Matrix4x4 GetParticleToWorldMatrix()
        {
            return m_ParticleSystemData._ParticleToWorldMatrix;
        }
#endregion

#region Unity Methods
        //!\cond PRIVATE
        protected override void OnDisable()
        {
            base.OnDisable();

            if (!m_ParticleSystem) return;

            m_ParticleSystem.Clear(true);
            m_ParticleSystem.startDelay = m_StartDelay;
            m_StartDelayTime = 0.0f;
            m_StartDelayLastTime = 0.0f;
            m_AppliedPrewarm = 0;
        }
        protected override void OnEnable()
        {
            base.OnEnable();

            GetParticleSystem();
            m_RewindParticles = false;
            m_ShouldGetSetParticles = true;
            m_LastHWSolverState = IsHardwareAccelerated();
            m_StaticFrameCount = 0;
            m_StartDelayTime = 0.0f;
            m_StartDelayLastTime = 0.0f;
            m_AppliedPrewarm = 0;

            m_ComputeShader = null;

            if (!m_ComputeShader)
            {
                m_ComputeShader = FluvioComputeShader.Find("ComputeShaders/FluidParticleSystem");
            }

            if (m_ComputeShader)
            {
                m_ParticleSystemToFluidKernel = m_ComputeShader.FindKernel("ParticleSystemToFluid");
                m_FluidToParticleSystemKernel = m_ComputeShader.FindKernel("FluidToParticleSystem");
                m_FluidToParticleSystemFastKernel = m_ComputeShader.FindKernel("FluidToParticleSystemFast");
            }
        }
        [UsedImplicitly]
        protected override void OnDestroy()
        {
            base.OnDestroy();

            if (!m_ParticleSystem) return;

            m_ParticleSystem.hideFlags &= ~HideFlags.HideInInspector;
        }
        //!\endcond
        [UsedImplicitly]
        void Awake()
        {
            if (m_ParticleSystem)
            {
                m_ParticleSystem.playbackSpeed = 1.0f;
            }

            for (int i = 0; i < 6; ++i)
            {
                ParticleSystem subEmitter = GetSubEmitter(i);

                if (subEmitter && !subEmitter.GetComponent<FluidParticleSystem>())
                    subEmitter.playbackSpeed = 1.0f;
            }
        }
        [UsedImplicitly]
        void LateUpdate()
        {
            if (!Application.isPlaying)
                return;

            DoLateUpdate();
        }        
        [UsedImplicitly]
        void OnBecameInvisible()
        {
            // TODO: SubEmitters
            SetVisibility(false);
        }
        [UsedImplicitly]
        void OnBecameVisible()
        {
            // TODO: SubEmitters
            SetVisibility(true);
        }
        [UsedImplicitly]
        void Update()
        {
            if (!Application.isPlaying)
                return;

            DoUpdate();
        }
        [UsedImplicitly]
        void OnParticleCollision(GameObject other)
        {
            // ReSharper disable once CompareOfFloatsByEqualityOperator
            if (!m_ParticleSystem || m_CollisionForceModifier == 0.0f)
                return;

            var rb = other.GetComponentInParent<Rigidbody>();
            var rb2D = rb ? null : other.GetComponentInParent<Rigidbody2D>();
            if (!rb && !rb2D) return;

            var fc = other.GetComponent<FluidColliderBase>();

            if (fc && fc.fluidType != FluidType.Dynamic) return;

#if UNITY_5_0_PLUS
            var safeLength = m_ParticleSystem.GetSafeCollisionEventSize();            
#else
            var safeLength = m_ParticleSystem.safeCollisionEventSize;
#endif
            if (m_ParticleSystemData._CollisionEvents == null || m_ParticleSystemData._CollisionEvents.Length < safeLength)
                m_ParticleSystemData._CollisionEvents = new ParticleCollisionEvent[safeLength];

            var collisionEvents = m_ParticleSystemData._CollisionEvents;

            var numCollisionEvents = m_ParticleSystem.GetCollisionEvents(other, collisionEvents);
            
            for(var i = 0; i < numCollisionEvents; ++i)
            {
                var pos = collisionEvents[i].intersection;
                var force = collisionEvents[i].velocity * m_CollisionForceModifier;
                if (rb) rb.AddForceAtPosition(force, pos);
                if (rb2D) rb2D.AddForceAtPosition(force, pos);
            }
        }
#endregion

#region Abstract, Virtual, and Override
        public override int GetActiveParticleCount()
        {
            ParticleSystem system = GetParticleSystem();
            return system ? system.particleCount : base.GetActiveParticleCount();
        }
        //! \cond PRIVATE
        protected internal override bool IsWorldSpace()
        {
            return m_IsWorldSpace;
        }
        protected internal override Matrix4x4 GetLocalToWorldMatrix()
        {
            return m_ParticleSystemData._ParticleToWorldMatrix;
        }
        protected internal override int SetMaxParticles(int value)
        {
            var max = base.SetMaxParticles(value);
            m_ParticleSystem.maxParticles = max;
            return max;
        }
        protected internal override float GetTimeScale()
        {
            return Mathf.Max(Time.timeScale * (Application.isPlaying ? m_ParticleSystem.playbackSpeed : m_EditorPlaybackSpeed), 0);
        }
        protected internal override void SimulateParticles(float dt)
        {
            if (!m_ParticleSystem)
                return;

            m_ParticleSystem.Simulate(dt, false, false);
            for (int i = 0; i < 6; ++i)
            {
                ParticleSystem subEmitter = GetSubEmitter(i);

                if (!subEmitter || subEmitter.GetComponent<FluidParticleSystem>()) continue;

                subEmitter.Simulate(dt, false, false);
            }
        }
        protected internal override void ProcessSolverFrame(float dt)
        {
            // -------------- TIMER START
            Timers.StartTimer(m_OverheadTimer);

            // --------------
            // Pre solve
            // --------------
            for (var i = -1; i < subFluidCount; ++i)
            {
                var f = i < 0 ? this : GetSubFluid(i) as FluidParticleSystem;
                if (!f) continue;
                f.SetMaxParticles(f.m_ParticleSystem.maxParticles);
            }
            PreSolve(dt);
            for (var i = -1; i < subFluidCount; ++i)
            {
                var f = i < 0 ? this : GetSubFluid(i) as FluidParticleSystem;
                if (!f) continue;

                // Resize arrays
                var max = f.GetParticleCount();
                if (f.m_ParticleSystemData._UnityParticles == null || f.m_ParticleSystemData._UnityParticles.Length != max)
                {
                    Array.Resize(ref f.m_ParticleSystemData._UnityParticles, max);
                    Array.Resize(ref f.m_ParticleSystemData._VorticityTurbulence, max);
                }
            }

            // --------------
            // Simulate particles
            // --------------
            SimulateParticles(dt);
            for (int i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i) as FluidParticleSystem;

                if (subFluid)
                    subFluid.SimulateParticles(dt);
            }
            
            // --------------
            // Set fluid ID (including sub-fluids)
            // --------------  
            m_ParticleSystemData._FluidID = _solver.GetFluidID(this);

            for (int i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i) as FluidParticleSystem;

                if (subFluid)
                    subFluid.m_ParticleSystemData._FluidID = _solver.GetFluidID(subFluid);
            }

            // --------------
            // Get particles (including sub-fluids)
            // --------------           
            if (m_ShouldGetSetParticles) GetParticles();
            for (int i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i) as FluidParticleSystem;

                if (subFluid && subFluid.m_ShouldGetSetParticles)
                    subFluid.GetParticles();
            }

            // --------------
            // Convert to Fluvio format
            // --------------           
            UnityToFluvioParticles();

            // --------------
            // Colliders
            // --------------
            SyncColliders();

            var accelerated = IsHardwareAccelerated();

            if (accelerated && _solver.canUseFastIntegrationPath && m_ComputeShader && m_ParticleSystemToFluidKernel >= 0)
            {
                var fluvio = _solver.solverDataInternal;

                // Set buffers early
                fluvio.UploadBuffers();

                // Skip if the fluid is in world space                
                if (!m_IsWorldSpace && m_ShouldGetSetParticles)
                {
                    DispatchComputeShader(m_ParticleSystemToFluidKernel);
                }

                for (int i = 0; i < subFluidCount; ++i)
                {
                    var subFluid = GetSubFluid(i) as FluidParticleSystem;

                    // Skip if the fluid is in world space
                    if (!subFluid || subFluid.m_IsWorldSpace) continue;

                    if (subFluid.m_ShouldGetSetParticles)
                    {
                        subFluid.DispatchComputeShader(m_ParticleSystemToFluidKernel);
                    }
                }
            }
            else
            {
                _solver.canUseFastIntegrationPath = false;

                _solver.ForEachParticle((f, i) =>
                {
                    var fluid = f as FluidParticleSystem;

                    // Skip if the fluid is in world space
                    if (!fluid || fluid.m_IsWorldSpace) return;

                    if (fluid.m_ShouldGetSetParticles)
                        fluid.ParticleSystemToFluid(fluid._solver.solverDataInternal, i);
                }, false);
            }

            // -------------- TIMER STOP
            Timers.StopTimer(m_OverheadTimer);

            // --------------
            // Solver: simulate fluid to t+1, update plugins
            // --------------
            Solve();

            // -------------- TIMER START
            Timers.StartTimer(m_OverheadTimer);

            // --------------
            // Set particles
            // --------------
            if (accelerated && _solver.canUseFastIntegrationPath && m_ComputeShader && m_FluidToParticleSystemKernel >= 0)
            {
                var kernelIndex = m_IsWorldSpace ? m_FluidToParticleSystemFastKernel : m_FluidToParticleSystemKernel;

                DispatchComputeShader(kernelIndex);

                for (int i = 0; i < subFluidCount; ++i)
                {
                    var subFluid = GetSubFluid(i) as FluidParticleSystem;
                    if (!subFluid) continue;

                    kernelIndex = subFluid.m_IsWorldSpace ? m_FluidToParticleSystemFastKernel : m_FluidToParticleSystemKernel;

                    subFluid.DispatchComputeShader(kernelIndex);
                }
            }
            else
            {
                _solver.canUseFastIntegrationPath = false;
                _solver.ForEachParticle(
                    (f, i) =>
                    {
                        var fluid = f as FluidParticleSystem;
                        if (!fluid) return;

                        if (fluid.m_IsWorldSpace)
                            fluid.FluidToParticleSystemFast(f._solver.solverDataInternal, i);
                        else
                            fluid.FluidToParticleSystem(f._solver.solverDataInternal, i);
                    });
            }

            // --------------
            // Convert to Unity format
            // --------------           
            FluvioToUnityParticles();

            if (m_ShouldGetSetParticles) SetParticles();
            for (int i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i) as FluidParticleSystem;

                if (subFluid && subFluid.m_ShouldGetSetParticles)
                    subFluid.SetParticles();
            }


            // -------------
            // Static fluid optimization
            // --------------
            // Note - this optimization is only active:
            //  * When in play mode or in a build
            //  * When simulating in world space
            if (Application.isPlaying)
            {
                if (m_LastHWSolverState != IsHardwareAccelerated())
                {
                    m_ShouldGetSetParticles = true;
                    m_StaticFrameCount = 0;
                    m_LastHWSolverState = IsHardwareAccelerated();
                }
                else
                {
                    if (fluidType == FluidType.Static && m_StaticFrameCount++ > 1)
                    {
                        m_ShouldGetSetParticles = !m_IsWorldSpace;
                    }
                    else
                    {
                        m_ShouldGetSetParticles = true;
                        m_StaticFrameCount = 0;
                    }

                    for (var i = 0; i < subFluidCount; ++i)
                    {
                        var subFluid = GetSubFluid(i) as FluidParticleSystem;
                        if (!subFluid) continue;

                        if (subFluid.fluidType == FluidType.Static && subFluid.m_StaticFrameCount++ > 1)
                        {
                            subFluid.m_ShouldGetSetParticles = !subFluid.m_IsWorldSpace;
                        }
                        else
                        {
                            subFluid.m_ShouldGetSetParticles = true;
                            subFluid.m_StaticFrameCount = 0;
                        }
                    }
                }
            }

            // -------------- TIMER STOP
            Timers.StopTimer(m_OverheadTimer);

            // --------------
            // Post solve
            // --------------
            PostSolve();
        }
        //! \endcond
#endregion

        internal void DoLateUpdate()
        {
            // Timer
            m_OverheadTimer = Timers.CreateTimer(parentFluid ? parentFluid : this, "Overhead");
            Timers.StartTimer(m_OverheadTimer);

            GetParticleSystem();

            // Check for particle system
            if (!m_ParticleSystem)
            {
                Timers.StopTimer(m_OverheadTimer);
                return;
            }

            // Initialize fluid (assign sub-fluids)
            Initialize();

            // Get cached dimensions
            var dim = dimensions;
            m_ParticleSystemData._Dimensions = new float4(dim == SimulationDimensions.Fluid2D ? 0.0f : 1.0f, dim == SimulationDimensions.Fluid2D ? _position.z : 0.0f, 0.0f, 0.0f);
            
            // Set particle system properties
            SetGravity(Physics.gravity*m_ParticleSystem.gravityModifier);
            
            // Don't update if we aren't playing
            if (!FluidIsPlaying())
            {
                if (m_StartDelay > 0.0f) m_ParticleSystem.startDelay = m_StartDelay;
                m_StartDelay = 0.0f;
                m_StartDelayTime = 0.0f;
                m_StartDelayLastTime = Time.realtimeSinceStartup;
                m_AppliedPrewarm = 0;
                Timers.StopTimer(m_OverheadTimer);
                return;
            }

            // Start delay
            if (m_ParticleSystem.startDelay > 0.0f)
            {
                m_StartDelay = m_ParticleSystem.startDelay;
                m_ParticleSystem.startDelay = 0.0f;
            }

            if (!m_Prewarm && m_StartDelayTime < m_StartDelay)
            {
                var dt = (Time.realtimeSinceStartup - m_StartDelayLastTime) * GetTimeScale();
                m_StartDelayTime += dt;
                m_StartDelayLastTime = Time.realtimeSinceStartup;
                return;
            }

            // Update parent fluid only
            if (parentFluid)
            {
                Timers.StopTimer(m_OverheadTimer);
                return;
            }

            var doPrewarm = m_Prewarm && m_AppliedPrewarm == 1;
            if (FluidIsVisible() || doPrewarm)
            {
                ProcessFluidFrame(doPrewarm ? m_ParticleSystem.duration : 0.0f);
                ++m_AppliedPrewarm;
            }            

            // Play and set rewind flag
            PlayAndSetRewindFlag();
            for (var i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i) as FluidParticleSystem;

                if (subFluid)
                    subFluid.PlayAndSetRewindFlag();
            }
            Timers.StopTimer(m_OverheadTimer);
        }
        internal void DoUpdate()
        {
            // Timer
            m_OverheadTimer = Timers.CreateTimer(parentFluid ? parentFluid : this, "Overhead");
            Timers.StartTimer(m_OverheadTimer);

            GetParticleSystem();

            // Check for particle system
            if (!m_ParticleSystem)
            {
                Timers.StopTimer(m_OverheadTimer);
                return;
            }
            
            // Rewind particles
            RewindParticles();
            for (var i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i) as FluidParticleSystem;

                if (subFluid)
                    subFluid.RewindParticles();
            }

            Timers.StopTimer(m_OverheadTimer);
        }
        internal float GetSortingFudge()
        {
#if UNITY_5_3_PLUS
            var rend = GetComponent<ParticleSystemRenderer>();
            return rend ? rend.sortingFudge : 0;
#else
            return m_SortingFudge;
#endif
        }
        internal ParticleSystem GetSubEmitter(int index)
        {
#if UNITY_5_3_PLUS
            var system = GetParticleSystem();
            if (!system) return null;
            var subEmitters = system.subEmitters;
            if (!subEmitters.enabled) return null;

            switch (index)
            {
                case 0:
                    return subEmitters.birth0;
                case 1:
                    return subEmitters.birth1;
                case 2:
                    return subEmitters.collision0;
                case 3:
                    return subEmitters.collision1;
                case 4:
                    return subEmitters.death0;
                case 5:
                    return subEmitters.death1;
                default:
                    return null;
            }
#else
            return m_SubEmitters[index];
#endif
        }
        internal void SetEditorPlaybackSpeed(float speed)
        {
            m_EditorPlaybackSpeed = speed;
        }
        void FluvioToUnityParticles()
        {
            var fluvio = _solver.solverDataInternal;

            _solver.ForEachParticle((f, particleIndex) =>
            {
                var fluid = f as FluidParticleSystem;

                if (!fluid) return;

                var fluvio_ParticleSystem = fluid.m_ParticleSystemData;
                
                var id = fluvio._Particle[particleIndex].id.y;

                // Set Unity particle
                var pos = fluvio._Particle[particleIndex].position;
                if (!float.IsNaN(pos.x) && !float.IsInfinity(pos.x) && Math.Abs(pos.x) < 1.0f/Vector3.kEpsilon &&
                    !float.IsNaN(pos.y) && !float.IsInfinity(pos.y) && Math.Abs(pos.y) < 1.0f/Vector3.kEpsilon &&
                    !float.IsNaN(pos.z) && !float.IsInfinity(pos.z) && Math.Abs(pos.z) < 1.0f/Vector3.kEpsilon)
                {
                    fluvio_ParticleSystem._UnityParticles[id].position = pos;
                }
                var vel = fluvio._Particle[particleIndex].velocity;
                if (!float.IsNaN(vel.x) && !float.IsInfinity(vel.x) && Math.Abs(vel.x) < 1.0f/Vector3.kEpsilon &&
                    !float.IsNaN(vel.y) && !float.IsInfinity(vel.y) && Math.Abs(vel.y) < 1.0f/Vector3.kEpsilon &&
                    !float.IsNaN(vel.z) && !float.IsInfinity(vel.z) && Math.Abs(vel.z) < 1.0f/Vector3.kEpsilon)
                {
                    fluvio_ParticleSystem._UnityParticles[id].velocity = vel;
                }
#if UNITY_5_3_PLUS
                fluvio_ParticleSystem._UnityParticles[id].startSize = Math.Max(vel.w, Vector3.kEpsilon);
                fluvio_ParticleSystem._UnityParticles[id].startColor = (Color)fluvio._Particle[particleIndex].color;
#else
                fluvio_ParticleSystem._UnityParticles[id].size = Mathf.Max(vel.w, 0.0f);
                fluvio_ParticleSystem._UnityParticles[id].color = (Color)fluvio._Particle[particleIndex].color;
#endif

#if UNITY_5_3_PLUS
                Vector3 normal = fluvio._Particle[particleIndex].normal;
                var normalLen = fluvio._Particle[particleIndex].normal.w;
                var sqrMag = normal.sqrMagnitude;

                if (sqrMag > 0 && normalLen > 0)
                {
                    if (dimensions == SimulationDimensions.Fluid3D || (normalLen > Mathf.PI && normalLen < Mathf.PI*2.0f))
                    {
                        fluvio_ParticleSystem._UnityParticles[id].rotation3D = Quaternion.LookRotation(normal).eulerAngles;
                    }
                    else if (dimensions == SimulationDimensions.Fluid2D)
                    {
                        fluvio_ParticleSystem._UnityParticles[id].rotation3D = Vector3.zero;
                    }
                }
#endif

                fluvio_ParticleSystem._UnityParticles[id].lifetime = Mathf.Clamp(fluvio._Particle[particleIndex].lifetime.x, 0.0f, 1.0f/FluvioSettings.kEpsilon);
                fluvio_ParticleSystem._UnityParticles[id].startLifetime = Mathf.Clamp(fluvio._Particle[particleIndex].lifetime.y, 0.0f, 1.0f/FluvioSettings.kEpsilon);
                fluvio_ParticleSystem._UnityParticles[id].randomSeed = unchecked((uint)fluvio._Particle[particleIndex].id.z);
                        
                // Pass through vorticity and turbulence
                fluvio_ParticleSystem._VorticityTurbulence[id] = fluvio._Particle[particleIndex].vorticityTurbulence;                
            }, true, _solver.canUseFastIntegrationPath);
        }
        void UnityToFluvioParticles()
        {
            var fluvio = _solver.solverDataInternal;

            _solver.ForEachParticle((f, particleIndex) =>
            {
                var fluid = f as FluidParticleSystem;

                if (!fluid) return;

                var fluvio_ParticleSystem = fluid.m_ParticleSystemData;

                var id = fluvio._Particle[particleIndex].id.y;

                // Clear particles past particle count
                if (id >= fluvio_ParticleSystem._ParticleCount)
                {
                    fluvio._Particle[particleIndex].lifetime.x = 0.0f;
                    return;
                }

                // Set Fluvio particle
                fluvio._Particle[particleIndex].position = fluvio_ParticleSystem._UnityParticles[id].position;

                float4 vel = fluvio_ParticleSystem._UnityParticles[id].velocity;

#if UNITY_5_3_PLUS
                fluvio._Particle[particleIndex].color = (Color) fluvio_ParticleSystem._UnityParticles[id].startColor;
                vel.w = fluvio_ParticleSystem._UnityParticles[id].startSize;
#else
                fluvio._Particle[particleIndex].color = (Color)fluvio_ParticleSystem._UnityParticles[id].color;
                vel.w = fluvio_ParticleSystem._UnityParticles[id].size;
#endif

                fluvio._Particle[particleIndex].velocity = vel;
                float lifetime = fluvio_ParticleSystem._UnityParticles[id].lifetime;
                float startLifetime = fluvio_ParticleSystem._UnityParticles[id].startLifetime;
                fluvio._Particle[particleIndex].lifetime.x = lifetime;
                fluvio._Particle[particleIndex].lifetime.y = startLifetime;
                fluvio._Particle[particleIndex].id.z = unchecked((int)fluvio_ParticleSystem._UnityParticles[id].randomSeed);
                
                // Assign turbulence and vorticity
                if (Mathf.Abs(startLifetime - lifetime) < fluvio._Time.x * 2.0f)
                {
                    fluvio._Particle[particleIndex].vorticityTurbulence = default(float4);
                }
                else
                {
                    fluvio._Particle[particleIndex].vorticityTurbulence = fluvio_ParticleSystem._VorticityTurbulence[id];
                }
            }, false, _solver.canUseFastIntegrationPath);
        }        
        void GetParticles()
        {
            if (!m_ParticleSystem)
                return;

            m_IsWorldSpace = m_ParticleSystem.simulationSpace == ParticleSystemSimulationSpace.World;

            // Get particle to world matrix
            var particleToWorldMatrix = Matrix4x4.identity;

            if (!m_IsWorldSpace)
            {
#if UNITY_5_3_PLUS
                switch (m_ParticleSystem.scalingMode)
                {
                    case ParticleSystemScalingMode.Hierarchy:
                        particleToWorldMatrix = m_ParticleSystem.transform.localToWorldMatrix;
                        break;
                    case ParticleSystemScalingMode.Local:
                        particleToWorldMatrix = Matrix4x4.TRS(m_ParticleSystem.transform.position, m_ParticleSystem.transform.rotation, m_ParticleSystem.transform.localScale);
                        break;
                    case ParticleSystemScalingMode.Shape:
#endif
                        particleToWorldMatrix = Matrix4x4.TRS(m_ParticleSystem.transform.position, m_ParticleSystem.transform.rotation, Vector3.one);
#if UNITY_5_3_PLUS
                        break;
                }
#endif
            }

            m_ParticleSystemData._ParticleToWorldMatrix = particleToWorldMatrix;

            // Get world to particle matrix
            m_ParticleSystemData._WorldToParticleMatrix = m_IsWorldSpace ? Matrix4x4.identity : m_ParticleSystemData._ParticleToWorldMatrix.inverse;

#if !UNITY_5_3_PLUS
            if (m_IsSubEmitterEditor)
                return;
#endif

            // Get particles
            m_ParticleSystemData._ParticleCount = m_ParticleSystem.GetParticles(m_ParticleSystemData._UnityParticles);
        }
        bool FluidIsPlaying()
        {
            return m_RewindParticles || !(!m_ParticleSystem.isPlaying || m_ParticleSystem.isPaused || m_ParticleSystem.isStopped);
        }
        void PlayAndSetRewindFlag()
        {
            GetParticleSystem();

            // Check for particle system
            if (!m_ParticleSystem)
                return;

            if (!Application.isPlaying) m_ParticleSystem.playbackSpeed = 0.0f;
            m_ParticleSystem.Play(false);

            for (var i = 0; i < 6; ++i)
            {
                var subEmitter = GetSubEmitter(i);

                if (!subEmitter || subEmitter.GetComponent<FluidParticleSystem>()) continue;

                if (!Application.isPlaying) subEmitter.playbackSpeed = 0.0f;
                subEmitter.Play(false);
            }
            m_RewindParticles = true;
        }
        void RewindParticles()
        {
            if (!m_ParticleSystem)
            {
                m_RewindParticles = false;
                return;
            }

            if (!m_ParticleSystem.isPlaying || m_ParticleSystem.isPaused || m_ParticleSystem.isStopped)
            {
                m_RewindParticles = false;
                return;
            }

            if (!m_RewindParticles) return;

            if (!Application.isPlaying) m_ParticleSystem.playbackSpeed = m_EditorPlaybackSpeed;
            m_ParticleSystem.Pause(false);
            
            for (var i = 0; i < 6; ++i)
            {
                var subEmitter = GetSubEmitter(i);

                if (!subEmitter || subEmitter.GetComponent<FluidParticleSystem>()) continue;

                if (!Application.isPlaying) subEmitter.playbackSpeed = m_EditorPlaybackSpeed;

                subEmitter.Pause(false);
            }
        }
        void SetParticles()
        {

#if !UNITY_5_3_PLUS
            if (m_IsSubEmitterEditor)
                return;
#endif

            if (m_ParticleSystem)
                m_ParticleSystem.SetParticles(m_ParticleSystemData._UnityParticles, m_ParticleSystemData._ParticleCount);
        }
        void ParticleSystemToFluid(SolverDataInternal fluvio, int particleIndex)
        {
            if (fluvio._Particle[particleIndex].lifetime.x <= 0) return;

            // ReSharper disable once RedundantCast
            var fluvio_ParticleSystem = m_ParticleSystemData;
            
            // Get particle ID
            int id = fluvio._Particle[particleIndex].id.y;

            // Skip despawned particles
            if (id >= fluvio_ParticleSystem._ParticleCount)
                return;

            // Get local position and velocity
            float4 position = fluvio._Particle[particleIndex].position;
            float4 velocity = fluvio._Particle[particleIndex].velocity;
            float size = velocity.w;

            // Apply transformation matrix
            float4 worldPosition = fluvio_ParticleSystem._ParticleToWorldMatrix.MultiplyPoint3x4(position);
            float4 worldVelocity = fluvio_ParticleSystem._ParticleToWorldMatrix.MultiplyVector(velocity);

            // Assign transformed position and velocity
            fluvio._Particle[particleIndex].position = worldPosition;
            worldVelocity.w = size;
            fluvio._Particle[particleIndex].velocity = worldVelocity;
        }
        void FluidToParticleSystem(SolverDataInternal fluvio, int particleIndex)
        {
            if (fluvio._Particle[particleIndex].lifetime.x <= 0) return;

            // ReSharper disable once RedundantCast
            var fluvio_ParticleSystem = m_ParticleSystemData;

            // Get particle ID
            int id = fluvio._Particle[particleIndex].id.y;

            // Skip despawned particles
            if (id >= fluvio_ParticleSystem._ParticleCount)
                return;

            // Get world position, velocity, and normal
            float4 worldPosition = fluvio._Particle[particleIndex].position;
            float4 worldVelocity = fluvio._Particle[particleIndex].velocity;
            float4 worldNormal = fluvio._Particle[particleIndex].normal;
            float size = worldVelocity.w;
            float normalLen = worldNormal.w;

            // Axis constraint
            worldPosition.z *= fluvio_ParticleSystem._Dimensions.x;
            worldPosition.z += fluvio_ParticleSystem._Dimensions.y;
            worldVelocity.z *= fluvio_ParticleSystem._Dimensions.x;

            // Force integration: dynamic particles only
            if (solverEnabled)
            {
                IntegrateParticles(fluvio, particleIndex, ref fluvio._Particle[particleIndex], fluvio_ParticleSystem._Dimensions.x, ref worldVelocity);
            }

            // Apply transformation matrix
            float4 position = fluvio_ParticleSystem._WorldToParticleMatrix.MultiplyPoint3x4(worldPosition);
            float4 velocity = fluvio_ParticleSystem._WorldToParticleMatrix.MultiplyVector(worldVelocity);
            float4 normal = fluvio_ParticleSystem._WorldToParticleMatrix.MultiplyVector(worldNormal);

            // Assign transformed position, velocity and normal
            fluvio._Particle[particleIndex].position = position;
            fluvio._Particle[particleIndex].velocity = new float4(velocity.x, velocity.y, velocity.z, size);
            fluvio._Particle[particleIndex].normal = new float4(normal.x, normal.y, normal.z, normalLen);
        }
        void FluidToParticleSystemFast(SolverDataInternal fluvio, int particleIndex)
        {
            if (fluvio._Particle[particleIndex].lifetime.x <= 0) return;

            // ReSharper disable once RedundantCast
            var fluvio_ParticleSystem = m_ParticleSystemData;

            // Get particle ID
            int id = fluvio._Particle[particleIndex].id.y;

            // Skip despawned particles
            if (id >= fluvio_ParticleSystem._ParticleCount)
                return;

            // Get world position, velocity, and normal
            float4 worldPosition = fluvio._Particle[particleIndex].position;
            float4 worldVelocity = fluvio._Particle[particleIndex].velocity;
            float4 worldNormal = fluvio._Particle[particleIndex].normal;

            // Axis constraint
            worldPosition.z *= fluvio_ParticleSystem._Dimensions.x;
            worldPosition.z += fluvio_ParticleSystem._Dimensions.y;
            worldVelocity.z *= fluvio_ParticleSystem._Dimensions.x;

            // Force integration: dynamic particles only
            if (solverEnabled)
            {
                IntegrateParticles(fluvio, particleIndex, ref fluvio._Particle[particleIndex], fluvio_ParticleSystem._Dimensions.x, ref worldVelocity);
            }

            // Assign position, velocity and normal
            fluvio._Particle[particleIndex].position = worldPosition;
            fluvio._Particle[particleIndex].velocity = worldVelocity;
            fluvio._Particle[particleIndex].normal = worldNormal;            
        }        
        void DispatchComputeShader(int kernelIndex)
        {
            // Set arguments
            m_ComputeShader.SetInt(kernelIndex, "fluvio_ParticleSystem_FluidID", m_ParticleSystemData._FluidID);
            m_ComputeShader.SetInt(kernelIndex, "fluvio_ParticleSystem_ParticleCount", m_ParticleSystemData._ParticleCount);
            m_ComputeShader.SetVector(kernelIndex, "fluvio_ParticleSystem_Dimensions", m_ParticleSystemData._Dimensions);
            m_ComputeShader.SetMatrix(kernelIndex, "fluvio_ParticleSystem_ParticleToWorldMatrix", m_ParticleSystemData._ParticleToWorldMatrix);
            m_ComputeShader.SetMatrix(kernelIndex, "fluvio_ParticleSystem_WorldToParticleMatrix", m_ParticleSystemData._WorldToParticleMatrix);
            
            // Dispatch compute shader
            _solver.ForEachParticle(m_ComputeShader, kernelIndex, true, true);
        }       
    }
}
