// VersionInfo.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System.Globalization;
using System.Text;

#pragma warning disable 429
#pragma warning disable 162
// ReSharper disable UnreachableCode
// ReSharper disable ConditionIsAlwaysTrueOrFalse
namespace Thinksquirrel.Fluvio.Internal
{
    /// <summary>
    ///     Contains Fluvio version information.
    /// </summary>
    public static class VersionInfo
    {
        /// <summary>
        ///     Gets the current version of Fluvio.
        /// </summary>
        public const string version = "3.0.0b12";

        /// <summary>
        ///     Whether or not the current Fluvio build is a pre-release build.
        /// </summary>
        public static bool isPreRelease
        {
            get { return !version.Contains("f"); }
        }
        /// <summary>
        ///     Whether or not the current Fluvio build is the free edition.
        /// </summary>
        public const bool isFreeEdition =
#if FLUVIO_FREE
            true;
#else
            false;
#endif
        /// <summary>
        ///     Whether or not this build of Fluvio is the professional edition.
        /// </summary>
        public const bool isProEdition =
#if FLUVIO_PRO
            true;
#else
            false;
#endif
        /// <summary>
        ///     Whether or not this build of Fluvio is the standard edition.
        /// </summary>
        public const bool isStandardEdition =
#if FLUVIO_STANDARD
            true;
#else
            false;
#endif
        /// <summary>
        ///     Gets the current Fluvio license, in human-readable form.
        /// </summary>
        public static string license
        {
            get
            {
                return isProEdition ? "Fluvio Pro" : isFreeEdition ? "Fluvio Free" : "Fluvio";
            }
        }
        public static string copyright
        {
            get { return "(c) 2011-2015 Thinksquirrel Software, LLC."; }
        }        
    }
}
