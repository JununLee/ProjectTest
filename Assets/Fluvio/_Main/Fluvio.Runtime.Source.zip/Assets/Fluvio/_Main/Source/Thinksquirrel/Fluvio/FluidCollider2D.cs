// FluidCollider2D.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.
#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Represents a two dimensional fluid collider.
    /// </summary>
    /// <remarks>
    ///     Fluid colliders are a special type of fluid that serve as collision boundaries for fluid simulation.
    /// </remarks>
    [RequireComponent(typeof(Collider2D))]
    [AddComponentMenu("Fluvio/Colliders/Fluid Collider 2D")]
    [ExecuteInEditMode]
    public sealed class FluidCollider2D : FluidColliderBase
    {
        #region Serialized Fields
        [SerializeField] Collider2D m_AttatchedCollider;
        #endregion

        #region Instance Fields
        [NonSerialized] Vector2 m_OldCenter;
        [NonSerialized] Vector2 m_OldSize;
        [NonSerialized] float m_OldRadius;
        [NonSerialized] int m_OldPointCount;
        [NonSerialized] int m_OldShapeCount;
        [NonSerialized] int m_OldPathCount;
        [NonSerialized] Vector2[][] m_CachedPoints;
        #endregion

        #region Public API
        /// <summary>
        ///     The attatched collider. This must be on the same GameObject as the fluid collider.
        /// </summary>
        public Collider2D attatchedCollider
        {
            get { return m_AttatchedCollider; }
            set
            {
                if (value == null || m_AttatchedCollider == value || value.gameObject != gameObject) return;
                m_AttatchedCollider = value;
            }
        }
        /// <summary>
        ///     Controls whether or not the collider should be filled.
        /// </summary>
        /// <remarks>
        ///     Filled colliders provide better simulation for solid objects and higher velocity objects, but have a higher performance overhead (especially in 3D).
        ///     For edge and terrain colliders, this will always return false.
        /// </remarks>
        public override bool fillCollider
        {
            get
            {
                var edge = m_AttatchedCollider as EdgeCollider2D;
                return !edge && base.fillCollider;
            }
            set { base.fillCollider = value; }
        }
        #endregion

        #region Unity Methods
        protected override void DrawCollider()
        {
            var points = GetCollisionPoints();
            
            var sz = smoothingDistance / colliderResolution;
            var ext = new Vector2(sz*0.5f/transform.localScale.x, sz*0.5f/transform.localScale.y);
            
            var matrix = GetLocalToWorldMatrix();
            for (var i = 0; i < points.Count; ++i)
            {
                var pt = (Vector2)points[i];
                var p1 = matrix.MultiplyPoint3x4(pt + ext);
                var p2 = matrix.MultiplyPoint3x4(pt + new Vector2(ext.x, -ext.y));
                var p3 = matrix.MultiplyPoint3x4(pt - ext);
                var p4 = matrix.MultiplyPoint3x4(pt + new Vector2(-ext.x, ext.y));
                Gizmos.DrawLine(p1, p2);
                Gizmos.DrawLine(p2, p3);
                Gizmos.DrawLine(p3, p4);
                Gizmos.DrawLine(p4, p1);
            }
        }
        #endregion
        protected override bool ColliderIsValid()
        {
            return IsValid(attatchedCollider);
        }
        protected override bool ColliderHasChanged()
        {
            var box = attatchedCollider as BoxCollider2D;
            var circle = attatchedCollider as CircleCollider2D;
            var edge = attatchedCollider as EdgeCollider2D;
            var poly = attatchedCollider as PolygonCollider2D;

            if (box)
            {
                #if UNITY_5_0_PLUS
                var center = box.offset;
                #else
                var center = box.center;
                #endif

                if ((center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    (box.size - m_OldSize).sqrMagnitude > kEpsilon * kEpsilon)
                {
                    m_OldCenter = center;
                    m_OldSize = box.size;
                    return true;
                }
            }
            if (circle)
            {
                #if UNITY_5_0_PLUS
                var center = circle.offset;
                #else
                var center = circle.center;
                #endif

                if ((center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    Mathf.Abs(circle.radius - m_OldRadius) > kEpsilon)
                {
                    m_OldCenter = center;
                    m_OldRadius = circle.radius;
                    return true;
                }
            }
            if (edge)
            {
                #if UNITY_5_0_PLUS
                var center = edge.offset;
                #else
                var center = Vector2.zero;
                #endif
                
                if ((center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    edge.pointCount != m_OldPointCount)
                {
                    m_OldCenter = center;
                    m_OldPointCount = edge.pointCount;
                    return true;
                }                
            }
            if (poly)
            {
                #if UNITY_5_0_PLUS
                var center = poly.offset;
                #else
                var center = Vector2.zero;
                #endif

                var totalPointCount = poly.GetTotalPointCount();

                if ((center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    poly.shapeCount != m_OldShapeCount ||
                    poly.pathCount != m_OldPathCount ||
                    totalPointCount != m_OldPointCount)
                {
                    m_OldCenter = center;
                    m_OldShapeCount = poly.shapeCount;
                    m_OldPathCount = poly.pathCount;
                    m_OldPointCount = totalPointCount;
                    return true;
                }                
            }
            return false;
        }
        protected override void Voxelize()
        {
            var box = attatchedCollider as BoxCollider2D;
            var circle = attatchedCollider as CircleCollider2D;
            var edge = attatchedCollider as EdgeCollider2D;
            var poly = attatchedCollider as PolygonCollider2D;

            Vector2 scale = transform.localScale;

            // This should take care of zero and negative scales
            scale.x = Mathf.Abs(transform.localScale.x) < kEpsilon ? kEpsilon : Mathf.Abs(transform.localScale.x);
            scale.y = Mathf.Abs(transform.localScale.y) < kEpsilon ? kEpsilon : Mathf.Abs(transform.localScale.y);

            if (circle)
            {
                var scaleMax = Mathf.Max(scale.x, scale.y);
                scale.Set(scaleMax, scaleMax);
            }

            var dist = new Vector2(
                (smoothingDistance / colliderResolution) / scale.x,
                (smoothingDistance / colliderResolution) / scale.y);

            if (box)
            {
                #if UNITY_5_0_PLUS
                var bounds = new Bounds(box.offset, box.size);
                #else
                var bounds = new Bounds(box.center, box.size);
                #endif
                Voxelize(bounds, box, dist, DistanceBox);
            }
            else if (circle)
            {
                #if UNITY_5_0_PLUS
                var bounds = new Bounds(circle.offset, new Vector3(circle.radius * 2.0f, circle.radius * 2.0f, 0.0f));
                #else
                var bounds = new Bounds(circle.center, new Vector3(circle.radius * 2.0f, circle.radius * 2.0f, 0.0f));
                #endif
                Voxelize(bounds, circle, dist, DistanceCircle);
            }
            else if (edge)
            {
                var min = new Vector3(float.MaxValue, float.MaxValue, 0.0f);
                var max = new Vector3(float.MinValue, float.MinValue, 0.0f);

                m_CachedPoints = new[] { edge.points };

                for (var i = 0; i < m_CachedPoints[0].Length; ++i)
                {
                    var pt = m_CachedPoints[0][i];

                    if (pt.x < min.x) min.x = pt.x;
                    if (pt.x > max.x) max.x = pt.x;

                    if (pt.y < min.y) min.y = pt.y;
                    if (pt.y > max.y) max.y = pt.y;
                }

                var bounds = new Bounds();
                
                #if UNITY_5_0_PLUS
                bounds.SetMinMax((Vector3)edge.offset + min, (Vector3)edge.offset + max);
                #else
                bounds.SetMinMax(min, max);
                #endif

                Voxelize(bounds, edge, dist, DistanceEdge);
            }
            else if (poly)
            {
                var min = new Vector3(float.MaxValue, float.MaxValue, 0.0f);
                var max = new Vector3(float.MinValue, float.MinValue, 0.0f);
                
                m_CachedPoints = new Vector2[poly.pathCount][];
                for (var i = 0; i < m_CachedPoints.Length; ++i)
                {
                    m_CachedPoints[i] = poly.GetPath(i);                    
                }

                for (var i = 0; i < m_CachedPoints.Length; ++i)
                {
                    for (var j = 0; j < m_CachedPoints[i].Length; ++j)
                    {
                        var pt = m_CachedPoints[i][j];
                        
                        if (pt.x < min.x) min.x = pt.x;
                        if (pt.x > max.x) max.x = pt.x;

                        if (pt.y < min.y) min.y = pt.y;
                        if (pt.y > max.y) max.y = pt.y;
                    }
                }
                
                var bounds = new Bounds();
                
                #if UNITY_5_0_PLUS
                bounds.SetMinMax((Vector3)poly.offset + min, (Vector3)poly.offset + max);
                #else
                bounds.SetMinMax(min, max);
                #endif
                
                Voxelize(bounds, poly, dist, DistancePoly);
            }
        }
        protected override void GetDefaultCollider()
        {
            if (m_AttatchedCollider) return;
            m_AttatchedCollider = GetComponent<Collider2D>();
        }

        void Voxelize(Bounds bounds, Collider2D col, Vector2 dist, Func<Bounds, Collider2D, Vector2, Vector2, bool> distanceFunc)
        {
            var min = bounds.min;
            var max = bounds.max;

            var shouldBreak = false;

            for (var x = min.x; x < max.x + dist.x; x += dist.x)
            {
                if (shouldBreak) break;

                for (var y = min.y; y < max.y + dist.y; y += dist.y)
                {
                    if (shouldBreak) break;

                    var pos = new Vector3(x, y, 0.0f);
                    if (distanceFunc(bounds, col, pos, dist))
                    {
                        shouldBreak = !AddCollisionPoint(pos);
                    }                    
                }
            }
        }
        #region Distance functions
        bool DistanceBox(Bounds bounds, Collider2D col, Vector2 pos, Vector2 dist)
        {
            bounds.Expand(dist);

            return bounds.Contains(pos) &&
                   (fillCollider ||
                    pos.x < bounds.min.x + (dist.x * FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.y < bounds.min.y + (dist.y * FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.x > bounds.max.x - (dist.x * FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.y > bounds.max.y - (dist.y * FluvioSettings.kFluidColliderSkinWidth));
        }
        bool DistanceCircle(Bounds bounds, Collider2D col, Vector2 pos, Vector2 dist)
        {
            var circle = col as CircleCollider2D;
            if (!circle) return false;

            #if UNITY_5_0_PLUS
            var center = circle.offset;
            #else
            var center = circle.center;
            #endif
            var radius = circle.radius;

            var dst = Vector2.Distance(pos, center);
            return dst < radius && (fillCollider || dst > radius - (dist.x * FluvioSettings.kFluidColliderSkinWidth));
        }
        bool DistanceEdge(Bounds bounds, Collider2D col, Vector2 pos, Vector2 dist)
        {
            var edge = col as EdgeCollider2D;
            if (!edge) return false;

            #if UNITY_5_0_PLUS
            var center = edge.offset;
            #else
            var center = Vector2.zero;
            #endif
            
            var dst = Mathf.Max(dist.x, dist.y);

            var pts = m_CachedPoints[0]; // Use cached points to save on allocations
            
            for (var i = 0; i < pts.Length-1; ++i)
            {
                var ptA = pts[i] + center;
                var ptB = pts[i + 1] + center;

                var proj = PointToLine2(ptA, ptB, pos);
                var d = Vector2.Distance(proj, pos);
                if (d <= dst*FluvioSettings.kFluidColliderSkinWidth*0.5f) return true;
            }

            return false;
        }
        Collider2D[] m_CachedCollider = new Collider2D[1];
        bool DistancePoly(Bounds bounds, Collider2D col, Vector2 pos, Vector2 dist)
        {
            var poly = col as PolygonCollider2D;
            if (!poly) return false;

            #if UNITY_5_0_PLUS
            var center = poly.offset;
            #else
            var center = Vector2.zero;
            #endif

            var p = pos - center;
            var dst = Mathf.Max(dist.x, dist.y);

            // Point-in-poly test via Unity
            m_CachedCollider[0] = poly;
            var intersection = Physics2D.OverlapPointNonAlloc((Vector2)(GetLocalToWorldMatrix() * pos) + (Vector2)transform.position, m_CachedCollider);
            if (intersection == 0 || m_CachedCollider[0] != poly) return false;

            // Return early if filling collider
            if (fillCollider) return true;

            // Use cached points to save on allocations
            for (var i = 0; i < m_CachedPoints.Length; ++i)
            {
                var pts = m_CachedPoints[i];                
                
                // Get distance
                for (var j = 0; j < pts.Length; ++j)
                {
                    var ptA = pts[j];
                    var ptB = pts[(j + 1) % pts.Length];

                    var proj = PointToLine2(ptA, ptB, p);
                    var d = Vector2.Distance(proj, p);
                    if (d <= dst * FluvioSettings.kFluidColliderSkinWidth) return true;
                }
            }
            
            return false;
        }
        #endregion
        #region Helpers
        // Point to line distance - http://stackoverflow.com/questions/849211/shortest-distance-between-a-point-and-a-line-segment
        // Returns the point to check distance against, rather than the distance itself
        Vector2 PointToLine2(Vector2 v, Vector2 w, Vector2 p)
        {
            // Return minimum distance between line segment vw and point p
            var l2 = (w - v).sqrMagnitude;  // i.e. |w-v|^2 -  avoid a sqrt
            if (l2 < kEpsilon) return v;   // v == w case            
            // Consider the line extending the segment, parameterized as v + t (w - v).
            // We find projection of point p onto the line. 
            // It falls where t = [(p-v) . (w-v)] / |w-v|^2
            var t = Vector2.Dot(p - v, w - v) / l2;
            if (t < 0.0f) return v;       // Beyond the 'v' end of the segment
            if (t > 1.0f) return w;  // Beyond the 'w' end of the segment
            return v + t * (w - v);  // Projection falls on the segment
        }
        // Point in polygon - http://stackoverflow.com/questions/4243042/c-sharp-point-in-polygon
        //bool IsInPolygon(Vector2[] poly, Vector2 point)
        //{
        //    var result = false;
        //    var j = poly.Length - 1;
        //    for (var i = 0; i < poly.Length; ++i)
        //    {
        //        var pI = poly[i];
        //        var pJ = poly[j];

        //        if (pI.y < point.y &&
        //            pJ.y >= point.y ||
        //            pJ.y < point.y &&
        //            pI.y >= point.y)
        //        {
        //            if (pI.x + (point.y - pI.y)/(pJ.y - pI.y)*(pJ.x - pI.x) < point.x)
        //            {
        //                result ^= true;
        //            }
        //        }
        //        j = i;
        //    }
        //    return result;
        //}     
        #endregion
    }
}
