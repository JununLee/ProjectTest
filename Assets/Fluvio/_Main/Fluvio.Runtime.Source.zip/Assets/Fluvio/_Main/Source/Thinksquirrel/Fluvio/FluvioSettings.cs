// FluvioSettings.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using Cloo;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Internal.Threading;
using UnityEngine;
using UnityEngine.Serialization;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     This class controls global Fluvio settings.
    /// </summary>
    public sealed class FluvioSettings : FluvioScriptableObjectBase
    {
        #region Serialized Fields
        [SerializeField] bool m_EnableLiveEdit = true;
        [SerializeField] bool m_PreloadComputeShaders = true;
        [SerializeField] float m_FixedDeltaTime = 1f/30f;
        [SerializeField] float m_MaxDeltaTime = 1f/3f;
        [SerializeField] bool m_LimitTimestep = true;
        [SerializeField] bool m_MotionExtrapolation = true;
        [SerializeField] int m_SolverIterations = 2;
        [SerializeField] bool m_UseIndexGrid = true;
        [SerializeField] int m_MaxGridSize = 64;
        [SerializeField] int m_GridBucketSize = 64;
        [SerializeField] FluvioThreadPriority m_ThreadPriority = FluvioThreadPriority.Normal;
        [SerializeField] int m_DesiredThreads = 8;
        [SerializeField] [FormerlySerializedAs("m_DesiredHardwareAccelerationAPI")] ComputeAPI m_DesiredComputeAPI = ComputeAPI.OpenCL;
        [SerializeField] OpenCLDeviceType m_OpenCLDesiredDeviceType = OpenCLDeviceType.GPU;
        [SerializeField] bool m_EnableOpenCLGPUOnOSX;
        [SerializeField] string[] m_OpenCLPlatformBlacklist = new string[0];
        [SerializeField] string[] m_OpenCLDeviceBlacklist = new string[0];
        [SerializeField, HideInInspector] int[] m_SortingLayerUniqueIDs = {0};
        #endregion

        #region Static and Constant Fields
        static FluvioSettings s_Instance;
        static bool s_CreatingInstance;
        #pragma warning disable 414
        static ComputeAPI s_LastComputeAPI;
        #pragma warning restore 414
        /// <summary>
        ///     Compute shader thread group size (single dimension).
        /// </summary>
        public const int kComputeThreadGroupSize = 128;
        /// <summary>
        ///     Compute shader thread group size (X).
        /// </summary>
        public const int kComputeThreadGroupSizeX = 16;
        /// <summary>
        ///     Compute shader thread group size (Y).
        /// </summary>
        public const int kComputeThreadGroupSizeY = 16;
        /// <summary>
        ///     Compute shader thread group size (Z).
        /// </summary>
        public const int kComputeThreadGroupSizeZ = 4;
        /// <summary>
        ///     Minimum float value for fluid simulation.
        /// </summary>
        public const float kEpsilon = 9.99999944e-11f;
        /// <summary>
        ///     Maximum squared velocity magnitude that will be applied in a single solver iteration. Higher values are ignored. Prevents numerical errors.
        /// </summary>
        public const float kMaxSqrVelocityChange = 100.0f;
        /// <summary>
        /// Turbulence constant for vortical forces.
        /// </summary>
        public const float kTurbulenceConstant = 10.0f;        
        /// <summary>
        ///     Maximum amount of plugin buffers supported.
        /// </summary>
        /// <remarks>
        ///     Plugin values also take up buffer spots.
        ///     The actual amount of plugin buffers that can be used is platform-dependent.
        ///     For mobile platforms, it is recommended to not have more than two plugin buffers (or one read-write plugin buffer).
        ///     It is highly recommended to pack plguin information into structs in order to use as few buffers as possible.
        /// </remarks>
        public const int kMaxPluginBuffers = 10;
        /// <summary>
        ///     Fluid collider skin width. This is multiplied by the fluid's smoothing distance to determine boundary skin width.
        /// </summary>
        public const float kFluidColliderSkinWidth = 1.0f;
        /// <summary>
        ///     Fluid colldier maximum particle count.
        /// </summary>
        public const int kFluidColliderMaxParticleCount = ushort.MaxValue*2;
        #endregion

        #region Public API
        /// <summary>
        ///     Preload compute shaders whenever possible.
        /// </summary>
        /// <remarks>
        ///     This currently only applies to OpenCL and can only be changed in the editor.
        ///     All OpenCL shaders will preload with the first API call to any Fluvio object, even if a fluid is not yet in the scene.
        ///     Shaders will not preload in edit mode.
        /// </remarks>
        public static bool preloadComputeShaders
        {
            get { return GetInstance().m_PreloadComputeShaders; }
        }
        /// <summary>
        ///     Controls the default physics time step for fluid simulation.
        /// </summary>
        public static float fixedDeltaTime
        {
            get { return GetInstance().m_FixedDeltaTime; }
            set
            {
                var i = GetInstance();
                i.m_FixedDeltaTime = Mathf.Clamp(value, 0.0001f, 10f);
                i.m_MaxDeltaTime = Mathf.Max(i.m_FixedDeltaTime, i.m_MaxDeltaTime);
            }
        }
        /// <summary>
        ///     Controls the maximum physics time step for fluid simulation.
        /// </summary>
        public static float maxDeltaTime
        {
            get { return GetInstance().m_MaxDeltaTime; }
            set
            {
                var i = GetInstance();
                i.m_MaxDeltaTime = Mathf.Clamp(value, i.m_FixedDeltaTime, float.MaxValue);
            }
        }
        /// <summary>
        ///     If true, limits the frame timestep based on real time passed.
        /// </summary>
        /// <remarks>
        ///     This helps prevent runaway physics, in the cases where the amount of computational time to simulate a timestep is
        ///     longer than the amount of time passed. It is recommended to leave this on for realtime use.
        /// </remarks>
        public static bool limitTimestep
        {
            get { return GetInstance().m_LimitTimestep; }
            set { GetInstance().m_LimitTimestep = value; }
        }
        /// <summary>
        ///     Controls the amount of solver iterations.
        /// </summary>
        public static int solverIterations
        {
            get { return GetInstance().m_SolverIterations; }
            set { GetInstance().m_SolverIterations = Mathf.Clamp(value, 1, 20); }
        }
        /// <summary>
        ///     Enables or disables motion extrapolation.
        /// </summary>
        /// <remarks>
        ///     Motion extrapolation extrapolates the position of particles between physics frames for a smoother experience and a lower overall 
        ///     computational cost.
        ///     It is recommended to keep this enabled, especially for VR.
        /// </remarks>
        public static bool motionExtrapolation
        {
            get { return GetInstance().m_MotionExtrapolation; }
            set { GetInstance().m_MotionExtrapolation = value; }
        }
        /// <summary>
        ///     Whether or not an index grid should be used to accelerate neighbor search.
        /// </summary>
        /// <remarks>
        ///     In almost all situations, this should be enabled. The index grid significantly accelerates particle simulation, 
        ///     in exchange for an additional memory cost.
        ///     Changing this value will trigger a recompile of all compute shaders and can only be changed in the editor.
        /// </remarks>
        public static bool useIndexGrid {  get { return GetInstance().m_UseIndexGrid; } }
        /// <summary>
        ///     The maximum amount of grid cells to have in any one direction (X/Y or X/Y/Z). Cells are the same size as the root fluid's smoothing distance.
        /// </summary>
        /// <remarks>
        ///     Grid sizes have a very large affect on fluid memory usage and performance. It is recommended to use the default values in almost every case.
        ///     Changing this value will trigger a recompile of all compute shaders and can only be changed in the editor.
        /// </remarks>
        public static int maxGridSize { get { return GetInstance().m_MaxGridSize; } }
        /// <summary>
        ///     The maximum amount of particles per grid cell.
        /// </summary>
        /// <remarks>
        ///     Grid sizes have a very large affect on fluid memory usage and performance. It is recommended to use the default values in almost every case.
        ///     Changing this value will trigger a recompile of all compute shaders and can only be changed in the editor.
        /// </remarks>
        public static int gridBucketSize {  get { return GetInstance().m_GridBucketSize; } }
        /// <summary>
        ///    Gets the size of the index grid, in bytes.
        /// </summary>
        /// <remarks>
        ///     This can be used to evaluate whether or not the target device has enough memory to support the index grid.
        ///     If the index grid is disabled, returns 0.
        /// </remarks>
        public static int gridBytes {  get { return useIndexGrid ? gridLength*sizeof(int) : 0; } }
        internal static int gridLength { get { return maxGridSize * maxGridSize * maxGridSize * gridBucketSize; } }
        /// <summary>
        ///     Particle stride for solver arrays for 2D fluids. Equal to 9 full grid cells minus one particle (gridBucketSize * 9 - 1).
        /// </summary>
        public static int particleStride2D { get { return gridBucketSize * 9 - 1; } }
        /// <summary>
        ///     Particle stride for solver arrays for 3D fluids. Equal to 27 full grid cells minus one particle (gridBucketSize * 27 - 1).
        /// </summary>
        public static int particleStride3D { get { return gridBucketSize * 27 - 1; } }
        /// <summary>
        ///     The desired amount of threads to use globally for fluid simulation and other parallel tasks.
        /// </summary>
        /// <remarks>
        ///     The maximum amount of threads used (including the main thread) will always be the amount of logical cores in the system. 
        ///     Setting the desired amount of threads can greatly affect performance. 
        ///     When setting this property, the current thread will wait on all running tasks to complete.
        ///     If the current platform does not support multithreading, this will have no effect.
        /// </remarks>
        public static int desiredThreads
        {
            get { return GetInstance().m_DesiredThreads + 1; }
            set { Parallel.Reset(); GetInstance().m_DesiredThreads = Mathf.Max(1, value - 1); }
        }
        /// <summary>
        ///     The current amount of threads used for fluid simulation and other parallel tasks.
        /// </summary>
        /// <remarks>
        ///     The maximum amount of threads used will always be the amount of logical cores in the system - 1.
        ///     If the current platform does not support multithreading, this will return a value of 1.
        /// </remarks>
        public static int currentThreadCount
        {
            get { return Parallel.GetThreadCount() + 1; }
        }
        /// <summary>
        ///     Controls the thread priority for fluid simulation and other parallel tasks.
        /// </summary>
        public static FluvioThreadPriority threadPriority
        {
            get { return GetInstance().m_ThreadPriority; }
            set { GetInstance().m_ThreadPriority = value; }
        }
        /// <summary>
        ///     Controls the desired compute API for hardware accelerated fluid simulation.
        /// </summary>
        public static ComputeAPI desiredComputeAPI
        {
            get { return GetInstance().m_DesiredComputeAPI; }
            set { GetInstance().m_DesiredComputeAPI = value; }
        }
        //! \cond PRIVATE
        [Obsolete("Use FluvioSettings.desiredComputeAPI instead")]
        public static ComputeAPI desiredHardwareAccelerationAPI
        {
            get { return desiredComputeAPI; }
            set { desiredComputeAPI = value; }
        }
        //! \endcond
        /// <summary>
        ///     Controls the desired device type when using OpenCL hardware acceleration.
        /// </summary>
        /// <remarks>
        ///     Using a CPU device may perform better for applications that are GPU bound, or for GPUs that have a low CPU/GPU memory latency or poor compute capabilities.
        ///     Using a GPU device may perform better for applications that are CPU bound when using larger particle counts on a system with low CPU/GPU memory latency.
        ///     When multiple devices of the same class exist, these devices are given a score based on the number of compute cores and processor speed, and the device with the highest score is picked.
        ///     Blacklisted devices are always skipped, regardless of their type.
        /// </remarks>
        public static OpenCLDeviceType openCLDesiredDeviceType
        {
            get { return GetInstance().m_OpenCLDesiredDeviceType; }
            set { GetInstance().m_OpenCLDesiredDeviceType = value; }
        }
        /// <summary>
        ///     Controls whether or not OpenCL GPU and accelerator devices are enabled on Mac OS X. This feature is experimental, and off by default. 
        /// </summary>
        /// <remarks>
        ///     Due to driver issues, some Mac OS devices may crash with OpenCL in GPU mode. 
        ///     This option allows for a global override on whether or not GPU devices should be considered for simulation on Mac OS X devices.
        /// </remarks>
        public static bool enableOpenCLGPUOnOSX
        {
            get { return GetInstance().m_EnableOpenCLGPUOnOSX; }
            set { GetInstance().m_EnableOpenCLGPUOnOSX = value; }
        }
        /// <summary>
        ///     Controls device strings that should be blacklisted when using OpenCL.
        /// </summary>
        /// <remarks>
        ///     When changing these values, accelerated fluids must have their buffers reinitialized using ReinitializeAllAcceleratedFluids manually.
        /// </remarks>
        public static string[] openCLDeviceBlacklist
        {
            get { return GetInstance().m_OpenCLDeviceBlacklist; }
            set { GetInstance().m_OpenCLDeviceBlacklist = value; }
        }
        /// <summary>
        ///     Controls platforms that should be blacklisted when using OpenCL.
        /// </summary>
        /// <remarks>
        ///     When changing these values, accelerated fluids must have their buffers reinitialized using ReinitializeAllAcceleratedFluids manually.
        /// </remarks>
        public static string[] openCLPlatformBlacklist
        {
            get { return GetInstance().m_OpenCLPlatformBlacklist; }
            set { GetInstance().m_OpenCLPlatformBlacklist = value; }
        }
        
        /// <summary>
        ///     Gets the current compute API used for Fluvio.
        /// </summary>
        /// <returns>The desired compute API, or a fallback if available.</returns>
        public static ComputeAPI GetCurrentComputeAPI()
        {
            #pragma warning disable 162
            #pragma warning disable 429
            // ReSharper disable HeuristicUnreachableCode            
            // ReSharper disable RedundantLogicalConditionalExpressionOperand
            
            ComputeAPI computeAPI;

            switch (desiredComputeAPI)
            {
                case ComputeAPI.None:
                    s_LastComputeAPI = ComputeAPI.None;
                    return ComputeAPI.None;
                case ComputeAPI.OpenCL:
                    computeAPI = FluvioOpenCL.IsOpenCLAvailable() ? ComputeAPI.OpenCL : SystemInfo.supportsComputeShaders ? ComputeAPI.UnityNative : ComputeAPI.None;
                    if (s_LastComputeAPI != ComputeAPI.None && 
                        computeAPI != ComputeAPI.None &&
                        s_LastComputeAPI != computeAPI)
                    {
                        s_LastComputeAPI = computeAPI;
                        ReinitializeAllAcceleratedFluids();
                    }
                    return computeAPI;
                case ComputeAPI.UnityNative:
                    computeAPI = SystemInfo.supportsComputeShaders ? ComputeAPI.UnityNative : FluvioOpenCL.IsOpenCLAvailable() ? ComputeAPI.OpenCL : ComputeAPI.None;
                    if (s_LastComputeAPI != ComputeAPI.None &&
                        computeAPI != ComputeAPI.None &&
                        s_LastComputeAPI != computeAPI)
                    {
                        s_LastComputeAPI = computeAPI;
                        ReinitializeAllAcceleratedFluids();
                    }
                    return computeAPI;
                default:
                    FluvioDebug.Log("Unknown/Not implemented hardware acceleration type", GetInstance());
                    s_LastComputeAPI = ComputeAPI.None;
                    return ComputeAPI.None;
            }
            // ReSharper restore RedundantLogicalConditionalExpressionOperand
            // ReSharper restore HeuristicUnreachableCode
            #pragma warning restore 429
            #pragma warning restore 162
        }        
        //! \cond PRIVATE
        [Obsolete("Use FluvioSettings.GetCurrentComputeAPI instead")]
        public static ComputeAPI GetCurrentHardwareAcceleration()
        {
            return GetCurrentComputeAPI();
        }
        //! \endcond
        /// <summary>
        ///     Force an initialization of OpenCL.
        /// </summary>
        /// <param name="device">An optional compute device to use (from the Cloo OpenCL library). This can be used to force a specific OpenCL device, overriding the detault device option.</param>
        /// <remarks>
        ///     This should only be called if OpenCL has already been initialized and the desired device type, platform blacklist, or device blacklist have changed.
        /// </remarks>
        public static void ForceInitializeOpenCL(ComputeDevice device = null)
        {
            FluvioOpenCL.ForceInitialize();
        }
        /// <summary>
        ///     Reinitialize all accelerated fluids in the scene.
        /// </summary>
        /// <remarks>
        ///      This will not reset simulation, but is a very performance-intensive operation.
        /// </remarks>
        public static void ReinitializeAllAcceleratedFluids()
        {
            var fluids = FluidBase.GetAllFluids();

            foreach (var fluid in fluids)
            {
                if (fluid.parentFluid) continue;

                if (fluid._solver != null)
                {
                    fluid._solver.ClearBuffers();
                }
            }
        }
        /// <summary>
        ///     Get the name of the current compute platform for the specified fluid.
        /// </summary>
        /// <param name="fluid">The fluid to get the compute platform name for.</param>
        /// <returns>The name and version of the current compute platform.</returns>
        public static string GetCurrentComputePlatform([NotNull] FluidBase fluid)
        {
            if (fluid == null) throw new ArgumentNullException("fluid");
            return GetCurrentComputePlatform(fluid.enableHardwareAcceleration ? GetCurrentComputeAPI() : ComputeAPI.None);
        }
        internal static string GetCurrentComputePlatform(ComputeAPI computeAPI)
        {
            switch (computeAPI)
            {
                case ComputeAPI.None:
                    return string.Format("C# Solver - {0} Threads", currentThreadCount);
                case ComputeAPI.UnityNative:
                    return SystemInfo.graphicsDeviceVersion.Trim();
                case ComputeAPI.OpenCL:
                    var context = FluvioOpenCL.GetComputeContext();
                    return context == null ? "OpenCL NULL Platform" : string.Format("{0} [{1}]", context.Platform.Name.Trim(), context.Platform.Version.Trim());
                default:
                    return "Unknown Platform";
            }
        }

        /// <summary>
        /// Get the name of the current compute device for the specified fluid.
        /// </summary>
        /// <param name="fluid">The fluid to get the compute device name for.</param>
        /// <returns>The name of the current compute device.</returns>
        public static string GetCurrentDeviceName([NotNull] FluidBase fluid)
        {
            if (fluid == null) throw new ArgumentNullException("fluid");
            return GetCurrentDeviceName(fluid.enableHardwareAcceleration ? GetCurrentComputeAPI() : ComputeAPI.None);
        }
        internal static string GetCurrentDeviceName(ComputeAPI computeAPI)
        {
            switch (computeAPI)
            {
                case ComputeAPI.None:
                    return SystemInfo.processorType.Trim();
                case ComputeAPI.UnityNative:
                    return SystemInfo.graphicsDeviceName.Trim();
                case ComputeAPI.OpenCL:
                    var context = FluvioOpenCL.GetComputeContext();
                    return context == null ? "OpenCL NULL Device" : context.Devices[0].Name.Trim();
                default:
                    return "Unknown Device";
            }
        }
        internal static bool IsLiveEditEnabled()
        {
            return GetInstance().m_EnableLiveEdit;
        }
        static GameObject s_RuntimeHelper;
        internal static void InitializeRuntimeHelper()
        {            
            if (!s_RuntimeHelper)
            {
                var runtimeHelperType = Type.GetType("Thinksquirrel.Fluvio.Internal.FluvioRuntimeHelper, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null") ??
                                        Type.GetType("Thinksquirrel.Fluvio.Internal.FluvioRuntimeHelper, Assembly-CSharp-firstpass, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");

                if (runtimeHelperType != null)
                {
                    var go = GameObject.Find("Fluvio Runtime Helper");

                    if (!go)
                        go = new GameObject("Fluvio Runtime Helper") { hideFlags = HideFlags.HideAndDontSave };
                    else
                        go.hideFlags = HideFlags.HideAndDontSave;

                    var components = go.GetComponents<Component>();
                    for (var i = 0; i < components.Length; ++i)
                    {
                        if (components[i]) continue;

                        // Some component on the object is invalid                        
                        DestroyImmediate(go);
                        go = new GameObject("Fluvio Runtime Helper") { hideFlags = HideFlags.HideAndDontSave };
                        DontDestroyOnLoad(go);
                        break;
                    }

                    if (!go.GetComponent(runtimeHelperType))
                    {
                        go.AddComponent(runtimeHelperType);
                    }

                    s_RuntimeHelper = go;
                }
            }
        }
        /// <summary>
        ///     Enables or disables timers. This should be disabled for release builds.
        /// </summary>
        /// <remarks>
        ///    The FluidDebug plugin enables this by default.
        /// </remarks>
        public static bool enableTimers { get; set; }
        //! \cond PRIVATE
        public static FluvioSettings GetFluvioSettingsObject()
        {
            return GetInstance(false, false);
        }
        public static void SetFluvioSettingsObject(FluvioSettings obj)
        {
            s_Instance = obj;
        }
        //! \endcond
        #endregion
        //! \cond PRIVATE
        protected override void OnEnable()
        {
            base.OnEnable();

            name = "FluvioManager";
            isEditor = Application.isEditor;
            s_SetIsEditor = true;
        }
        protected override void OnDisable()
        {
            base.OnDisable();

            s_Instance = null;
            s_CreatingInstance = false;
        }
        protected override void Reset()
        {
            base.Reset();

            name = "FluvioManager";
            if (onReset != null) onReset();
        }
        //! \endcond
        internal static event System.Action onReset;
        internal static bool isEditor { get; private set; }
        private static bool s_SetIsEditor;
        internal static FluvioSettings GetInstance(bool showWarning = true, bool safe = true)
        {
            if (!s_SetIsEditor && !safe)
            {
                isEditor = Application.isEditor;
                s_SetIsEditor = true;
            }
            if (HasResource(isEditor && !safe))
            {
                return s_Instance;
            }
            
            // Stop recursion
            if (s_CreatingInstance)
            {
                return s_Instance;
            }

            s_CreatingInstance = true;
            s_Instance = CreateInstance<FluvioSettings>();
            s_CreatingInstance = false;

            s_Instance.name = "FluvioManager";
                        
            if (showWarning)
            {
                FluvioDebug.LogWarning("FluvioSettings object is missing, creating a new one", s_Instance);
            }

            return s_Instance;
        }
        internal static bool HasResource(bool forceCheck = false)
        {
            // ReSharper disable once RedundantCast
            if (!s_Instance || forceCheck)
            {
                s_Instance = Resources.Load("FluvioManager", typeof (FluvioSettings)) as FluvioSettings;        
            }

            // ReSharper disable once RedundantCast.0
            return s_Instance != null;
        }
        internal static int GetSortingLayerIndex(int id)
        {
            var arr = GetInstance().m_SortingLayerUniqueIDs;
            if (arr == null) return 0;
            var index = Array.IndexOf(arr, id);
            return index < 0 ? 0 : index;
        }
    }
}
