using System;
using System.Runtime.InteropServices;
using Cloo;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal
{
    internal abstract class FluvioComputeBufferBase : IDisposable
    {
        [NonSerialized] int m_Count;
        [NonSerialized] int m_Stride;
        [NonSerialized] internal bool _readWrite;
        [NonSerialized] internal Type _bufferType;
        [NonSerialized] internal ComputeAPI _computeAPI;        
        [NonSerialized] internal ComputeBuffer _computeBufferNative;
        [NonSerialized] internal ComputeMemory _computeBufferOpenCL;
        
        public int count
        {
            get { return m_Count; }
            protected set { m_Count = value; }
        }

        public int stride
        {
            get { return m_Stride; }
            protected set { m_Stride = value; }
        }

        protected FluvioComputeBufferBase(int count, bool readWrite, Type bufferType)
        {
            m_Count = count;
            m_Stride = Marshal.SizeOf(bufferType);
            _readWrite = readWrite;
            _bufferType = bufferType;
            _computeAPI = FluvioSettings.GetCurrentComputeAPI();

            Initialize();
        }
        protected void Initialize()
        {
            _computeAPI = FluvioSettings.GetCurrentComputeAPI();

            switch (_computeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (_computeBufferOpenCL != null)
                    {
                        _computeBufferOpenCL.Dispose();
                        _computeBufferOpenCL = null;
                    }
                    if (_computeBufferNative == null) _computeBufferNative = new ComputeBuffer(count, stride);
                    break;
                case ComputeAPI.OpenCL:
                    if (_computeBufferNative != null)
                    {
                        _computeBufferNative.Dispose();
                        _computeBufferNative = null;
                    }
                    if (_computeBufferOpenCL != null && !Equals(_computeBufferOpenCL.Context, FluvioOpenCL.GetComputeContext()))
                    {
                        _computeBufferOpenCL.Dispose();
                        _computeBufferOpenCL = null;
                    }
                    if (_computeBufferOpenCL == null)
                    {
                        try
                        {
                            _computeBufferOpenCL = CreateOpenCLBuffer();
                            FluvioOpenCL._buffers.Add(this);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Dispose();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }

        protected abstract ComputeMemory CreateOpenCLBuffer();

        public abstract void Dispose();
    }

    internal sealed class FluvioComputeBuffer<T> : FluvioComputeBufferBase where T : struct
    {
        public FluvioComputeBuffer(int count, bool readWrite = false) : base(count, readWrite, typeof(T)) {}

        public void GetData(T[] data)
        {
            switch (_computeAPI)
            {
                case ComputeAPI.UnityNative:
                    if (_computeBufferNative != null) _computeBufferNative.GetData(data);
                    break;
                case ComputeAPI.OpenCL:
                    if (_computeBufferOpenCL != null)
                    {
                        try
                        {
                            var queue = FluvioOpenCL.GetCommandQueue();
                            if (Equals(queue.Context, _computeBufferOpenCL.Context))
                                queue.ReadFromBuffer((ComputeBuffer<T>)_computeBufferOpenCL, ref data, true, null);
                        }
                        catch (Exception e)
                        {
                            FluvioDebug.LogException(e);
                            Dispose();
                            FluvioOpenCL.Cleanup(true);
                        }
                    }
                    break;
            }
        }

        public void SetData(T[] data)
        {
            Initialize();
          
            switch (_computeAPI)
            {
                case ComputeAPI.UnityNative:
                    _computeBufferNative.SetData(data);
                    break;
                case ComputeAPI.OpenCL:
                    try
                    {
                        var queue = FluvioOpenCL.GetCommandQueue();
                        // BUG: Asynchronous calls on some OpenCL implementations will continue allocating (and not freeing) events. As a result, asynchronous writes are disabled for now. TODO: See if this can be worked around with a temporary event
                        // https://www.khronos.org/bugzilla/show_bug.cgi?id=427
                        if (Equals(queue.Context, _computeBufferOpenCL.Context))
                            queue.WriteToBuffer(data, (ComputeBuffer<T>)_computeBufferOpenCL, true, null);
                    }
                    catch (Exception e)
                    {
                        FluvioDebug.LogException(e);
                        Dispose();
                        FluvioOpenCL.Cleanup(true);
                    }
                    break;
            }
        }
        protected override ComputeMemory CreateOpenCLBuffer()
        {
            var flags = _readWrite ? ComputeMemoryFlags.ReadWrite : ComputeMemoryFlags.ReadOnly;
            return new ComputeBuffer<T>(FluvioOpenCL.GetComputeContext(), flags, count);
        }
        public override void Dispose()
        {
            //FluvioDebug.Log("Disposing OpenCL compute buffer", "Fluvio", "FluvioComputeBuffer");

            if (_computeBufferNative != null)
            {
                _computeBufferNative.Dispose();
                _computeBufferNative = null;            
            }
            if (_computeBufferOpenCL != null)
            {
                _computeBufferOpenCL.Dispose();
                _computeBufferOpenCL = null;
            }

            FluvioOpenCL._buffers.Remove(this);
            FluvioOpenCL.Cleanup();
            GC.SuppressFinalize(this);
        }

        ~FluvioComputeBuffer()
        {
            if (_computeBufferOpenCL != null || _computeBufferNative != null)
            {
                FluvioDebug.LogError("Compute buffer leaked!", this);
                Dispose();
            }
        }
    }
}
