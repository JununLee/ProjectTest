// FluidGroup.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Provides a manual override of a fluid group for multi-fluid simulation.
    /// </summary>
    /// <remarks>
    ///     By default, fluid groups are formed when fluids are in the same hierarchy. This component can be used to create custom groups out
    ///     of one or more hierarchies or other object setups.
    /// </remarks>
    [AddComponentMenu("Fluvio/Fluid Group", -5)]
    [ExecuteInEditMode]
    public sealed class FluidGroup : FluvioMonoBehaviourBase, IEnumerable<FluidBase>
    {
        [SerializeField] FluidBase m_ParentFluid;
        // ReSharper disable once FieldCanBeMadeReadOnly.Local
        [SerializeField] List<FluidBase> m_SubFluids = new List<FluidBase>();

        //! \cond PRIVATE
        protected override void OnEnable()
        {
            base.OnEnable();
            
            Validate();

            if (m_ParentFluid) m_ParentFluid.SetFluidGroup(this);
            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                if (subFluid) subFluid.SetFluidGroup(this);
            }
        }
        protected override void OnDisable()
        {
            base.OnDisable();

            if (m_ParentFluid) m_ParentFluid.SetFluidGroup(null);
            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                if (subFluid) subFluid.SetFluidGroup(null);
            }
        }
        //! \endcond

        void Validate()
        {
            var fluidCollider = parentFluid as FluidColliderBase;

            if (fluidCollider)
            {
                FluvioDebug.LogError("Parent fluids cannot be fluid colliders.", this);
                parentFluid = null;
            }

            for (var i = m_SubFluids.Count - 1; i >= 0; --i)
            {
                var subFluid = m_SubFluids[i];

                if (subFluid == m_ParentFluid && m_ParentFluid != null)
                {
                    if (Application.isEditor)
                    {
                        m_SubFluids[i] = null;
                    }
                    else
                    {
                        m_SubFluids.RemoveAt(i);
                    }
                    FluvioDebug.LogError("Parent fluids cannot also be sub-fluids.", this);
                    continue;
                }

                for (var j = i - 1; j >= 0; --j)
                {
                    var compareFluid = m_SubFluids[j];

                    if (Application.isEditor)
                    {
                        if (subFluid == compareFluid && compareFluid != null)
                        {
                            m_SubFluids[j] = null;
                            FluvioDebug.LogError("Duplicate sub-fluids are not allowed.", this);
                        } 
                    }
                    else
                    {
                        if (subFluid == compareFluid || compareFluid == null)
                        {
                            m_SubFluids.RemoveAt(j);
                            if (compareFluid != null) FluvioDebug.LogError("Duplicate sub-fluids are not allowed.", this);
                        }
                    }
                }
            }
        }
        internal void ReloadFluidGroup()
        {
            OnDisable();
            OnEnable();
        }

        /// <summary>
        ///     The parent fluid of the fluid group.
        /// </summary>
        /// <remarks>
        ///     With multi-fluid simulation, some physical properties must be applied to all fluids within a group. The parent fluid controls these properties.
        /// </remarks>
        public FluidBase parentFluid
        {
            get { return m_ParentFluid; }
            set
            {
                if (!value)
                {
                    FluvioDebug.LogError("Attempting to set a destroyed or null parent fluid. This is not allowed.", this);
                    return;
                }
                var fluidCollider = value as FluidColliderBase;
                if (fluidCollider)
                {
                    FluvioDebug.LogError("Parent fluids cannot be fluid colliders.", this);
                    return;
                }
                if (m_SubFluids.Contains(value))
                {
                    FluvioDebug.LogError("Parent fluids cannot also be sub-fluids.", this);
                    return;
                }                
                if (m_ParentFluid) m_ParentFluid.SetFluidGroup(null);
                m_ParentFluid = value;
                if (m_ParentFluid) m_ParentFluid.SetFluidGroup(this);
            }
        }
        /// <summary>
        ///     Returns the total number of sub-fluids in the fluid group.
        /// </summary>
        public int subFluidCount { get { return m_SubFluids.Count; } }

        IEnumerable<FluidBase> AsEnumerable()
        {
            yield return parentFluid;
            for (var i = 0; i < m_SubFluids.Count; i++)
            {
                yield return m_SubFluids[i];
            }
        }
        /// <summary>
        ///     Returns an enumerator that iterates through the fluid group (generic version).
        /// </summary>
        /// <returns>An enumerator for the fluid group.</returns>
        public IEnumerator<FluidBase> GetEnumerator()
        {
            return AsEnumerable().GetEnumerator();
        }
        /// <summary>
        ///     Returns an enumerator that iterates through the fluid group.
        /// </summary>
        /// <returns>An enumerator for the fluid group.</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        /// <summary>
        ///     Adds a sub-fluid to the fluid group.
        /// </summary>
        /// <param name="fluid">The sub-fluid to add to the fluid group.</param>
        /// <returns>True if the sub-fluid was added; otherwise false.</returns>
        public bool AddSubFluid([NotNull] FluidBase fluid)
        {
            if (!fluid)
            {
                FluvioDebug.LogError("Attempting to add a destroyed or null sub-fluid. This is not allowed.", this);
                return false;
            }
            if (fluid == m_ParentFluid)
            {
                FluvioDebug.LogError("Parent fluids cannot also be sub-fluids.", this);
                return false;
            }

            if (m_SubFluids.Contains(fluid))
            {
                FluvioDebug.LogError("Duplicate sub-fluids are not allowed.", this);
                return false;
            }

            m_SubFluids.Add(fluid);
            fluid.SetFluidGroup(this);
            return true;
        }
        /// <summary>
        ///     Remove all sub-fluids from the fluid group.
        /// </summary>
        public void ClearSubFluids()
        {
            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                if (subFluid) subFluid.SetFluidGroup(null);
            }
            m_SubFluids.Clear();
        }
        /// <summary>
        ///     Determines whether or not the fluid group contains the specified fluid.
        /// </summary>
        /// <param name="fluid">The fluid to search for.</param>
        /// <returns>True if the fluid group contains the fluid; otherwise false.</returns>
        public bool Contains(FluidBase fluid)
        {
            if (!fluid) return false;
            return fluid == m_ParentFluid || m_SubFluids.Contains(fluid);
        }
        /// <summary>
        ///     Removes a sub-fluid from the fluid group.
        /// </summary>
        /// <param name="fluid">The fluid to remove from the fluid group.</param>
        /// <returns>True if the remove operation was successful; otherwise false.</returns>
        public bool RemoveSubFluid([NotNull] FluidBase fluid)
        {
            if (!fluid) return false;
            if (fluid) fluid.SetFluidGroup(null);
            return m_SubFluids.Remove(fluid);
        }
    }
}
