// FluidParticlePairPlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     Base class for all fluid plugins that operate on particle pairs.
    /// </summary>
    public abstract class FluidParticlePairPlugin : FluidParallelPlugin
    {
        #region Abstract, Virtual, and Override
        /// <summary>
        ///     Provides an update method for the fluid plugin. If the fluid and plugin are hardware accelerated, this method will not be executed.
        /// </summary>
        /// <param name="solverData">Solver data for the current simulation. This can be used to modify forces and other physical parameters.</param>
        /// <param name="particleIndex">The current particle index for the update.</param>
        /// <param name="neighborIndex">The current neighbor index for the update.</param>
        /// <remarks>
        ///     This method provides internal solver data, along with the indices of a particle and its neighbor.
        ///     Because this method may run on multiple threads along with other plugins, the neighbor particle should
        ///     NOT be modified. Each pair will execute twice (A -> B and B -> A). Also note that neighbor information may
        ///     not be up to date (it may be modified on another thread at any time). It is recommended to access each neighbor
        ///     property only once, in order to keep physical consistency and reduce potential numerical errors.
        /// </remarks>
        protected abstract void OnUpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex);
        internal override bool IsPairPlugin()
        {
            return true;
        }
        internal override void UpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex)
        {
            OnUpdatePlugin(solverData, particleIndex, neighborIndex);
        }
        #endregion
    }
}
