// Poly6Kernel.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    sealed class Poly6Kernel : SmoothingKernel
    {
        #region Public API
        public Poly6Kernel() {}
        public Poly6Kernel(float kernelSize) : base(kernelSize) {}
        #endregion

        #region Abstract, Virtual, and Override
        public override float Calculate(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var diffSq = kernelSizeSq - lenSq;
            return factor*diffSq*diffSq*diffSq;
        }
        public override Vector4 CalculateGradient(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var diffSq = kernelSizeSq - lenSq;
            var f = -factor*6.0f*diffSq*diffSq; // 6.0 to convert 315/64 to 945/32
            return new Vector3(distance.x*f, distance.y*f, distance.z*f);
        }
        public override float CalculateLaplacian(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var diffSq = kernelSizeSq - lenSq;
            var f = lenSq - (0.75f*diffSq);
            return factor*24.0f*diffSq*diffSq*f; // 24.0 to convert 315/64 to 945/8
        }
        protected override void CalculateFactor()
        {
            // Factor
            factor = (315.0f/(64.0f*Mathf.PI*kernelSize9));
        }
        #endregion
    }
}
