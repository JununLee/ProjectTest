// SpikyKernel.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    sealed class SpikyKernel : SmoothingKernel
    {
        #region Public API
        public SpikyKernel() {}
        public SpikyKernel(float kernelSize) : base(kernelSize) {}
        #endregion

        #region Abstract, Virtual, and Override
        public override float Calculate(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var f = kernelSize - Mathf.Sqrt(lenSq);
            return factor*f*f*f;
        }
        public override Vector4 CalculateGradient(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var len = Mathf.Sqrt(lenSq);
            var f = -factor*3.0f*(kernelSize - len)*(kernelSize - len)/len; // 3.0 to convert 15/1 to 45/1
            return new Vector4(distance.x*f, distance.y*f, distance.z*f);
        }
        public override float CalculateLaplacian(ref Vector4 distance)
        {
            throw new NotImplementedException();
        }
        protected override void CalculateFactor()
        {
            // Factor
            factor = (15.0f/(Mathf.PI*kernelSize6));
        }
        #endregion
    }
}
