// FluidParticlePlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     Base class for all fluid plugins that operate on particles.
    /// </summary>
    public abstract class FluidParticlePlugin : FluidParallelPlugin
    {
        #region Public API
        /// <summary>
        /// Get a random float from a seed value. Suitable for parallel access.
        /// </summary>
        /// <param name="seed">The seed to use.</param>
        /// <returns>A random [0-1] float.</returns>
        public static float RandomFloat(uint seed)
        {
            float f = WangHash(seed);
            return f*(1.0f/4294967295.0f); // 2^32 - 1
        }
        static uint WangHash(uint seed)
        {
            // Pseudo random number generator - hash method by Thomas Wang
            seed = (seed ^ 61) ^ (seed >> 16);
            seed *= 9;
            seed = seed ^ (seed >> 4);
            seed *= 0x27d4eb2d;
            seed = seed ^ (seed >> 15);
            return seed;
        }
        #endregion

        #region Abstract, Virtual, and Override
        /// <summary>
        ///     Provides an update method for the fluid plugin. If the fluid and plugin are hardware accelerated, this method will
        ///     not be executed.
        /// </summary>
        /// <param name="solverData">Solver data for the current simulation. This can be used to modify forces and other physical parameters.</param>
        /// <param name="particleIndex">The current particle index for the update.</param>
        /// <remarks>
        ///     This method provides internal solver data, along with the index of a particle.
        ///     This method may run on multiple threads - arrays should be modified only at the particle index.
        /// </remarks>
        protected abstract void OnUpdatePlugin(SolverData solverData, int particleIndex);
        internal override bool IsPairPlugin()
        {
            return false;
        }
        internal override void UpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex)
        {
            OnUpdatePlugin(solverData, particleIndex);
        }
        #endregion
    }
}
