// LockFreeQueue.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
#pragma warning disable 420
using System.Collections.Generic;
using System.Threading;
using System.Collections;

//! \cond PRIVATE
namespace Thinksquirrel.Fluvio.Internal.Threading
{
    public class LockFreeQueue : IEnumerable<Action>
    {
        #region Instance Fields
        volatile object m_Head;
        volatile object m_Tail;
        #endregion

        Node head { get { return (Node)m_Head; } }
        Node tail { get { return (Node)m_Tail; } }
        

        #region Public API
        
        public int count
        {
            get
            {
                int c;
                EvaluateCount(x => false, out c);
                return c;
            }
        }
        public bool isEmpty
        {
            get { return head._next == null; }
        }
        public int unsafeCount
        {
            get { return tail.id - head.id; }
        }
        public void Clear()
        {
            while (!isEmpty)
                Dequeue();
        }
        public Action Dequeue()
        {
            // keep spinning until we catch the propper head.
            while (true)
            {
                var localHead = head;
                var localNext = localHead.next;
                var localTail = tail;

                // if the queue is empty then return the default for that
                // typeparam.
                if (localNext == null)
                {
                    return null;
                }
                if (localHead == localTail)
                {
                    // our tail is lagging behind so we need to swing it.
                    Interlocked.CompareExchange(ref m_Tail, localHead, localTail);
                }
                else
                {
                    localNext._previous = localHead._previous;

                    // if no other thread changed the head then we are good to
                    // go and we can return the local value;
                    if (Interlocked.CompareExchange(
                        ref m_Head, localNext, localHead) == localHead)
                    {
                        return localNext.val;
                    }
                }
            }
                
        }
        public Action DequeueLast()
        {
            // ReSharper disable TooWideLocalVariableScope
            Node localTail;
            Node localPrevious;
            // ReSharper restore TooWideLocalVariableScope
            
            var swapNode = new Node();

            do
            {
                //get the tail.
                localTail = GetTail();
                localPrevious = localTail.previous;

                // ReSharper disable ConditionIsAlwaysTrueOrFalse
                // ReSharper disable HeuristicUnreachableCode                
                if (localPrevious == null)
                    return default(Action);
                if (localPrevious._previous == null)
                    return default(Action);
                if (localPrevious._previous == m_Head)
                    return default(Action);
                if (localTail == null)
                    return default(Action);
                // ReSharper restore HeuristicUnreachableCode
                // ReSharper restore ConditionIsAlwaysTrueOrFalse

                // Set the swap node values that will exchange the element
                // in a sense that it will skip right through it.
                swapNode._next = localTail._next;
                swapNode._previous = localPrevious._previous;
                swapNode.val = localPrevious.val;
                swapNode.id = localPrevious.id;
            } // In order for this to be actually *thread safe* we need to subscribe ourselves
                // to the same logic as the enqueue and create a blockade by setting the next value
                // of the tail!
            while (Interlocked.CompareExchange(ref localTail._next, localTail, null) != null);

            // do a double exchange, if we get interrupted between we should be still fine as,
            // all we need to do after the first change is to swing the previous element to point at the
            // correct tail.
            Interlocked.CompareExchange(ref m_Tail, swapNode, m_Tail);
            Interlocked.CompareExchange(ref tail.previous._next, swapNode, tail.previous._next);

            return localTail.val;
        }
        public void Enqueue(Action obj)
        {
            Node localTail;
            var newNode = new Node {val = obj};

            TryResetCounter();

            do
            {
                //get the tail.
                localTail = GetTail();

                //TODO: This should be atomic.
                newNode._next = localTail._next;
                newNode.id = localTail.id + 1;
                newNode._previous = localTail;
            } // if we aren't null, then this means that some other
                // thread interfered with our plans (sic!) and we need to
                // start over.
            while (Interlocked.CompareExchange(
                ref localTail._next, newNode, null) != null);
            // if we finally are at the tail and we are the same,
            // then we switch the values to the new node, phew! :)
            Interlocked.CompareExchange(ref m_Tail, newNode, localTail);
        }
        public bool EvaluateCount(Predicate<int> value)
        {
            int c;
            return EvaluateCount(value, out c);
        }
        public bool TryPeek(out Action value)
        {
            var currentNode = head.next;

            if (currentNode == null)
            {
                value = default(Action);
                return false;
            }
            value = currentNode.val;
            return true;
        }
        public LockFreeQueue()
        {
            m_Head = new Node();
            m_Tail = new Node();
            m_Head = m_Tail;
        }
        #endregion

        #region IEnumerable<Action> Implementation
        public IEnumerator<Action> GetEnumerator()
        {
            var currentNode = head.next;
            var localTail = GetTail();

            while (currentNode != null)
            {
                yield return currentNode.val;

                if (currentNode == localTail)
                    break;

                currentNode = currentNode.next;
            }
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<Action>) this).GetEnumerator();
        }
        #endregion

        bool EvaluateCount(Predicate<int> value, out int actualCount)
        {
            var c = 0;
            for (var current = head.next;
                 current != null;
                 current = current.next)
            {
                c++;

                if (!value(c)) continue;
                
                actualCount = c;
                return true;
            }
            actualCount = c;
            return false;
        }
        Node GetTail()
        {
            var localTail = tail;
            var localNext = localTail._next;

            //if some other thread moved the tail we need to set to the right position.
            while (localNext != null)
            {
                //set the tail.
                Interlocked.CompareExchange(ref m_Tail, localNext, localTail);
                localTail = tail;
                localNext = localTail._next;
            }

            return tail;
        }
        void TryResetCounter()
        {
            if (tail.id < short.MaxValue) return;
            
            var res = (tail.id - head.id);
            head.id = 0;
            tail.id = res;
        }

        #region Nested type: Node
        class Node
        {
            #region Public API
            public int id;
            internal volatile object _next;
            internal volatile object _previous;

            public Node next
            {
                get { return (Node) _next; }
            }

            public Node previous
            {
                get { return (Node) _previous; }
            }
            public Action val;
            #endregion
        }
        #endregion
    }
}
//! \endcond
