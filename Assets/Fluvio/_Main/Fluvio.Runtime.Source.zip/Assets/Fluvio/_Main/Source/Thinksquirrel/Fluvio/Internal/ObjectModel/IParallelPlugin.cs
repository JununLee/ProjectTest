// IParallelPlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using Thinksquirrel.Fluvio.Plugins;

namespace Thinksquirrel.Fluvio.Internal.ObjectModel
{
    interface IParallelPlugin : IFluidPlugin
    {
        #region Abstract, Virtual, and Override
        void EndPluginFrame();
        void StartPluginFrame(ref FluvioTimeStep timeStep);
        void PluginPostSolve();
        void UpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex);
        bool includeFluidGroup { get; }
        bool isPairPlugin { get; }
        bool shouldUpdate { get; }
        #endregion
    }
}
