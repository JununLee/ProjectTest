// Enums.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Controls whether or not a fluid uses 2D or 3D simulation.
    /// </summary>
    /// <remarks>
    ///     2D fluid simulation can be much faster and more memory efficient than 3D fluid simulation.
    /// </remarks>
    public enum SimulationDimensions
    {
        /// <summary>
        ///     Use 3D fluid simulation.
        /// </summary>
        Fluid3D = 0,
        /// <summary>
        ///     Use 2D fluid simulation.
        /// </summary>
        Fluid2D = 1
    }
    
    /// <summary>
    ///     Controls whether or not the fluid is dynamic, kinematic, or static.
    /// </summary>
    public enum FluidType
    {
        /// <summary>
        ///     Dynamic fluids will have forces applied to them by the solver. Their positions/velocities can also be updated externally.
        /// </summary>
        Dynamic = 0,
        /// <summary>
        ///     Kinematic fluids will not have forces applied to them by the solver. Their positions/velocities can be updated externally.
        /// </summary>
        Kinematic = 1,
        /// <summary>
        ///     Static fluids will not have forces applied to them and cannot be updated externally.
        /// </summary>
        Static = 2
    }
    /// <summary>
    ///     Defines a compute API for hardware acceleration.
    /// </summary>
    public enum ComputeAPI
    {
        /// <summary>
        ///     Represents disabled hardware acceleration or no hardware acceleration available.
        /// </summary>
        None = 0,
        /// <summary>
        ///     OpenCL, or the Open Computing Language. This is an open hardware acceleration platform that can run on the GPU or CPU in various forms.
        /// </summary>
        OpenCL = 1,
        /// <summary>
        ///     Unity's native compute shader pipeline.
        /// </summary>
        UnityNative = 2
    }
    //! \cond PRIVATE
    [Obsolete("Use the ComputeAPI enum instead")]
    public enum HardwareAccelerationType
    {
        /// <summary>
        ///     Represents disabled hardware acceleration or no hardware acceleration available.
        /// </summary>
        None = 0,
        /// <summary>
        ///     OpenCL, or the Open Computing Language. This is an open hardware acceleration platform that can run on the GPU or CPU in various forms.
        /// </summary>
        OpenCL = 1,
        /// <summary>
        ///     Represents Unity's native compute shader pipeline.
        /// </summary>
        UnityNative = 2
    }
    //! \endcond
    
    /// <summary>
    ///     For OpenCL, controls the desired acceleration device type. This maps to CL_DEVICE_TYPE in the underlying OpenCL driver.
    /// </summary>
    public enum OpenCLDeviceType
    {
        /// <summary>
        ///     An OpenCL device that is the host processor.
        /// </summary>
        CPU = 2,
        /// <summary>
        ///     An OpenCL device that is a GPU. By this we mean that the device can also be used to accelerate a 3D API such as OpenGL or DirectX.
        /// </summary>
        GPU = 4,
        /// <summary>
        ///     Dedicated OpenCL accelerators (for example the IBM CELL Blade). These devices communicate with the host processor using a peripheral interconnect such as PCIe.
        /// </summary>
        Accelerator = 8
    }
    /// <summary>
    ///     Controls how fluid simulation is culled.
    /// </summary>
    public enum SimulationCullingType
    {
        /// <summary>
        ///     Always simulate the fluid, even when offscreen.
        /// </summary>
        AlwaysSimulate = 0,
        /// <summary>
        ///     Pause simulation when renderers are not visible.
        /// </summary>
        BasedOnRenderers = 1
    }

    /// <summary>
    ///     Controls how the bounds for fluid colliders are calculated.
    /// </summary>
    public enum FluidColliderBoundsType
    {
        /// <summary>
        ///     Calculates collider bounds automatically.
        /// </summary>
        Automatic = 0,
        /// <summary>
        ///     Allows the specification of one or more bounding boxes where collider particles can be created.
        /// </summary>
        Manual = 1
    }
    /// <summary>
    ///     Controls the type of force that an effector uses.
    /// </summary>
    public enum FluidEffectorForceType
    {
        /// <summary>
        ///     Radial forces push or pull particles relative to an effector's center.
        /// </summary>
        Radial = 0,
        /// <summary>
        ///     Directional forces pull particles in the specified local space direction.
        /// </summary>
        Directional = 1
    }
    /// <summary>
    ///     Controls the local axis of an effector's force when using directional forces.
    /// </summary>
    public enum FluidEffectorForceAxis
    {
        /// <summary>
        ///     Apply the directional force in the local X axis.
        /// </summary>
        X = 0,
        /// <summary>
        ///     Apply the directional force in the local Y axis.
        /// </summary>
        Y = 1,
        /// <summary>
        ///     Apply the directional force in the local Z axis.
        /// </summary>
        Z = 2
    }
    /// <summary>
    ///     Controls how particles in an effector will decay.
    /// </summary>
    public enum FluidEffectorDecayType
    {
        /// <summary>
        ///     Don't decay particles or affect their lifetime in any way.
        /// </summary>
        None = 0,
        /// <summary>
        ///     Keep particles within the effector's area alive (pause particle lifetime).
        /// </summary>
        KeepAlive = 1,
        /// <summary>
        ///     Decay particles based on the effector's decay and decay jitter properties.
        /// </summary>
        Decay
    }

    /// <summary>
    ///     Controls the state of a fluid curve. Used in various fluid plugins.
    /// </summary>
    public enum FluvioMinMaxCurveState
    {
        /// <summary>
        ///     Sample a constant value.
        /// </summary>
        Constant = 0,
        /// <summary>
        ///     Sample a single curve.
        /// </summary>
        Curve = 1,
        /// <summary>
        ///     Sample a random value between two constants.
        /// </summary>
        RandomBetweenTwoConstants = 2,
        /// <summary>
        ///     Sample a random value between two curves.
        /// </summary>
        RandomBetweenTwoCurves = 3
    }

    /// <summary>
    ///     Controls the state of a fluid gradient. Used in various fluid plugins.
    /// </summary>
    public enum FluvioMinMaxGradientState
    {
        /// <summary>
        ///     Sample a constant color.
        /// </summary>
        Color = 0,
        /// <summary>
        ///     Sample a single gradient.
        /// </summary>
        Gradient = 1,
        /// <summary>
        ///     Sample a random color between two colors.
        /// </summary>
        RandomBetweenTwoColors = 2,
        /// <summary>
        ///     Sample a random color between two gradients.
        /// </summary>
        RandomBetweenTwoGradients = 3
    }

    /// <summary>
    /// The priority of threads in Fluvio. Only supported on platforms that allow multithreading and changing of thread priority. This maps to System.Thread.ThreadPriority.
    /// </summary>
    public enum FluvioThreadPriority
    {
        /// <summary>
        /// The thread can be scheduled after threads with Highest priority and before those with Normal priority.
        /// </summary>
        Lowest,
        /// <summary>
        /// The thread can be scheduled after threads with Normal priority and before those with Lowest priority.
        /// </summary>
        BelowNormal,
        /// <summary>
        /// The thread can be scheduled before threads with any other priority.
        /// </summary>
        Normal,
        /// <summary>
        /// The thread can be scheduled after threads with any other priority.
        /// </summary>
        AboveNormal,
        /// <summary>
        /// The thread can be scheduled after threads with AboveNormal priority and before those with BelowNormal priority. Threads have Normal priority by default.
        /// </summary>
        Highest,
    }
}
