// AssemblyInfo.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System.Runtime.CompilerServices;
using UnityEngine;

#if FLUVIO_DEVELOPMENT
[assembly: InternalsVisibleTo("Assembly-CSharp-Editor")]
#endif

[assembly: InternalsVisibleTo("Fluvio.Editor")]

#if UNITY_5_0_PLUS
[assembly: UnityAPICompatibilityVersion("5.0.0f4")]
[assembly: UnityAPICompatibilityVersion("5.0.1f1")]
[assembly: UnityAPICompatibilityVersion("5.0.2f1")]
[assembly: UnityAPICompatibilityVersion("5.0.3f2")]
[assembly: UnityAPICompatibilityVersion("5.1.0f3")]
[assembly: UnityAPICompatibilityVersion("5.1.2f1")]
#endif
