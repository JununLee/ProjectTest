// FluvioColors.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using Thinksquirrel.Fluvio.Plugins;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal
{
    static class FluvioColors
    {
        #region Static and Constant Fields
        internal static readonly Color s_FluidColor = new Color(0.4f, 0.75f, 1.0f, 0.25f);
        internal static readonly Color s_FluidColliderColor = new Color(0.4f, 1.0f, 1.0f, 0.8f);
        internal static readonly Color s_PluginColor = new Color(1.0f, 0.35f, 0.0f, 1.0f);
        internal static readonly Color s_PluginColorDisabled = new Color(1.0f, 0.35f, 0.0f, 0.25f);
        internal static readonly Color s_PluginColorAlt = new Color(1.0f, 0.1f, 0.0f, 1.0f);
        internal static readonly Color s_PluginColorAltDisabled = new Color(1.0f, 0.1f, 0.0f, 0.25f);
        #endregion

        #region Public API
        public static Color GetColor(FluvioMonoBehaviourBase obj, bool altColor = false)
        {
            var plugin = obj as FluidPlugin;

            if (plugin)
            {
                if (altColor)
                {
                    return FluvioMonoBehaviourBase.IsValid(plugin) ? s_PluginColorAlt : s_PluginColorAltDisabled;
                }
                return FluvioMonoBehaviourBase.IsValid(plugin) ? s_PluginColor : s_PluginColorDisabled;
            }

            return Color.white;
        }
        #endregion
    }
}
