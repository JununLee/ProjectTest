// IFluidPlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

namespace Thinksquirrel.Fluvio.Internal.ObjectModel
{
    interface IFluidPlugin
    {
        #region Abstract, Virtual, and Override
        FluidBase fluid { get; }
        int weight { get; }
        #endregion
    }
}
