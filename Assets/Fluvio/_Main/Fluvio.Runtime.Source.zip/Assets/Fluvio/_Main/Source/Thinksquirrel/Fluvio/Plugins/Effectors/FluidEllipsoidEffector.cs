// FluidEllipsoidEffector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins.Effectors
{
    /// <summary>
    ///     Defines an ellipsoid shaped effector.
    /// </summary>
    [AddComponentMenu("Fluvio/Plugins/Effectors/Ellipsoid Effector")]
    public sealed class FluidEllipsoidEffector : FluidEffector
    {
        #region Serialized Fields
        [SerializeField] Vector3 m_Dimensions;
        #endregion

        #region Public API
        /// <summary>
        ///     The dimensions (in local space) of the ellipsoid.
        /// </summary>
        public Vector3 dimensions
        {
            get { return m_Dimensions; }
            set { m_Dimensions = value; }
        }
        #endregion

        #region Abstract, Virtual, and Override
        protected override void OnResetPlugin()
        {
            base.OnResetPlugin();

            m_Dimensions = Vector3.one;
        }
        protected override void OnEnablePlugin()
        {
            SetComputeShader(FluvioComputeShader.Find("ComputeShaders/Plugins/FluidEffector"), "OnUpdatePlugin_EllipsoidEffector");
        }
        protected override Vector4 GetExtents()
        {
            return m_Dimensions*0.5f;
        }
        protected override bool IsInEffector(ref Vector3 queryPosition)
        {
            var p = _worldToLocalMatrix.MultiplyPoint3x4(queryPosition) - GetPosition();
            var d = m_Dimensions*.5f;

            // (x/a)^2 + (y/b)^2 + (z/c)^2 = 1
            return ((p.x/d.x)*(p.x/d.x)) + ((p.y/d.y)*(p.y/d.y)) + ((p.z/d.z)*(p.z/d.z)) <= 1;
        }
        protected override void OnDrawEffectorGizmosSelected()
        {
            Gizmos.color = FluvioColors.GetColor(this);
            Gizmos.matrix = Matrix4x4.TRS(transform.TransformPoint(position), transform.rotation,
                                          Vector3.Scale(transform.lossyScale, dimensions));
            Gizmos.DrawWireSphere(Vector3.zero, 1f);
        }
        #endregion
    }
}
