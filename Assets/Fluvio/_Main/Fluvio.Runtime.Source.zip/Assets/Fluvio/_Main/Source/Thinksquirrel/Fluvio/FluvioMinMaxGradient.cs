using System;
using Thinksquirrel.Fluvio.Plugins;
using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    /// Defines a min-max gradient for fluid plugins.
    /// </summary>
    [Serializable]
    public class FluvioMinMaxGradient
    {
        [SerializeField] Gradient m_MaxGradient = new Gradient();
        [SerializeField] Gradient m_MinGradient = new Gradient();
        [SerializeField] Color m_MinColor = Color.white;
        [SerializeField] Color m_MaxColor = Color.white;
        [SerializeField] FluvioMinMaxGradientState m_MinMaxState;

        /// <summary>
        /// Creates a new min-max gradient.
        /// </summary>
        public FluvioMinMaxGradient()
        {
            SetConstant(Color.white, Color.white, FluvioMinMaxGradientState.Color);
        }

        /// <summary>
        /// The maximum gradient.
        /// </summary>
        public Gradient maxGradient
        {
            get { return m_MaxGradient; }
            set
            {
                ValidateGradient(ref value);
                m_MaxGradient = value;
            }
        }

        /// <summary>
        /// The minimum gradient.
        /// </summary>
        public Gradient minGradient
        {
            get { return m_MinGradient; }
            set
            {
                ValidateGradient(ref value);
                m_MinGradient = value;
            }
        }
        /// <summary>
        /// The maximum color.
        /// </summary>
        public Color maxColor
        {
            get { return m_MaxColor; }
            set { m_MaxColor = value; }
        }
        /// <summary>
        /// The minimum color.
        /// </summary>
        public Color minColor
        {
            get { return m_MinColor; }
            set { m_MinColor = value; }
        }

        /// <summary>
        /// The min-max state of the gradient.
        /// </summary>
        public FluvioMinMaxGradientState minMaxState
        {
            get { return m_MinMaxState; }
            set { m_MinMaxState = value; }
        }

        /// <summary>
        /// Evaluate the min-max gradient.
        /// </summary>
        /// <param name="seed">The random seed to use for gradient evaluation.</param>
        /// <param name="time">The time to evaluate, between 0 and 1.</param>
        /// <returns>The evaluated min-max gradient.</returns>
        public Color Evaluate(uint seed, float time)
        {
            var state = (int) minMaxState;
            var isColor = state%2 == 0;

            var colMax = isColor ? m_MaxColor : m_MaxGradient.Evaluate(time);
            var colMin = state > 1 ? (isColor ? m_MinColor : m_MinGradient.Evaluate(time)) : colMax;
            
            var rand = FluidParticlePlugin.RandomFloat(seed);
            
            return Color.Lerp(colMin, colMax, rand);
        }

        internal void SetConstant(Color min, Color max, FluvioMinMaxGradientState state)
        {
            if (m_MinGradient == null)
                m_MinGradient = new Gradient();

            m_MinGradient.SetKeys(new[] { new GradientColorKey(min, 0.0f),  new GradientColorKey(min, 1.0f) }, new []{ new GradientAlphaKey(min.a, 0.0f), new GradientAlphaKey(min.a, 1.0f) });
            
            if (m_MaxGradient == null)
                m_MaxGradient = new Gradient();

            m_MaxGradient.SetKeys(new[] { new GradientColorKey(max, 0.0f), new GradientColorKey(max, 1.0f) }, new[] { new GradientAlphaKey(max.a, 0.0f), new GradientAlphaKey(max.a, 1.0f) });

            m_MinColor = min;
            m_MaxColor = max;
            m_MinMaxState = state;
        }

        static GradientColorKey[] s_ColorKeyCache = new GradientColorKey[2];
        static GradientAlphaKey[] s_AlphaKeyCache = new GradientAlphaKey[2];
        static GradientColorKey[] s_ColorKeyCache2 = new GradientColorKey[2];
        static GradientAlphaKey[] s_AlphaKeyCache2 = new GradientAlphaKey[2];

        internal void GetCachedGradientsForColors(Color c, Color c2, out GradientColorKey[] colorKeys, out GradientAlphaKey[] alphaKeys, out GradientColorKey[] colorKeys2, out GradientAlphaKey[] alphaKeys2)
        {
            var a = c.a;
            c.a = 1.0f;
            var a2 = c2.a;
            c2.a = 1.0f;

            s_ColorKeyCache[0] = new GradientColorKey(c, 0.0f);
            s_ColorKeyCache[1] = new GradientColorKey(c, 1.0f);
            s_AlphaKeyCache[0] = new GradientAlphaKey(a, 0.0f);
            s_AlphaKeyCache[1] = new GradientAlphaKey(a, 1.0f);

            s_ColorKeyCache2[0] = new GradientColorKey(c2, 0.0f);
            s_ColorKeyCache2[1] = new GradientColorKey(c2, 1.0f);
            s_AlphaKeyCache2[0] = new GradientAlphaKey(a2, 0.0f);
            s_AlphaKeyCache2[1] = new GradientAlphaKey(a2, 1.0f);

            colorKeys = s_ColorKeyCache;
            alphaKeys = s_AlphaKeyCache;

            colorKeys2 = s_ColorKeyCache2;
            alphaKeys2 = s_AlphaKeyCache2;
        }

        static void ValidateGradient(ref Gradient gradient)
        {
            if (gradient != null) return;
            
            gradient = new Gradient();
            gradient.SetKeys(new[] { new GradientColorKey(Color.white, 0.0f), new GradientColorKey(Color.white, 1.0f) }, new[] { new GradientAlphaKey(1.0f, 0.0f), new GradientAlphaKey(1.0f, 1.0f) });
        }
    }
}
