// ColorByDensity.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     This plugin changes the color of particles based on their density.
    /// </summary>
    /// <remarks>
    ///     Changing color by density is useful for particle visualization, fire, or for foam effects.
    /// </remarks>
    [AddComponentMenu("Fluvio/Plugins/Color By Density")]
    public class ColorByDensity : FluidParticlePlugin
    {
        [SerializeField] FluvioMinMaxGradient m_Color;
        [SerializeField] Vector2 m_Range;
        [SerializeField] float m_Smoothing;

        /// <summary>
        ///     The color by density gradient, from minimum to rest density.
        /// </summary>
        public FluvioMinMaxGradient color { get { return m_Color; } set { m_Color = value; } }

        /// <summary>
        ///     The density range for the gradient.
        /// </summary>
        public Vector2 range { get { return m_Range; } set { m_Range = value; } }

        /// <summary>
        ///     The amount to smooth the color output by interpolating with the previous color.
        /// </summary>
        public float smoothing { get { return m_Smoothing; } set { m_Smoothing = value; } }

        protected override void OnResetPlugin()
        {
            color = new FluvioMinMaxGradient();
            range = fluid ? new Vector2(fluid.minimumDensity, fluid.density * 1.25f) : new Vector2(100, 1000);
            smoothing = 0.25f;
        }
        protected override void OnEnablePlugin()
        {
            SetComputeShader(FluvioComputeShader.Find("ComputeShaders/Plugins/ColorByDensity"), "OnUpdatePlugin");
        }
        protected override bool OnStartPluginFrame(ref FluvioTimeStep timeStep)
        {
            if (color == null) color = new FluvioMinMaxGradient();

            smoothing = Mathf.Clamp01(smoothing);

            return true;
        }
        protected override void OnSetComputeShaderVariables()
        {
            SetComputePluginMinMaxGradient(0, 1, color);
            var rangeSmoothing = new Vector4(m_Range.x, m_Range.y, m_Smoothing, 0.0f);
            SetComputePluginValue(2, rangeSmoothing);
        }        
        protected override void OnUpdatePlugin(SolverData solverData, int particleIndex)
        {
            var density = solverData.GetDensity(particleIndex);            
            var d = Mathf.InverseLerp(m_Range.x, m_Range.y, density);
            var seed = solverData.GetRandomSeed(particleIndex);

            solverData.SetColor(particleIndex, Color.Lerp(solverData.GetColor(particleIndex), m_Color.Evaluate(seed, d), m_Smoothing));
        }
    }
}
