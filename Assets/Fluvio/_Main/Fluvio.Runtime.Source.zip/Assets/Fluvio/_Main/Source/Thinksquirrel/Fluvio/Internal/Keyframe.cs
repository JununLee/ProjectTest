namespace Thinksquirrel.Fluvio.Internal
{
    public struct Keyframe
    {
        float m_Time;
        float m_Value;
        float m_InTangent;
        float m_OutTangent;
        int m_TangentMode;

        public float time
        {
            get
            {
                return m_Time;
            }
            set
            {
                m_Time = value;
            }
        }

        public float value
        {
            get
            {
                return m_Value;
            }
            set
            {
                m_Value = value;
            }
        }

        public float inTangent
        {
            get
            {
                return m_InTangent;
            }
            set
            {
                m_InTangent = value;
            }
        }

        public float outTangent
        {
            get
            {
                return m_OutTangent;
            }
            set
            {
                m_OutTangent = value;
            }
        }

        public int tangentMode
        {
            get
            {
                return m_TangentMode;
            }
            set
            {
                m_TangentMode = value;
            }
        }

        public Keyframe(float time, float value)
        {
            m_Time = time;
            m_Value = value;
            m_InTangent = 0.0f;
            m_OutTangent = 0.0f;
            m_TangentMode = 0;
        }

        public Keyframe(float time, float value, float inTangent, float outTangent)
        {
            m_Time = time;
            m_Value = value;
            m_InTangent = inTangent;
            m_OutTangent = outTangent;
            m_TangentMode = 0;
        }

        public static implicit operator Keyframe(UnityEngine.Keyframe kf)
        {
            return new Keyframe
            {
                m_Time = kf.time,
                m_Value = kf.value,
                m_InTangent = kf.inTangent,
                m_OutTangent = kf.outTangent,
                m_TangentMode = kf.tangentMode
            };
        }
    }
}
