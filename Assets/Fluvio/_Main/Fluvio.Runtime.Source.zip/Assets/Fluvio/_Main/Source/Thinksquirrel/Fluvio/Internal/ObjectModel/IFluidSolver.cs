// IFluidSolver.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Collections.Generic;
using Thinksquirrel.Fluvio.Internal.Solvers;

namespace Thinksquirrel.Fluvio.Internal.ObjectModel
{
    interface IFluidSolver : IDisposable
    {
        #region Abstract, Virtual, and Override
        FluidBase fluid { get; }
        void ForEachParticleDynamic(SolverParticleDelegate particleDelegate);
        void ForEachParticle(SolverParticleDelegate particleDelegate, bool getBuffers = true, bool useFastPath = false);
        void ForEachParticleBoundary(SolverParticleDelegate particleDelegate);
        void ForEachParticleAll(SolverParticleDelegate particleDelegate, bool getBuffers = true, bool useFastPath = false);
        void ForEachParticlePair(SolverParticlePairDelegate particlePairDelegate);
        void ForEachParticleDynamic(FluvioComputeShader computeShader, int kernelIndex);
        void ForEachParticle(FluvioComputeShader computeShader, int kernelIndex, bool isPlugin = false, bool suppressTimer = false);
        FluidBase GetFluid(int index);
        int GetFluidID(FluidBase fluid);
        void PreSolve(ref FluvioTimeStep timeStep);
        void ProcessChanges();
        void SetSubFluids(IEnumerable<FluidBase> fluids);
        void Solve();
        void ClearBuffers();
        SolverDataInternal solverDataInternal { get; }
        bool canUseFastIntegrationPath { get; set; }
        bool supportsTurbulence { get; }
        bool supportsExternalForces { get; }
        bool supportsDistanceConstraintSolver { get; }
        bool shouldUpdateBoundaries { get; set; }
        #endregion
    }
}
