// Callbacks.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

namespace Thinksquirrel.Fluvio.Internal
{  
    // Used in the solver internally
    delegate void SolverParticleDelegate(FluidBase fluid, int solverParticleIndex);

    delegate void SolverParticlePairDelegate(FluidBase fluidA, FluidBase fluidB, int particleIndex, int neighborIndex);
}
