// IThreadPool.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.
using System;

//! \cond PRIVATE
namespace Thinksquirrel.Fluvio.Internal.Threading
{       
    public interface IThreadPool : IDisposable
    {
        void SetPriority();        
        void For(int iterations, ParallelAction action);
        void RunInBackground(Action action);
        int GetThreadCount();
        int CompareExchange(ref int location1, int value, int comparand);
    }

    public delegate void ParallelAction(int index);
}
//! \endcond
