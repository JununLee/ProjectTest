// SolverData.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using Thinksquirrel.Fluvio.Internal.ObjectModel;
using Thinksquirrel.Fluvio.Internal.Solvers;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     Represents data from Fluvio's internal solver, for use in plugins.
    /// </summary>
    /// <remarks>
    ///     Fluvio's solver data is organized as a set of linear arrays for fast parallel access.
    ///     Solver data is always in world space, and while any units can be used, numbers are tuned for MKS units (meters, kilograms, and seconds).
    /// </remarks>
    public class SolverData
    {
        #region Static Fields
        [ThreadStatic] static int s_CurrentIndex;
        #endregion

        #region Instance Fields
        IFluidSolver m_InternalSolver;
        SolverDataInternal fluvio;
        #endregion

        #region Public API
        /// <summary>
        ///     Adds the specified force to the particle, using an optional force mode.
        /// </summary>
        /// <param name="particleIndex">The particle index to add a force to.</param>
        /// <param name="forceAmount">The amount and direction of force to apply to the particle.</param>
        /// <param name="forceMode">The type of force to apply to the particle.</param>
        /// <remarks>
        /// <list type="bullet">
        /// <item><term>ForceMode.Force: </term><description>f<sub>0</sub> += f<sub>1</sub></description></item>
        /// <item><term>ForceMode.Acceleration: </term><description>f<sub>0</sub> += f<sub>1</sub> * invMass</description></item>
        /// <item><term>ForceMode.Impulse: </term><description>f<sub>0</sub> += f<sub>1</sub> / dt</description></item>
        /// <item><term>ForceMode.VelocityChange: </term><description>f<sub>0</sub> += (f<sub>1</sub> * invMass) / dt</description></item> 
        /// </list>
        /// </remarks>
        public void AddForce(int particleIndex, Vector3 forceAmount, ForceMode forceMode = ForceMode.Force)
        {
            if (!CheckCurrentIndex(particleIndex))
                return;

            var deltaTime = fluvio._Time.x;
            var v4Force = (Vector4)forceAmount;

            if (Mathf.Abs(deltaTime) < FluvioSettings.kEpsilon)
                return;

            // f = mass * distance / (time ^ 2)
            switch (forceMode)
            {
                case ForceMode.Force:
                    fluvio._Particle[particleIndex].force += v4Force;
                    break;
                case ForceMode.Acceleration:
                    fluvio._Particle[particleIndex].force += v4Force * (1.0f / fluvio._Fluid[fluvio._Particle[particleIndex].id.x].particleMass);
                    break;
                case ForceMode.Impulse:
                    fluvio._Particle[particleIndex].force += v4Force / deltaTime;
                    break;
                case ForceMode.VelocityChange:
                    fluvio._Particle[particleIndex].force += (v4Force * (1.0f / fluvio._Fluid[fluvio._Particle[particleIndex].id.x].particleMass)) / deltaTime;
                    break;
            }
        }
        /// <summary>
        ///     Gets the color of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle color.</returns>
        public Color GetColor(int particleIndex)
        {
            return fluvio._Particle[particleIndex].color;
        }
        /// <summary>
        ///     Gets the fluid that is associated with the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The fluid associated with the particle.</returns>
        public FluidBase GetFluid(int particleIndex)
        {
            return m_InternalSolver.GetFluid(fluvio._Particle[particleIndex].id.x);
        }
        /// <summary>
        ///     Gets the density of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle density.</returns>
        public float GetDensity(int particleIndex)
        {
            return fluvio._Particle[particleIndex].densityPressure.x;
        }

        /// <summary>
        ///     Gets the unapplied force of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle force.</returns>
        public Vector3 GetForce(int particleIndex)
        {
            return fluvio._Particle[particleIndex].force;
        }
        /// <summary>
        ///     Gets the mass of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle mass.</returns>
        public float GetMass(int particleIndex)
        {
            return fluvio._Fluid[fluvio._Particle[particleIndex].id.x].particleMass;
        }
        /// <summary>
        ///     Gets the lifetime of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle lifetime.</returns>
        public float GetLifetime(int particleIndex)
        {
            return fluvio._Particle[particleIndex].lifetime.x;
        }
        /// <summary>
        ///     Gets the position of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle position.</returns>
        public Vector3 GetPosition(int particleIndex)
        {
            return fluvio._Particle[particleIndex].position;
        }
        /// <summary>
        ///     Gets the pressure of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle pressure.</returns>
        public float GetPressure(int particleIndex)
        {
            return fluvio._Particle[particleIndex].densityPressure.z;
        }
        /// <summary>
        ///     Gets the random seed of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle random seed.</returns>
        public uint GetRandomSeed(int particleIndex)
        {
            return unchecked((uint)fluvio._Particle[particleIndex].id.z);
        }
        /// <summary>
        ///     Gets the size of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle size.</returns>
        public float GetSize(int particleIndex)
        {
            return fluvio._Particle[particleIndex].velocity.w;
        }
        /// <summary>
        ///     Gets the surface normal of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle surface normal.</returns>
        public Vector3 GetSurfaceNormal(int particleIndex)
        {
            return fluvio._Particle[particleIndex].normal;
        }
        /// <summary>
        ///     Gets the surface normal length of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle surface normal length. If this value is between pi and 2 * pi, the particle can be assumed to be on the surface of the fluid.</returns>
        public float GetSurfaceNormalLength(int particleIndex)
        {
            return fluvio._Particle[particleIndex].normal.w;
        }
        /// <summary>
        ///     Gets the turbulence probability of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle turbulence probability.</returns>
        public float GetTurbulence(int particleIndex)
        {
            return fluvio._Particle[particleIndex].vorticityTurbulence.w;
        }
        /// <summary>
        ///     Gets the current velocity of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle velocity.</returns>
        public Vector3 GetVelocity(int particleIndex)
        {
            return fluvio._Particle[particleIndex].velocity;
        }        
        /// <summary>
        ///     Gets the vorticity of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <returns>The particle vorticity.</returns>
        public Vector3 GetVorticity(int particleIndex)
        {
            return fluvio._Particle[particleIndex].vorticityTurbulence;
        }
        /// <summary>
        ///     Sets the color of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <param name="color">The color to set.</param>
        public void SetColor(int particleIndex, Color color)
        {
            if (CheckCurrentIndex(particleIndex))
            {
                fluvio._Particle[particleIndex].color = color;
            }
        }
        /// <summary>
        ///     Sets the unapplied force of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <param name="force">The force to set.</param>
        public void SetForce(int particleIndex, Vector3 force)
        {
            if (CheckCurrentIndex(particleIndex))
            {
                fluvio._Particle[particleIndex].force = force;
            }
        }
        /// <summary>
        ///     Sets the lifetime of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <param name="lifetime">The lifetime to set.</param>
        public void SetLifetime(int particleIndex, float lifetime)
        {
            if (CheckCurrentIndex(particleIndex))
            {
                fluvio._Particle[particleIndex].lifetime.x = lifetime;
            }
        }
        /// <summary>
        ///     Sets the size of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <param name="size">The size to set.</param>
        public void SetSize(int particleIndex, float size)
        {
            if (CheckCurrentIndex(particleIndex))
            {
                fluvio._Particle[particleIndex].velocity.w = size;                
            }
        }
        /// <summary>
        ///     Sets the turbulence probability of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <param name="turbulence">The turbulence to set.</param>
        public void SetTurbulence(int particleIndex, float turbulence)
        {
            if (CheckCurrentIndex(particleIndex))
            {
                fluvio._Particle[particleIndex].vorticityTurbulence.w = turbulence;
            }
        }
        /// <summary>
        ///     Sets the vorticity of the particle at the specified index in the solver data.
        /// </summary>
        /// <param name="particleIndex">The index of the particle in the solver data.</param>
        /// <param name="vorticity">The vorticity to set.</param>
        public void SetVorticity(int particleIndex, Vector3 vorticity)
        {
            if (CheckCurrentIndex(particleIndex))
            {
                fluvio._Particle[particleIndex].vorticityTurbulence.x = vorticity.x;
                fluvio._Particle[particleIndex].vorticityTurbulence.y = vorticity.y;
                fluvio._Particle[particleIndex].vorticityTurbulence.z = vorticity.z;
            }
        }
        #endregion

        internal static void SetCurrentIndex(int index)
        {
            s_CurrentIndex = index;
        }
        bool CheckCurrentIndex(int index)
        {
            if (index == s_CurrentIndex) return true;
            FluvioDebug.LogError(string.Format("Invalid solver data access - attempt to set array for index {0} instead of {1}", index, s_CurrentIndex), this);
            return false;
        }
        #region Constructors
        internal SolverData(IFluidSolver internalSolver)
        {
            Initialize(internalSolver);
        }
        internal void Initialize(IFluidSolver internalSolver)
        {
            m_InternalSolver = internalSolver;
            fluvio = internalSolver.solverDataInternal;
        }
        #endregion
    }
}
