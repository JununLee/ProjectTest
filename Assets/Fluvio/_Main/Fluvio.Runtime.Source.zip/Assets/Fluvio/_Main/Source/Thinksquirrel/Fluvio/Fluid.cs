// Fluid.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Internal.Solvers;
using UnityEngine;
using float4 = UnityEngine.Vector4;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Represents a fluid that can be simulated and integrates with a rendering component.
    /// </summary>
    /// <remarks>
    ///     Fluids are the main component for fluid simulation with Fluvio.
    /// </remarks>
    [ExecuteInEditMode]
    public abstract class Fluid : FluidBase
    {
        #region Serialized Fields
        [SerializeField] float m_PrewarmTimeScale = 4.0f;
        #endregion
        
        #region Instance Fields
        [NonSerialized] float m_Accumulator;
        [NonSerialized] float m_RewindAccumulator;
        [NonSerialized] float m_LastFrameTime;
        //[NonSerialized] int m_OverheadTimer;
        #endregion

        #region Public API
        /// <summary>
        ///     Controls the initial simulation accuracy of a fluid with "Prewarm" enabled, applied as a multiplier to the fluid's fixed delta time. Higher values consume less CPU for the first fluid frame, but reduce simulation quality.
        /// </summary>
        public float prewarmTimeScale
        {
            get
            {
                var parent = parentFluid as Fluid;
                return parent ? parent.m_PrewarmTimeScale : m_PrewarmTimeScale;
            }
            set
            {
                var parent = parentFluid as Fluid;

                if (parent)
                    parent.m_PrewarmTimeScale = value;
                else
                    m_PrewarmTimeScale = value;
            }
        }
        #endregion

        #region Internal
        internal static void IntegrateParticles(SolverDataInternal fluvio, int particleIndex, ref FluidParticle particle, float axisConstraint, ref float4 worldVelocity)
        {
            if (particleIndex < fluvio._Count.z)
            {
                // Get world force
                float4 worldForce = particle.force;

                // Axis constraint
                worldForce.z *= axisConstraint;

                // Euler explicit integration (ignoring gravity since it's applied later)
                float invMass = 1.0f / fluvio._Fluid[particle.id.x].particleMass;
                float4 acceleration = worldForce * invMass;
                int solverIterations = (int)fluvio._Time.w;
                float dtIter = fluvio._Time.y;

                for (int iter = 0; iter < solverIterations; ++iter)
                {
                    float4 t = dtIter * acceleration;

                    // Ignore very large velocity changes
                    if (float4.Dot(t, t) > (FluvioSettings.kMaxSqrVelocityChange * fluvio._KernelSize.w * fluvio._KernelSize.w))
                    {
                        t *= 0;
                    }

                    worldVelocity += t;
                }
            }
        }
        internal static void IntegrateParticles(SolverDataInternal fluvio, int particleIndex, ref FluidParticle particle, float axisConstraint, ref float4 worldVelocity, ref float4 worldPosition)
        {
            if (particleIndex < fluvio._Count.z)
            {
                // Get world force
                float4 worldForce = particle.force;

                // Axis constraint
                worldForce.z *= axisConstraint;

                // Euler explicit integration (ignoring gravity since it's applied later)
                float invMass = 1.0f / fluvio._Fluid[particle.id.x].particleMass;
                float4 acceleration = worldForce * invMass;
                int solverIterations = (int)fluvio._Time.w;
                float dtIter = fluvio._Time.y;

                for (int iter = 0; iter < solverIterations; ++iter)
                {
                    float4 t = dtIter * acceleration;

                    // Ignore very large velocity changes
                    if (float4.Dot(t, t) > (FluvioSettings.kMaxSqrVelocityChange * fluvio._KernelSize.w * fluvio._KernelSize.w))
                    {
                        t *= 0;
                    }

                    worldVelocity += t;
                    worldPosition += t * dtIter;
                }
            }
        }
        internal void ProcessFluidFrame(float prewarmTime)
        {
            // Accumulator
            var prewarm = prewarmTime > 0.0f;
            var t = Time.realtimeSinceStartup;
            var scale = GetTimeScale();

            var dtRaw = t - m_LastFrameTime;
            var frameTime = Mathf.Min(FluvioSettings.maxDeltaTime * scale, dtRaw * scale) + prewarmTime * scale;

            m_LastFrameTime = t;

            m_Accumulator += frameTime;
            
            var dt = prewarm ? FluvioSettings.fixedDeltaTime * m_PrewarmTimeScale : FluvioSettings.fixedDeltaTime;
            var doPhysicsUpdate = m_Accumulator >= dt && solverEnabled;
            
            // Motion extrapolation
            // Here we rewind simulation if needed
            if (FluvioSettings.motionExtrapolation && !prewarm && m_RewindAccumulator < 0.0f && doPhysicsUpdate)
            {
                SimulateParticles(m_RewindAccumulator);
                for (var i = 0; i < subFluidCount; ++i)
                {
                    var subFluid = GetSubFluid(i) as Fluid;

                    if (subFluid)
                        subFluid.SimulateParticles(m_RewindAccumulator);
                }
                m_RewindAccumulator = 0.0f;
            }

            // Physics solver
            while (doPhysicsUpdate && m_Accumulator >= dt)
            {
                ProcessSolverFrame(dt);
                m_Accumulator -= dt;

                // To prevent runaway physics
                if (FluvioSettings.limitTimestep && !prewarm && Time.realtimeSinceStartup - m_LastFrameTime >= dt) break;
            }

            // To prevent runaway physics also
            if (FluvioSettings.limitTimestep && !prewarm)
            {
                m_Accumulator = Mathf.Min(m_Accumulator, FluvioSettings.maxDeltaTime);
            }

            // Motion extrapolation
            // Here we "simulate" particles without physics
            // Only run motion extrapolation if we haven't already pushed an update for this frame
            if (FluvioSettings.motionExtrapolation && !prewarm && !doPhysicsUpdate && m_Accumulator > 0.0f)
            {
                var extrapolationDt = Mathf.Min(m_Accumulator, dtRaw) * scale;
                SimulateParticles(extrapolationDt);
                for (var i = 0; i < subFluidCount; ++i)
                {
                    var subFluid = GetSubFluid(i) as Fluid;

                    if (subFluid)
                        subFluid.SimulateParticles(extrapolationDt);
                }
                m_RewindAccumulator -= extrapolationDt;
            }
        }
        internal void SyncColliders()
        {
            var fluvio = _solver.solverDataInternal;

            bool hasCollider = false;
            for (var i = 0; i < subFluidCount; ++i)
            {
                if (GetSubFluid(i) is FluidColliderBase)
                {
                    hasCollider = true;
                    break;
                }
            }

            if (hasCollider)
            {
                // Dynamic/kinematic colliders
                _solver.ForEachParticle((f, particleIndex) =>
                {
                    var col = f as FluidColliderBase;
                    if (!col || col.fluidType == FluidType.Static) return;

                    var collisionPoints = col.GetCollisionPoints();

                    var i = particleIndex;
                    var id = fluvio._Particle[i].id.y;
                    fluvio._Particle[i].position = col.GetLocalToWorldMatrix().MultiplyPoint3x4(collisionPoints[id]);
                    fluvio._Particle[i].lifetime.x = 1.0f / FluvioSettings.kEpsilon;
                    fluvio._Particle[i].velocity = default(float4);
                }, false, _solver.canUseFastIntegrationPath);

                // Static colliders
                if (_solver.shouldUpdateBoundaries)
                {
                    _solver.ForEachParticleBoundary((f, particleIndex) =>
                    {
                        var col = f as FluidColliderBase;
                        if (!col || col.fluidType != FluidType.Static) return;

                        var collisionPoints = col.GetCollisionPoints();

                        var i = particleIndex - fluvio._Count.y;
                        var id = fluvio._BoundaryParticle[i].id.y;
                        fluvio._BoundaryParticle[i].position = col.GetLocalToWorldMatrix().MultiplyPoint3x4(collisionPoints[id]);
                        fluvio._BoundaryParticle[i].lifetime.x = 1.0f / FluvioSettings.kEpsilon;
                        fluvio._BoundaryParticle[i].velocity = default(float4);
                    });
                }
            }
        }
        #endregion

        #region Abstract and virtual
        //! \cond PRIVATE
        protected override void Initialize()
        {
            base.Initialize();
            m_PrewarmTimeScale = Mathf.Max(m_PrewarmTimeScale, 0.5f);
        }
        protected internal abstract float GetTimeScale();
        protected internal abstract void SimulateParticles(float dt);
        protected internal abstract void ProcessSolverFrame(float dt);
        //! \endcond
        #endregion

        #region Unity methods
        //! \cond PRIVATE
        protected override void OnEnable()
        {
            base.OnEnable();

            m_LastFrameTime = Time.realtimeSinceStartup;            
            m_Accumulator = 0;
            m_RewindAccumulator = 0;
        }
        [UsedImplicitly]
        void OnApplicationPause(bool isPaused)
        {
            if (!isPaused)
            {
                m_LastFrameTime = Time.realtimeSinceStartup;
                m_Accumulator = 0;
                m_RewindAccumulator = 0;
            }
        }
        //! \endcond
        #endregion
    }
}
