// FluidBase.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#pragma warning disable 429
#pragma warning disable 162
// ReSharper disable ConditionIsAlwaysTrueOrFalse
// ReSharper disable HeuristicUnreachableCode
using System;
using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Internal.ObjectModel;
using Thinksquirrel.Fluvio.Internal.Solvers;
using Thinksquirrel.Fluvio.Plugins;
using UnityEngine;
    
namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     This is the base fluid component that interfaces with a solver and represents all types of fluids.
    /// </summary>
    /// <remarks>
    ///     Fluids are the main component for fluid simulation with Fluvio.
    /// </remarks>
    [ExecuteInEditMode]
    public abstract class FluidBase : FluvioMonoBehaviourBase, IEnumerable<FluidBase>
    {
        #region Serialized Fields
        [SerializeField] bool m_SolverEnabled = true;
        [SerializeField] bool m_EnableHardwareAcceleration = true;
        [SerializeField] FluidType m_FluidType;        
        [SerializeField] SimulationDimensions m_Dimensions;
        [SerializeField] SimulationCullingType m_CullingType;
        [SerializeField] float m_SmoothingDistance = 0.38125f;
        [SerializeField] float m_ParticleMass = 7.625f;
        [SerializeField] float m_Density = 998.29f;
        [SerializeField] float m_MinimumDensity = 499.145f;
        [SerializeField] float m_Viscosity = 2.0f;
        [SerializeField] float m_Turbulence = 0.2f;
        [SerializeField] float m_SurfaceTension = 0.728f;
        [SerializeField] float m_GasConstant = 0.01f;
        [SerializeField] float m_BuoyancyCoefficient;
        [SerializeField] float m_SimulationScale = 1.0f;
        [SerializeField, HideInInspector, UsedImplicitly] bool m_FluidSettingsFoldoutEditor;
        [SerializeField, HideInInspector, UsedImplicitly] bool m_PhysicalPropertiesFoldoutEditor;
        [SerializeField, HideInInspector, UsedImplicitly] bool m_PluginsFoldoutEditor;
        #endregion

        #region Instance Fields
        [NonSerialized] static readonly List<FluidBase> s_AllFluids = new List<FluidBase>();
        [NonSerialized] internal IFluidSolver _solver;
        [NonSerialized] protected Vector3 _position;
        [NonSerialized] protected FluvioTimeStep _timeStep;
        [NonSerialized] int m_MaxParticles;
        [NonSerialized] Vector3 m_Gravity;
        [NonSerialized] bool m_IsVisible;
        [NonSerialized] readonly List<IParallelPlugin> m_ParallelPlugins = new List<IParallelPlugin>();
        [NonSerialized] readonly List<FluidPlugin> m_Plugins = new List<FluidPlugin>();
        [NonSerialized] readonly List<FluidBase> m_SubFluids = new List<FluidBase>();
        [NonSerialized] FluidGroup m_FluidGroup;
        [NonSerialized] FluidBase m_ParentFluid;        
        [NonSerialized] Transform m_CachedTransformParent;
        [NonSerialized] bool m_Initialized;
        [NonSerialized] SolverData m_PluginSolverData;
        #endregion

        #region Public API
        /// <summary>
        /// Gets the current gravity vector of the fluid, in world space.
        /// </summary>
        public Vector3 gravity { get { return m_Gravity; } }
        /// <summary>
        ///     Controls the buoyancy coefficient of a fluid. This should be used when simulating gas like smoke or fire.
        /// </summary>
        public float buoyancyCoefficient
        {
            get
            {
                return m_BuoyancyCoefficient;
            }
            set
            {
                m_BuoyancyCoefficient = value;
            }
        }
        /// <summary>
        ///     Controls the simulation scale of a fluid.
        /// </summary>
        public float simulationScale
        {
            get { return m_ParentFluid ? m_ParentFluid.m_SimulationScale : m_SimulationScale ; }
            set
            {
                if (m_ParentFluid)
                    m_ParentFluid.m_SimulationScale = value;
                else
                    m_SimulationScale = value;
            }
        }
        /// <summary>
        ///     Controls the overall density of the fluid.
        /// </summary>
        public float density
        {
            get
            {
      
                return m_Density;
            }
            set
            {
                m_Density = value;
            }
        }
        /// <summary>
        ///     Controls the simulation dimensions for the fluid.
        /// </summary>
        public SimulationDimensions dimensions
        {
            get
            {
                return m_ParentFluid ? m_ParentFluid.m_Dimensions : m_Dimensions;
            }
            set
            {
                if (m_ParentFluid)
                    m_ParentFluid.m_Dimensions = value;
                else
                    m_Dimensions = value;
            }
        }
        /// <summary>
        ///     Controls how fluid simulation should be culled.
        /// </summary>
        public SimulationCullingType cullingType
        {
            get
            {
                return m_ParentFluid ? m_ParentFluid.m_CullingType : m_CullingType;
            }
            set
            {
                if (m_ParentFluid)
                    m_ParentFluid.m_CullingType = value;
                else
                    m_CullingType = value;
            }
        }
        /// <summary>
        ///     Controls the gas constant of a fluid.
        /// </summary>
        public float gasConstant
        {
            get
            {
                return m_GasConstant;
            }
            set
            {
                m_GasConstant = value;
            }
        }

        //! \cond PRIVATE
        protected internal abstract bool IsWorldSpace();
        protected internal abstract Matrix4x4 GetLocalToWorldMatrix();
        protected internal virtual int SetMaxParticles(int value)
        {
            if (m_MaxParticles != value)
            {
                // ReSharper disable once UnreachableCode
                // ReSharper disable once RedundantCast
                m_MaxParticles = Mathf.Clamp(value, 0, 1410065408);
            }

            return m_MaxParticles;
        }
        protected internal bool FluidIsVisible()
        {
            if (cullingType == SimulationCullingType.AlwaysSimulate) return true;
            if (parentFluid) return parentFluid.FluidIsVisible();

            var isVisible = false;

            for (var i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i);

                if (subFluid && subFluid.m_IsVisible)
                {
                    isVisible = true;
                    break;
                }
            }

            return isVisible;
        }
        protected void SetVisibility(bool value)
        {
            m_IsVisible = value;
        }
        protected void SetGravity(Vector3 value)
        {
            m_Gravity = value;
        }
        //! \endcond

        /// <summary>
        ///     Controls the minimum density of each fluid particle.
        /// </summary>
        public float minimumDensity
        {
            get
            {
                return m_MinimumDensity;
            }
            set
            {
                m_MinimumDensity = value;
            }
        }
        /// <summary>
        ///     Gets the parent fluid, if this fluid is a sub-fluid.
        /// </summary>
        public FluidBase parentFluid
        {
            get
            {
                return m_ParentFluid;
            }
        }
        /// <summary>
        ///     Controls the mass of each fluid particle.
        /// </summary>
        public float particleMass
        {
            get
            {
                return m_ParticleMass;
            }
            set
            {
                m_ParticleMass = value;
            }
        }       
        /// <summary>
        ///     Gets the fluid's plugin count.
        /// </summary>
        public int pluginCount
        {
            get
            {
                return m_Plugins.Count;
            }
        }
        /// <summary>
        ///     Gets an array of the fluid's plugins. (Allocates a new array)
        /// </summary>
        public FluidPlugin[] plugins
        {
            get
            {
                FluidPlugin[] newArray = null;
                GetPlugins(ref newArray);
                return newArray;
            }
        }
        /// <summary>
        ///     Controls the smoothing distance of fluid particles.
        /// </summary>
        public float smoothingDistance
        {
            get
            {
                return m_ParentFluid ? m_ParentFluid.m_SmoothingDistance : m_SmoothingDistance;
            }
            set
            {
                if (m_ParentFluid)
                {
                    m_ParentFluid.smoothingDistance = value;
                    return;
                }

                if (Mathf.Abs(m_SmoothingDistance - value) < FluvioSettings.kEpsilon) return;
                
                m_SmoothingDistance = value;
            }
        }
        /// <summary>
        ///     Controls whether or not the fluid's simulation solver is enabled.
        /// </summary>
        public bool solverEnabled
        {
            get { return _solver != null && (m_ParentFluid ? m_ParentFluid.m_SolverEnabled : m_SolverEnabled); }
            set
            {
                if (m_ParentFluid)
                    m_ParentFluid.m_SolverEnabled = value;
                else
                    m_SolverEnabled = value;
            }
        }
        /// <summary>
        ///     Returns true if the current fluid supports turbulent forces.
        /// </summary>
        /// <remarks>
        ///     Turbulence is disabled on mobile platforms.
        /// </remarks>
        public bool supportsTurbulence { get { return _solver != null && _solver.supportsTurbulence; } }
        /// <summary>
        ///     Returns true if the current fluid supports external forces.
        /// </summary>
        /// <remarks>
        ///     External forces are disabled on mobile platforms.
        /// </remarks>
        public bool supportsExternalForces { get { return _solver != null && _solver.supportsExternalForces; } }
        /// <summary>
        ///     Returns true if the current fluid supports the distance constraint solver.
        /// </summary>
        /// <remarks>
        ///     The distance constraint solver is disabled on mobile platforms.
        /// </remarks>
        public bool supportsDistanceConstraintSolver { get { return _solver != null && _solver.supportsExternalForces; } }
        /// <summary>
        ///     Controls whether or not hardware acceleration is enabled, if available.
        /// </summary>
        public bool enableHardwareAcceleration
        {
            get { return m_ParentFluid ? m_ParentFluid.m_EnableHardwareAcceleration : m_EnableHardwareAcceleration; }
            set
            {
                if (m_ParentFluid)
                    m_ParentFluid.m_EnableHardwareAcceleration = value;
                else
                    m_EnableHardwareAcceleration = value;
            }
        }
        /// <summary>
        ///     Returns true if GPU acceleration is available and enabled for the fluid.
        /// </summary>
        /// <returns>True if GPU acceleration is available and enabled.</returns>
        public bool IsHardwareAccelerated()
        {
            return FluvioSettings.GetCurrentComputeAPI() != ComputeAPI.None && enableHardwareAcceleration;
        }
        /// <summary>
        ///     Controls whether or not the fluid is dynamic, kinematic, or static.
        /// </summary>
        public FluidType fluidType
        {
            get { return m_FluidType; }
            set { m_FluidType = value; }
        }        
        /// <summary>
        ///     Gets the number of sub-fluids currently attached to this fluid.
        /// </summary>
        public int subFluidCount
        {
            get
            {
                return m_SubFluids.Count;
            }
        }
        /// <summary>
        ///     Controls the surface tension of a fluid (liquids only).
        /// </summary>
        public float surfaceTension
        {
            get
            {
                return m_SurfaceTension;
            }
            set
            {
                m_SurfaceTension = value;
            }
        }
        /// <summary>
        ///     Controls the viscosity of a fluid.
        /// </summary>
        public float viscosity
        {
            get
            {
                return m_Viscosity;
            }
            set
            {
                m_Viscosity = value;
            }
        }
        /// <summary>
        ///     Controls the turbulence probability of a fluid.
        /// </summary>
        /// <remarks>
        ///     The turbulence probability is a threshold beyond which a particle may become turbulent.
        ///     Turbulent particles will not affect non-turbulent particles.
        ///     Fluid particles are not turbulent by default. Turbulent forces are applied through effectors (using the Vorticity property), or can be applied to particles through custom plugins.
        /// </remarks>
        public float turbulence
        {
            get { return m_Turbulence; }
            set { m_Turbulence = value; }
        }
        /// <summary>
        ///     Find the first fluid matching the name specified.
        /// </summary>
        /// <param name="name">
        ///     The name of the fluid to search for.
        /// </param>
        /// <returns>
        ///     The matching fluid. Returns null if not found.
        /// </returns>
        public static FluidBase Find(string name)
        {
            var fluids = s_AllFluids;

            for (int i = 0, c = fluids.Count; i < c; i++)
            {
                var fluid = fluids[i];
                if (fluid.name == name)
                {
                    return fluid;
                }
            }
            return null;
        }
        /// <summary>
        ///     Find all fluids matching the name specified.
        /// </summary>
        /// <param name="name">
        ///     The name of the fluid to search for.
        /// </param>
        /// <returns>
        ///     The matching fluids. Returns null if not found.
        /// </returns>
        public static IEnumerable<FluidBase> FindAll(string name)
        {
            var fluids = s_AllFluids;

            var fluidsList = new List<FluidBase>();

            for (int i = 0, c = fluids.Count; i < c; i++)
            {
                var fluid = fluids[i];
                if (fluid.name == name)
                {
                    fluidsList.Add(fluid);
                }
            }

            return fluidsList;
        }
        /// <summary>
        ///     Gets all active fluids.
        /// </summary>
        /// <returns>
        ///     All active fluids in the scene.
        /// </returns>
        public static IEnumerable<FluidBase> GetAllFluids()
        {
            return s_AllFluids;
        }
        /// <summary>
        /// Gets the fluid's solver ID.
        /// </summary>
        /// <returns>The solver ID, or -1 if there is currently no solver for the fluid or the solver has not been initialized.</returns>
        public int GetFluidID()
        {
            return _solver == null ? -1 : _solver.GetFluidID(this);
        }
        /// <summary>
        ///     Gets the currently allocated particle count for the fluid.
        /// </summary>
        /// <returns>
        ///     The currently allocated maximum particle count.
        /// </returns>
        public int GetParticleCount()
        {
            return m_MaxParticles;
        }
        /// <summary>
        ///     Gets the fluid's active particle count.
        /// </summary>
        /// <returns>
        ///     The current active particle count.
        /// </returns>
        public virtual int GetActiveParticleCount()
        {
            var c = 0;
            
            if (_solver == null || _solver.solverDataInternal == null)
                return c;

            for (var i = 0; i < _solver.solverDataInternal._Count.y; ++i)
            {
                if (_solver.solverDataInternal._Particle[i].lifetime.x > 0.0f && _solver.solverDataInternal._Particle[i].id.x == _solver.GetFluidID(this))
                    ++c;
            }
            return c;
        }
        /// <summary>
        ///     Gets the plugin at the specified index.
        /// </summary>
        /// <param name="index">The zero-based index of the fluid plugin to get.</param>
        /// <returns>The fluid plugin at the specified index.</returns>
        public FluidPlugin GetPlugin(int index)
        {
            return m_Plugins[index];
        }
        /// <summary>
        ///     Gets the first fluid plugin found of the specified type.
        /// </summary>
        /// <returns>The first plugin found of the specified type.</returns>
        public T GetPlugin<T>() where T : FluidPlugin
        {            
            if (m_Plugins.Count == 0)
                return default(T);

            var plugs = new List<FluidPlugin>(m_Plugins);
            return plugs.Find(p => p is T) as T;
        }
        /// <summary>
        ///     Writes the fluid's plugins into an array. This will automatically resize the array, if needed.
        /// </summary>
        /// <param name="pluginArray">The array to write the fluid's plugins into.</param>
        public void GetPlugins(ref FluidPlugin[] pluginArray)
        {
            Array.Resize(ref pluginArray, m_Plugins.Count);

            GetPlugins(pluginArray);
        }
        /// <summary>
        ///     Writes the fluid's plugins into an array.
        /// </summary>
        /// <param name="pluginArray">The array to write the fluid's plugins into.</param>
        /// <returns>
        ///     The amount of plugins written into the array.
        /// </returns>
        public int GetPlugins(FluidPlugin[] pluginArray)
        {
            if (pluginArray == null)
                throw new ArgumentNullException("pluginArray");

            var c = Mathf.Min(m_Plugins.Count, pluginArray.Length);

            for (var i = 0; i < c; ++i)
            {
                pluginArray[i] = m_Plugins[i];
            }

            return c;
        }
        /// <summary>
        ///     Gets all fluid plugins of the specified type.
        /// </summary>
        /// <returns>An enumerable of all fluid plugins of the specified type.</returns>
        public IEnumerable<T> GetPlugins<T>() where T : FluidPlugin
        {
            if (m_Plugins.Count == 0)
                return null;

            var result = new List<T>();

            for (var i = 0; i < m_Plugins.Count; ++i)
            {
                var plugin = m_Plugins[i] as T;

                if (plugin)
                    result.Add(plugin);
            }
            return result;
        }
        /// <summary>
        ///     Gets the sub-fluid at the specified index.
        /// </summary>
        /// <param name="index">The zero-based index of the sub-fluid to get.</param>
        /// <returns>The sub-fluid at the specified index.</returns>
        public FluidBase GetSubFluid(int index)
        {
            return m_SubFluids[index];
        }
        /// <summary>
        ///     Gets the total particle count for the fluid group (includes sub-fluids and parent fluids).
        /// </summary>
        /// <returns>The total active particle count.</returns>
        public int GetTotalActiveParticleCount()
        {
            if (parentFluid)
                return parentFluid.GetTotalActiveParticleCount();

            var c = GetActiveParticleCount();

            for (var i = 0; i < subFluidCount; ++i)
            {
                var subFluid = GetSubFluid(i);

                if (subFluid)
                    c += subFluid.GetActiveParticleCount();
            }

            return c;
        }

        /// <summary>
        ///     Gets the total particle count for the fluid group (includes sub-fluids and parent fluids).
        /// </summary>
        /// <returns>The total maximum particle count.</returns>
        public int GetTotalParticleCount()
        {
            if (m_ParentFluid)
                return m_ParentFluid.GetTotalParticleCount();

            var c = m_MaxParticles;

            for (var i = 0; i < m_SubFluids.Count; ++i)
                c += m_SubFluids[i].m_MaxParticles;

            return c;
        }
        #endregion

        #region Unity Methods
        //! \cond PRIVATE
        protected override void OnDisable()
        {
            base.OnDisable();

            s_AllFluids.Remove(this);

            if (_solver != null && _solver.fluid == this)
            {
                _solver.Dispose();
                _solver = null;
            }
            
            if (m_ParentFluid)
                m_ParentFluid.m_SubFluids.Remove(this);

            m_Initialized = false;
        }
        protected override void OnEnable()
        {
            base.OnEnable();

            s_AllFluids.Add(this);

            // Clamp user input values
            UpdateClampValues();

            // Handle fluid initialization
            UpdateInitialization();
        }
        //! \endcond
        [UsedImplicitly]
        void OnApplicationQuit()
        {
            if (_solver != null)
            {
                _solver.Dispose();
                _solver = null;
            }
        }
        #endregion

        #region IEnumerable<Fluid> Implementation
        IEnumerator<FluidBase> IEnumerable<FluidBase>.GetEnumerator()
        {
            return m_SubFluids.GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return m_SubFluids.GetEnumerator();
        }
        #endregion

        internal bool FluidSettingsFoldoutVisible()
        {
            return m_FluidSettingsFoldoutEditor;
        }
        internal bool PhysicalPropertiesFoldoutVisible()
        {
            return m_PhysicalPropertiesFoldoutEditor;
        }
        internal bool PluginsFoldoutVisible()
        {
            return m_PluginsFoldoutEditor;
        }
        internal int AddPlugin(FluidPlugin plugin)
        {
            if (!plugin || plugin.fluid == this)
                throw new ArgumentException("Plugin is null or already added to the fluid.", "plugin");

            return AddPluginInternal(plugin);
        }
        internal int AddPluginInternal(FluidPlugin plugin)
        {
            var parallelPlugin = plugin as IParallelPlugin;

            m_Plugins.Add(plugin);

            if (parallelPlugin != null)
            {
                m_ParallelPlugins.Add(parallelPlugin);
                m_ParallelPlugins.Sort((a, b) => a.weight.CompareTo(b.weight));
            }
            return m_Plugins.Count - 1;
        }
        internal void RemovePlugin(FluidPlugin plugin)
        {
            if (!plugin || plugin.fluid != this)
                throw new ArgumentException("Plugin is null or not added to the fluid.", "plugin");

            RemovePluginInternal(plugin);
        }
        internal void RemovePluginInternal(FluidPlugin plugin)
        {
            if (plugin._pluginID >= 0 && plugin._pluginID < m_Plugins.Count)
            {
                m_Plugins.RemoveAt(plugin._pluginID);
            }
            else
            {
                // Fallback
                m_Plugins.Remove(plugin);
            }

            for (var i = m_Plugins.Count - 1; i >= 0; i--)
            {
                if (!m_Plugins[i])
                {
                    m_Plugins.RemoveAt(i);
                    continue;
                }

                m_Plugins[i]._pluginID = i;
            }

            // Remove particle and particle pair plugins
            var parallelPlugin = plugin as IParallelPlugin;

            if (parallelPlugin != null)
            {
                m_ParallelPlugins.Remove(parallelPlugin);
                m_ParallelPlugins.Sort((a, b) => a.weight.CompareTo((b.weight)));
            }
        }
        internal void PreSolve(float deltaTime)
        {
            if (!solverEnabled)
            {
                if (_solver != null) _solver.canUseFastIntegrationPath = false;
                return;
            }
            
            // Process all changes, resize arrays, etc
            _solver.ProcessChanges();

            // Get time step
            GetTimeStep(deltaTime);

            // Start the solver frame
            _solver.PreSolve(ref _timeStep);

            // Disable fast path if a CPU plugin is present
            var parallelPlugins = m_ParallelPlugins;
            for (var i = 0; i < parallelPlugins.Count; ++i)
            {
                var plugin = parallelPlugins[i] as IComputePlugin;

                if (plugin == null || plugin.isValidComputePlugin) continue;

                _solver.canUseFastIntegrationPath = false;
                break;
            }
        }
        internal void Solve()
        {
            if (!solverEnabled)
            {
                if (_solver != null) _solver.canUseFastIntegrationPath = false;
                return;
            }
           
            // Apply SPH forces
            _solver.Solve();

            // Update plugins
            UpdatePlugins();
        }
        internal void PostSolve()
        {
            if (!solverEnabled)
            {
                if (_solver != null) _solver.canUseFastIntegrationPath = false;
                return;
            }

            // Update plugins
            UpdatePluginsPostSolve();
        }
        void DoPluginFrame(FluidBase fluidA, FluidBase fluidB, int particleIndex, int neighborIndex, bool pairPlugin)
        {
            SolverData.SetCurrentIndex(particleIndex);

            for (int i = 0, l = m_ParallelPlugins.Count; i < l; ++i)
            {
                var plugin = m_ParallelPlugins[i];

                // Skip compute plugins
                var computePlugin = plugin as IComputePlugin;
                if (computePlugin != null && computePlugin.isValidComputePlugin) continue;

                if (!plugin.shouldUpdate || plugin.isPairPlugin != pairPlugin)
                    continue;

                if (plugin.includeFluidGroup)
                {
                    plugin.UpdatePlugin(m_PluginSolverData, particleIndex, neighborIndex);
                }
                else if (plugin.fluid == fluidA && plugin.fluid == fluidB)
                {
                    plugin.UpdatePlugin(m_PluginSolverData, particleIndex, neighborIndex);
                }
            }

            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                for (int j = 0, l = subFluid.m_ParallelPlugins.Count; j < l; ++j)
                {
                    var plugin = subFluid.m_ParallelPlugins[j];

                    // Skip compute plugins
                    var computePlugin = plugin as IComputePlugin;
                    if (computePlugin != null && computePlugin.isValidComputePlugin) continue;

                    if (!plugin.shouldUpdate || plugin.isPairPlugin != pairPlugin)
                        continue;

                    if (plugin.includeFluidGroup)
                    {
                        plugin.UpdatePlugin(m_PluginSolverData, particleIndex, neighborIndex);
                    }
                    else if (plugin.fluid == fluidA && plugin.fluid == fluidB)
                    {
                        plugin.UpdatePlugin(m_PluginSolverData, particleIndex, neighborIndex);
                    }
                }
            }
        }
        internal void SetFluidGroup(FluidGroup group)
        {
            if (m_FluidGroup == group) return;
            if (m_FluidGroup != null && group != null)
            {
                FluvioDebug.LogWarning("Overwriting fluid group - make sure two FluidGroup components are not referencing the same fluid!", @group);
            }
            m_FluidGroup = group;
            m_Initialized = false;
        }
        internal FluidGroup GetFluidGroup()
        {
            return m_FluidGroup;
        }
        void GetTimeStep(float dt)
        {
            _timeStep = new FluvioTimeStep(dt, FluvioSettings.solverIterations);

            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];
                subFluid._timeStep = _timeStep;
            }
        }
        void DoInitializeFluid()
        {
            m_SubFluids.Clear();

            if (!enabled)
                return;

            var parent = FluvioHelpers.FindSubFluidParent(this);
            if (parent)
            {
                // SubFluid
                if (!parent.m_Initialized)
                {
                    parent.DoInitializeFluid();
                }

                m_ParentFluid = parent;
                if (!m_ParentFluid.m_SubFluids.Contains(this)) m_ParentFluid.m_SubFluids.Add(this);

                if (_solver != m_ParentFluid._solver)
                {
                    if (_solver != null && (_solver.fluid == this || !_solver.fluid))
                    {
                        _solver.Dispose();
                    }

                    _solver = m_ParentFluid._solver;
                }
            }
            else
            {
                // Parent fluid
                if (m_ParentFluid)
                {
                    m_ParentFluid.m_SubFluids.Remove(this);
                }
                m_ParentFluid = null;

                if (_solver != null && (_solver.fluid == this || !_solver.fluid))
                {
                    _solver.Dispose();
                }

                _solver = new SPHSimulationSolver(this);
            }
            
            m_Initialized = true;
            m_CachedTransformParent = transform.parent;
        }
        void OnComputePluginFrame()
        {
            // Flush the command queue
            if (_solver.solverDataInternal._computeAPI == ComputeAPI.OpenCL) FluvioOpenCL.FlushCommandQueue();

            for (int i = 0, l = m_ParallelPlugins.Count; i < l; ++i)
            {
                var computePlugin = m_ParallelPlugins[i] as IComputePlugin;

                if (computePlugin == null || !computePlugin.isValidComputePlugin || !computePlugin.shouldUpdate) continue;
                    
                computePlugin.SetComputeShaderVariables();
                _solver.ForEachParticleDynamic(computePlugin.computeShader, computePlugin.kernelIndex);
                computePlugin.GetComputeShaderBuffers();
            }

            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                for (int j = 0, l = subFluid.m_ParallelPlugins.Count; j < l; ++j)
                {
                    var computePlugin = subFluid.m_ParallelPlugins[j] as IComputePlugin;

                    if (computePlugin == null || !computePlugin.isValidComputePlugin || !computePlugin.shouldUpdate) continue;
                    
                    computePlugin.SetComputeShaderVariables();
                    _solver.ForEachParticleDynamic(computePlugin.computeShader, computePlugin.kernelIndex);
                    computePlugin.GetComputeShaderBuffers();
                }
            }
        }
        void OnPluginFrame(FluidBase fluid, int particleIndex)
        {
            DoPluginFrame(fluid, fluid, particleIndex, particleIndex, false);
        }
        void OnPluginPairFrame(FluidBase fluidA, FluidBase fluidB, int particleIndex, int neighborIndex)
        {
            DoPluginFrame(fluidA, fluidB, particleIndex, neighborIndex, true);
        }
        //! \cond PRIVATE
        protected virtual void Initialize()
        {
            UpdateClampValues();
            UpdateInitialization();

            if (_solver != null && !m_ParentFluid)
               _solver.SetSubFluids(m_SubFluids);
        }
        //! \endcond
        void UpdateClampValues()
        {
            m_SmoothingDistance = Mathf.Max(m_SmoothingDistance, FluvioSettings.kEpsilon*10f);
            m_ParticleMass = Mathf.Max(m_ParticleMass, FluvioSettings.kEpsilon*10f);
            m_Density = Mathf.Max(m_Density, FluvioSettings.kEpsilon*10f);
            m_MinimumDensity = Mathf.Clamp(m_MinimumDensity, FluvioSettings.kEpsilon*10f, m_Density);
            m_Viscosity = Mathf.Max(m_Viscosity, 0.0f);
            m_Turbulence = Mathf.Clamp01(m_Turbulence);
            m_SurfaceTension = Mathf.Max(m_SurfaceTension, 0.0f);
            m_GasConstant = Mathf.Max(m_GasConstant, 0.0f);
            m_SimulationScale = Mathf.Clamp(m_SimulationScale, FluvioSettings.kEpsilon*10f, 10.0f/FluvioSettings.kEpsilon);
        }
        void UpdateInitialization()
        {
            for (var i = m_SubFluids.Count - 1; i >= 0; --i)
            {
                if (i >= m_SubFluids.Count)
                    continue;

                var subFluid = m_SubFluids[i];

                if (subFluid)
                    subFluid.UpdateInitialization();
            }

            if (!m_Initialized || transform.parent != m_CachedTransformParent || (m_ParentFluid && !m_ParentFluid))
            {
                DoInitializeFluid();
            }

            _position = transform.position;
        }
        void UpdatePlugins()
        {
            var processTask = false;
            var processParticleTask = false;
            var processParticlePairTask = false;
            var processCompute = false;

            // Start frame (including sub-fluids)
            for (int i = 0, l = m_ParallelPlugins.Count; i < l; ++i)
            {
                var plugin = m_ParallelPlugins[i];
                plugin.StartPluginFrame(ref _timeStep);
                var computePlugin = plugin as IComputePlugin;
                var canUseCompute = computePlugin != null && computePlugin.isValidComputePlugin;
                processTask |= plugin.shouldUpdate;
                processParticleTask |= !plugin.isPairPlugin && !canUseCompute;
                processParticlePairTask |= plugin.isPairPlugin && !canUseCompute;
                processCompute |= canUseCompute;
            }

            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                for (int j = 0, l = subFluid.m_ParallelPlugins.Count; j < l; ++j)
                {
                    var plugin = subFluid.m_ParallelPlugins[j];
                    plugin.StartPluginFrame(ref _timeStep);
                    var computePlugin = plugin as IComputePlugin;
                    var canUseCompute = computePlugin != null && computePlugin.isValidComputePlugin;
                    processTask |= plugin.shouldUpdate;
                    processParticleTask |= !plugin.isPairPlugin && !canUseCompute;
                    processParticlePairTask |= plugin.isPairPlugin && !canUseCompute;
                    processCompute |= canUseCompute;
                }
            }

            // Don't even query the solver if there are no plugins to process this frame
            if (!processTask) return;

            // Create plugin solver data on demand
            if (m_PluginSolverData == null) 
                m_PluginSolverData = new SolverData(_solver);
            else
                m_PluginSolverData.Initialize(_solver);
            
            // Process frame (including sub-fluids)
            // Start with compute shaders, as they don't need to wait on transfer
            if (processCompute)
            {
                OnComputePluginFrame();
            }
            if (processParticleTask)
                _solver.ForEachParticleDynamic(OnPluginFrame);
            if (processParticlePairTask)
                _solver.ForEachParticlePair(OnPluginPairFrame);
            

            // End frame (including sub-fluids)
            for (int i = 0, l = m_ParallelPlugins.Count; i < l; ++i)
            {
                var plugin = m_ParallelPlugins[i];

                if (!plugin.shouldUpdate)
                    continue;

                plugin.EndPluginFrame();
            }

            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                for (int j = 0, l = subFluid.m_ParallelPlugins.Count; j < l; ++j)
                {
                    var plugin = subFluid.m_ParallelPlugins[j];

                    if (!plugin.shouldUpdate)
                        continue;

                    plugin.EndPluginFrame();
                }
            }
        }
        void UpdatePluginsPostSolve()
        {
            // Post solve (including sub-fluids)
            for (int i = 0, l = m_ParallelPlugins.Count; i < l; ++i)
            {
                var plugin = m_ParallelPlugins[i];

                if (!plugin.shouldUpdate)
                    continue;

                plugin.PluginPostSolve();
            }

            for (var i = 0; i < m_SubFluids.Count; ++i)
            {
                var subFluid = m_SubFluids[i];

                for (int j = 0, l = subFluid.m_ParallelPlugins.Count; j < l; ++j)
                {
                    var plugin = subFluid.m_ParallelPlugins[j];

                    if (!plugin.shouldUpdate)
                        continue;

                    plugin.PluginPostSolve();
                }
            }
        }
    }
}
