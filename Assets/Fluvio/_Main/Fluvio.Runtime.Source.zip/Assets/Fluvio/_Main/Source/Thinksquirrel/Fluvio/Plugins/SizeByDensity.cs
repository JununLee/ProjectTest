// SizeByDensity.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     This plugin changes the size of particles based on their density.
    /// </summary>
    /// <remarks>
    ///     Changing size by density is useful for simulating the diffusion of gas particles.
    /// </remarks>
    [AddComponentMenu("Fluvio/Plugins/Size By Density")]
    public class SizeByDensity : FluidParticlePlugin
    {
        [SerializeField] FluvioMinMaxCurve m_Size;
        [SerializeField] Vector2 m_Range;
        [SerializeField] float m_Smoothing;

        /// <summary>
        ///     The size by density curve, from minimum to rest density.
        /// </summary>
        public FluvioMinMaxCurve size { get { return m_Size; } set { m_Size = value; } }

        /// <summary>
        ///     The density range for the curve.
        /// </summary>
        public Vector2 range { get { return m_Range; } set { m_Range = value; } }

        /// <summary>
        ///     The amount to smooth the size output by interpolating with the previous size.
        /// </summary>
        public float smoothing { get { return m_Smoothing; } set { m_Smoothing = value; } }

        protected override void OnResetPlugin()
        {
            var sz = fluid ? fluid.smoothingDistance : 1.0f;
            m_Size = new FluvioMinMaxCurve { scalar = sz, minConstant = sz, maxConstant = sz };
            SetCurveAsSigned(m_Size, false);
            range = fluid ? new Vector2(fluid.minimumDensity, fluid.density * 1.25f) : new Vector2(100, 1000);
            smoothing = 0.25f;
        }
        protected override void OnEnablePlugin()
        {
            SetComputeShader(FluvioComputeShader.Find("ComputeShaders/Plugins/SizeByDensity"), "OnUpdatePlugin");
        }
        protected override bool OnStartPluginFrame(ref FluvioTimeStep timeStep)
        {            
            smoothing = Mathf.Clamp01(m_Smoothing);

            if (m_Size == null)
            {
                var sz = fluid ? fluid.smoothingDistance : 1.0f;
                m_Size = new FluvioMinMaxCurve { scalar = sz, minConstant = sz, maxConstant = sz };
            }
            SetCurveAsSigned(m_Size, false);

            return true;
        }
        protected override void OnSetComputeShaderVariables()
        {
            SetComputePluginMinMaxCurve(0, m_Size);
            var rangeSmoothing = new Vector4(m_Range.x, m_Range.y, m_Smoothing, 0.0f);
            SetComputePluginValue(1, rangeSmoothing);
        }        
        protected override void OnUpdatePlugin(SolverData solverData, int particleIndex)
        {
            var density = solverData.GetDensity(particleIndex);
            var d = Mathf.InverseLerp(m_Range.x, m_Range.y, density);
            var seed = solverData.GetRandomSeed(particleIndex);

            solverData.SetSize(particleIndex, Mathf.Max(0.0f, Mathf.Lerp(solverData.GetSize(particleIndex), m_Size.Evaluate(seed, d), m_Smoothing)));
        }
    }
}
