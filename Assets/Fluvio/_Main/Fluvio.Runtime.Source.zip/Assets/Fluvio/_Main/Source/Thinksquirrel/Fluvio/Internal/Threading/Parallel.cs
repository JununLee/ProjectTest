// Parallel.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;

namespace Thinksquirrel.Fluvio.Internal.Threading
{   
    //! \cond PRIVATE
    public static class Parallel
    {
        static IThreadPool s_ThreadPool;

        public static bool supportsMultipleThreads { get { return s_ThreadPool != null; } }
        
        public static void InitializeThreadPool(IThreadPool threadPool)
        {
            s_ThreadPool = threadPool;
        }

        public static void SetPriority()
        {
            if (s_ThreadPool != null)
                s_ThreadPool.SetPriority();
        }

        public static int GetThreadCount()
        {
            return s_ThreadPool != null ? s_ThreadPool.GetThreadCount() : 0;
        }

        public static void Reset()
        {
            if (s_ThreadPool == null)
                return;
            
            s_ThreadPool.Dispose();
            s_ThreadPool = null;
        }

        public static void For(int iterations, ParallelAction action)
        {
            // No multithreaded support
            if (s_ThreadPool == null)
            {
                for (var i = 0; i < iterations; ++i) action(i);                
                return;
            }
            
            s_ThreadPool.For(iterations, action);
        }
        public static void RunInBackground(Action action)
        {
            // No multithreaded support
            if (s_ThreadPool == null)
            {
                action();
                return;
            }

            s_ThreadPool.RunInBackground(action);
        }
        public static int CompareExchange(ref int location1, int value, int comparand)
        {
            // No multithreaded support
            if (s_ThreadPool == null)
            {
                var initialValue = location1;
                if (location1 == comparand) location1 = value;
                return initialValue;
            }

            return s_ThreadPool.CompareExchange(ref location1, value, comparand);
        }
    }
    //! \endcond
}
