// SmoothingKernel.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    abstract class SmoothingKernel
    {
        #region Instance Fields
        protected float factor;
        protected float kernelSize;
        protected float kernelSize3;
        protected float kernelSize6;
        protected float kernelSize9;
        protected float kernelSizeSq;
        #endregion

        #region Public API
        public void Initialize(float kernelSize)
        {
            if (kernelSize == this.kernelSize)
                return;

            this.kernelSize = kernelSize;
            kernelSizeSq = kernelSize*kernelSize;
            kernelSize3 = kernelSize*kernelSize*kernelSize;
            kernelSize6 = kernelSize*kernelSize*kernelSize*kernelSize*kernelSize*kernelSize;
            kernelSize9 = kernelSize*kernelSize*kernelSize*kernelSize*kernelSize*kernelSize*kernelSize*kernelSize*
                          kernelSize;
            CalculateFactor();
        }
        public float GetFactor()
        {
            return factor;
        }
        #endregion

        #region Constructors
        protected SmoothingKernel() : this(1.0f) {}
        protected SmoothingKernel(float kernelSize)
        {
            Initialize(kernelSize);
        }
        #endregion

        #region Abstract, Virtual, and Override
        public abstract float Calculate(ref Vector4 distance);
        public abstract Vector4 CalculateGradient(ref Vector4 distance);
        public abstract float CalculateLaplacian(ref Vector4 distance);
        protected abstract void CalculateFactor();
        #endregion
    }
}
