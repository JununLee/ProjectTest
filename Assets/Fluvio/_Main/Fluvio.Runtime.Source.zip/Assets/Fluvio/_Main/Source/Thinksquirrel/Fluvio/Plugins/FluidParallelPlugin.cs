// FluidParallelPlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Internal.ObjectModel;
using UnityEngine;
using Keyframe = Thinksquirrel.Fluvio.Internal.Keyframe;

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     Base class for all fluid plugins that can operate on multiple threads or in a compute shader.
    /// </summary>
    public abstract class FluidParallelPlugin : FluidPlugin, IComputePlugin
    {
        #region Serialized Fields
        [SerializeField] bool m_IncludeFluidGroup;
        [SerializeField] bool m_RunAcceleratedOnly;
        [SerializeField, HideInInspector] FluvioComputeShader m_ComputeShader;
        [SerializeField, HideInInspector] int m_ComputeShaderKernelIndex = -1;
        #endregion

        #region Instance Fields
        bool m_IsValidComputePlugin;
        bool m_ShouldUpdate;
        int m_Timer;
        readonly FluvioComputeBufferBase[] m_PluginBuffers = new FluvioComputeBufferBase[FluvioSettings.kMaxPluginBuffers];
        readonly Array[] m_BufferValueCache = new Array[FluvioSettings.kMaxPluginBuffers];
        #endregion

        #region Abstract, Virtual, and Override
        internal abstract bool IsPairPlugin();
        internal abstract void UpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex);
        /// <summary>
        ///     Provides an end method for the fluid plugin each frame.
        /// </summary>
        /// <remarks>
        ///     This runs on the main thread.
        /// </remarks>
        protected virtual void OnEndPluginFrame() {}
        /// <summary>
        ///     Provides a method that runs after integration each frame.
        /// </summary>
        /// <remarks>
        ///     This runs on the main thread. Use this method to modify resulting particle velocities or to emit particles.
        /// </remarks>
        protected virtual void OnPluginPostSolve() {}
        /// <summary>
        ///     Provides a start method for the fluid plugin each frame. Returns false if the plugin should not continue execution
        ///     for this frame.
        /// </summary>
        /// <param name="timeStep">The current simulation time step for this frame.</param>
        /// <returns>False if the plugin should not continue execution for the rest of the frame; otherwise, true.</returns>
        /// <remarks>
        ///     This runs on the main thread.
        /// </remarks>
        protected virtual bool OnStartPluginFrame(ref FluvioTimeStep timeStep)
        {
            return true;
        }
        /// <summary>
        ///     Provides a method to pass plugin variables to the plugin's compute shader.
        /// </summary>
        /// <remarks>
        ///     This runs on the main thread.
        /// </remarks>
        protected virtual void OnSetComputeShaderVariables() {}
        /// <summary>
        ///     Provides a method to read custom compute buffers from the plugin, if needed.
        /// </summary>
        /// <remarks>
        ///     Reading back from compute buffers can incur a significant overhead.
        /// </remarks>
        protected virtual void OnReadComputeBuffers() {}
        
        // ReSharper disable ParameterHidesMember

        /// <summary>
        ///     Sets a compute shader for the plugin to use, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="computeShader">The compute shader to set.</param>
        /// <param name="kernelName">The compute kernel to use.</param>
        /// <remarks>
        ///     If a compute shader is unavailable on a hardware accelerated fluid, the plugin will execute using the CPU fallback.
        /// </remarks>        
        protected void SetComputeShader(FluvioComputeShader computeShader, string kernelName)
        {
            m_ComputeShader = computeShader;
            m_ComputeShaderKernelIndex = computeShader ? computeShader.FindKernel(kernelName) : -1;
        }
        // ReSharper restore ParameterHidesMember
        /// <summary>
        ///     Sets a compute buffer for the plugin to use and copy the specified data into the buffer, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index">The plugin data index to use. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="data">An array of data to copy to the buffer.</param>
        /// <param name="readWrite">If true, set the buffer as writable from the hardware device.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnSetComputeShaderVariables"/>.
        /// </remarks>
        protected void SetComputePluginBuffer<T>(int index, T[] data, bool readWrite = false) where T : struct
        {
            SetComputePluginBuffer<T>(index, data.Length, readWrite);

            var buffer = m_PluginBuffers[index];
            
            ((FluvioComputeBuffer<T>)buffer).SetData(data);
        }

        /// <summary>
        ///     Sets a compute buffer of the specified type and length for the plugin to use, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index">The plugin data index to use. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="length">The number of elements in the buffer.</param>
        /// <param name="readWrite">If true, set the buffer as writable from the hardware device.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnSetComputeShaderVariables"/>.
        /// </remarks>
        protected void SetComputePluginBuffer<T>(int index, int length, bool readWrite = false) where T : struct
        {
            if (index < 0 || index >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer = m_PluginBuffers[index];

            if (buffer != null && buffer._readWrite == readWrite && buffer.count == length &&
                buffer._bufferType == typeof (T)) return;
            
            if (buffer != null) buffer.Dispose();
            buffer = new FluvioComputeBuffer<T>(length, readWrite);
            m_PluginBuffers[index] = buffer;
        }

        /// <summary>
        ///     Sets a value for the plugin to use, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index">The plugin data index to use. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="value">The value to copy to the compute plugin.</param>
        /// <param name="readWrite">If true, set the data as writable from the hardware device.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnSetComputeShaderVariables"/>.
        /// </remarks>
        protected void SetComputePluginValue<T>(int index, T value, bool readWrite = false) where T : struct
        {
            if (index < 0 || index >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer = m_PluginBuffers[index];
            var bufferValueCache = m_BufferValueCache[index] as T[];

            if (buffer == null || bufferValueCache == null || buffer._readWrite != readWrite || buffer.count != 1 ||
                buffer._bufferType != typeof(T))
            {
                if (buffer != null) buffer.Dispose();
                buffer = new FluvioComputeBuffer<T>(1, readWrite);
                bufferValueCache = new T[1];
                m_PluginBuffers[index] = buffer;
                m_BufferValueCache[index] = bufferValueCache;
            }

            bufferValueCache[0] = value;
            ((FluvioComputeBuffer<T>)buffer).SetData(bufferValueCache);
        }

        /// <summary>
        ///     Sets a min-max curve for the plugin to use, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index">The plugin data index to use. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="minMaxCurve">The min-max curve to copy to the compute plugin.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnSetComputeShaderVariables"/>.
        /// </remarks>
        protected void SetComputePluginMinMaxCurve(int index, FluvioMinMaxCurve minMaxCurve)
        {
            // TODO: Smaller buffers when not using "random between"

            if (index < 0 || index >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer = m_PluginBuffers[index];

            var bufferValueCache = m_BufferValueCache[index] as Keyframe[];

            var state = (int)minMaxCurve.minMaxState;
            var isConstant = state % 2 == 0;

            Keyframe[] maxCurveKeys;
            Keyframe[] minCurveKeys;

            if (isConstant)
            {
                minMaxCurve.GetCachedCurvesForConstants(
                    minMaxCurve.maxConstant, 
                    minMaxCurve.minConstant,
                    out maxCurveKeys,
                    out minCurveKeys);

                if (state < 2)
                    minCurveKeys = maxCurveKeys;
            }
            else
            {
                maxCurveKeys = FluvioHelpers.ConvertAll(minMaxCurve.maxCurve.keys, key => (Keyframe)key);
                minCurveKeys = state < 2 ? maxCurveKeys : FluvioHelpers.ConvertAll(minMaxCurve.minCurve.keys, key => (Keyframe)key);
            }

            var length = maxCurveKeys.Length + minCurveKeys.Length + 1;

            if (buffer == null || bufferValueCache == null || buffer._readWrite || buffer.count != length ||
                buffer._bufferType != typeof (Keyframe))
            {
                if (buffer != null) buffer.Dispose();
                buffer = new FluvioComputeBuffer<Keyframe>(length);
                bufferValueCache = new Keyframe[length];
                m_PluginBuffers[index] = buffer;
                m_BufferValueCache[index] = bufferValueCache;
            }

            const int maxCurveStartIndex = 1;
            var maxCurveEndIndex = maxCurveStartIndex + maxCurveKeys.Length - 1;

            var minCurveStartIndex = maxCurveEndIndex + 1;
            var minCurveEndIndex = minCurveStartIndex + minCurveKeys.Length - 1;
            var scalar = isConstant ? 1.0f : minMaxCurve.scalar;

            var infoKeyframe = new Keyframe(maxCurveEndIndex, minCurveStartIndex, minCurveEndIndex, scalar);

            bufferValueCache[0] = infoKeyframe;

            maxCurveKeys.CopyTo(bufferValueCache, maxCurveStartIndex);
            minCurveKeys.CopyTo(bufferValueCache, minCurveStartIndex);
            
            ((FluvioComputeBuffer<Keyframe>)buffer).SetData(bufferValueCache);
        }
        /// <summary>
        ///     Sets a min-max gradient for the plugin to use, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index0">The plugin data index to use for color keys. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="index1">The plugin data index to use for alpha keys. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="minMaxGradient">The min-max gradient to copy to the compute plugin.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnSetComputeShaderVariables"/>.
        /// </remarks>
        protected void SetComputePluginMinMaxGradient(int index0, int index1, FluvioMinMaxGradient minMaxGradient)
        {
            // TODO: Smaller buffers when not using "random between"

            if (index0 < 0 || index0 >= FluvioSettings.kMaxPluginBuffers || 
                index1 < 0 || index1 >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer0 = m_PluginBuffers[index0];
            var buffer1 = m_PluginBuffers[index1];

            var bufferValueCache0 = m_BufferValueCache[index0] as GradientColorKey[];
            var bufferValueCache1 = m_BufferValueCache[index1] as GradientAlphaKey[];

            var state = (int)minMaxGradient.minMaxState;
            var isColor = state % 2 == 0;

            GradientColorKey[] maxGradientColorKeys;
            GradientAlphaKey[] maxGradientAlphaKeys;
            GradientColorKey[] minGradientColorKeys;
            GradientAlphaKey[] minGradientAlphaKeys;

            if (isColor)
            {
                minMaxGradient.GetCachedGradientsForColors(
                    minMaxGradient.maxColor, 
                    minMaxGradient.minColor,
                    out maxGradientColorKeys, 
                    out maxGradientAlphaKeys,
                    out minGradientColorKeys,
                    out minGradientAlphaKeys);

                if (state < 2)
                {
                    minGradientColorKeys = maxGradientColorKeys;
                    minGradientAlphaKeys = maxGradientAlphaKeys;
                }
            }
            else
            {
                maxGradientColorKeys = minMaxGradient.maxGradient.colorKeys;
                maxGradientAlphaKeys = minMaxGradient.maxGradient.alphaKeys;

                if (state < 2)
                {
                    minGradientColorKeys = maxGradientColorKeys;
                    minGradientAlphaKeys = maxGradientAlphaKeys;
                }
                else
                {
                    minGradientColorKeys = minMaxGradient.minGradient.colorKeys;
                    minGradientAlphaKeys = minMaxGradient.minGradient.alphaKeys;
                }
            }

            var length0 = maxGradientColorKeys.Length + minGradientColorKeys.Length + 1;
            var length1 = maxGradientAlphaKeys.Length + minGradientAlphaKeys.Length + 1;

            if (buffer0 == null || bufferValueCache0 == null || buffer0._readWrite || buffer0.count != length0 ||
                buffer0._bufferType != typeof(GradientColorKey))
            {
                if (buffer0 != null) buffer0.Dispose();
                buffer0 = new FluvioComputeBuffer<GradientColorKey>(length0);
                bufferValueCache0 = new GradientColorKey[length0];
                m_PluginBuffers[index0] = buffer0;
                m_BufferValueCache[index0] = bufferValueCache0;
            }

            if (buffer1 == null || bufferValueCache1 == null || buffer1._readWrite || buffer1.count != length1 ||
                buffer1._bufferType != typeof(GradientAlphaKey))
            {
                if (buffer1 != null) buffer1.Dispose();
                buffer1 = new FluvioComputeBuffer<GradientAlphaKey>(length1);
                bufferValueCache1 = new GradientAlphaKey[length1];
                m_PluginBuffers[index1] = buffer1;
                m_BufferValueCache[index1] = bufferValueCache1;
            }

            const int maxColorKeyStartIndex = 1;
            var maxColorKeyEndIndex = maxColorKeyStartIndex + maxGradientColorKeys.Length - 1;

            var minColorKeyStartIndex = maxColorKeyEndIndex + 1;
            var minColorKeyEndIndex = minColorKeyStartIndex + minGradientColorKeys.Length - 1;

            const int maxAlphaKeyStartIndex = 1;
            var maxAlphaKeyEndIndex = maxAlphaKeyStartIndex + maxGradientAlphaKeys.Length - 1;

            var minAlphaKeyStartIndex = maxAlphaKeyEndIndex + 1;
            var minAlphaKeyEndIndex = minAlphaKeyStartIndex + minGradientAlphaKeys.Length - 1;

            var colorInfo = new GradientColorKey(new Color(maxColorKeyEndIndex, minColorKeyStartIndex, minColorKeyEndIndex, maxAlphaKeyEndIndex), minAlphaKeyStartIndex);
            var alphaInfo = new GradientAlphaKey(minAlphaKeyEndIndex, 0.0f);
            
            bufferValueCache0[0] = colorInfo;
            bufferValueCache1[0] = alphaInfo;
            
            maxGradientColorKeys.CopyTo(bufferValueCache0, maxColorKeyStartIndex);
            minGradientColorKeys.CopyTo(bufferValueCache0, minColorKeyStartIndex);
            
            maxGradientAlphaKeys.CopyTo(bufferValueCache1, maxAlphaKeyStartIndex);
            minGradientAlphaKeys.CopyTo(bufferValueCache1, minAlphaKeyStartIndex);

            ((FluvioComputeBuffer<GradientColorKey>)buffer0).SetData(bufferValueCache0);
            ((FluvioComputeBuffer<GradientAlphaKey>)buffer1).SetData(bufferValueCache1);
        }
        /// <summary>
        /// Set a min-max curve as signed (between -1 and 1). Whether or not a curve is signed depends on the plugin implementation.
        /// </summary>
        /// <param name="curve">The curve to set as signed.</param>
        /// <param name="isSigned">If true, the curve will be signed; otherwise it will be unsigned.</param>
        /// <remarks>Curves are unsigned by default.</remarks>
        protected void SetCurveAsSigned(FluvioMinMaxCurve curve, bool isSigned)
        {
            curve.isSigned = isSigned;
        }
        /// <summary>
        ///     Gets the data from a plugin compute buffer, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index">The plugin data index to use. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="data">An array to write buffer data to.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnReadComputeBuffers"/>.
        /// </remarks>
        protected void GetComputePluginBuffer<T>(int index, T[] data) where T : struct
        {
            if (index < 0 || index >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer = m_PluginBuffers[index];

            if (buffer != null) ((FluvioComputeBuffer<T>)buffer).GetData(data);
        }
        /// <summary>
        ///     Gets a value from a compute plugin, if the fluid is hardware accelerated.
        /// </summary>
        /// <param name="index">The plugin data index to use. Must be less than FluvioSettings.kMaxPluginBuffers.</param>
        /// <param name="value">The value to retrieve from the compute plugin.</param>
        /// <remarks>
        ///     This should only be used in <see cref="OnReadComputeBuffers"/>.
        /// </remarks>
        protected void GetComputePluginValue<T>(int index, ref T value) where T : struct
        {
            if (index < 0 || index >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer = m_PluginBuffers[index];
            var bufferValueCache = m_BufferValueCache[index] as T[];

            if (buffer == null || bufferValueCache == null) return;
            
            ((FluvioComputeBuffer<T>) buffer).SetData(bufferValueCache);
            value = bufferValueCache[0];
        }

        /// <summary>
        ///     Release the compute plugin buffer at the specified index. Does nothing if the buffer has never been set.
        /// </summary>
        /// <param name="index">The index of the buffer to release.</param>
        /// <remarks>
        ///     Plugin buffers are automatically cleaned up when a plugin is disabled.
        /// </remarks>
        protected void ClearComputePluginData(int index)
        {
            if (index < 0 || index >= FluvioSettings.kMaxPluginBuffers)
                return;

            var buffer = m_PluginBuffers[index];

            if (buffer == null) return;
            
            buffer.Dispose();
            m_PluginBuffers[index] = null;
            m_BufferValueCache[index] = null;
        }

        //! \cond PRIVATE
        protected override sealed void OnDisable()
        {
            for(var i = 0; i < FluvioSettings.kMaxPluginBuffers; ++i)
                ClearComputePluginData(i);

            base.OnDisable();
        }
        //! \endcond

        /// <summary>
        ///     Removes a compute shader from the plugin. This forces the plugin to execute on the CPU.
        /// </summary>
        protected void RemoveComputeShader()
        {
            m_ComputeShader = null;
            m_ComputeShaderKernelIndex = -1;
        }
        #endregion

        #region IComputePlugin implementation
        /// <summary>
        ///     The compute shader currently assigned to this plugin.
        /// </summary>
        public FluvioComputeShader computeShader
        {
            get { return m_ComputeShader; }
        }
        /// <summary>
        ///     The compute shader kernel currently assigned to this plugin. 
        /// </summary>
        public int kernelIndex
        {
            get { return m_ComputeShaderKernelIndex; }
        }
        /// <summary>
        ///     Returns true if the plugin can currently execute on the GPU or another hardware accelerated platform.
        /// </summary>
        public bool isValidComputePlugin
        {
            get { return m_IsValidComputePlugin; }
        }
        /// <summary>
        ///     Controls whether or not a plugin should run on hardware accelerated platforms only.
        /// </summary>
        /// <remarks>
        ///     This disables the CPU fallback for the plugin.
        /// </remarks>
        public bool runAcceleratedOnly
        {
            get { return m_RunAcceleratedOnly; }
            set { m_RunAcceleratedOnly = value; }
        }
        void IComputePlugin.SetComputeShaderVariables()
        {
            // Set variables
            OnSetComputeShaderVariables();
            
            // Built-in
            m_ComputeShader.SetInt(kernelIndex, "fluvio_IncludeFluidGroup", m_IncludeFluidGroup ? 1 : 0);
            m_ComputeShader.SetInt(kernelIndex, "fluvio_PluginFluidID", fluid.GetFluidID());

            // User buffers
            for (var i = 0; i < FluvioSettings.kMaxPluginBuffers; ++i)
            {
                var buffer = m_PluginBuffers[i];

                if (buffer != null)
                {
                    m_ComputeShader.SetPluginData(kernelIndex, i, buffer);
                }
            }
        }
        void IComputePlugin.GetComputeShaderBuffers()
        {
            // Get buffers
            OnReadComputeBuffers();
        }
        #endregion

        #region IParallelPlugin Implementation
        bool IParallelPlugin.isPairPlugin
        {
            get { return IsPairPlugin(); }
        }
        bool IParallelPlugin.shouldUpdate
        {
            get { return m_ShouldUpdate; }
        }
        void IParallelPlugin.StartPluginFrame(ref FluvioTimeStep timeStep)
        {
            if (!fluid)
            {
                m_ShouldUpdate = false;
                return;
            }

            var f = fluid.parentFluid ? fluid.parentFluid : fluid;
            m_Timer = Timers.CreateTimer(f, "Plugins");
            Timers.StartTimer(m_Timer);
            m_IsValidComputePlugin = f.IsHardwareAccelerated() && computeShader != null && kernelIndex >= 0;
            if (runAcceleratedOnly && !m_IsValidComputePlugin)
            if (!enabled || !gameObject.activeInHierarchy)
            {
                m_ShouldUpdate = false;
                Timers.StopTimer(m_Timer);
                return;
            }

            m_IsValidComputePlugin = f.IsHardwareAccelerated() && computeShader != null && kernelIndex >= 0;
            if (runAcceleratedOnly && !m_IsValidComputePlugin)
                m_ShouldUpdate = false;
            else
                m_ShouldUpdate = OnStartPluginFrame(ref timeStep);
            Timers.StopTimer(m_Timer);
        }
        void IParallelPlugin.PluginPostSolve()
        {
            Timers.StartTimer(m_Timer);
            OnPluginPostSolve();
            Timers.StopTimer(m_Timer);
        }
        void IParallelPlugin.UpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex)
        {
            Timers.StartTimer(m_Timer);
            UpdatePlugin(solverData, particleIndex, neighborIndex);
            Timers.StopTimer(m_Timer);
        }
        void IParallelPlugin.EndPluginFrame()
        {
            Timers.StartTimer(m_Timer);
            OnEndPluginFrame();
            Timers.StopTimer(m_Timer);
        }
        /// <summary>
        ///     If true, also process any sub-fluids or parent fluids with this plugin.
        /// </summary>
        public bool includeFluidGroup
        {
            get { return m_IncludeFluidGroup; }
            set { m_IncludeFluidGroup = value; }
        }
        #endregion
    }
}
