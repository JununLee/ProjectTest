// FluidCollider.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Represents a three dimensional fluid collider.
    /// </summary>
    /// <remarks>
    ///     Fluid colliders are a special type of fluid that serve as collision boundaries for fluid simulation.
    /// </remarks>
    [RequireComponent(typeof(Collider))]
    [AddComponentMenu("Fluvio/Colliders/Fluid Collider")]    
    [ExecuteInEditMode]
    public sealed class FluidCollider : FluidColliderBase
    {
        #region Serialized Fields
        [SerializeField] Collider m_AttatchedCollider;
        [SerializeField] float m_WheelColliderThickness = 0.214884f;
        #endregion

        #region Instance Fields
        [NonSerialized] Vector3 m_OldCenter;
        [NonSerialized] Vector3 m_OldSize;
        [NonSerialized] float m_OldRadius;
        #endregion

        #region Public API        
        /// <summary>
        ///     The attatched collider. This must be on the same GameObject as the fluid collider.
        /// </summary>
        public Collider attatchedCollider
        {
            get { return m_AttatchedCollider; }
            set
            {
                if (value == null || m_AttatchedCollider == value || value.gameObject != gameObject) return;
                m_AttatchedCollider = value;
            }
        }
        /// <summary>
        ///     Controls whether or not the collider should be filled.
        /// </summary>
        /// <remarks>
        ///     Filled colliders provide better simulation for solid objects and higher velocity objects, but have a higher performance overhead (especially in 3D).
        ///     For edge and terrain colliders, this will always return false.
        /// </remarks>
        public override bool fillCollider
        {
            get
            {
                var terrain = m_AttatchedCollider as TerrainCollider;
                return !terrain && base.fillCollider;
            }
            set { base.fillCollider = value; }
        }
        /// <summary>
        ///     Controls the thickness of the collider when using attached wheel colliders.
        /// </summary>
        /// <remarks>
        ///     This has no effect for other collider types.
        /// </remarks>
        public float wheelColliderThickness
        {
            get { return m_WheelColliderThickness; }
            set { m_WheelColliderThickness = value; }
        }
        #endregion

        #region Unity Methods
        protected override void DrawCollider()
        {
            var points = GetCollisionPoints();
            
            var sz = smoothingDistance / colliderResolution;
            var sz3 = new Vector3(sz, sz, sz);
            var matrix = GetLocalToWorldMatrix();
            for (var i = 0; i < points.Count; ++i)
            {
                Gizmos.DrawWireCube(matrix.MultiplyPoint3x4(points[i]), sz3);
            }
        }
        #endregion
        protected override void SetColliderMatrix()
        {
            var wheel = attatchedCollider as WheelCollider;
            var terrain = attatchedCollider as TerrainCollider;

            if (wheel)
            {
                Vector3 pos;
                Quaternion quat;
#if UNITY_5_0_PLUS
                wheel.GetWorldPose(out pos, out quat);
#else
                var wheelCenter = transform.TransformPoint(wheel.center);

                RaycastHit hit;
                if (Physics.Raycast(wheelCenter, -transform.up, out hit, wheel.suspensionDistance + wheel.radius))
                {
                    pos = hit.point + transform.up*wheel.radius;
                }
                else
                {
                    pos = wheelCenter - (transform.up*wheel.suspensionDistance);
                }

                quat = Quaternion.Euler(0, 90 + wheel.steerAngle, 0);
#endif
                SetMatrix(Matrix4x4.TRS(pos, quat, Vector3.one));
            }
            else if (terrain)
            {
                // override matrix
                SetMatrix(Matrix4x4.TRS(transform.position, Quaternion.identity, Vector3.one));
            }
            else
            {
                base.SetColliderMatrix();
            }
        }
        protected override bool ColliderIsValid()
        {
            return IsValid(attatchedCollider);
        }
        protected override bool ColliderHasChanged()
        {
            var box = attatchedCollider as BoxCollider;
            var sphere = attatchedCollider as SphereCollider;
            var capsule = attatchedCollider as CapsuleCollider;
            var wheel = attatchedCollider as WheelCollider;
            
            if (box)
            {
                if ((box.center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    (box.size - m_OldSize).sqrMagnitude > kEpsilon * kEpsilon)
                {
                    m_OldCenter = box.center;
                    m_OldSize = box.size;
                    return true;
                }
            }
            if (sphere)
            {
                if ((sphere.center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    Mathf.Abs(sphere.radius - m_OldRadius) > kEpsilon)
                {
                    m_OldCenter = sphere.center;
                    m_OldRadius = sphere.radius;
                    return true;
                }
            }
            if (capsule)
            {
                if ((capsule.center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    Mathf.Abs(capsule.radius - m_OldRadius) > kEpsilon ||
                    Mathf.Abs(capsule.height - m_OldSize[capsule.direction]) > kEpsilon)
                {
                    m_OldCenter = capsule.center;
                    m_OldRadius = capsule.radius;
                    m_OldSize = Vector3.zero;
                    m_OldSize[capsule.direction] = capsule.height;
                    return true;
                }
            }
            if (wheel)
            {
                if ((wheel.center - m_OldCenter).sqrMagnitude > kEpsilon * kEpsilon ||
                    Mathf.Abs(wheel.radius - m_OldRadius) > kEpsilon ||
                    Mathf.Abs(m_WheelColliderThickness - m_OldSize.x) > kEpsilon ||
                    Mathf.Abs(wheel.suspensionDistance - m_OldSize.y) > kEpsilon)
                {
                    m_OldCenter = wheel.center;
                    m_OldRadius = wheel.radius;
                    m_OldSize.x = m_WheelColliderThickness;
                    m_OldSize.y = wheel.suspensionDistance;
                    return true;
                }
            }
            return false;
        }
        protected override void Voxelize()
        {
            var box = attatchedCollider as BoxCollider;
            var sphere = attatchedCollider as SphereCollider;
            var capsule = attatchedCollider as CapsuleCollider;
            var mesh = attatchedCollider as MeshCollider;
            var wheel = attatchedCollider as WheelCollider;
            var terrain = attatchedCollider as TerrainCollider;

            var scale = transform.localScale;

            // This should take care of zero and negative scales
            scale.x = Mathf.Abs(transform.localScale.x) < kEpsilon ? kEpsilon : Mathf.Abs(transform.localScale.x);
            scale.y = Mathf.Abs(transform.localScale.y) < kEpsilon ? kEpsilon : Mathf.Abs(transform.localScale.y);
            scale.z = Mathf.Abs(transform.localScale.z) < kEpsilon ? kEpsilon : Mathf.Abs(transform.localScale.z);

            if (sphere || capsule || mesh || wheel || terrain)
            {
                var scaleMax = terrain ? 1.0f : Mathf.Max(scale.x, Mathf.Max(scale.y, scale.z));
                scale.Set(scaleMax, scaleMax, scaleMax);
            }

            var dist = new Vector3(
                (smoothingDistance / colliderResolution) / scale.x,
                (smoothingDistance / colliderResolution) / scale.y,
                (smoothingDistance / colliderResolution) / scale.z);
            
            if (box)
            {
                var bounds = new Bounds(box.center, box.size);
                Voxelize(bounds, box, dist, DistanceBox);
            }
            else if (sphere)
            {
                var rad = sphere.radius * 2.0f + scale.x;

                var bounds = new Bounds(sphere.center, new Vector3(rad, rad, rad));
                Voxelize(bounds, sphere, dist, DistanceSphere);
            }
            else if (capsule)
            {
                var rad = capsule.radius * 2.0f + scale.x;

                var size = new Vector3(rad, rad, rad);
                size[capsule.direction] = capsule.height + (capsule.radius * 2.0f) + scale[capsule.direction];

                var bounds = new Bounds(capsule.center, size);
                Voxelize(bounds, capsule, dist, DistanceCapsule);
            }
            else if (mesh)
            {
                var bounds = mesh.sharedMesh.bounds;
                Voxelize(bounds, mesh, dist, DistanceMesh);
            }
            else if (wheel)
            {
                var rad = wheel.radius * 2.0f + scale.x;

                var bounds = new Bounds(wheel.center, new Vector3(m_WheelColliderThickness, rad, rad));
                Voxelize(bounds, wheel, dist, DistanceWheel);
            }
            else if (terrain)
            {
                var data = terrain.terrainData;

                if (data)
                {
                    var size = data.size;
                    var center = new Vector3(size.x * 0.5f, size.y * 0.5f, size.z * 0.5f);
                    var bounds = new Bounds(center, size);
                    Voxelize(bounds, terrain, dist, DistanceTerrain);
                }
            }
        }
        protected override void GetDefaultCollider()
        {
            if (m_AttatchedCollider) return;
            m_AttatchedCollider = GetComponent<Collider>();
        }

        void Voxelize(Bounds bounds, Collider col, Vector3 dist, Func<Bounds, Collider, Vector3, Vector3, bool> distanceFunc)
        {
            var min = bounds.min;
            var max = bounds.max;
            
            var shouldBreak = false;

            for (var x = min.x; x < max.x + dist.x; x += dist.x)
            {
                if (shouldBreak) break;

                for (var y = min.y; y < max.y + dist.y; y += dist.y)
                {
                    if (shouldBreak) break;
                    
                    for (var z = min.z; z < max.z + dist.z; z += dist.z)
                    {
                        if (shouldBreak) break;

                        var pos = new Vector3(x, y, z);
                        if (distanceFunc(bounds, col, pos, dist))
                        {
                            shouldBreak = !AddCollisionPoint(pos);
                        }
                    }
                }
            }
        }
        #region Distance functions
        bool DistanceBox(Bounds bounds, Collider col, Vector3 pos, Vector3 dist)
        {
            bounds.Expand(dist);            

            return bounds.Contains(pos) &&
                   (fillCollider ||
                    pos.x < bounds.min.x + (dist.x*FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.y < bounds.min.y + (dist.y*FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.z < bounds.min.z + (dist.z*FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.x > bounds.max.x - (dist.x*FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.y > bounds.max.y - (dist.y*FluvioSettings.kFluidColliderSkinWidth) ||
                    pos.z > bounds.max.z - (dist.z*FluvioSettings.kFluidColliderSkinWidth));
        }
        bool DistanceSphere(Bounds bounds, Collider col, Vector3 pos, Vector3 dist)
        {
            var sphere = col as SphereCollider;
            if (!sphere) return false;

            var center = sphere.center;
            var radius = sphere.radius;
            var dst = Vector3.Distance(pos, center);

            return dst < radius && (fillCollider || dst > radius - (dist.x * FluvioSettings.kFluidColliderSkinWidth));
        }
        bool DistanceCapsule(Bounds bounds, Collider col, Vector3 pos, Vector3 dist)
        {
            var capsule = col as CapsuleCollider;
            if (!capsule) return false;

            var center = capsule.center;
            var radius = capsule.radius;
            var height = capsule.height;
            
            // Special case: Height < radius - use sphere test
            if (height < radius)
            {
                var dst = Vector3.Distance(pos, center);
                return dst < radius && (fillCollider || dst > radius - (dist.x * FluvioSettings.kFluidColliderSkinWidth));
            }

            var h = Vector3.zero;
            h[capsule.direction] = (height - radius * 2.0f) * 0.5f;

            var ptA = center - h;
            var ptB = center + h;
            var proj = PointToLine3(ptA, ptB, pos);
            var d = Vector3.Distance(pos, proj);

            return fillCollider ? 
                d <= radius :
                d >= radius - dist.x * FluvioSettings.kFluidColliderSkinWidth * 0.5f && d <= radius;
        }
        bool DistanceMesh(Bounds bounds, Collider col, Vector3 pos, Vector3 dist)
        {
            var mesh = col as MeshCollider;
            if (!mesh) return false;

            var isInside = false;
            var isConcave = false;
            var distance = 1.0f/kEpsilon;

            var right = new Ray(Vector3.zero, -Vector3.right);
            var left = new Ray(Vector3.zero, -Vector3.left);
            var up = new Ray(Vector3.zero, -Vector3.up);
            var down = new Ray(Vector3.zero, -Vector3.down);
            var forward = new Ray(Vector3.zero, -Vector3.forward);
            var back = new Ray(Vector3.zero, -Vector3.back);
            
            bool isRight, isLeft, isUp, isDown, isFront, isBack;         

            RaycastHit rightHit, leftHit, upHit, downHit, forwardHit, backHit;

            var worldPos = GetLocalToWorldMatrix().MultiplyPoint3x4(pos);
            right.origin = -right.direction*distance + worldPos;
            left.origin = -left.direction*distance + worldPos;
            up.origin = -up.direction*distance + worldPos;
            down.origin = -down.direction*distance + worldPos;
            forward.origin = -forward.direction*distance + worldPos;
            back.origin = -back.direction*distance + worldPos;

            isRight = mesh.Raycast(right, out rightHit, distance);
            isLeft = mesh.Raycast(left, out leftHit, distance);
            isUp = mesh.Raycast(up, out upHit, distance);
            isDown = mesh.Raycast(down, out downHit, distance);
            isFront = mesh.Raycast(forward, out forwardHit, distance);
            isBack = mesh.Raycast(back, out backHit, distance);

            if (isRight && isLeft && isUp && isDown && isFront && isBack)
            {
                if (!ConcaveHull(worldPos, right, rightHit, mesh, distance) &&
                    !ConcaveHull(worldPos, left, leftHit, mesh, distance) &&
                    !ConcaveHull(worldPos, up, upHit, mesh, distance) &&
                    !ConcaveHull(worldPos, down, downHit, mesh, distance) &&
                    !ConcaveHull(worldPos, forward, forwardHit, mesh, distance) &&
                    !ConcaveHull(worldPos, back, backHit, mesh, distance))
                {
                    isInside = true;
                }
                else
                {
                    isConcave = true;
                }
            }

            if (fillCollider) return isInside;
            if (!isInside && !isConcave) return false;

            var verts = mesh.sharedMesh.vertices;
            var tris = mesh.sharedMesh.triangles;

            for (var i = 0; i < tris.Length; i +=3)
            {
                var a = verts[tris[i]];
                var b = verts[tris[i+1]];
                var c = verts[tris[i+2]];

                var d = dist.x * FluvioSettings.kFluidColliderSkinWidth*0.5f;
                var d2 = d*d;
                var result = (IsInTriangle(a, b, c, pos) ||
                        PointToLine3(a, b, pos).sqrMagnitude <= d2 ||
                        PointToLine3(b, c, pos).sqrMagnitude <= d2 ||
                        PointToLine3(c, a, pos).sqrMagnitude <= d2);

                if (result) return true;
            }

            return false;
        }
        bool DistanceWheel(Bounds bounds, Collider col, Vector3 pos, Vector3 dist)
        {
            var wheel = col as WheelCollider;
            if (!wheel) return false;

            var center = wheel.center;
            var radius = wheel.radius;

            // Constrain to two dimensions
            var x = pos.x;
            pos.x = 0;
            center.x = 0;

            var dst = Vector3.Distance(pos, center);            

            var d = dist.x*FluvioSettings.kFluidColliderSkinWidth;
            var width = m_WheelColliderThickness*0.5f;
            return dst < radius && 
                (fillCollider || 
                x >= width - d ||
                x <= -width + d ||
                dst > radius - d);
        }
        bool DistanceTerrain(Bounds bounds, Collider col, Vector3 pos, Vector3 dist)
        {
            var terrain = col as TerrainCollider;
            if (!terrain) return false;

            var data = terrain.terrainData;
            if (!data) return false;

            var size = bounds.size;
            var h = data.GetInterpolatedHeight(pos.x/size.x, pos.z/size.z);
            var pt = new Vector3(pos.x, h, pos.z);
            return Vector3.Distance(pt, pos) <= dist.x*FluvioSettings.kFluidColliderSkinWidth * 0.5f;
        }
#endregion
#region Helpers
        // Point to line - http://stackoverflow.com/questions/849211/shortest-distance-between-a-point-and-a-line-segment
        // Returns the point to check distance against, rather than the distance itself
        Vector3 PointToLine3(Vector3 v, Vector3 w, Vector3 p)
        {
            // Return minimum distance between line segment vw and point p
            var l2 = (w - v).sqrMagnitude;  // i.e. |w-v|^2 -  avoid a sqrt
            if (l2 < kEpsilon) return v;   // v == w case            
            // Consider the line extending the segment, parameterized as v + t (w - v).
            // We find projection of point p onto the line. 
            // It falls where t = [(p-v) . (w-v)] / |w-v|^2
            var t = Vector3.Dot(p - v, w - v) / l2;
            if (t < 0.0f) return v;       // Beyond the 'v' end of the segment
            if (t > 1.0f) return w;  // Beyond the 'w' end of the segment
            return v + t * (w - v);  // Projection falls on the segment
        }
        // Triangle test
        // http://www.blackpawn.com/texts/pointinpoly/
        bool IsInTriangle(Vector3 a, Vector3 b, Vector3 c, Vector3 p)
        {
            return SameSide(p, a, b, c) && SameSide(p, b, a, c);
        }
        bool SameSide(Vector3 p1, Vector3 p2, Vector3 a, Vector3 b)
        {
            var cp1 = Vector3.Cross(b - a, p1 - a);
            var cp2 = Vector3.Cross(b - a, p2 - a);
            return Vector3.Dot(cp1, cp2) >= 0.0f;
        }
        // Concave hull - http://answers.unity3d.com/questions/48243/finding-if-point-is-contained-within-irregular-mes.html
        bool ConcaveHull(Vector3 worldPos, Ray ray, RaycastHit hit, MeshCollider meshCollider, float distance)
        {
            Ray tempRay = new Ray(worldPos, -ray.direction);
            RaycastHit tempHit;
            float customDistance = distance - hit.distance;
            int lastPoint = hit.triangleIndex;

            while (meshCollider.Raycast(tempRay, out tempHit, customDistance))
            {

                if (tempHit.triangleIndex == lastPoint) break;
                lastPoint = tempHit.triangleIndex;
                customDistance = tempHit.distance;
                ray.origin = -ray.direction * customDistance + worldPos;

                if (!meshCollider.Raycast(ray, out tempHit, customDistance))
                {
                    return true;
                }

                if (tempHit.triangleIndex == lastPoint) break;
                lastPoint = tempHit.triangleIndex;
                customDistance -= tempHit.distance;

            }

            return false;

        }
#endregion
    }
}
