// FluidCubeEffector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins.Effectors
{
    /// <summary>
    ///     Defines a cube shaped effector.
    /// </summary>
    [AddComponentMenu("Fluvio/Plugins/Effectors/Cube Effector")]
    public sealed class FluidCubeEffector : FluidEffector
    {
        #region Serialized Fields
        [SerializeField] Vector3 m_Dimensions;
        #endregion

        #region Public API
        /// <summary>
        ///     The dimensions (in local space) of the cube.
        /// </summary>
        public Vector3 dimensions
        {
            get { return m_Dimensions; }
            set { m_Dimensions = value; }
        }
        #endregion
        
        #region Abstract, Virtual, and Override
        protected override void OnResetPlugin()
        {
            base.OnResetPlugin();

            m_Dimensions = Vector3.one;
        }
        protected override void OnEnablePlugin()
        {
            SetComputeShader(FluvioComputeShader.Find("ComputeShaders/Plugins/FluidEffector"), "OnUpdatePlugin_CubeEffector");
        }
        protected override Vector4 GetExtents()
        {
            return m_Dimensions*0.5f;
        }
        protected override bool IsInEffector(ref Vector3 queryPosition)
        {
            var bounds = new Bounds(GetPosition(), m_Dimensions);
            return bounds.Contains(_worldToLocalMatrix.MultiplyPoint3x4(queryPosition));
        }
        protected override void OnDrawEffectorGizmosSelected()
        {
            Gizmos.color = FluvioColors.GetColor(this);
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.DrawWireCube(position, dimensions);
        }
        #endregion
    }
}
