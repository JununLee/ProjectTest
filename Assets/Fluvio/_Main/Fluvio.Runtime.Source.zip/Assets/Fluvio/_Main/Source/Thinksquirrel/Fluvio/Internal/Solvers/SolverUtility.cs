﻿// SolverUtility.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Collections.Generic;

namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    internal static class SolverUtility
    {
        public static FluidParticle[] GetParticleArray(int particleIndex, int particleCount, FluidParticle[] particle, FluidParticle[] boundaryParticle)
        {
            return particleIndex >= particleCount ? boundaryParticle : particle;
        }
        public static int GetParticleArrayIndex(int particleIndex, int particleCount)
        {
            return particleIndex >= particleCount ? particleIndex - particleCount : particleIndex;
        }
    }
}