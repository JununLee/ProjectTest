// FluidPointEffector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins.Effectors
{
    /// <summary>
    ///     Defines a point effector.
    /// </summary>
    [AddComponentMenu("Fluvio/Plugins/Effectors/Point Effector")]
    public sealed class FluidPointEffector : FluidEffector
    {
        #region Abstract, Virtual, and Override
        protected override void OnEnablePlugin()
        {
            SetComputeShader(FluvioComputeShader.Find("ComputeShaders/Plugins/FluidEffector"), "OnUpdatePlugin_PointEffector");
        }
        protected override bool IsInEffector(ref Vector3 queryPosition)
        {
            return _worldToLocalMatrix.MultiplyPoint3x4(queryPosition) == GetPosition();
        }
        protected override void OnDrawEffectorGizmosSelected()
        {
            if (!fluid)
                return;

            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = FluvioColors.GetColor(this);
            Gizmos.DrawWireSphere(position, fluid.smoothingDistance * 0.125f);
        }
        #endregion
    }
}
