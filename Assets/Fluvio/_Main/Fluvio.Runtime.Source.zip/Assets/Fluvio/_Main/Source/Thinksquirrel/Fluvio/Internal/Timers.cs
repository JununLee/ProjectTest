using System.Collections.Generic;
using System.Diagnostics;

namespace Thinksquirrel.Fluvio.Internal
{
    class Timer
    {
        readonly Stopwatch m_Stopwatch = new Stopwatch();
        
        public void Start()
        {
            m_Stopwatch.Start();
        }
        public void Stop()
        {
            m_Stopwatch.Stop();
        }

        public void Reset()
        {
            m_Stopwatch.Reset();
        }
        public double milliseconds
        {
            get
            {
                return m_Stopwatch.Elapsed.TotalMilliseconds;
            }
        }
    }
    static class Timers
    {
        static readonly List<Timer> s_Timers = new List<Timer>();
        static readonly List<string> s_TimerNames = new List<string>();
        static readonly List<string> s_TimerIdentifiers = new List<string>(); 
 
        public static void StartTimer(int id)
        {
            if (!FluvioSettings.enableTimers)
                return;

            var timer = s_Timers[id];

            timer.Start();
        }

        public static void StopTimer(int id)
        {
            if (!FluvioSettings.enableTimers)
                return;

            var timer = s_Timers[id];

            timer.Stop();
        }
        public static int CreateTimer(object obj, string name)
        {
            var result = FindTimer(obj, name);

            if (result >= 0) return result;
            
            s_TimerIdentifiers.Add(string.Format("{0}{1}", obj.GetHashCode(), name));
            s_TimerNames.Add(name);
            s_Timers.Add(new Timer());
            return s_Timers.Count - 1;
        }
        public static int FindTimer(object obj, string name)
        {
            return s_TimerIdentifiers.IndexOf(string.Format("{0}{1}", obj.GetHashCode(), name));
        }
        public static double GetTime(object obj, string name)
        {
            if (!FluvioSettings.enableTimers)
                return -1.0;

            var id = FindTimer(obj, name); 
            
            if (id < 0)
                return 0.0;

            var timer = s_Timers[id];
            var result = timer.milliseconds;
            timer.Reset();

            return result;
        } 
    }
}
