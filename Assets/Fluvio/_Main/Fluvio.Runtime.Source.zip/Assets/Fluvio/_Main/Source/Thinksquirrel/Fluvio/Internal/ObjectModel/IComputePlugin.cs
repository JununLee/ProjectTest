// IComputePlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal.ObjectModel
{
    interface IComputePlugin : IParallelPlugin
    {
        #region Abstract, Virtual, and Override
        FluvioComputeShader computeShader { get; }
        int kernelIndex { get; }
        bool isValidComputePlugin { get; }
        bool runAcceleratedOnly { get; }
        void SetComputeShaderVariables();
        void GetComputeShaderBuffers();
        #endregion
    }
}
