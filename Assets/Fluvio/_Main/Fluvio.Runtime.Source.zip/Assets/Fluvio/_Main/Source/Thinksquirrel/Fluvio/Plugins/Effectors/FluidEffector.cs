// FluidEffector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.
#pragma warning disable 169

using System;
using System.Runtime.InteropServices;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

//! This namespace contains all fluid effector components.
namespace Thinksquirrel.Fluvio.Plugins.Effectors
{
    /// <summary>Base class for effector components.</summary>
    public abstract class FluidEffector : FluidParticlePlugin
    {
        #region Serialized Fields
        [SerializeField] FluidEffectorForceType m_ForceType;
        [SerializeField] FluidEffectorForceAxis m_ForceAxis;
        [SerializeField] FluvioMinMaxCurve m_Force;
        [SerializeField] FluvioMinMaxCurve m_Vorticity;
        [SerializeField] float m_EffectorRange;
        [SerializeField] FluidEffectorDecayType m_DecayType;
        [SerializeField] float m_Decay;
        [SerializeField] float m_DecayJitter;
        [SerializeField] Vector3 m_Position;
        #endregion

        #region Instance Fields
        [NonSerialized]internal Matrix4x4 _worldToLocalMatrix;
        [NonSerialized] internal Matrix4x4 _localToWorldMatrix;
        #pragma warning disable 414
        [NonSerialized] Vector4 m_DecayParams;
        #pragma warning restore 414
        [NonSerialized] Vector4 m_ForceDirection;
        #endregion

        #region Public API
        /// <summary>
        ///     Controls the force type for the effector.
        /// </summary>
        public FluidEffectorForceType forceType
        {
            get { return m_ForceType; }
            set { m_ForceType = value; }
        }
        /// <summary>
        ///     Controls the force axis for the effector.
        /// </summary>
        /// <remarks>
        ///     This is only used for directional forces.
        /// </remarks>
        public FluidEffectorForceAxis forceAxis
        {
            get { return m_ForceAxis; }
            set { m_ForceAxis = value; }
        }
        /// <summary>
        ///     Controls the force applied to particles within the effector's range.
        /// </summary>
        /// <remarks>
        ///     This property adds a constant linear force to particles.
        /// </remarks>
        public FluvioMinMaxCurve force
        {
            get { return m_Force; }
            set { m_Force = value; }
        }
        /// <summary>
        ///     Controls the vorticity applied to particles within the effector's range.
        /// </summary>
        /// <remarks>
        ///     This property adds a turbulent rotational force to particles.
        /// </remarks>
        public FluvioMinMaxCurve vorticity
        {
            get { return m_Vorticity; }
            set { m_Vorticity = value; }
        }
        /// <summary>
        ///     Gets the effector's center in world space. The location of this point depends on the type of effector as
        ///     well as the position of the object's transform.
        /// </summary>
        public Vector3 effectorCenter
        {
            get { return GetEffectorCenter(); }
        }
        /// <summary>
        ///     Controls the maximum range of the effector, from the effector's center.
        /// </summary>
        public float effectorRange
        {
            get { return m_EffectorRange; }
            set { m_EffectorRange = value; }
        }
        /// <summary>
        ///     Controls how the effector will decay.
        /// </summary>
        public FluidEffectorDecayType decayType
        {
            get { return m_DecayType; }
            set { m_DecayType = value; }
        }
        /// <summary>
        ///     If the effector decays particles, controls the rate of decay (from 0-1).
        /// </summary>
        public float decay
        {
            get { return m_Decay; }
            set { m_Decay = value; }
        }
        /// <summary>
        ///     If the effector decays particles, provides a random jitter to the rate of decay (from 0-1).
        /// </summary>
        public float decayJitter
        {
            get { return m_DecayJitter; }
            set { m_DecayJitter = value; }
        }
        /// <summary>The position offset (in local space) of the effector.</summary>
        public Vector3 position
        {
            get { return m_Position; }
            set { m_Position = value; }
        }
        /// <summary>The world space position of the effector.</summary>
        public Vector3 worldPosition
        {
            get { return _localToWorldMatrix.MultiplyPoint3x4(m_Position); }
            set { m_Position = _worldToLocalMatrix.MultiplyPoint3x4(value); }
        }        
        #endregion

        #region Abstract, Virtual, and Override
        protected override void OnResetPlugin()
        {
            m_ForceType = FluidEffectorForceType.Radial;
            m_ForceAxis = FluidEffectorForceAxis.Z;
            m_Force = new FluvioMinMaxCurve {scalar = 1.0f, minConstant = 0.0f, maxConstant = 0.0f};
            m_Vorticity = new FluvioMinMaxCurve {scalar = 10.0f, minConstant = 10.0f, maxConstant = 10.0f};
            SetCurveAsSigned(m_Force, true);
            SetCurveAsSigned(m_Vorticity, true);
            m_EffectorRange = 2.0f;
            m_DecayType = FluidEffectorDecayType.None;
            m_Decay = 1.0f;
            m_DecayJitter = 0.0f;
            m_Position = Vector3.zero;
        }
        /// <summary>
        ///     Determines whether or not the specified point (in world space) is within the effector.
        /// </summary>
        /// <param name="position">The world space position to query.</param>
        /// <returns>True if the point is in the effector, otherwise false.</returns>
        protected abstract bool IsInEffector(ref Vector3 position);
        protected override bool OnStartPluginFrame(ref FluvioTimeStep timeStep)
        {
            _localToWorldMatrix = transform.localToWorldMatrix;
            _worldToLocalMatrix = transform.worldToLocalMatrix;
            
            var doDecay = m_DecayType == FluidEffectorDecayType.Decay;
            var keepAlive = m_DecayType == FluidEffectorDecayType.KeepAlive;
            
            m_DecayParams = new Vector4(doDecay ? m_Decay : 0.0f, doDecay ? m_DecayJitter : 0.0f, keepAlive ? timeStep.deltaTime : 0.0f, m_ForceType == FluidEffectorForceType.Radial ? 1.0f : 0.0f);
            
            m_ForceDirection = Vector4.zero;
            if (m_ForceType == FluidEffectorForceType.Directional)
            {
                m_ForceDirection[(int) m_ForceAxis] = 1.0f;
                m_ForceDirection = _localToWorldMatrix.MultiplyVector(m_ForceDirection);
            }

            if (m_Force == null) m_Force = new FluvioMinMaxCurve { scalar = 1.0f, minConstant = 0.0f, maxConstant = 0.0f };                
            if (m_Vorticity == null) m_Vorticity = new FluvioMinMaxCurve { scalar = 10.0f, minConstant = 10.0f, maxConstant = 10.0f };                
            
            SetCurveAsSigned(m_Force, true);
            SetCurveAsSigned(m_Vorticity, true);

            return true;
        }
        [StructLayout(LayoutKind.Sequential)]
        internal struct FluidEffectorData
        {
	        public Matrix4x4 worldToLocalMatrix;
	        public Vector4 position;
	        public Vector4 worldPosition;
	        public Vector4 extents;
	        public Vector4 decayParams; // decayParams: x - decay (or 0), y - decayJitter, z - dt (or 0), w - 1.0f if radial force, 0.0f if directional force
	        public Vector4 forceDirection;
	        public float effectorRange;

	        // For alignment
	        float unused0;
	        float unused1;
	        float unused2;
        }
        protected override void OnSetComputeShaderVariables()
        {
            var effectorData = new FluidEffectorData
            {
                worldToLocalMatrix = _worldToLocalMatrix,
                position = m_Position,
                worldPosition = worldPosition,
                extents = GetExtents(),
                decayParams = m_DecayParams,
                forceDirection = m_ForceDirection,
                effectorRange = m_EffectorRange
            };
                        
            SetComputePluginValue(0, effectorData);
            SetComputePluginMinMaxCurve(1, m_Force);
            SetComputePluginMinMaxCurve(2, m_Vorticity);
        }
        /// <summary>
        ///     Gets the extents of the effector.
        /// </summary>
        /// <returns>
        ///     How this value is used is implementation-specific.
        /// </returns>
        protected virtual Vector4 GetExtents() { return Vector4.zero; }
        protected override void OnUpdatePlugin(SolverData solverData, int particleIndex)
        {
            var pos = solverData.GetPosition(particleIndex);
            var dist = (GetEffectorCenter() - pos).magnitude;
            var norm = GetForceNormal(pos);
            var seed = solverData.GetRandomSeed(particleIndex);

            if (IsInEffector(ref pos))
            {
                solverData.SetLifetime(particleIndex, (solverData.GetLifetime(particleIndex) + m_DecayParams.z) * GetDecay(seed, m_DecayParams.x, m_DecayParams.y));
            }
            else if (dist < m_EffectorRange)
            {
            
                solverData.AddForce(particleIndex, GetForce(norm, dist, m_Force, seed));
                var v = GetForce(norm, dist, m_Vorticity, seed);                
                if (v.sqrMagnitude > FluvioSettings.kEpsilon)
                {
                    solverData.SetTurbulence(particleIndex, RandomFloat(seed));
                    solverData.SetVorticity(particleIndex, v);                    
                }
            }
        }
        /// <summary>
        ///     Provides a gizmo drawing method for the fluid effector.
        /// </summary>
        protected virtual void OnDrawEffectorGizmos() {}
        /// <summary>
        ///     Provides a selected gizmo drawing method for the fluid effector.
        /// </summary>
        protected virtual void OnDrawEffectorGizmosSelected() {}
        [UsedImplicitly]
        void OnDrawGizmos()
        {
            OnDrawEffectorGizmos();
        }
        [UsedImplicitly]
        void OnDrawGizmosSelected()
        {
            if (!isVisibleInEditor)
                return;

            Gizmos.color = FluvioColors.GetColor(this, true);
            var mat = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(transform.TransformPoint(position), transform.rotation, Vector3.one * m_EffectorRange);
            Gizmos.DrawWireSphere(Vector3.zero, 1.0f);
            Gizmos.matrix = mat;
            OnDrawEffectorGizmosSelected();
        }
        #endregion

        /// <summary>Gets the center of the effector, in world space (thread-safe).</summary>
        /// <returns>The center of the fluid effector.</returns>
        protected Vector3 GetEffectorCenter()
        {
            return _localToWorldMatrix.MultiplyPoint3x4(m_Position);
        }
        /// <summary>Gets the position offset of the effector (thread-safe).</summary>
        /// <returns>The position offset of the fluid effector, in world space.</returns>
        protected Vector3 GetPosition()
        {
            return m_Position;
        }

        static float GetDecay(uint seed, float decay, float decayJitter)
        {
            return Mathf.Clamp(1.0f - (Mathf.Clamp(decay, 0.0f, 1.0f - FluvioSettings.kEpsilon) + (RandomFloat(seed)*(decayJitter*2.0f) - decayJitter)), 0.0f, 1.0f);
        }

        // This is done differently on the CPU
        Vector4 GetForceNormal(Vector3 pos)
        {
            var f = Vector4.zero;
                        
            switch (m_ForceType)
            {
                case FluidEffectorForceType.Radial:
                        f = (GetEffectorCenter() - pos).normalized;
                        break;
                case FluidEffectorForceType.Directional:
                        f = m_ForceDirection;
                        break;
            }

            return f;
        }

        Vector4 GetForce(Vector4 norm, float dist, FluvioMinMaxCurve f, uint seed)
        {
            return norm * f.Evaluate(seed, dist/m_EffectorRange);
        }
    }
}
