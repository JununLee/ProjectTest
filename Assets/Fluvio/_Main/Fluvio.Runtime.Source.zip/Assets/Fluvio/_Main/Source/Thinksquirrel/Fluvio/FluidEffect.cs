// FluidEffect.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#pragma warning disable 169
#pragma warning disable 414

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using JetBrains.Annotations;
using System;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;
using System.Collections.Generic;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Renders a fluid as screen space metaballs.
    /// </summary>
    [AddComponentMenu("")]
    [ExecuteInEditMode]
    public sealed class FluidEffect : FluvioMonoBehaviourBase, IComparable<FluidEffect>
    {
        #region Serialized Fields
        // ReSharper disable ConvertToConstant.Local
        // ReSharper disable UnassignedField.Compiler
        [SerializeField] FilterMode m_ParticleFilterMode = FilterMode.Bilinear;
#if UNITY_5_0_PLUS
        [SerializeField] int m_DepthPassCount = 1;
        [SerializeField] float m_DepthPassFactor = 1.0f;
        [SerializeField] bool m_OverrideNormals = true;
#else
        [SerializeField, HideInInspector] int m_DepthPassCount = 1;
        [SerializeField, HideInInspector] float m_DepthPassFactor = 1.0f;
        [SerializeField, HideInInspector] bool m_OverrideNormals = false;
#endif
        [SerializeField] Renderer[] m_AdditionalRenderers = new Renderer[0];
        [SerializeField] bool m_ShowInSceneView = true;
        [SerializeField, HideInInspector] Shader m_ReplacementShader;
        [SerializeField, HideInInspector] Shader m_ReplacementShaderSpecular;
        [SerializeField, HideInInspector] Shader m_ReplacementShaderDepth;
        [SerializeField, HideInInspector] Shader m_BlurShader;
        [SerializeField, HideInInspector] Shader m_PreCompositeShader;
        [SerializeField, HideInInspector] Shader m_CompositeShader;        
        [SerializeField, HideInInspector] Material m_Material;
        // ReSharper restore UnassignedField.Compiler
        // ReSharper restore ConvertToConstant.Local        
        #endregion

        #region Instance Fields
        [NonSerialized] internal FluidBase _fluid;
        [NonSerialized] internal readonly List<Camera> _sceneViewCameras = new List<Camera>();
        [NonSerialized] readonly List<Camera> m_Cameras = new List<Camera>();
        [NonSerialized] Material m_BlurMaterial;
        [NonSerialized] Material m_BlurNormalsMaterial;
        [NonSerialized] Material m_PreCompositeMaterial;
        [NonSerialized] Material m_CompositeMaterial;
        [NonSerialized] Renderer m_FluidRenderer;             
        [NonSerialized] bool m_MaterialIsValid;
        [NonSerialized] readonly List<FluidEffectLayer> m_Layers = new List<FluidEffectLayer>();
        [NonSerialized] readonly List<FluidEffectLayer> m_EditorLayers = new List<FluidEffectLayer>();
        //[NonSerialized] static bool s_ShowedAntiAliasingWarning;
        [NonSerialized] bool m_ShowedSameMaterialWarning;
        //[NonSerialized] int m_AntiAliasingState;
        [NonSerialized] static readonly List<FluidEffect> s_Effects = new List<FluidEffect>();
        #endregion

        #region Public API
#if UNITY_5_0_PLUS
        /// <summary>
        ///     The amount of depth passes to render.
        /// </summary>
        /// <remarks>
        ///     Additional depth passes will ensure that overlapping particles will render correctly. However, each depth pass requires the fluid to be rendered again and increases the performance cost.
        /// </remarks>
        public int depthPassCount
        {
            get { return m_DepthPassCount; }
            set { m_DepthPassCount = value; }
        }
        /// <summary>
        ///     Controls the size of each depth pass.
        /// </summary>
        /// <remarks>
        ///     The final size of a depth pass is the depth pass factor multiplied by the fluid's smoothing distance.
        /// </remarks>
        public float depthPassFactor
        {
            get { return m_DepthPassFactor; }
            set { m_DepthPassFactor = value; }
        }
#endif
        /// <summary>
        ///     The filter mode for the particle render texture.
        /// </summary>
        public FilterMode particleFilterMode
        {
            get { return m_ParticleFilterMode; }
            set { m_ParticleFilterMode = value; }
        }
        /// <summary>
        ///     Additional renderers (other than the fluid's renderer) that should be processed by this fluid effect.
        /// </summary>
        /// <remarks>
        ///     Additional renderers should have the same layer and shader as the fluid.
        /// </remarks>
        public Renderer[] additionalRenderers
        {
            get { return m_AdditionalRenderers; }
            set { m_AdditionalRenderers = value; }
        }
        /// <summary>
        ///     Compares a fluid effect's rendering order to another.
        /// </summary>
        /// <param name="other">The fluid effect to compare.</param>
        /// <param name="camera">The optional camera to use for comparison. If no camera is specified, the current or main camera is used, if available.</param>
        /// <returns>A comparison between the two effects (-1, 0, or 1).</returns>
        /// <remarks>
        /// Fluid effects are sorted by sorting layer, sorting fudge, distance, and render queue, in order.
        /// Additionally, the effect's renderer and additional renderers are rendered as one batch and sorted by Unity.
        /// </remarks>
        public int CompareTo(FluidEffect other, Camera camera = null)
        {
            // Sort effects in the following order:
            // A) Sorting layer (inverse)
            // B) Sorting layer order
            // C) Sorting fudge (inverse)
            // D) Euler or Z distance (depending on camera setting, inverse)
            // E) Render queue

            var sortingLayerCompare = GetSortingLayerIndex().CompareTo(other.GetSortingLayerIndex());
            if (sortingLayerCompare != 0) return -sortingLayerCompare;
            var sortingOrderCompare = GetSortingOrder().CompareTo(other.GetSortingOrder());
            if (sortingOrderCompare != 0) return sortingOrderCompare;
            var sortingFudge = GetSortingFudge();
            var otherSortingFudge = other.GetSortingFudge();
            var sortingFudgeCompare = 0;
            if (!Mathf.Approximately(sortingFudge, otherSortingFudge))
            {
                sortingFudgeCompare = sortingFudge.CompareTo(otherSortingFudge);
            }
            if (sortingFudgeCompare != 0) return -sortingFudgeCompare;

            if (!camera) camera = Camera.current;
            if (!camera) camera = Camera.main;
            if (camera)
            {

                var distanceCompare = GetSqrDistance(camera).CompareTo(other.GetSqrDistance(camera));
                if (distanceCompare != 0) return distanceCompare;
            }

            return GetRenderQueue().CompareTo(other.GetRenderQueue());
        }

        int IComparable<FluidEffect>.CompareTo(FluidEffect other)
        {
            return CompareTo(other);
        }
        #endregion

        #region Unity Methods
        //! \cond PRIVATE
        protected override void OnEnable()
        {
#if !UNITY_5_0_PLUS
            // TODO: Fix this for 4.x?
            m_OverrideNormals = false;
#endif
            base.OnEnable();

            //s_ShowedAntiAliasingWarning = false;

            DestroyLayers();

            s_Effects.Add(this);

            _fluid = GetComponent<FluidBase>();

            //if (!m_ReplacementShader)
            {
#if UNITY_5_0_PLUS
                m_ReplacementShader = Shader.Find("Hidden/Fluvio/FluidEffectReplace");
#else
                m_ReplacementShader = Shader.Find("Hidden/Fluvio/FluidEffectReplace4x");
#endif
            }
            //if (!m_ReplacementShaderSpecular)
            {
#if UNITY_5_0_PLUS
                m_ReplacementShaderSpecular = Shader.Find("Hidden/Fluvio/FluidEffectReplaceSpecular");
#else
                m_ReplacementShaderSpecular = m_ReplacementShader;
#endif
            }

            //if (!m_ReplacementShaderDepth)
            {
                m_ReplacementShaderDepth = Shader.Find("Hidden/Fluvio/FluidEffectReplaceDepth");
            }

            //if (!m_CompositeShader)
            m_CompositeShader = Shader.Find("Hidden/Fluvio/FluidEffectComposite");

            //if (!m_PreCompositeShader)
                m_PreCompositeShader = Shader.Find("Hidden/Fluvio/FluidEffectPreComposite");

            //if (!m_BlurShader)
                m_BlurShader = Shader.Find("Hidden/Fluvio/FluidEffectBlur");

            // Disable if we don't support image effects
            if (!SystemInfo.supportsImageEffects)
            {
                FluvioDebug.LogError("Current platform does not support image effects.", this);
                enabled = false;
                return;
            }

            // Disable the image effect if the replacement shader can't run.
            if (!m_ReplacementShader || !m_ReplacementShaderSpecular || !m_ReplacementShaderDepth || !m_ReplacementShader.isSupported || !m_ReplacementShaderSpecular.isSupported || !m_ReplacementShaderDepth.isSupported)
            {
                FluvioDebug.LogError("Current platform does not support the replacement shader.", this);
                enabled = false;
                return;
            }
            // Disable the image effect if the composite shader can't run.
            if (!m_PreCompositeShader || !m_PreCompositeShader.isSupported || !m_CompositeShader || !m_CompositeShader.isSupported)
            {
                FluvioDebug.LogError("Current platform does not support the composite shader.", this);
                enabled = false;
                return;
            }

            if (m_Cameras.Count != 0) return;
            var allCameras = FindObjectsOfType<Camera>();

            foreach (var cam in allCameras)
            {
                if (!m_Cameras.Contains(cam))
                    m_Cameras.Add(cam);
            }

            m_FluidRenderer = _fluid.GetComponent<Renderer>(); // TODO: Geometry shader needs to handle this differently
            Validate();
        }
        [UsedImplicitly]
        protected override void OnDestroy()
        {
            base.OnDestroy();

            DestroyLayers();

            if (m_PreCompositeMaterial)
            {
                DestroyImmediate(m_PreCompositeMaterial);
            }
            if (m_CompositeMaterial)
            {
                DestroyImmediate(m_CompositeMaterial);
            }
            if (m_BlurMaterial)
            {
                DestroyImmediate(m_BlurMaterial);
            }

            s_Effects.Remove(this);
        }
        //! \endcond
        [UsedImplicitly]
        void Update()
        {
            m_FluidRenderer = _fluid.GetComponent<Renderer>(); // TODO: Geometry shader needs to handle this differently
        }
        [UsedImplicitly]
        void LateUpdate()
        {
            m_FluidRenderer = _fluid.GetComponent<Renderer>(); // TODO: Geometry shader needs to handle this differently

            CreateLayers();
        }
#endregion

        internal void Validate()
        {
            if (!this || !enabled || !gameObject || !_fluid)
            {
                m_MaterialIsValid = false;
                return;
            }

            m_FluidRenderer = _fluid.GetComponent<Renderer>(); // TODO: Geometry shader needs to handle this differently

            if (m_FluidRenderer == null)
            {
                m_MaterialIsValid = false;
                return;
            }

            if (m_FluidRenderer.sharedMaterial == null)
            {
                m_MaterialIsValid = false;
                return;
            }

            var currentMat = m_FluidRenderer.sharedMaterial;
            if (
               !currentMat.HasProperty("_Cutoff") ||
               !currentMat.HasProperty("_Glossiness") ||
               !currentMat.HasProperty("_Color") ||
               !currentMat.HasProperty("_FluidBlurUI") ||
               !currentMat.HasProperty("_FluidBlurBackgroundUI") ||
               !currentMat.HasProperty("_FluidSpecularScaleUI") ||
               !currentMat.HasProperty("_FluidTintUI"))
            {
                m_MaterialIsValid = false;
                return;
            }

            if (m_Material != m_FluidRenderer.sharedMaterial)
            {
                // Delete any current copied materials
                if (m_Material && m_Material.name.Contains("Fluid Effect Copy"))
                {
                    DestroyImmediate(m_Material);
                }
                m_Material = m_FluidRenderer.sharedMaterial;
                SetMaterialKeywords(m_Material);
            }

            m_MaterialIsValid = true;
        }
        int GetRenderQueue()
        {
            return m_Material == null ? 2000 : m_Material.renderQueue;
        }
        int GetSortingLayerIndex()
        {
            return m_FluidRenderer == null ? 0 : FluvioSettings.GetSortingLayerIndex(m_FluidRenderer.sortingLayerID);
        }
        int GetSortingOrder()
        {
            return m_FluidRenderer == null ? 0 : m_FluidRenderer.sortingOrder;
        }
        float GetSortingFudge()
        {
            var fps = _fluid as FluidParticleSystem;
            return !fps ? 0 : fps.GetSortingFudge();
        }
        float GetSqrDistance(Camera cam)
        {
            if (cam == null) return 0;

            var transformPos = m_FluidRenderer ? transform.TransformPoint(m_FluidRenderer.bounds.center) : transform.position;

            var sortMode = cam.transparencySortMode == TransparencySortMode.Default
                ? (cam.orthographic ? TransparencySortMode.Orthographic : TransparencySortMode.Perspective)
                : cam.transparencySortMode;

            if (sortMode == TransparencySortMode.Orthographic)
            {
                var plane = new Plane(-cam.transform.forward, transformPos);
                return plane.GetDistanceToPoint(cam.transform.position);
            }

            return Vector3.Distance(cam.transform.position, transformPos);
        }
        internal bool materialIsValid
        {
            get { return m_Material != null && m_MaterialIsValid; }
        }
        internal void DoOnPreCull(Camera cam)
        {
            Validate();

            if (!m_MaterialIsValid)
                return;

            // ===============
            // Set shader variables
            // ===============
            var threshold = Mathf.Max(m_Material.GetFloat("_Cutoff"), .001f);
            var tint = m_Material.GetColor("_FluidTintUI");
            GetPreCompositeMaterial().SetFloat("_FluidThreshold", threshold);
            GetCompositeMaterial().SetFloat("_FluidThreshold", threshold);
            GetCompositeMaterial().SetFloat("_FluidSpecular", Mathf.Max(m_Material.GetFloat("_Glossiness"), .001f));
            GetCompositeMaterial().SetFloat("_FluidOpacity", 1 - Mathf.Clamp01(m_Material.GetColor("_Color").a * tint.a));
            GetCompositeMaterial().SetFloat("_FluidSpecularScale", m_Material.GetFloat("_FluidSpecularScaleUI"));
            GetCompositeMaterial().SetColor("_FluidTint", tint);            

            // ===============
            // Antialiasing
            // ===============            
            //m_AntiAliasingState = QualitySettings.antiAliasing;
            /*if ((cam.orthographic || cam.actualRenderingPath == RenderingPath.Forward) && QualitySettings.antiAliasing > 1)
            {
                if (!s_ShowedAntiAliasingWarning)
                {
                    FluvioDebug.LogWarning("Multisample antialiasing is not supported with the Fluid Effect.", this);
                    s_ShowedAntiAliasingWarning = true;
                }                
                QualitySettings.antiAliasing = 0;
            }*/

            switch (cam.depthTextureMode)
            {
                case DepthTextureMode.Depth:
                    GetCompositeMaterial().DisableKeyword("_DEPTHNORMALSTEX");
                    GetCompositeMaterial().EnableKeyword("_DEPTHTEX");
                    break;
                case DepthTextureMode.DepthNormals:
                    GetCompositeMaterial().DisableKeyword("_DEPTHTEX");
                    GetCompositeMaterial().EnableKeyword("_DEPTHNORMALSTEX");
                    break;
                default:
                    cam.depthTextureMode = DepthTextureMode.Depth;
                    GetCompositeMaterial().DisableKeyword("_DEPTHNORMALSTEX");
                    GetCompositeMaterial().EnableKeyword("_DEPTHTEX");
                    break;
            }
        }
        internal void DoOnRenderImage(Camera fluidCamera, RenderTexture source, RenderTexture destination,
                                      List<FluidEffect> renderingEffects)
        {
            if (!source || !_fluid || !m_Material || !m_MaterialIsValid)
            {
                Graphics.Blit(source, destination);
                return;
            }
            
            // ===============
            // Get render texture properties
            // ===============
            var downsampleFactor = m_Material.GetFloat("_DownsampleFactorUI");
            var down = downsampleFactor < 0.25f ? 1.0f : Mathf.Max(0.25f, downsampleFactor);
            // ReSharper disable RedundantCast
            var w = Mathf.Clamp((int) (source.width/down), 1, (int) source.width);
            var h = Mathf.Clamp((int) (source.height/down), 1, (int) source.height);
            const int d = 24; // TODO: Configurable depth buffer bits
            var format = source.format;
            var readWrite = source.sRGB ? RenderTextureReadWrite.sRGB : RenderTextureReadWrite.Linear;
            const int antiAliasing = 1;
            // ReSharper restore RedundantCasts

            // ===============
            // Render the fluid
            // ===============

            // Render entire scene (opaques/ZWrites + fluid) in fluid camera with replacement shader
            //      - Opaque objects are composite color with ZWrite on
            //      - Particles render with fluid shader
            //      - Optional soft particles
            // End result: occluded off-screen particles. Opaques have an alpha of 0, therefore
            // not contributing to the composite step

            // Get temporary texture and set filter mode

            var fluidColorTextureTemp = RenderTexture.GetTemporary(w, h, d, format, readWrite, antiAliasing);
            fluidColorTextureTemp.filterMode = m_ParticleFilterMode;

            var fluidDepthTextureTemp = RenderTexture.GetTemporary(w, h, 1, format, readWrite, antiAliasing);
            fluidDepthTextureTemp.filterMode = m_ParticleFilterMode;
            
            fluidCamera.backgroundColor = Color.clear;
            fluidCamera.clearFlags = CameraClearFlags.SolidColor;
            fluidCamera.renderingPath = RenderingPath.Forward;
            fluidCamera.depthTextureMode = DepthTextureMode.None;
            fluidCamera.useOcclusionCulling = false;

            if (m_OverrideNormals)
            {
                Shader.SetGlobalInt("_Fluvio_OverrideNormals", 1);
                var mat = Matrix4x4.TRS(transform.position, Quaternion.identity, transform.lossyScale);
                Shader.SetGlobalMatrix("_Fluvio_FluidToObject", mat);
            }
            else
            {
                Shader.SetGlobalInt("_Fluvio_OverrideNormals", 0);
            }

            // Render            
            var sameMaterial = false;
            foreach (var effect in renderingEffects)
            {
                if (effect != this && effect.m_Material == m_Material)
                {
                    sameMaterial = true;

                    var isDefault = effect.m_Material.name == "Default-Fluvio";
                   
                    effect.m_Material = new Material(effect.m_Material)
                    {
                        hideFlags = m_FluidRenderer.sharedMaterial.hideFlags | HideFlags.NotEditable
                    };
                    if (!effect.m_Material.name.Contains("Fluid Effect Copy"))
                    {
                        effect.m_Material.name += " (Fluid Effect Copy)";
                    }
                    effect.m_FluidRenderer.sharedMaterial = effect.m_Material;
                    SetMaterialKeywords(effect.m_Material);
                    if (!isDefault && !m_ShowedSameMaterialWarning)
                    {
                        FluvioDebug.LogWarning(string.Format("Fluids '{0}' and '{1}' share the same material and have separate fluid effects. Duplicating the material on fluid '{1}'." +
                                                             "\nTo avoid this duplication, disable the fluid effect on '{1}' and set it as an additional renderer for '{0}'.", _fluid.name, effect._fluid.name), this);                        
                    }
                    m_ShowedSameMaterialWarning = true;
                    effect.m_ShowedSameMaterialWarning = true;
                }
            }

            if (!sameMaterial) m_ShowedSameMaterialWarning = false;

            m_Material.SetFloat("_CullFluid", 0.0f);
            for (var j = 0; j < m_AdditionalRenderers.Length; ++j)
            {
                var r = m_AdditionalRenderers[j];
                if (r && r.sharedMaterial && r.sharedMaterial.HasProperty("_CullFluid")) r.sharedMaterial.SetFloat("_CullFluid", 0.0f);
            }

#if UNITY_5_0_PLUS
            // Notes:
            //  A) Render with replacement shader more than once
            //  B) Composite with each replacement shader render (each group ic sut and composited onto the next)
            //  C) Do blurs as one solid group
            //  D) Composite the whole thing onto the screen

            var passCount = Mathf.Clamp(depthPassCount, 1, 512);
            depthPassCount = passCount;

            var passFactor = Mathf.Max(Vector3.kEpsilon, depthPassFactor);
            depthPassFactor = passFactor;

            if (fluidCamera.orthographic) passCount = 1;
            
            Shader.SetGlobalFloat("_Fluvio_DepthPassCount", passCount);
            Shader.SetGlobalFloat("_Fluvio_DepthPassCellSpace", _fluid.smoothingDistance * depthPassFactor);

            if (passCount == 1)
            {
                // Render fluid RGBA
                fluidCamera.targetTexture = fluidColorTextureTemp;
                Shader.SetGlobalFloat("_Fluvio_DepthPassIndex", 0);
                fluidCamera.RenderWithShader(GetReplacementShader(), "RenderType");
            }
            else
            {
                var fluidTextureTemp2 = RenderTexture.GetTemporary(w, h, d, format, readWrite, antiAliasing);
                fluidTextureTemp2.filterMode = m_ParticleFilterMode;
                fluidCamera.targetTexture = fluidTextureTemp2;

                // Fill fluidTextureTemp with black
                var active = RenderTexture.active;
                RenderTexture.active = fluidColorTextureTemp;
                GL.Begin(GL.TRIANGLES);
                GL.Clear(true, true, new Color(0f, 0f, 0f, 0f));
                GL.End();

                RenderTexture.active = active;

                for (var j = passCount - 1; j >= 0; --j)
                {                
                    Shader.SetGlobalFloat("_Fluvio_DepthPassIndex", j); // Set slice
                    fluidCamera.RenderWithShader(GetReplacementShader(), "RenderType"); // Render slice
                    Graphics.Blit(fluidTextureTemp2, fluidColorTextureTemp, GetPreCompositeMaterial()); // Composite offscreen
                }

                RenderTexture.ReleaseTemporary(fluidTextureTemp2);
            }
#else
            fluidCamera.targetTexture = fluidColorTextureTemp;
            fluidCamera.RenderWithShader(GetReplacementShader(), "RenderType");
#endif
            
            // Render fluid depth
            fluidCamera.targetTexture = fluidDepthTextureTemp;
            fluidCamera.RenderWithShader(m_ReplacementShaderDepth, "RenderType");

            m_Material.SetFloat("_CullFluid", -1.0f);
            for (var j = 0; j < m_AdditionalRenderers.Length; ++j)
            {
                var r = m_AdditionalRenderers[j];
                if (r && r.sharedMaterial && r.sharedMaterial.HasProperty("_CullFluid")) r.sharedMaterial.SetFloat("_CullFluid", -1.0f);
            }

            Shader.SetGlobalInt("_Fluvio_OverrideNormals", 0);

            // ===============
            // Combine the fluid into source with the composite material
            // ===============
            var blur = m_Material.GetFloat("_FluidBlurUI");
            var doBlur = blur > Vector3.kEpsilon;
            var blurBackground = m_Material.GetFloat("_FluidBlurBackgroundUI");
            var doBlurBackground = blurBackground > Vector3.kEpsilon;
            var alpha = m_Material.GetColor("_Color").a;
            var transparent = alpha < 1.0f;
            var backgroundTextureTemp = transparent
                ? RenderTexture.GetTemporary(w, h, d, format, readWrite, antiAliasing)
                : null;
            if (backgroundTextureTemp != null) backgroundTextureTemp.filterMode = m_ParticleFilterMode;
            RenderTexture fluidCameraBlurTempColor = null, fluidCameraBlurTempDepth = null;

            if (doBlur)
            {
                fluidCameraBlurTempColor = RenderTexture.GetTemporary(w, h, d, format, readWrite, antiAliasing);
                fluidCameraBlurTempColor.filterMode = m_ParticleFilterMode;

                fluidCameraBlurTempDepth = RenderTexture.GetTemporary(w, h, 1, format, readWrite, antiAliasing);
                fluidCameraBlurTempDepth.filterMode = m_ParticleFilterMode;

                DoBlur(fluidColorTextureTemp, fluidCameraBlurTempColor, blur, false);
                
                // TODO: Blur fluid normals
                // DoBlur(fluidDepthTextureTemp, fluidCameraBlurTempDepth, blur, true);
                // GetCompositeMaterial().SetTexture("_FluidDepthTex", fluidCameraBlurTempDepth);
            }
            // else // TODO: Blur fluid normals
            {
                GetCompositeMaterial().SetTexture("_FluidDepthTex", fluidDepthTextureTemp);
            }

            if (doBlurBackground && transparent)
            {
                // Get holding texture
                var backgroundTextureTemp2 = RenderTexture.GetTemporary(w, h, d, format, readWrite, antiAliasing);
                backgroundTextureTemp2.filterMode = m_ParticleFilterMode;

                // Copy
                Graphics.Blit(source, backgroundTextureTemp);
                // Blur
                DoBlur(backgroundTextureTemp, backgroundTextureTemp2, blurBackground, false);
                // Send blurred texture to shader
                GetCompositeMaterial().SetTexture("_BGCameraTex", backgroundTextureTemp2);
                // Composite with source
                Graphics.Blit(doBlur ? fluidCameraBlurTempColor : fluidColorTextureTemp, source, GetCompositeMaterial());

                // Cleanup
                RenderTexture.ReleaseTemporary(backgroundTextureTemp2);
            }
            else if (transparent)
            {
                // Copy
                Graphics.Blit(source, backgroundTextureTemp);
                // Send copied texture to shader
                GetCompositeMaterial().SetTexture("_BGCameraTex", backgroundTextureTemp);
                // Composite with source
                backgroundTextureTemp.MarkRestoreExpected();
                Graphics.Blit(doBlur ? fluidCameraBlurTempColor : fluidColorTextureTemp, source, GetCompositeMaterial());
            }
            else
            {
                source.DiscardContents();
                Graphics.Blit(doBlur ? fluidCameraBlurTempColor : fluidColorTextureTemp, source, GetCompositeMaterial());
            }

            // ===============
            // Combine source into destination
            // ===============
            Graphics.Blit(source, destination);

            // ===============
            // Cleanup
            // ===============
            if (doBlur)
            {
                RenderTexture.ReleaseTemporary(fluidCameraBlurTempColor);
                RenderTexture.ReleaseTemporary(fluidCameraBlurTempDepth);
            }
            fluidCamera.targetTexture = null;
            RenderTexture.ReleaseTemporary(fluidColorTextureTemp);
            RenderTexture.ReleaseTemporary(fluidDepthTextureTemp);
            RenderTexture.ReleaseTemporary(backgroundTextureTemp);

            //if (s_ShowedAntiAliasingWarning)
            //{
            //    QualitySettings.antiAliasing = m_AntiAliasingState;
            //}
        }
        internal void CreateLayers()
        {
            for (var i = 0; i < m_Cameras.Count; ++i)
            {
                var cam = m_Cameras[i];

                if (!cam) continue;

                var camObj = cam.gameObject;

                // Skip fluid cameras
                if (camObj.name.Contains("_Fluvio-FluidCamera")) continue;

                // Skip Water/Water4 cameras
                if (camObj.name.Contains("Water4") || camObj.name.Contains("Water Refl Camera id") || camObj.name.Contains("Water Refr Camera id")) continue;

                var layer = camObj.GetComponent<FluidEffectLayer>();
                if (!layer) layer = camObj.AddComponent<FluidEffectLayer>();

                layer.AddFluidEffect(this);
                if (!m_Layers.Contains(layer)) m_Layers.Add(layer);
            }

            if (!Application.isEditor) return;
            
            if (m_ShowInSceneView && _sceneViewCameras != null && _sceneViewCameras.Count > 0)
            {
                DestroyEditorLayers();
                for (var i = 0; i < _sceneViewCameras.Count; ++i)
                {
                    var cam = _sceneViewCameras[i];

                    if (!cam) continue;

                    var camObj = cam.gameObject;

                    // Skip fluid cameras
                    if (camObj.name.Contains("_Fluvio-FluidCamera")) continue;

                    // Skip Water/Water4 cameras
                    if (camObj.name.Contains("Water4") || camObj.name.Contains("Water Refl Camera id") || camObj.name.Contains("Water Refr Camera id")) continue;

                    var layer = camObj.GetComponent<FluidEffectLayer>();
                    if (!layer) layer = camObj.AddComponent<FluidEffectLayer>();

                    // Set hide flags on scene view layers to DontSave so they don't leak
                    layer.hideFlags = HideFlags.DontSave;

                    layer.AddFluidEffect(this);
                    if (!m_EditorLayers.Contains(layer)) m_EditorLayers.Add(layer);
                }
            }
            else if (!m_ShowInSceneView || _sceneViewCameras == null || _sceneViewCameras.Count == 0)
            {
                DestroyEditorLayers();
            }
        }
        void DestroyLayers()
        {
            for (var i = 0; i < m_Layers.Count; ++i)
            {
                var layer = m_Layers[i];

                if (!layer) continue;

                layer.RemoveFluidEffect(this);
            }

            m_Layers.Clear();

            DestroyEditorLayers();
        }
        void DestroyEditorLayers()
        {
            for (var i = 0; i < m_EditorLayers.Count; ++i)
            {
                var layer = m_EditorLayers[i];

                if (!layer) continue;

                layer.RemoveFluidEffect(this);
            }

            m_EditorLayers.Clear();
        }
        void DoBlur(RenderTexture source, RenderTexture destination, float strength, bool blurNormals)
        {
            var blurMat = blurNormals ? GetBlurNormalsMaterial() : GetBlurMaterial();
            blurMat.SetFloat("_BlurStrength", strength);
            var blurTemp = RenderTexture.GetTemporary(source.width, source.height, source.depth, source.format, source.sRGB ? RenderTextureReadWrite.sRGB : RenderTextureReadWrite.Linear, source.antiAliasing);
            Graphics.Blit(source, blurTemp, blurMat, 0);
            Graphics.Blit(blurTemp, destination, blurMat, 1);
            RenderTexture.ReleaseTemporary(blurTemp);
        }        
        Material GetBlurMaterial()
        {
            if (!m_BlurMaterial)
            {
                m_BlurMaterial = new Material(m_BlurShader) {hideFlags = HideFlags.HideAndDontSave};
                m_BlurMaterial.DisableKeyword("_BLUR_NORMALS");
                m_BlurMaterial.EnableKeyword("_BLUR_COLORS");
            }
            return m_BlurMaterial;
        }
        Material GetBlurNormalsMaterial()
        {
            if (!m_BlurNormalsMaterial)
            {
                m_BlurNormalsMaterial = new Material(m_BlurShader) { hideFlags = HideFlags.HideAndDontSave };
                m_BlurNormalsMaterial.DisableKeyword("_BLUR_COLORS");
                m_BlurNormalsMaterial.EnableKeyword("_BLUR_NORMALS");
            }
            return m_BlurNormalsMaterial;
        }
        Material GetPreCompositeMaterial()
        {
            if (!m_PreCompositeMaterial)
            {
                m_PreCompositeMaterial = new Material(m_PreCompositeShader) { hideFlags = HideFlags.HideAndDontSave };
            }
            return m_PreCompositeMaterial;
        }
        Material GetCompositeMaterial()
        {
            if (!m_CompositeMaterial)
            {
                m_CompositeMaterial = new Material(m_CompositeShader) {hideFlags = HideFlags.HideAndDontSave};
            }
            return m_CompositeMaterial;
        }
        Shader GetReplacementShader()
        {
            var mat = m_Material;
            return mat.shader.name.Contains("Specular") ? m_ReplacementShaderSpecular : m_ReplacementShader;
        }
        internal static void SetMaterialKeywords(Material material)
        {
#if UNITY_5_0_PLUS
            if (!material || !material.shader || material.shader.name == "Hidden/InternalErrorShader")
                return;

            // Clamp EmissionScale to always positive
            var emissionScale = material.GetFloat("_EmissionScaleUI");
            if (emissionScale < 0.0f) emissionScale = 0.0f;

            var emissionColorOut = material.GetColor("_EmissionColorUI") * Mathf.LinearToGammaSpace(emissionScale);
            material.SetColor("_EmissionColor", emissionColorOut);

            SetKeyword(material, "_EMISSION", emissionColorOut.grayscale > (1.0f / 255.0f));

            SetKeyword(material, "_NORMALMAP", material.GetTexture("_BumpMap"));
            if (material.shader.name.Contains("Specular"))
            {
                SetKeyword(material, "_SPECGLOSSMAP", material.GetTexture("_SpecGlossMap"));
            }
            else
            {
                SetKeyword(material, "_METALLICGLOSSMAP", material.GetTexture("_MetallicGlossMap"));
            }

            material.EnableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHATEST_ON");
#endif
        }
        static void SetKeyword(Material m, string keyword, bool state)
        {
            if (state)
                m.EnableKeyword(keyword);
            else
                m.DisableKeyword(keyword);
        }
    }
}