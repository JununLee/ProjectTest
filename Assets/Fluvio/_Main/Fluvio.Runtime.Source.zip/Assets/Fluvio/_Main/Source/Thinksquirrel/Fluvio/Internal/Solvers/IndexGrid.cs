// IndexGrid.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.
using System;

using Thinksquirrel.Fluvio.Internal.Threading;
using UnityEngine;
using float4 = UnityEngine.Vector4;

namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    sealed class IndexGrid
    {
        #region Instance Fields
        int[] m_Grid;
        float m_CellSpace;
        static readonly int[] s_Clear = {-1};
        #endregion

        static int mod_pos(int a, int b)
        {
            return (a % b + b) % b;
        }
        static float GetCellSpace(float kernelSize)
        {
            return kernelSize;
        }
        static int4 GetIndexVector(ref float4 position, float cellSpace)
        {
            return position/cellSpace;
        }
        static int GetIndex(ref int4 indexVector)
        {
            return mod_pos(indexVector.x + FluvioSettings.maxGridSize * (indexVector.y + FluvioSettings.maxGridSize * indexVector.z), FluvioSettings.maxGridSize * FluvioSettings.maxGridSize * FluvioSettings.maxGridSize);
        }
        static int GetBucketIndex(int gridIndex, int i)
        {
            return gridIndex * FluvioSettings.gridBucketSize + i;
        }
        static int GetIndexFromPosition(ref float4 position, float cellSpace)
        {
            var indexVector = GetIndexVector(ref position, cellSpace);
            return GetIndex(ref indexVector);
        }
        #region Public API
        public void Clear()
        {
            // Note: Fastest array clear to -1 that we could get on the CPU at the moment without going native.            
            var threadCount = Mathf.Max(Parallel.GetThreadCount(), 1);
            var len = m_Grid.Length/threadCount;

            if (len != 0)
            {
                Parallel.For(threadCount, threadIndex =>
                {
                    // set the initial array value
                    int offset = threadIndex*len;
                    Array.Copy(s_Clear, 0, m_Grid, offset, 1);

                    int arrayToFillHalfLength = len/2;
                    int copyLength;

                    for (copyLength = 1; copyLength < arrayToFillHalfLength; copyLength <<= 1)
                    {
                        Array.Copy(m_Grid, 0, m_Grid, offset + copyLength, copyLength);
                    }

                    Array.Copy(m_Grid, 0, m_Grid, offset + copyLength, len - copyLength);
                });
            }
        }
        public void Add(int particleIndex, ref float4 position)
        {
            int gridIndex = GetIndexFromPosition(ref position, m_CellSpace);

            int gridAddIndex = particleIndex;
	        for (int i = 0; i < FluvioSettings.gridBucketSize; ++i)
	        {
		        // Get grid array index
		        int gi = GetBucketIndex(gridIndex, i);

                // Try to set the bucket item
                int original = Parallel.CompareExchange(ref m_Grid[gi], gridAddIndex, -1);

                // If the bucket item was not already set or set on another thread during this loop, we're done
		        if (original == -1) return;
	        }
        }
        bool DoQuery(int particleIndex, int particleCount, int stride, float kernelSizeSq, FluidParticle[] particle,
                        FluidParticle[] boundaryParticle, int[] neighbors, ref int4 indexVector, ref int4 indexVectorOff,
                        ref float4 position, ref int neighborCount)
        {
            int4 indexVectorOffset;
            indexVectorOffset.x = indexVector.x + indexVectorOff.x;
            indexVectorOffset.y = indexVector.y + indexVectorOff.y;
            indexVectorOffset.z = indexVector.z + indexVectorOff.z;
            indexVectorOffset.w = 0;

            int gridIndex = GetIndex(ref indexVectorOffset);

            for (int i = 0; i < FluvioSettings.gridBucketSize; ++i)
            {
                int neighborIndex = m_Grid[GetBucketIndex(gridIndex, i)];

                if (neighborIndex < 0) break;
                if (particleIndex == neighborIndex) continue;

                FluidParticle[] neighborArray = SolverUtility.GetParticleArray(neighborIndex, particleCount, particle, boundaryParticle);
                int neighborInd = SolverUtility.GetParticleArrayIndex(neighborIndex, particleCount);

                float4 dist = neighborArray[neighborInd].position - position;

                dist.w = 0;
                float d = float4.Dot(dist, dist);

                if (d < kernelSizeSq)
                {
                    neighbors[particleIndex*stride + neighborCount++] = neighborIndex;

                    if (neighborCount >= stride)
                        return false;
                }
            }
            return true;
        }
        public int Query2D(
            int particleIndex,
            int particleCount,
            int stride,
            float kernelSizeSq,
            FluidParticle[] particleArray,
            int particleInd,
            FluidParticle[] particle,
            FluidParticle[] boundaryParticle,
            int[] neighbors)
        {
            int4 indexVectorOff;
            int neighborCount = 0;

            float4 position = particleArray[particleInd].position;

            int4 indexVector = GetIndexVector(ref position, m_CellSpace);
            indexVectorOff.z = 0;
            indexVectorOff.w = 0;

            for (indexVectorOff.x = -1; indexVectorOff.x <= 1; indexVectorOff.x++)
            {
                for (indexVectorOff.y = -1; indexVectorOff.y <= 1; indexVectorOff.y++)
                {
                    if (!DoQuery(particleIndex, particleCount, stride, kernelSizeSq, particle, boundaryParticle, neighbors, ref indexVector, ref indexVectorOff, ref position, ref neighborCount))
                        return stride;
                }
            }
            return neighborCount;
        }
        public int Query3D(
            int particleIndex,
            int particleCount,
            int stride,
            float kernelSizeSq,
            FluidParticle[] particleArray,
            int particleInd,
            FluidParticle[] particle,
            FluidParticle[] boundaryParticle,
            int[] neighbors)
        {
            int4 indexVectorOff;
            int neighborCount = 0;

            float4 position = particleArray[particleInd].position;

            int4 indexVector = GetIndexVector(ref position, m_CellSpace);
            indexVectorOff.w = 0;

            for (indexVectorOff.x = -1; indexVectorOff.x <= 1; indexVectorOff.x++)
            {
                for (indexVectorOff.y = -1; indexVectorOff.y <= 1; indexVectorOff.y++)
                {
                    for (indexVectorOff.z = -1; indexVectorOff.z <= 1; indexVectorOff.z++)
                    {
                        if (!DoQuery(particleIndex, particleCount, stride, kernelSizeSq, particle, boundaryParticle, neighbors, ref indexVector, ref indexVectorOff, ref position, ref neighborCount))
                            return stride;
                    }
                }
            }
            return neighborCount;
        }
        public void Initialize(float kernelSize)
        {
            m_CellSpace = GetCellSpace(kernelSize);
            var len = FluvioSettings.gridLength;
            if (m_Grid == null || m_Grid.Length != len) m_Grid = new int[len];
        }
        public int[] GetGrid()
        {
            return m_Grid;
        }
        #endregion
    }
}
