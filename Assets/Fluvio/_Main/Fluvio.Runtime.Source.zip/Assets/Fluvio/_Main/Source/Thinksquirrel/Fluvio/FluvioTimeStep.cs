// FluvioTimeStep.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     Represents a single fixed timestep for fluid simulation.
    /// </summary>
    public struct FluvioTimeStep
    {
        #region Public API
        /// <summary>
        ///     The delta time of the current frame.
        /// </summary>
        public readonly float deltaTime;
        /// <summary>
        ///     dt * (1.0f / solverIterations)
        /// </summary>
        public readonly float dtIter;
        /// <summary>
        ///     1.0f / deltaTime
        /// </summary>
        public readonly float invDt;
        /// <summary>
        ///     The amount of solver solver iterations, as a float.
        /// </summary>
        public readonly float solverIterations;

        /// <summary>
        ///     Provides an implicit conversion of a timestep into a 4-component vector.
        /// </summary>
        /// <param name="timeStep">The timestep to convert.</param>
        /// <returns>The converted vector. x - deltaTime, y - dtIter, z - invDt, w - solverIterations</returns>
        public static implicit operator Vector4(FluvioTimeStep timeStep)
        {
           return new Vector4(timeStep.deltaTime, timeStep.dtIter, timeStep.invDt, timeStep.solverIterations);
        }
        #endregion

        #region Constructors
        internal FluvioTimeStep(float deltaTime, float solverIterations)
        {
            this.solverIterations = solverIterations;
            this.deltaTime = deltaTime;
            invDt = 1.0f/deltaTime;
            dtIter = deltaTime*(1.0f/solverIterations);
        }
        #endregion
    }
}
