// ViscosityKernel.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    sealed class ViscosityKernel : SmoothingKernel
    {
        #region Public API
        public ViscosityKernel() {}
        public ViscosityKernel(float kernelSize) : base(kernelSize) {}
        #endregion

        #region Abstract, Virtual, and Override
        public override float Calculate(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var len = Mathf.Sqrt(lenSq);
            var len3 = len*len*len;
            return factor*(((-len3/(2.0f*kernelSize3)) + (lenSq/kernelSizeSq) + (kernelSize/(2.0f*len))) - 1.0f);
        }
        public override Vector4 CalculateGradient(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var len = Mathf.Sqrt(lenSq);
            var len3 = len*len*len;
            var f = factor*((-3.0f*len/(2.0f*kernelSize3)) + (2.0f/kernelSizeSq) + (kernelSize/(2.0f*len3)));
            return new Vector4(distance.x*f, distance.y*f, distance.z*f);
        }
        public override float CalculateLaplacian(ref Vector4 distance)
        {
            var lenSq = distance.sqrMagnitude;
            var len = Mathf.Sqrt(lenSq);
            return factor*(6.0f/kernelSize3)*(kernelSize - len);
        }
        protected override void CalculateFactor()
        {
            // Factor
            factor = (15.0f/(2.0f*Mathf.PI*kernelSize3));
        }
        #endregion
    }
}
