// FluvioDebug.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Diagnostics;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    /// Provides various static logging methods.
    /// </summary>
    public static class FluvioDebug
    {
        const string k_Prefix = "Fluvio";
        const string k_Format = "[{0}]{1}: {2}";
        const string k_FormatEditor = "<color=#36b1d8ff>[<b>{0}</b>]</color>{1}: {2}";
        
        /// <summary>
        ///     Logs a prefixed message (wrapped in conditional compilation flags).
        /// </summary>
        /// <param name="message">The message to log.</param>        
        /// <param name="context">Object to which the message applies.</param>
        [Conditional("FLUVIO_DEBUG")]
        public static void Log(object message, object context = null)
        {
            var staticType = context as Type;
            var type = staticType != null ? staticType : context != null ? context.GetType() : null;
            var format = FluvioSettings.isEditor ? k_FormatEditor : k_Format;       
            var logMessage = string.Format(format, k_Prefix, type == null ? string.Empty : string.Format(" ({0})", type.Name), message);
            var unityObj = context as Object;

            if (unityObj)
            {
                Debug.Log(logMessage, unityObj);
            }
            else
            {
                Debug.Log(logMessage);
            }
        }
        /// <summary>
        ///     Logs a prefixed warning.
        /// </summary>
        /// <param name="message">The message to log.</param>        
        /// <param name="context">Object to which the message applies.</param>
        public static void LogWarning(object message, object context = null)
        {
            var staticType = context as Type;
            var type = staticType != null ? staticType : context != null ? context.GetType() : null;
            var format = FluvioSettings.isEditor ? k_FormatEditor : k_Format;
            var logMessage = string.Format(format, k_Prefix, type == null ? string.Empty : string.Format(" ({0})", type.Name), message);
            var unityObj = context as Object;

            if (unityObj)
            {
                Debug.LogWarning(logMessage, unityObj);
            }
            else
            {
                Debug.LogWarning(logMessage);
            }
        }
        /// <summary>
        ///     Logs a prefixed erorr.
        /// </summary>
        /// <param name="message">The message to log.</param>        
        /// <param name="context">Object to which the message applies.</param>
        public static void LogError(object message, object context = null)
        {
            var staticType = context as Type;
            var type = staticType != null ? staticType : context != null ? context.GetType() : null;
            var format = FluvioSettings.isEditor ? k_FormatEditor : k_Format;
            var logMessage = string.Format(format, k_Prefix, type == null ? string.Empty : string.Format(" ({0})", type.Name), message);
            var unityObj = context as Object;

            if (unityObj)
            {
                Debug.LogError(logMessage, unityObj);
            }
            else
            {
                Debug.LogError(logMessage);
            }
        }
        /// <summary>
        ///     Logs an exception.
        /// </summary>
        /// <param name="ex">The exception to log.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void LogException(Exception ex, object context = null)
        {
            var unityObj = context as Object;

            if (unityObj)
            {
                Debug.LogException(ex, unityObj);
            }
            else
            {
                Debug.LogException(ex);
            }
        }    
    }
}
