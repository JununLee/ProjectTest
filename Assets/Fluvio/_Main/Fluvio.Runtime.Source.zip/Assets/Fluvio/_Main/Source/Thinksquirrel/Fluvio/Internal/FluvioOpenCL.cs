using System;
using System.Collections.Generic;
using System.Linq;
using Cloo;
using Cloo.Bindings;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal
{
    static class FluvioOpenCL
    {
        [NonSerialized] static bool s_Initialized;
        [NonSerialized] static ComputePlatform s_ComputePlatform;
        [NonSerialized] static ComputeDevice s_ComputeDevice;        
        [NonSerialized] static ComputeContext s_ComputeContext;        
        [NonSerialized] static ComputeCommandQueue s_CommandQueue;
        [NonSerialized] internal static readonly HashSet<FluvioComputeBufferBase> _buffers = new HashSet<FluvioComputeBufferBase>();
        [NonSerialized] internal readonly static HashSet<FluvioComputeShader> _computeShaders = new HashSet<FluvioComputeShader>();
        [NonSerialized] static int s_CrashCounter;
        [NonSerialized] static bool s_OpenCLCrashed;
        [NonSerialized] static bool s_CrashMessageShown;

        internal static void ForceInitialize(ComputeDevice device = null)
        {
            Cleanup(true);
            s_OpenCLCrashed = false;
            s_CrashCounter = 0;
            Initialize(device);
        }
        static void Initialize(ComputeDevice device = null)
        {
            if (s_Initialized)
                return;

            if (!CLInterface.IsAvailable())
                return;

            try
            {
                if (device == null)
                {
                    var platforms = ComputePlatform.Platforms;

                    if (platforms.Count == 0) return;
                    
                    ComputeDevice fallbackDeviceA = null;
                    ComputeDevice fallbackDeviceB = null;

                    var bestScore = long.MinValue;
                    var bestFallbackScoreA = long.MinValue;
                    var bestFallbackScoreB = long.MinValue;

                    var bestType = FluvioSettings.openCLDesiredDeviceType;
                    var fallbackTypeA = OpenCLDeviceType.CPU;
                    var fallbackTypeB = OpenCLDeviceType.CPU;

                    if (!FluvioSettings.enableOpenCLGPUOnOSX && 
                        (Application.platform == RuntimePlatform.OSXEditor || Application.platform == RuntimePlatform.OSXPlayer))
                    {
                        // Only accept OpenCL on the CPU for OS X, unless overriden
                        bestType = OpenCLDeviceType.CPU;
                        fallbackTypeA = OpenCLDeviceType.CPU;
                        fallbackTypeB = OpenCLDeviceType.CPU;
                    }
                    else
                    {
                        switch (bestType)
                        {
                            case OpenCLDeviceType.GPU:
                                fallbackTypeA = OpenCLDeviceType.Accelerator;
                                fallbackTypeB = OpenCLDeviceType.CPU;
                                break;
                            case OpenCLDeviceType.Accelerator:
                                fallbackTypeA = OpenCLDeviceType.GPU;
                                fallbackTypeB = OpenCLDeviceType.CPU;
                                break;
                            case OpenCLDeviceType.CPU:
                                fallbackTypeA = OpenCLDeviceType.GPU;
                                fallbackTypeB = OpenCLDeviceType.Accelerator;
                                break;
                        }
                    }

                    for (var i = 0; i < platforms.Count; ++i)
                    {
                        var platform = platforms[i];

                        if (platform.Devices.Count == 0)
                            continue;

                        var skipPlatform = false;
                        foreach(var blacklistItem in FluvioSettings.openCLPlatformBlacklist)
                        {
                            if (blacklistItem.Contains(platform.Name))
                            {
                                skipPlatform = true;
                                break;
                            }
                        }
                        if (skipPlatform) continue;

                        for (var j = 0; j < platform.Devices.Count; ++j)
                        {
                            var candidateDevice = platform.Devices[j];

                            if (!candidateDevice.Available || !candidateDevice.CompilerAvailable)
                                continue;
                            
                            var skipDevice = false;
                            foreach (var blacklistItem in FluvioSettings.openCLDeviceBlacklist)
                            {
                                if (blacklistItem.Contains(candidateDevice.Name))
                                {
                                    skipDevice = true;
                                    break;
                                }
                            }
                            if (skipDevice) continue;

                            // Custom scoring algorithm for processing devices
                            var score =
                                candidateDevice.MaxClockFrequency + // Speed
                                (candidateDevice.MaxComputeUnits*candidateDevice.MaxWorkGroupSize) + // Compute capability
                                (candidateDevice.GlobalMemorySize*candidateDevice.MaxSamplers); // Memory capability

                            //Debug.Log(candidateDevice.Name + ": " + score);

                            var type = (long) candidateDevice.Type;

                            if (type == (long) bestType)
                            {
                                if (score > bestScore)
                                {
                                    bestScore = score;
                                    device = candidateDevice;
                                }
                            }
                            else if (type == (long)fallbackTypeA)
                            {
                                if (score > bestFallbackScoreA)
                                {
                                    bestFallbackScoreA = score;
                                    fallbackDeviceA = candidateDevice;
                                }
                            }
                            else if (type == (long) fallbackTypeB)
                            {
                                if (score > bestFallbackScoreB)
                                {
                                    bestFallbackScoreB = score;
                                    fallbackDeviceB = candidateDevice;
                                }
                            }
                        }
                    }

                    device = device ?? fallbackDeviceA ?? fallbackDeviceB;
                }

                if (device == null)
                    return;

                //FluvioDebug.Log("Creating new OpenCL compute context", "Fluvio", "FluvioOpenCL");

                s_ComputePlatform = device.Platform;
                var properties = new ComputeContextPropertyList(s_ComputePlatform);
                s_ComputeDevice = device;
                s_ComputeContext = new ComputeContext(new[] {device}, properties, null, IntPtr.Zero);

                //FluvioDebug.Log("Creating new OpenCL command queue", "Fluvio", "FluvioOpenCL");
                s_CommandQueue = new ComputeCommandQueue(s_ComputeContext, device, ComputeCommandQueueFlags.None);

                s_Initialized = true;
                s_CrashMessageShown = false;

                // Preload shaders
                if (Application.isPlaying && FluvioSettings.preloadComputeShaders)
                {
                    var shaders = Resources.FindObjectsOfTypeAll<FluvioComputeShader>();
                    foreach (var shader in shaders)
                    {
                        if (shader._shouldCompile) shader.CompileOpenCLProgram();
                    }
                }
            }
            catch (Exception ex)
            {
                FluvioDebug.LogException(ex);
                Cleanup(true);
            }
            finally
            {
                GC.Collect();
            }
        }

        internal static void Cleanup(bool force = false)
        {
            //FluvioDebug.Log(string.Format("Object was destroyed. Buffer count: {0}", _buffers.Count), "Fluvio", "FluvioOpenCL.Cleanup");
            
            if (!force && _buffers.Count > 0) return;

            s_OpenCLCrashed = force && s_CrashCounter++ > 3;

            //FluvioDebug.Log("Invalidating current OpenCL buffers", "Fluvio", "FluvioOpenCL");
            
            foreach (var buffer in _buffers)
            {
                if (buffer._computeBufferOpenCL != null)
                {
                    buffer._computeBufferOpenCL.Dispose();
                    buffer._computeBufferOpenCL = null;
                }
            }

            //FluvioDebug.Log("Invalidating current OpenCL compute kernels and programs", "Fluvio", "FluvioOpenCL");
            
            foreach (var computeShader in _computeShaders)
            {
                computeShader.Cleanup();
            }

            //FluvioDebug.Log("Disposing of OpenCL compute context and command queue", "Fluvio", "FluvioOpenCL");

            if (s_CommandQueue != null)
            {
                try
                {
                    s_CommandQueue.Finish();
                }
                catch {}
                finally
                {
                    s_CommandQueue.Dispose();    
                }
                
            }
            if (s_ComputeContext != null) s_ComputeContext.Dispose();

            s_ComputePlatform = null;
            s_ComputeDevice = null;
            s_CommandQueue = null;
            s_ComputeContext = null;

            GC.Collect();

            s_Initialized = false;
        }
        
        public static bool IsOpenCLAvailable()
        {
            if (s_OpenCLCrashed)
            {
                if (s_CrashMessageShown) return false;

                FluvioDebug.LogError(
                    Application.isEditor
                        ? "The current OpenCL device has crashed due to an invalid operation. Trying another device or restarting Unity is highly recommended to prevent a hard crash."
                        : "The current OpenCL device has crashed due to an invalid operation.", typeof(FluvioOpenCL));

                s_CrashMessageShown = true;
                return false;
            }

            Initialize();
            return s_Initialized;
        }
        internal static ComputePlatform GetComputePlatform()
        {
            Initialize();
            return s_Initialized ? s_ComputePlatform : null;
        }
        internal static ComputeContext GetComputeContext()
        {
            Initialize();
            return s_Initialized ? s_ComputeContext : null;
        }
        internal static ComputeDevice GetComputeDevice()
        {
            Initialize();
            return s_Initialized ? s_ComputeDevice : null;
        }
        internal static void FlushCommandQueue()
        {
            Initialize();
            if (s_Initialized && s_CommandQueue != null) s_CommandQueue.Flush();
        }
        internal static ComputeCommandQueue GetCommandQueue()
        {
            Initialize();
            return s_Initialized ? s_CommandQueue : null;
        }
    }
}
