// FluidDebug.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio.Internal;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     FluidPlugin for debug information.
    /// </summary>
    [AddComponentMenu("Fluvio/Plugins/Fluid Debug")]
    public sealed class FluidDebug : FluidPlugin
    {
        #region Serialized Fields
        [SerializeField] Color m_TextColor;
        [SerializeField] Vector2 m_DebugTextPosition;
        [SerializeField] TextAlignment m_DebugTextAlignment;
        [SerializeField] TextAnchor m_DebugTextAnchor;
        #endregion

        #region Private Fields
        [NonSerialized] float m_UpdateInterval = 0.1f;
        [NonSerialized] GUIText m_DebugText;
        [NonSerialized] double m_TimeLeft;
        [NonSerialized] double m_AccumulatorSolverTime;
        [NonSerialized] double m_AccumulatorGPUPluginsTime;
        [NonSerialized] double m_AccumulatorPluginsTime;
        [NonSerialized] double m_AccumulatorOverheadTime;
        [NonSerialized] double m_AccumulatorTotalTime;
        [NonSerialized] double m_SolverTime;
        [NonSerialized] double m_GPUPluginsTime;
        [NonSerialized] double m_PluginsTime;
        [NonSerialized] double m_OverheadTime;
        [NonSerialized] double m_TotalTime;
        [NonSerialized] double m_LastTime;
        [NonSerialized] int m_Frames;
        #endregion

        #region Protected, Abstract, and Virtual Methods
        protected override void OnResetPlugin()
        {
            m_TextColor = Color.white;
            m_DebugTextPosition = new Vector2(0.02f, 0.1f);
            m_DebugTextAlignment = TextAlignment.Left;
            m_DebugTextAnchor = TextAnchor.LowerLeft;
        }
        protected override void OnDisablePlugin()
        {
            if (m_DebugText)
                m_DebugText.enabled = false;
        }
        #endregion

        #region MonoBehaviour events and coroutines
        //! \cond PRIVATE
        [UsedImplicitly]
        protected override void OnDestroy()
        {
            base.OnDestroy();

            FluvioSettings.enableTimers = false;

            if (m_DebugText != null)
            {
                DestroyImmediate(m_DebugText);
            }
        }
        //! \endcond
        [UsedImplicitly]
        void Update()
        {
            if (!fluid)
                return;

            if (fluid._solver == null)
                return;

            FluvioSettings.enableTimers = true;

            if (!m_DebugText)
            {
                var debugObject = new GameObject
                {
                    name = "_Fluvio - Debug Information (" + fluid.gameObject.name + ")",
                    hideFlags = HideFlags.HideAndDontSave
                };
                m_DebugText = debugObject.AddComponent<GUIText>();
            }
            
            m_DebugText.transform.position = m_DebugTextPosition;
            m_DebugText.alignment = m_DebugTextAlignment;
            m_DebugText.anchor = m_DebugTextAnchor;
            m_DebugText.color = m_TextColor;
            m_DebugText.enabled = true;

            var f = fluid.parentFluid ? fluid.parentFluid : fluid;

            var solverTime = Timers.GetTime(f, "Solver");
            var gpuPluginsTime = Timers.GetTime(f, "HW Plugins");
            var pluginsTime = Timers.GetTime(f, "Plugins");
            var overheadTime = Timers.GetTime(f, "Overhead");

            double total;

            if (fluid.IsHardwareAccelerated())
            {
                total = solverTime + gpuPluginsTime + pluginsTime + overheadTime;
            }
            else
            {
                total = solverTime + pluginsTime + overheadTime;
            }

            m_TimeLeft -= Time.realtimeSinceStartup - m_LastTime;
            m_LastTime = Time.realtimeSinceStartup;
            m_AccumulatorSolverTime += solverTime;
            m_AccumulatorGPUPluginsTime += gpuPluginsTime;
            m_AccumulatorPluginsTime += pluginsTime;
            m_AccumulatorOverheadTime += overheadTime;
            m_AccumulatorTotalTime += total;
            ++m_Frames;

            // Interval ended
            if (m_TimeLeft <= 0)
            {
                m_SolverTime = m_AccumulatorSolverTime/m_Frames;
                m_GPUPluginsTime = m_AccumulatorGPUPluginsTime/m_Frames;
                m_PluginsTime = m_AccumulatorPluginsTime/m_Frames;
                m_OverheadTime = m_AccumulatorOverheadTime/m_Frames;
                m_TotalTime = m_AccumulatorTotalTime/m_Frames;
                m_TimeLeft = m_UpdateInterval;
                m_AccumulatorSolverTime = m_AccumulatorGPUPluginsTime = m_AccumulatorPluginsTime = m_AccumulatorOverheadTime = m_AccumulatorTotalTime = 0;
                m_Frames = 0;
                m_LastTime = Time.realtimeSinceStartup;
            }

            var accelerated = fluid.IsHardwareAccelerated();
            var fastPath = fluid._solver.canUseFastIntegrationPath;

            var timers = string.Format(
                "\nPlatform: {0}" +
                "\nDevice: {1}" +
                "\nSolver: {2:####0.###} ms" +
                (!accelerated || fastPath ? string.Empty : "\nEarly Buffer Sync: {3:####0.###} ms") +
                (accelerated && fastPath ? string.Empty : "\nPlugins (C#): {4:####0.###} ms") + 
                "\nOverhead: {5:####0.###} ms",
                FluvioSettings.GetCurrentComputePlatform(fluid),
                FluvioSettings.GetCurrentDeviceName(fluid),
                m_SolverTime,
                m_GPUPluginsTime,
                m_PluginsTime,
                m_OverheadTime);

            m_DebugText.text =
                string.Format("{0} - {1} | {2}" +
                              "\nParticles: {3}{4}" +
                              "{5}" +
                              "\n{6}",
                              fluid.name,
                              fluid.dimensions,
                              fluid.parentFluid
                                  ? string.Format("Parent Fluid: {0}", fluid.parentFluid.name)
                                  : string.Format("Sub-fluids: {0}", fluid.subFluidCount),
                              string.Format("{0}/{1}", fluid.GetActiveParticleCount(), fluid.GetParticleCount()),
                              fluid.parentFluid || fluid.subFluidCount > 0 ? string.Format(" | Fluid Group Particles: {0}/{1}", fluid.GetTotalActiveParticleCount(), fluid.GetTotalParticleCount()) : string.Empty,
                              timers,
                              m_TotalTime <= 0 ? "Total: Calculating..." : string.Format("Total: {0:####0.###} ms", m_TotalTime));
        }
        #endregion

        #region Public API
        /// <summary>
        ///     Controls the update interval for time averages.
        /// </summary>
        public float updateInterval
        {
            get { return m_UpdateInterval; }
            set { m_UpdateInterval = value; }
        }
        /// <summary>
        ///     Controls the color of the debug text.
        /// </summary>
        public Color textColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        /// <summary>
        ///     The position (in GUI space) of the debug text.
        /// </summary>
        public Vector2 debugTextPosition
        {
            get { return m_DebugTextPosition; }
            set { m_DebugTextPosition = value; }
        }
        /// <summary>
        ///     The debug text paragraph alignment.
        /// </summary>
        public TextAlignment debugTextAlignment
        {
            get { return m_DebugTextAlignment; }
            set { m_DebugTextAlignment = value; }
        }
        /// <summary>
        ///     The debug text anchor point.
        /// </summary>
        public TextAnchor debugTextAnchor
        {
            get { return m_DebugTextAnchor; }
            set { m_DebugTextAnchor = value; }
        }
        /// <summary>
        ///     Gets the debug text GUIText component.
        /// </summary>
        /// <returns>The GUIText component used to print debug text.</returns>
        public GUIText GetDebugText()
        {
            return m_DebugText;
        }
        #endregion
    }
}
