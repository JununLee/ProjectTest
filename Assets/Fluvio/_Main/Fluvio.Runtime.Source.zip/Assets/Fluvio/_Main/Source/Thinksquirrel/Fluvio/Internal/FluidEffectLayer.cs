// FluidEffectLayer.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#pragma warning disable 169
#pragma warning disable 414
#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using JetBrains.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Thinksquirrel.Fluvio.Internal
{
    [RequireComponent(typeof (Camera))]
    [AddComponentMenu("")]
    [ExecuteInEditMode]
    sealed class FluidEffectLayer : FluvioMonoBehaviourBase
    {
        struct EffectAndCamera
        {
            public FluidEffect fluidEffect;
            public Camera fluidCamera;

            public EffectAndCamera(FluidEffect fluidEffect, Camera fluidCamera)
            {
                this.fluidEffect = fluidEffect;
                this.fluidCamera = fluidCamera;
            }
        }
        #region Instance fields
        [NonSerialized] Camera m_Camera;
        [NonSerialized] readonly List<EffectAndCamera> m_FluidEffects = new List<EffectAndCamera>();
        [NonSerialized] readonly List<FluidEffect> m_RenderingEffects = new List<FluidEffect>();
        #endregion

        #region Public API
        public void AddFluidEffect(FluidEffect effect)
        {
            if (!m_Camera)
                m_Camera = GetComponent<Camera>();

            if (!effect || !m_Camera)
                return;

            int ind = -1;
            for (var i = 0; i < m_FluidEffects.Count; ++i)
            {
                if (m_FluidEffects[i].fluidEffect != effect) continue;
                ind = i;
                break;
            }

            var add = ind < 0;
            var nameStr = string.Format("_Fluvio-FluidCamera {0}", m_Camera.GetInstanceID());

            Camera fluidCamera = null;

            if (!add)
            {
                fluidCamera = m_FluidEffects[ind].fluidCamera;
            }

            if (fluidCamera) return;

            var fluidCamObj = GameObject.Find(nameStr);

            if (!fluidCamObj)
            {
                fluidCamObj = new GameObject(nameStr);
            }

            fluidCamObj.hideFlags = HideFlags.HideAndDontSave;

            fluidCamera = fluidCamObj.GetComponent<Camera>();
            if (!fluidCamera) fluidCamera = fluidCamObj.AddComponent<Camera>();

            fluidCamera.enabled = false;

            if (add)
            {
                m_FluidEffects.Add(new EffectAndCamera(effect, fluidCamera));
            }
            else
            {
                var effectAndCam = m_FluidEffects[ind];
                effectAndCam.fluidCamera = fluidCamera;
                m_FluidEffects[ind] = effectAndCam;
            }            
        }
        public void RemoveFluidEffect(FluidEffect effect)
        {
            int index = -1;
            for (var i = 0; i < m_FluidEffects.Count; ++i)
            {
                if (m_FluidEffects[i].fluidEffect != effect) continue;
                index = i;
                break;
            }

            if (index < 0) return;

            Camera fluidCamera = m_FluidEffects[index].fluidCamera;

            if (fluidCamera)
                DestroyImmediate(fluidCamera.gameObject);

            m_FluidEffects.RemoveAt(index);
        }
        public FluidEffect[] GetFluidEffects()
        {
            return m_FluidEffects.Select(i => i.fluidEffect).ToArray();
        }
        #endregion

        #region Unity Methods
        [UsedImplicitly]
        void OnPreCull()
        {
            if (Camera.current != m_Camera) return;
            
            for (int i = 0; i < m_FluidEffects.Count; ++i)
            {
                FluidEffect fluidEffect = m_FluidEffects[i].fluidEffect;
                Camera fluidCamera = m_FluidEffects[i].fluidCamera;

                // Remove orphaned cameras
                if (fluidCamera && !m_Camera)
                {
                    DestroyImmediate(fluidCamera.gameObject);
                    var effectAndCam = m_FluidEffects[i];
                    effectAndCam.fluidCamera = null;
                    m_FluidEffects[i] = effectAndCam;
                    continue;
                }

                if (fluidEffect && fluidEffect.enabled && m_Camera && fluidCamera &&
                    fluidEffect.gameObject.activeInHierarchy)
                {
                    fluidCamera.enabled = false;
                    fluidCamera.transform.position = m_Camera.transform.position;
                    fluidCamera.transform.rotation = m_Camera.transform.rotation;
                    fluidCamera.CopyFrom(m_Camera);
                    fluidCamera.useOcclusionCulling = m_Camera.useOcclusionCulling;
                    fluidCamera.hdr = m_Camera.hdr;
                    fluidCamera.clearFlags = CameraClearFlags.SolidColor;
                }
                else if (fluidCamera)
                {
                    fluidCamera.enabled = false;
                }
            }

            for (int i = 0; i < m_FluidEffects.Count; ++i)
            {
                FluidEffect fluidEffect = m_FluidEffects[i].fluidEffect;
                Camera fluidCamera = m_FluidEffects[i].fluidCamera;

                if (!fluidEffect || !fluidEffect._fluid || !fluidEffect.enabled || !m_Camera || !fluidCamera ||
                    !fluidEffect.gameObject.activeInHierarchy) continue;

                fluidEffect.DoOnPreCull(m_Camera);
            }

            m_FluidEffects.Sort((a, b) => -a.fluidEffect.CompareTo(b.fluidEffect));
        }
        [UsedImplicitly]
        [ImageEffectOpaque]
        void OnRenderImage(RenderTexture source, RenderTexture destination)
        {
            m_RenderingEffects.Clear();

            bool processed = false;

            if (Camera.current == m_Camera)
            {
                for (int i = 0; i < m_FluidEffects.Count; ++i)
                {
                    FluidEffect fluidEffect = m_FluidEffects[i].fluidEffect;
                    Camera fluidCamera = m_FluidEffects[i].fluidCamera;

                    // Remove orphaned cameras
                    if (fluidCamera && !m_Camera)
                    {
                        DestroyImmediate(fluidCamera.gameObject);
                        var effectAndCam = m_FluidEffects[i];
                        effectAndCam.fluidCamera = null;
                        m_FluidEffects[i] = effectAndCam;
                        continue;
                    }

                    if (!fluidEffect || !fluidEffect._fluid || !fluidEffect.enabled || !m_Camera || !fluidCamera ||
                        !fluidEffect.gameObject.activeInHierarchy || !fluidEffect.materialIsValid) continue;

                    m_RenderingEffects.Add(fluidEffect);
                }

                for (int i = 0; i < m_FluidEffects.Count; ++i)
                {
                    FluidEffect fluidEffect = m_FluidEffects[i].fluidEffect;
                    Camera fluidCamera = m_FluidEffects[i].fluidCamera;

                    // Remove orphaned cameras
                    if (fluidCamera && !m_Camera)
                    {
                        DestroyImmediate(fluidCamera.gameObject);
                        var effectAndCam = m_FluidEffects[i];
                        effectAndCam.fluidCamera = null;
                        m_FluidEffects[i] = effectAndCam;
                        continue;
                    }

                    if (!fluidEffect || !fluidEffect._fluid || !fluidEffect.enabled || !m_Camera || !fluidCamera ||
                        !fluidEffect.gameObject.activeInHierarchy) continue;
     
                    fluidEffect.DoOnRenderImage(fluidCamera, source, destination, m_RenderingEffects);
                    processed = true;
                }
            }

            if (!processed)
                Graphics.Blit(source, destination);
        }
        [UsedImplicitly]
        void LateUpdate()
        {
            if (m_Camera) return;

            for (var i = 0; i < m_FluidEffects.Count; i++)
            {
                var effect = m_FluidEffects[i].fluidEffect;
                RemoveFluidEffect(effect);
            }
        }
        //! \cond PRIVATE
        [UsedImplicitly]
        protected override void OnEnable()
        {
            base.OnEnable();
            hideFlags = HideFlags.None;
        }
        [UsedImplicitly]
        protected override void OnDestroy()
        {
            base.OnDestroy();

            for (int i = 0; i < m_FluidEffects.Count; i++)
            {
                FluidEffect effect = m_FluidEffects[i].fluidEffect;
                RemoveFluidEffect(effect);
            }
        }
        //! \endcond
#endregion
    }
}
