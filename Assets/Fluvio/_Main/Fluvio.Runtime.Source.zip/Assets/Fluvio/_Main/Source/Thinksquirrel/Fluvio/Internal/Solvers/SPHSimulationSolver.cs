// SPHSimulationSolver.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
#pragma warning disable 162
#pragma warning disable 429
#pragma warning disable 169
// ReSharper disable UnreachableCode
// ReSharper disable ConditionIsAlwaysTrueOrFalse
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Thinksquirrel.Fluvio.Internal.ObjectModel;
using Thinksquirrel.Fluvio.Internal.Threading;
using UnityEngine;

using float4 = UnityEngine.Vector4;

//! Contains physics solver interface types and classes.
namespace Thinksquirrel.Fluvio.Internal.Solvers
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    internal struct int4
    {
        public int x;
        public int y;
        public int z;
        public int w;

        public int4(int x, int y, int z, int w)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.w = w;
        }

        public static implicit operator int4(float4 val)
        {
            return new int4((int)val.x, (int)val.y, (int)val.z, (int)val.w);
        }
    }    
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    internal struct FluidData
    {
        public float4 gravity; // xyz - gravity, w - unused
        public float initialDensity;
        public float minimumDensity;
        public float particleMass;
        public float viscosity;
        public float turbulence;
        public float surfaceTension;
        public float gasConstant;
        public float buoyancyCoefficient;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    internal struct FluidParticle
    {
        // Particle properties
        public float4 position; // xyz - position, w - unused
        public float4 velocity; // xyz - velocity, w - particle size
        public float4 color; // rgba color
        public float4 vorticityTurbulence; // xyz - vorticity, w - turbulence probability
        public float4 lifetime; // x - lifetime, yzw - unused
        public int4 id; // x - fluid id, y - particle id, z - neighbor count, w - unused

        // Physical properties
        public float4 force; //xyz - force, w - unused
        public float4 normal; // xyz - normal, w - prenormalized length
        public float4 densityPressure; // x - density, y - self density, z - pressure, w - unused        
    }

    // Internal solver data class
    // Set up as a bunch of linear arrays for fast parallel access
    // TODO: Array bounds checking isn't the best on the CPU. Let's figure out a strategy for accessing particles w/o the bounds check
    sealed class SolverDataInternal
    {
        #region Instance Fields
        // ReSharper disable InconsistentNaming
        internal int4 _Count; // x - fluid count, y - particle count, z - dynamic particle count, w - boundary particle count
        internal int _Stride;
        internal float4 _Time; // FluvioTimestep struct
        internal float4 _KernelSize; // x - kernelSize, y - kernelSize^2, z - kernelSize^3, w - simulationScale
        internal float4 _KernelFactors; // x - poly6, y - spiky, z - viscosity, w - unused
        internal bool _fluidChanged;
        internal bool _boundaryParticlesChanged;
        internal ComputeAPI _computeAPI;
        // ReSharper restore InconsistentNaming
        #endregion
        #region Arrays and compute buffers
        internal FluidData[] _Fluid;
        internal FluidParticle[] _Particle = new FluidParticle[1];
        internal FluidParticle[] _BoundaryParticle = new FluidParticle[1];
        internal readonly IndexGrid _IndexGrid = new IndexGrid();
        internal int[] _Neighbors = new int[1];
        
        internal FluvioComputeBuffer<FluidData> _fluidCB;
        internal FluvioComputeBuffer<FluidParticle> _particleCB;
        internal FluvioComputeBuffer<FluidParticle> _boundaryParticleCB;
        internal FluvioComputeBuffer<uint> _indexGridCB;
        internal FluvioComputeBuffer<int> _neighborsCB;
        #endregion

        internal void Resize(IList<FluidBase> fluids)
        {   
            var computeAPI = FluvioSettings.GetCurrentComputeAPI();
            if (_computeAPI != computeAPI)
            {
                _computeAPI = computeAPI;
                _fluidChanged = true;
            }
            var fluid = fluids[0];
            var fluidCount = fluids.Count;

            Array.Resize(ref _Fluid, Mathf.Max(1, fluidCount));
            
            if (_Count.x != fluidCount)
            {
                _Count.x = fluidCount;
                _fluidChanged = true;
            }

            var particleCount = 0;
            var boundaryParticleCount = 0;
            var dynamicParticleCount = 0;

            var oldBoundaryParticleCount = _Count.w;

            for (var i = 0; i < _Count.x; ++i)
            {
                var f = fluids[i];
                var pc = f.GetParticleCount();
                var isCollider = f is FluidColliderBase;

                // ReSharper disable HeuristicUnreachableCode
                // ReSharper disable RedundantLogicalConditionalExpressionOperand
                if (VersionInfo.isFreeEdition && f.fluidType == FluidType.Dynamic && !isCollider && dynamicParticleCount + pc > 3000)
                {
                    FluvioDebug.LogError(
                        string.Format("Fluvio Free cannot have more than 3000 dynamic particles per solver group. Changing particle count from {0} to {1}", f.GetParticleCount(), 3000 - dynamicParticleCount), f);

                    pc = f.SetMaxParticles(3000 - dynamicParticleCount);                        
                }
                // ReSharper restore RedundantLogicalConditionalExpressionOperand
                // ReSharper restore HeuristicUnreachableCode
                    
                if (f.fluidType == FluidType.Dynamic && !isCollider) dynamicParticleCount += pc;
                if (f.fluidType == FluidType.Static && isCollider)
                {
                    boundaryParticleCount += pc;                    
                }
                else
                {
                    particleCount += pc;
                }
            }
                
            Array.Resize(ref _Particle, Mathf.Max(1, particleCount));
            Array.Resize(ref _BoundaryParticle, Mathf.Max(1, boundaryParticleCount));

            if (boundaryParticleCount != oldBoundaryParticleCount) _boundaryParticlesChanged = true;

            _Count.y = particleCount;                
            _Count.z = dynamicParticleCount;
            _Count.w = boundaryParticleCount;
                
            var stride = fluid.dimensions == SimulationDimensions.Fluid2D
                ? FluvioSettings.particleStride2D
                : FluvioSettings.particleStride3D;

            // neighborIndex = x * stride + y
            Array.Resize(ref _Neighbors, Mathf.Max(1, (particleCount + boundaryParticleCount)*stride));

            _Stride = stride;
        }

        internal void UploadBuffers()
        {
            // Upload fluids if needed
            if (_fluidChanged && _fluidCB != null) _fluidCB.SetData(_Fluid);
            
            // Upload particles
            //for (var i = 0; i < _Particle.Length; ++i) _Particle[i].force.x = 100*Mathf.Sin(Time.time)*UnityEngine.Random.Range(-1.0f, 1.0f);
            if (_particleCB != null) _particleCB.SetData(_Particle);
            //for (var i = 0; i < _Particle.Length; ++i) _Particle[i].force.x = 0;

            if (_boundaryParticlesChanged && _boundaryParticleCB != null)
            {
                _boundaryParticleCB.SetData(_BoundaryParticle);
            }
            
            // Reset changed flags
            _fluidChanged = false;
            _boundaryParticlesChanged = false;
        }     
    }

    /// SPH simulation solver. Multithreaded, CPU.
    /// Maximum # of fluids per solver group: 255
    /// Maximum # of particles per solver group: 65536
    sealed class SPHSimulationSolver : IFluidSolver
    {
        #region Fields
        readonly FluidBase m_RootFluid;
        // Fluids
        readonly List<FluidBase> m_Fluids = new List<FluidBase>();
        // SPH (kernels)
        SmoothingKernel Poly6;
        SmoothingKernel Spiky;
        SmoothingKernel Viscosity;
        // Compute shaders
        FluvioComputeShader m_ComputeShader;
        int m_SolverIndexGridClear = -1;
        int m_SolverIndexGridAdd = -1;
        int m_SolverNeighborSearchGrid2D = -1;
        int m_SolverNeighborSearchGrid3D = -1;
        int m_SolverNeighborSearch2D = -1;
        int m_SolverNeighborSearch3D = -1;
        int m_SolverDensityPressure = -1;
        int m_SolverNormal = -1;
        int m_SolverForces = -1;
        int m_SolverBoundaryForces = -1;
        int m_SolverTurbulence = -1;
        int m_SolverExternalForces = -1;
        int m_SolverConstraints = -1;
        bool m_ComputeShouldSync;
        // Solver data
        // ReSharper disable once InconsistentNaming
        readonly SolverDataInternal fluvio = new SolverDataInternal();
        // Timers
        readonly int m_SolverTimer;
        readonly int m_PluginsTimer;
        // Disable HQ features (turbulence, external forces, distance constraint)
        readonly bool m_IsNonDesktopPlatform;
        #endregion

        #region Properties
        public FluidBase fluid { get { return m_RootFluid; } }
        // Solver data for plugins
        public SolverDataInternal solverDataInternal
        {
            get { return fluvio; }
        }
        public bool canUseFastIntegrationPath { get; set; }
        public bool supportsTurbulence { get { return !m_IsNonDesktopPlatform; } }
        public bool supportsExternalForces { get { return !m_IsNonDesktopPlatform; } }
        public bool supportsDistanceConstraintSolver { get { return !m_IsNonDesktopPlatform; } }
        public bool shouldUpdateBoundaries { get { return fluvio._boundaryParticlesChanged; } set { fluvio._boundaryParticlesChanged = value; } }
        #endregion

        #region Methods
        public FluidBase GetFluid(int index)
        {
            return m_Fluids[index];
        }
        public int GetFluidID(FluidBase fluid)
        {
            for (var i = 0; i < m_Fluids.Count; ++i)
            {
                if (m_Fluids[i] == fluid)
                {
                    return i;
                }
            }
            return -1;
        }
        #endregion

        #region Initialization
        public SPHSimulationSolver(FluidBase fluid)
        {
            if (fluid == null)
                throw new ArgumentNullException("fluid");

            m_RootFluid = fluid;

            SetCellSpace();

            // Initialize timers
            m_SolverTimer = Timers.CreateTimer(fluid, "Solver");
            m_PluginsTimer = Timers.CreateTimer(fluid, "HW Plugins");

            // Disable HQ feature platforms
            m_IsNonDesktopPlatform = Application.platform == RuntimePlatform.Android ||
                                  Application.platform == RuntimePlatform.IPhonePlayer ||
                                  Application.platform == RuntimePlatform.WP8Player ||
                                  Application.platform == RuntimePlatform.BlackBerryPlayer ||
#if UNITY_5_0_PLUS
                                  Application.platform == RuntimePlatform.PSM ||
                                  Application.platform == RuntimePlatform.WebGLPlayer ||
                                  Application.platform == RuntimePlatform.TizenPlayer ||
#endif
                                  Application.platform == RuntimePlatform.SamsungTVPlayer;
        }
        public void SetSubFluids(IEnumerable<FluidBase> fluids)
        {
            m_Fluids.Clear();
            m_Fluids.Add(m_RootFluid);
            m_Fluids.AddRange(fluids);

            m_Fluids.Sort((a, b) =>
            {
                var aType = (int) a.fluidType;
                var bType = (int) b.fluidType;

                if (a is FluidColliderBase) aType += 3;
                if (b is FluidColliderBase) bType += 3;

                return aType.CompareTo(bType);
            });
        }
        void SetCellSpace()
        {
            var kernelSize = m_RootFluid.smoothingDistance * m_RootFluid.simulationScale;
            
            if (Poly6 == null)
            {
                Poly6 = new Poly6Kernel(kernelSize);
                Spiky = new SpikyKernel(kernelSize);
                Viscosity = new ViscosityKernel(kernelSize);
            }
            else
            {
                Poly6.Initialize(kernelSize);
                Spiky.Initialize(kernelSize);
                Viscosity.Initialize(kernelSize);
            }

            fluvio._KernelSize = new float4(kernelSize, kernelSize * kernelSize, kernelSize * kernelSize * kernelSize, m_RootFluid.simulationScale);
            fluvio._KernelFactors = new float4(Poly6.GetFactor(), Spiky.GetFactor(), Viscosity.GetFactor(), 1.0f);
        }
        #endregion

        #region Process changes
        public void ProcessChanges()
        {
            // Resize solver data
            var oldFluidCount = fluvio._Count.x;
            var oldParticleCount = fluvio._Count.y;
            var oldBoundaryParticleCount = fluvio._Count.w;
            var oldStride = fluvio._Stride;

            SetCellSpace();
            fluvio.Resize(m_Fluids);
            if (FluvioSettings.useIndexGrid) InitializeIndexGrid();

            if (m_ComputeShader == null)
            {
                m_ComputeShader = FluvioComputeShader.Find("ComputeShaders/Solvers/SPHSimulationSolver");
            }

            if (m_ComputeShader != null)
            {
                if (m_SolverIndexGridClear == -1)
                    m_SolverIndexGridClear = m_ComputeShader.FindKernel("Solver_IndexGridClear");
                if (m_SolverIndexGridAdd == -1)
                    m_SolverIndexGridAdd = m_ComputeShader.FindKernel("Solver_IndexGridAdd");
                if (m_SolverNeighborSearchGrid2D == -1)
                    m_SolverNeighborSearchGrid2D = m_ComputeShader.FindKernel("Solver_NeighborSearchGrid2D");
                if (m_SolverNeighborSearchGrid3D == -1)
                    m_SolverNeighborSearchGrid3D = m_ComputeShader.FindKernel("Solver_NeighborSearchGrid3D");
                if (m_SolverNeighborSearch2D == -1)
                    m_SolverNeighborSearch2D = m_ComputeShader.FindKernel("Solver_NeighborSearch2D");
                if (m_SolverNeighborSearch3D == -1)
                    m_SolverNeighborSearch3D = m_ComputeShader.FindKernel("Solver_NeighborSearch3D");
                if (m_SolverDensityPressure == -1)
                    m_SolverDensityPressure = m_ComputeShader.FindKernel("Solver_DensityPressure");
                if (m_SolverNormal == -1)
                    m_SolverNormal = m_ComputeShader.FindKernel("Solver_Normal");
                if (m_SolverForces == -1)
                    m_SolverForces = m_ComputeShader.FindKernel("Solver_Forces");
                if (m_SolverBoundaryForces == -1)
                    m_SolverBoundaryForces = m_ComputeShader.FindKernel("Solver_BoundaryForces");
                if (m_SolverTurbulence == -1)
                    m_SolverTurbulence = m_ComputeShader.FindKernel("Solver_Turbulence");
                if (m_SolverExternalForces == -1)
                    m_SolverExternalForces = m_ComputeShader.FindKernel("Solver_ExternalForces");
                if (m_SolverConstraints == -1)
                    m_SolverConstraints = m_ComputeShader.FindKernel("Solver_Constraints");

                CreateBuffers(oldFluidCount, oldParticleCount, oldBoundaryParticleCount, oldStride);
            }
        }
        #endregion

        #region Pre-solve (set up a solver frame)
        public void PreSolve(ref FluvioTimeStep timeStep)
        {
            // Set global properties
            fluvio._Time = timeStep;

            var particleIndex = 0;
            var boundaryIndex = 0;
            for (var i = 0; i < fluvio._Count.x; ++i)
            {
                var fluidObj = m_Fluids[i];
                var pc = fluidObj.GetParticleCount();
                
                // Set per-fluid properties
                var fluid = fluvio._Fluid[i];
                
                if (Mathf.Abs(fluid.initialDensity - fluidObj.density) > FluvioSettings.kEpsilon)
                {
                    fluid.initialDensity = fluidObj.density;
                    fluvio._fluidChanged = true;
                }
                if (Math.Abs(fluid.minimumDensity - fluidObj.minimumDensity) > FluvioSettings.kEpsilon)
                {
                    fluid.minimumDensity = fluidObj.minimumDensity;
                    fluvio._fluidChanged = true;
                }

                var scale = fluvio._KernelSize.w;
                var scale2 = scale*scale;
                var scale5 = (scale*scale*scale*scale*scale);

                if (Math.Abs((fluid.particleMass * scale) - (fluidObj.particleMass * scale)) > FluvioSettings.kEpsilon)
                {
                    fluid.particleMass = fluidObj.particleMass * scale;
                    fluvio._fluidChanged = true;
                }
                if (Math.Abs((fluid.viscosity * fluvio._KernelSize.x * scale5) - (fluidObj.viscosity * fluvio._KernelSize.x * scale5)) > FluvioSettings.kEpsilon)
                {
                    fluid.viscosity = fluidObj.viscosity * fluvio._KernelSize.x * scale5;
                    fluvio._fluidChanged = true;
                }
                if (Mathf.Abs(fluid.turbulence - fluidObj.turbulence) > FluvioSettings.kEpsilon)
                {
                    fluid.turbulence = fluidObj.turbulence;
                    fluvio._fluidChanged = true;
                }
                if (Math.Abs((fluid.surfaceTension * scale) - (fluidObj.surfaceTension * scale)) > FluvioSettings.kEpsilon)
                {
                    fluid.surfaceTension = fluidObj.surfaceTension * scale;
                    fluvio._fluidChanged = true;
                }
                if (Math.Abs((fluid.gasConstant * scale2) - (fluidObj.gasConstant * scale2)) > FluvioSettings.kEpsilon)
                {
                    fluid.gasConstant = fluidObj.gasConstant * scale2;
                    fluvio._fluidChanged = true;
                }
                if (Math.Abs((fluid.buoyancyCoefficient * scale2) - (fluidObj.buoyancyCoefficient * scale2)) > FluvioSettings.kEpsilon)
                {
                    fluid.buoyancyCoefficient = fluidObj.buoyancyCoefficient * scale2;
                    fluvio._fluidChanged = true;
                }
                var g = (Vector4)fluidObj.gravity;
                if ((fluid.gravity * scale) != (g * scale))
                {
                    fluid.gravity = g * scale;
                    fluvio._fluidChanged = true;
                }
                
                fluvio._Fluid[i] = fluid;

                var isBoundary = particleIndex >= fluvio._Count.y;
                var particleArray = isBoundary
                    ? fluvio._BoundaryParticle
                    : fluvio._Particle;

                for (var j = 0; j < pc; ++j)
                {
                    var id = particleArray[isBoundary ? boundaryIndex : particleIndex].id;
                    id.x = i;
                    id.y = j;
                    particleArray[isBoundary ? boundaryIndex : particleIndex].id = id;
                    if (isBoundary)
                        ++boundaryIndex;
                    else
                        ++particleIndex;
                }
            }            
            
            canUseFastIntegrationPath = true;
        }
        #endregion

        #region Neighbor search helpers
        static int FluvioGetNeighborIndex(int[] neighbors, int particleIndex, int stride, int offset)
        {
            return neighbors[particleIndex * stride + offset];
        }
        void InitializeIndexGrid()
        {
            fluvio._IndexGrid.Initialize(fluvio._KernelSize.x);
        }        
        int QueryIndexGrid2D(int particleIndex, int particleCount, int stride, float kernelSizeSq, FluidParticle[] particleArray, int particleInd, FluidParticle[] particle, FluidParticle[] boundaryParticle, int[] neighbors)
        {
            return fluvio._IndexGrid.Query2D(particleIndex, 
                                           particleCount, 
                                           stride, 
                                           kernelSizeSq, 
                                           particleArray, 
                                           particleInd, 
                                           particle, 
                                           boundaryParticle, 
                                           neighbors);
        }
        int QueryIndexGrid3D(int particleIndex, int particleCount, int stride, float kernelSizeSq, FluidParticle[] particleArray, int particleInd, FluidParticle[] particle, FluidParticle[] boundaryParticle, int[] neighbors)
        {
            return fluvio._IndexGrid.Query3D(particleIndex,
                                           particleCount,
                                           stride,
                                           kernelSizeSq,
                                           particleArray,
                                           particleInd,
                                           particle,
                                           boundaryParticle,
                                           neighbors);
        }
        int QueryBruteForce(int particleIndex, int particleCount, int boundaryParticleCount, int stride, float kernelSizeSq, FluidParticle[] particleArray, int particleInd, FluidParticle[] particle, FluidParticle[] boundaryParticle, int[] neighbors)
        {
            int neighborCount = 0;
            float4 dist;
            float d;
            int neighborInd;
            int totalCount = particleCount + boundaryParticleCount;
            FluidParticle[] neighborArray;
            
            for (int neighborIndex = 0; neighborIndex < totalCount; ++neighborIndex)
            {
                neighborArray = SolverUtility.GetParticleArray(neighborIndex, particleCount, particle, boundaryParticle);
                neighborInd = SolverUtility.GetParticleArrayIndex(neighborIndex, particleCount);

                dist = neighborArray[neighborInd].position - particleArray[particleInd].position;
                dist.w = 0;
                d = float4.Dot(dist, dist);

                if (particleIndex != neighborIndex && // Not the same
                    neighborArray[neighborInd].lifetime.x > 0.0f && // Neighbor is alive
                    d < kernelSizeSq) // Within the correct distance
                {
                    neighbors[particleIndex * stride + neighborCount++] = neighborIndex;
                    
                    if (neighborCount >= stride)
                        return stride;
                }

            }

            return neighborCount;
        }     
        #endregion
        
        #region Main solver
        public void Solve()
        {
            Timers.StartTimer(m_SolverTimer);
                
            if (m_RootFluid.IsHardwareAccelerated() && m_ComputeShader != null)
            {
                ComputeSolver();
            }
            else
            {
                RunSolver();            
            }
            Timers.StopTimer(m_SolverTimer);
        }
        void RunSolver()
        {
            var totalCount = fluvio._Count.y + fluvio._Count.w;

            if (totalCount > 0)
            {
                // Synchronize index grid
                if (FluvioSettings.useIndexGrid)
                {
                    fluvio._IndexGrid.Clear();
                    Profiler.BeginSample("Solver_IndexGridAdd");
                    Parallel.For(totalCount, Solver_IndexGridAdd);
                    Profiler.EndSample();

                    var gridLength = FluvioSettings.gridLength;
                    if (gridLength < totalCount)
                    {
                        if (fluid.dimensions == SimulationDimensions.Fluid2D)
                        {
                            Profiler.BeginSample("Solver_NeighborSearchGrid2D");
                            Parallel.For(gridLength, Solver_NeighborSearchGrid2D);
                            Profiler.EndSample();
                        }
                        else
                        {
                            Profiler.BeginSample("Solver_NeighborSearchGrid3D");
                            Parallel.For(gridLength, Solver_NeighborSearchGrid3D);
                            Profiler.EndSample();
                        }
                    }
                    else
                    {
                        if (fluid.dimensions == SimulationDimensions.Fluid2D)
                        {
                            Profiler.BeginSample("Solver_NeighborSearch2D");
                            Parallel.For(totalCount, Solver_NeighborSearch2D);
                            Profiler.EndSample();
                        }
                        else
                        {
                            Profiler.BeginSample("Solver_NeighborSearch3D");
                            Parallel.For(totalCount, Solver_NeighborSearch3D);
                            Profiler.EndSample();
                        }
                    }
                }
                else
                {
                    // TODO: Optimize brute force search into its own method
                    if (fluid.dimensions == SimulationDimensions.Fluid2D)
                    {
                        Profiler.BeginSample("Solver_NeighborSearch2D");
                        Parallel.For(totalCount, Solver_NeighborSearch2D);
                        Profiler.EndSample();
                    }
                    else
                    {
                        Profiler.BeginSample("Solver_NeighborSearch3D");
                        Parallel.For(totalCount, Solver_NeighborSearch3D);
                        Profiler.EndSample();
                    }
                }
                Profiler.BeginSample("Solver_DensityPressure");
                Parallel.For(totalCount, Solver_DensityPressure);
                Profiler.EndSample();
                Profiler.BeginSample("Solver_Normal");
                Parallel.For(totalCount, Solver_Normal);
                Profiler.EndSample();
            }

            if (fluvio._Count.z > 0)
            {
                Profiler.BeginSample("Solver_Forces");
                Parallel.For(fluvio._Count.z, Solver_Forces);
                Profiler.EndSample();

                if (fluvio._Count.w > 0)
                {
                    Profiler.BeginSample("Solver_BoundaryForces");
                    Parallel.For(fluvio._Count.z, Solver_BoundaryForces);
                    Profiler.EndSample();
                }

                if (!m_IsNonDesktopPlatform)
                {
                    Profiler.BeginSample("Solver_Turbulence");
                    Parallel.For(fluvio._Count.z, Solver_Turbulence);
                    Profiler.EndSample();
                    Profiler.BeginSample("Solver_ExternalForces");
                    Parallel.For(fluvio._Count.z, Solver_ExternalForces);
                    Profiler.EndSample();

                    int iter = (int) fluvio._Time.w;
                    if (iter > 0)
                    {
                        Profiler.BeginSample("Solver_Constraints");
                        for (var i = 0; i < iter; ++i)
                        {
                            Parallel.For(fluvio._Count.z, Solver_Constraints);
                        }
                        Profiler.EndSample();
                    }
                }
            }
        }
        void Solver_IndexGridAdd(int particleIndex)
        {
            // Reverse particle index.
            // This lets us count backwards,
            // prioritizing boundaries and static/kinematic particles for spatial partitioning.
            particleIndex = fluvio._Count.y + fluvio._Count.w - particleIndex - 1;
            
            FluidParticle[] particleArray = SolverUtility.GetParticleArray(particleIndex, fluvio._Count.y, fluvio._Particle, fluvio._BoundaryParticle);
            int particleInd = SolverUtility.GetParticleArrayIndex(particleIndex, fluvio._Count.y);

            // Clear neighbor count
            particleArray[particleInd].id.z = 0;

            if (particleArray[particleInd].lifetime.x <= 0) return;
            fluvio._IndexGrid.Add(particleIndex, ref particleArray[particleInd].position);
        }
        void Solver_NeighborSearchGrid2D(int gridIndex)
        {
            int particleIndex = fluvio._IndexGrid.GetGrid()[gridIndex];

            if (particleIndex < 0) return;

            Solver_NeighborSearch2D(particleIndex);
        }
        void Solver_NeighborSearchGrid3D(int gridIndex)
        {
            int particleIndex = fluvio._IndexGrid.GetGrid()[gridIndex];

            if (particleIndex < 0) return;

            Solver_NeighborSearch3D(particleIndex);
        }
        void Solver_NeighborSearch2D(int particleIndex)
        {
            FluidParticle[] particleArray = 
                SolverUtility.GetParticleArray(particleIndex, 
                                               fluvio._Count.y, 
                                               fluvio._Particle, 
                                               fluvio._BoundaryParticle);

            int particleInd = 
                SolverUtility.GetParticleArrayIndex(particleIndex, 
                                                    fluvio._Count.y);

            // ------------------------------
            // Zero forces
            // ------------------------------
            particleArray[particleInd].force = default(float4);

            // ------------------------------
            // Neighbor Search
            // ------------------------------        
            if (particleArray[particleInd].lifetime.x > 0.0f)
            {
                if (FluvioSettings.useIndexGrid)
                {
                    particleArray[particleInd].id.z = QueryIndexGrid2D(particleIndex,
                                                                       fluvio._Count.y,
                                                                       fluvio._Stride,
                                                                       fluvio._KernelSize.y,
                                                                       particleArray,
                                                                       particleInd,
                                                                       fluvio._Particle,
                                                                       fluvio._BoundaryParticle,
                                                                       fluvio._Neighbors);
                }
                else
                {
                    particleArray[particleInd].id.z = QueryBruteForce(particleIndex,
                                                                      fluvio._Count.y,
                                                                      fluvio._Count.w,
                                                                      fluvio._Stride,
                                                                      fluvio._KernelSize.y,
                                                                      particleArray,
                                                                      particleInd,
                                                                      fluvio._Particle,
                                                                      fluvio._BoundaryParticle,
                                                                      fluvio._Neighbors);
                }
            }
        }
        void Solver_NeighborSearch3D(int particleIndex)
        {
            FluidParticle[] particleArray =
                SolverUtility.GetParticleArray(particleIndex,
                                               fluvio._Count.y,
                                               fluvio._Particle,
                                               fluvio._BoundaryParticle);

            int particleInd =
                SolverUtility.GetParticleArrayIndex(particleIndex,
                                                    fluvio._Count.y);

            // ------------------------------
            // Zero forces
            // ------------------------------
            particleArray[particleInd].force = default(float4);

            // ------------------------------
            // Neighbor Search
            // ------------------------------        
            if (particleArray[particleInd].lifetime.x > 0.0f)
            {
                if (FluvioSettings.useIndexGrid)
                {
                    particleArray[particleInd].id.z = QueryIndexGrid3D(particleIndex,
                                                                       fluvio._Count.y,
                                                                       fluvio._Stride,
                                                                       fluvio._KernelSize.y,
                                                                       particleArray,
                                                                       particleInd,
                                                                       fluvio._Particle,
                                                                       fluvio._BoundaryParticle,
                                                                       fluvio._Neighbors);
                }
                else
                {
                    particleArray[particleInd].id.z = QueryBruteForce(particleIndex,
                                                                      fluvio._Count.y,
                                                                      fluvio._Count.w,
                                                                      fluvio._Stride,
                                                                      fluvio._KernelSize.y,
                                                                      particleArray,
                                                                      particleInd,
                                                                      fluvio._Particle,
                                                                      fluvio._BoundaryParticle,
                                                                      fluvio._Neighbors);
                }
            }
        }
        void Solver_DensityPressure(int particleIndex)
        {
            FluidParticle[] particleArray = SolverUtility.GetParticleArray(particleIndex, fluvio._Count.y, fluvio._Particle, fluvio._BoundaryParticle);
            int particleInd = SolverUtility.GetParticleArrayIndex(particleIndex, fluvio._Count.y);
            FluidParticle[] neighborArray;

            FluidData fluid = fluvio._Fluid[particleArray[particleInd].id.x];
            int neighborCount = particleArray[particleInd].id.z;
            int neighborIndex, neighborInd;
            float density = 0;
            float neighborMass;
            float4 dist;

            // ------------------------------
            // Density/Pressure calculation
            // ------------------------------  
            if (particleArray[particleInd].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);
                    neighborArray = SolverUtility.GetParticleArray(neighborIndex, fluvio._Count.y, fluvio._Particle, fluvio._BoundaryParticle);
                    neighborInd = SolverUtility.GetParticleArrayIndex(neighborIndex, fluvio._Count.y);

                    neighborMass = fluvio._Fluid[neighborArray[neighborInd].id.x].particleMass;

                    dist = particleArray[particleInd].position - neighborArray[neighborInd].position;
                    dist.w = 0;

                    density += neighborMass * Poly6.Calculate(ref dist);
                }

                density = Mathf.Max(density, fluid.minimumDensity);
                particleArray[particleInd].densityPressure.x = density;
                particleArray[particleInd].densityPressure.z = fluid.gasConstant * (density - fluid.initialDensity);
            }
        }
        void Solver_Normal(int particleIndex)
        {
            FluidParticle[] particleArray = SolverUtility.GetParticleArray(particleIndex, fluvio._Count.y, fluvio._Particle, fluvio._BoundaryParticle);
            int particleInd = SolverUtility.GetParticleArrayIndex(particleIndex, fluvio._Count.y);
            FluidParticle[] neighborArray;

            int neighborCount = particleArray[particleInd].id.z;
            int neighborIndex, neighborInd;
            float normalLen;
            float4 dist, normal = default(float4);

            if (particleArray[particleInd].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);
                    neighborArray = SolverUtility.GetParticleArray(neighborIndex, fluvio._Count.y, fluvio._Particle, fluvio._BoundaryParticle);
                    neighborInd = SolverUtility.GetParticleArrayIndex(neighborIndex, fluvio._Count.y);

                    dist = particleArray[particleInd].position - neighborArray[neighborInd].position;
                    dist.w = 0;

                    normal += fluvio._Fluid[neighborArray[neighborInd].id.x].particleMass / neighborArray[neighborInd].densityPressure.x * Poly6.CalculateGradient(ref dist);                    
                }

                normalLen = Vector3.Magnitude(normal);
                particleArray[particleInd].normal = normal / normalLen;
                particleArray[particleInd].normal.w = normalLen;
            }
        }
        void Solver_Forces(int particleIndex)
        {
            int neighborCount = fluvio._Particle[particleIndex].id.z;
            int neighborIndex;
            float neighborMass, scalar;
            float4 dist, force;

            // ------------------------------
            // Force calculation
            // ------------------------------
            if (fluvio._Particle[particleIndex].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);
                    
                    if (neighborIndex > particleIndex && neighborIndex < fluvio._Count.y)
                    {
                        neighborMass = fluvio._Fluid[fluvio._Particle[neighborIndex].id.x].particleMass;

                        dist = fluvio._Particle[particleIndex].position - fluvio._Particle[neighborIndex].position;
                        dist.w = 0;

                        // Pressure Term
                        scalar = neighborMass * (fluvio._Particle[particleIndex].densityPressure.z + fluvio._Particle[neighborIndex].densityPressure.z) / (fluvio._Particle[neighborIndex].densityPressure.x * 2.0f);

                        force = Spiky.CalculateGradient(ref dist);
                        force *= scalar;

                        fluvio._Particle[particleIndex].force -= force;
                        fluvio._Particle[neighborIndex].force += force;

                        // Viscosity Term
                        scalar = neighborMass * Viscosity.CalculateLaplacian(ref dist) * (1.0f / fluvio._Particle[neighborIndex].densityPressure.x);

                        force = (fluvio._Particle[neighborIndex].velocity - fluvio._Particle[particleIndex].velocity) / fluvio._KernelSize.w;
                        force *= scalar * fluvio._Fluid[fluvio._Particle[particleIndex].id.x].viscosity;
                        force.w = 0;

                        fluvio._Particle[particleIndex].force += force;
                        fluvio._Particle[neighborIndex].force -= force;
                    }
                }                
            }
        }
        void Solver_BoundaryForces(int particleIndex)
        {
            int neighborCount = fluvio._Particle[particleIndex].id.z;
            int neighborIndex;
            float neighborMass, scalar;
            float4 dist, force;

            // ------------------------------
            // Force calculation
            // ------------------------------
            if (fluvio._Particle[particleIndex].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);
                    
                    if (neighborIndex > particleIndex && neighborIndex >= fluvio._Count.y)
                    {
                        neighborIndex -= fluvio._Count.y;
                        neighborMass = fluvio._Fluid[fluvio._BoundaryParticle[neighborIndex].id.x].particleMass;

                        dist = fluvio._Particle[particleIndex].position - fluvio._BoundaryParticle[neighborIndex].position;
                        dist.w = 0;

                        // Pressure Term
                        scalar = neighborMass * (fluvio._Particle[particleIndex].densityPressure.z + fluvio._BoundaryParticle[neighborIndex].densityPressure.z) / (fluvio._BoundaryParticle[neighborIndex].densityPressure.x * 2.0f);

                        force = Spiky.CalculateGradient(ref dist);
                        force *= scalar;

                        fluvio._Particle[particleIndex].force -= force;
                        
                        // Viscosity Term
                        scalar = neighborMass * Viscosity.CalculateLaplacian(ref dist) * (1.0f / fluvio._BoundaryParticle[neighborIndex].densityPressure.x);

                        force = (fluvio._BoundaryParticle[neighborIndex].velocity - fluvio._Particle[particleIndex].velocity) / fluvio._KernelSize.w;
                        force *= scalar * fluvio._Fluid[fluvio._Particle[particleIndex].id.x].viscosity;
                        force.w = 0;

                        fluvio._Particle[particleIndex].force += force;
                    }
                }
            }
        }
        void Solver_Turbulence(int particleIndex)
        {
            int neighborCount = fluvio._Particle[particleIndex].id.z;
            int neighborIndex;
            float neighborMass, neighborTurbulence, scalar;
            float4 dist, force;

            // ------------------------------
            // Turbulence
            // ------------------------------
            if (fluvio._Particle[particleIndex].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);

                    if (neighborIndex < fluvio._Count.y)
                    {
                        neighborMass = fluvio._Fluid[fluvio._Particle[neighborIndex].id.x].particleMass;
                        neighborTurbulence = fluvio._Fluid[fluvio._Particle[neighborIndex].id.x].turbulence;

                        dist = fluvio._Particle[particleIndex].position - fluvio._Particle[neighborIndex].position;
                        dist.w = 0;

                        // Turbulence
                        if (neighborIndex < fluvio._Count.z && fluvio._Particle[particleIndex].vorticityTurbulence.w >= fluvio._Fluid[fluvio._Particle[particleIndex].id.x].turbulence && fluvio._Particle[neighborIndex].vorticityTurbulence.w < neighborTurbulence)
                        {
                            scalar = neighborMass * Viscosity.CalculateLaplacian(ref dist) * (1.0f / fluvio._Particle[neighborIndex].densityPressure.x);

                            fluvio._Particle[particleIndex].vorticityTurbulence = scalar * (fluvio._Particle[neighborIndex].vorticityTurbulence - fluvio._Particle[particleIndex].vorticityTurbulence);

                            force = Vector3.ClampMagnitude(FluvioSettings.kTurbulenceConstant * Vector3.Cross(dist, fluvio._Particle[particleIndex].vorticityTurbulence), FluvioSettings.kMaxSqrVelocityChange * fluvio._Fluid[fluvio._Particle[particleIndex].id.x].particleMass);

                            fluvio._Particle[particleIndex].force += force;
                        }
                    }
                }
            }
        }
        void Solver_ExternalForces(int particleIndex)
        {
            int neighborCount = fluvio._Particle[particleIndex].id.z;
            int neighborIndex;
            float neighborMass, scalar;
            float4 dist, force;

            // ------------------------------
            // External forces
            // ------------------------------
            if (fluvio._Particle[particleIndex].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);

                    if (neighborIndex > particleIndex && neighborIndex < fluvio._Count.y)
                    {
                        neighborMass = fluvio._Fluid[fluvio._Particle[neighborIndex].id.x].particleMass;

                        dist = fluvio._Particle[particleIndex].position - fluvio._Particle[neighborIndex].position;
                        dist.w = 0;

                        // Surface Tension (external)
                        if (fluvio._Particle[particleIndex].normal.w > Mathf.PI && fluvio._Particle[particleIndex].normal.w < Mathf.PI * 2.0f)
                        {
                            scalar = neighborMass * Poly6.CalculateLaplacian(ref dist) * fluvio._Fluid[fluvio._Particle[particleIndex].id.x].surfaceTension * (1.0f / fluvio._Particle[neighborIndex].densityPressure.x);

                            force = fluvio._Particle[particleIndex].normal;
                            force.w = 0;
                            force *= scalar;

                            fluvio._Particle[particleIndex].force -= force;
                            fluvio._Particle[neighborIndex].force += force;
                        }
                    }
                }

                // Buoyancy Term (external)
                fluvio._Particle[particleIndex].force += fluvio._Fluid[fluvio._Particle[particleIndex].id.x].gravity * (fluvio._Fluid[fluvio._Particle[particleIndex].id.x].buoyancyCoefficient * (fluvio._Particle[particleIndex].densityPressure.x - fluvio._Fluid[fluvio._Particle[particleIndex].id.x].initialDensity));
            }
        }
        void Solver_Constraints(int particleIndex)
        {
            float particleInvMass = 1.0f / fluvio._Fluid[fluvio._Particle[particleIndex].id.x].particleMass;
            float dt = fluvio._Time.y;
            int neighborCount = fluvio._Particle[particleIndex].id.z;
            float minDistance = (0.5f * fluvio._KernelSize.x);
            float minDistanceSq = minDistance * minDistance;
            int neighborIndex;
            float sqDistance, d;
            float4 dist;

            // ------------------------------
            // Distance constraint
            // ------------------------------
            if (fluvio._Particle[particleIndex].lifetime.x > 0.0f)
            {
                for (int j = 0; j < neighborCount; ++j)
                {
                    neighborIndex = FluvioGetNeighborIndex(fluvio._Neighbors, particleIndex, fluvio._Stride, j);

                    if (neighborIndex > particleIndex && neighborIndex < fluvio._Count.y)
                    {
                        dist = fluvio._Particle[particleIndex].position - fluvio._Particle[neighborIndex].position;
                        dist.w = 0;

                        sqDistance = Vector3.Dot(dist, dist);

                        if (sqDistance < minDistanceSq)
                        {
                            if (sqDistance > FluvioSettings.kEpsilon)
                            {
                                d = Mathf.Sqrt(sqDistance);
                                dist *= (0.5f*(d - minDistance)/d);
                            }
                            else
                            {
                                dist = new float4(0.0f, 0.5f*minDistance, 0.0f, 0.0f);
                            }
                            fluvio._Particle[particleIndex].force += (dist*particleInvMass)/dt;
                            fluvio._Particle[particleIndex].force -= (dist*(1.0f/fluvio._Fluid[fluvio._Particle[neighborIndex].id.x].particleMass))/dt;
                        }
                    }
                }
            }
        }
        #endregion

        #region Compute shaders
        public void ClearBuffers()
        {
            Dispose();
            CreateBuffers(-1, -1, -1, -1);
        }
        public void CreateBuffers(int oldFluidCount, int oldParticleCount, int oldBoundaryParticleCount, int oldStride)
        {
            var fluidCount = fluvio._Count.x;
            var particleCount = fluvio._Count.y;
            var boundaryParticleCount = fluvio._Count.w;
            var totalParticleCount = particleCount + boundaryParticleCount;
            var oldTotalParticleCount = oldParticleCount + oldBoundaryParticleCount;
            var stride = fluvio._Stride;
            
            if (fluvio._fluidCB == null || fluidCount != oldFluidCount)
            {
                if (fluvio._fluidCB != null) fluvio._fluidCB.Dispose();
                fluvio._fluidCB = new FluvioComputeBuffer<FluidData>(Mathf.Max(1, fluidCount));
            }
            
            if (fluvio._particleCB == null || particleCount != oldParticleCount)
            {
                if (fluvio._particleCB != null) fluvio._particleCB.Dispose();
                fluvio._particleCB = new FluvioComputeBuffer<FluidParticle>(Mathf.Max(1, particleCount), true);                
            }

            if (fluvio._boundaryParticleCB == null || boundaryParticleCount != oldBoundaryParticleCount)
            {
                if (fluvio._boundaryParticleCB != null) fluvio._boundaryParticleCB.Dispose();                
                fluvio._boundaryParticleCB = new FluvioComputeBuffer<FluidParticle>(Mathf.Max(1, boundaryParticleCount), true);
            }

            if (fluvio._neighborsCB == null || totalParticleCount != oldTotalParticleCount || stride != oldStride)
            {
                if (fluvio._neighborsCB != null) fluvio._neighborsCB.Dispose();
                fluvio._neighborsCB = new FluvioComputeBuffer<int>(Mathf.Max(1, totalParticleCount * stride), true);
            }

            var len = FluvioSettings.gridLength;

            if (fluvio._indexGridCB == null)
            {
                if (fluvio._indexGridCB != null) fluvio._indexGridCB.Dispose();
                if (len != 0 && FluvioSettings.useIndexGrid) fluvio._indexGridCB = new FluvioComputeBuffer<uint>(len, true);
            }
        }
        public void Dispose()
        {
            if (fluvio._fluidCB != null) fluvio._fluidCB.Dispose();
            if (fluvio._particleCB != null) fluvio._particleCB.Dispose();
            if (fluvio._boundaryParticleCB != null) fluvio._boundaryParticleCB.Dispose();
            if (fluvio._neighborsCB != null) fluvio._neighborsCB.Dispose();
            if (fluvio._indexGridCB != null) fluvio._indexGridCB.Dispose();
            
            fluvio._fluidCB = null;
            fluvio._particleCB = null;
            fluvio._boundaryParticleCB = null;
            fluvio._neighborsCB = null;
            fluvio._indexGridCB = null;

            fluvio._fluidChanged = true;
            fluvio._boundaryParticlesChanged = true;
        }
        void ComputeSolver()
        {
            if (fluvio._fluidCB == null)
                return;

            // Upload data (slow path only)
            if (!canUseFastIntegrationPath)
                fluvio.UploadBuffers();

            // Flush the command queue
            if (fluvio._computeAPI == ComputeAPI.OpenCL) FluvioOpenCL.FlushCommandQueue();

            var totalCount = fluvio._Count.y + fluvio._Count.w;

            if (totalCount > 0)
            {
                if (FluvioSettings.useIndexGrid)
                {
                    var gridLength = FluvioSettings.gridLength;

                    // Index grid clear
                    DispatchComputeShader(m_ComputeShader, m_SolverIndexGridClear, gridLength, false, true);
                    // Index grid add
                    DispatchComputeShader(m_ComputeShader, m_SolverIndexGridAdd, totalCount, false, true);

                    // Neighbor search
                    if (gridLength < totalCount)
                    {
                        if (fluid.dimensions == SimulationDimensions.Fluid2D)
                        {
                            DispatchComputeShader(m_ComputeShader, m_SolverNeighborSearchGrid2D, gridLength, false, true);
                        }
                        else
                        {
                            DispatchComputeShader(m_ComputeShader, m_SolverNeighborSearchGrid3D, gridLength, false, true);
                        }
                    }
                    else
                    {
                        if (fluid.dimensions == SimulationDimensions.Fluid2D)
                        {
                            DispatchComputeShader(m_ComputeShader, m_SolverNeighborSearch2D, totalCount, false, true);
                        }
                        else
                        {
                            DispatchComputeShader(m_ComputeShader, m_SolverNeighborSearch3D, totalCount, false, true);
                        }
                    }
                }
                else
                {
                    // Neighbor search
                    if (fluid.dimensions == SimulationDimensions.Fluid2D)
                    {
                        DispatchComputeShader(m_ComputeShader, m_SolverNeighborSearch2D, totalCount, false, true);
                    }
                    else
                    {
                        DispatchComputeShader(m_ComputeShader, m_SolverNeighborSearch3D, totalCount, false, true);
                    }
                }
                // Density/Pressure
                DispatchComputeShader(m_ComputeShader, m_SolverDensityPressure, totalCount, false);
                // Normal
                DispatchComputeShader(m_ComputeShader, m_SolverNormal, totalCount, false);
            }

            if (fluvio._Count.z > 0)
            {
                // Forces
                DispatchComputeShader(m_ComputeShader, m_SolverForces, fluvio._Count.z, false);
                // Boundary forces
                if (fluvio._Count.w > 0) DispatchComputeShader(m_ComputeShader, m_SolverBoundaryForces, fluvio._Count.z, false);

                if (!m_IsNonDesktopPlatform)
                {
                    // Turbulence
                    // TODO: Skip if no fluids are turbulent
                    DispatchComputeShader(m_ComputeShader, m_SolverTurbulence, fluvio._Count.z, false);
                    // External Forces
                    // TODO: Skip if no fluids have surface tension or buoyancy
                    DispatchComputeShader(m_ComputeShader, m_SolverExternalForces, fluvio._Count.z, false);

                    // Constraints
                    var iter = (int) fluvio._Time.w;
                    for (var i = 0; i < iter; ++i)
                    {
                        DispatchComputeShader(m_ComputeShader, m_SolverConstraints, fluvio._Count.z, false);
                    }
                }
            }
        }
        void DispatchComputeShader(FluvioComputeShader computeShader, int kernelIndex, int count, bool isPlugin = true, bool isIndexGrid = false, bool suppressTimer = false)
        {
            if (count <= 0)
                return;

            DispatchComputeShader(computeShader, kernelIndex, count, 1, 1, isPlugin, isIndexGrid, suppressTimer);
        }
        void DispatchComputeShader(FluvioComputeShader computeShader, int kernelIndex, int x, int y, int z, bool isPlugin = true, bool isIndexGrid = false, bool suppressTimer = false)
        {
            if (x*y*z <= 0)
                return;
            
            if (isPlugin && !suppressTimer) Timers.StartTimer(m_PluginsTimer);
    
            // General arguments
            computeShader.SetInts(kernelIndex, "fluvio_Count", fluvio._Count.x, fluvio._Count.y, fluvio._Count.z, fluvio._Count.w);
            computeShader.SetInt(kernelIndex, "fluvio_Stride", fluvio._Stride);
            computeShader.SetVector(kernelIndex, "fluvio_KernelSize", fluvio._KernelSize);
            computeShader.SetVector(kernelIndex, "fluvio_KernelFactors", fluvio._KernelFactors);
            computeShader.SetVector(kernelIndex, "fluvio_Time", fluvio._Time);

            // Buffers
            computeShader.SetBuffer(kernelIndex, "fluvio_Particle", fluvio._particleCB);
            computeShader.SetBuffer(kernelIndex, "fluvio_Neighbors", fluvio._neighborsCB);

            // Buffers (except index grid)
            if (!isIndexGrid) computeShader.SetBuffer(kernelIndex, "fluvio_Fluid", fluvio._fluidCB);
            
            // Plugins are handled by plugin class

            // Buffers (except plugins)
            if (!isPlugin && !isIndexGrid) computeShader.SetBuffer(kernelIndex, "fluvio_BoundaryParticle", fluvio._boundaryParticleCB);

            // Index grid
            if (isIndexGrid)
            {
                computeShader.SetBuffer(kernelIndex, "fluvio_IndexGridBoundaryParticle", fluvio._boundaryParticleCB);
                if (FluvioSettings.useIndexGrid)
                {
                    computeShader.SetBuffer(kernelIndex, "fluvio_IndexGrid", fluvio._indexGridCB);
                }
            }            
            
            // Particle system handled by FluidParticleSystem

            // Run compute shader
            computeShader.Dispatch(kernelIndex, x, y, z);
                
            m_ComputeShouldSync = true;
            
            if (isPlugin && !suppressTimer) Timers.StopTimer(m_PluginsTimer);
        }
        void GetBuffers(bool getPluginData)
        {
            Timers.StartTimer(m_PluginsTimer);

            if (fluvio._particleCB != null) fluvio._particleCB.GetData(fluvio._Particle);
            
            if (getPluginData)
            {
                if (fluvio._neighborsCB != null) fluvio._neighborsCB.GetData(fluvio._Neighbors);
            }

            m_ComputeShouldSync = false;
           
            Timers.StopTimer(m_PluginsTimer);
        }
        #endregion

        #region ForEachParticle
        public void ForEachParticleDynamic(SolverParticleDelegate particleDelegate)
        {
            if (m_ComputeShouldSync)
            {
                canUseFastIntegrationPath = false;
                GetBuffers(true);
            }
            Parallel.For(fluvio._Count.z, i => DoForEachParticleDynamic(i, particleDelegate));
        }
        public void ForEachParticle(SolverParticleDelegate particleDelegate, bool getBuffers, bool useFastPath)
        {
            if (getBuffers && m_ComputeShouldSync)
            {
                if (!useFastPath) canUseFastIntegrationPath = false;
                GetBuffers(false);
            }

            Parallel.For(fluvio._Count.y, i => DoForEachParticle(i, particleDelegate));
        }
        public void ForEachParticleAll(SolverParticleDelegate particleDelegate, bool getBuffers, bool useFastPath)
        {
            if (getBuffers && m_ComputeShouldSync)
            {
                if (!useFastPath) canUseFastIntegrationPath = false;
                GetBuffers(false);
            }

            Parallel.For(fluvio._Count.y + fluvio._Count.w, i => DoForEachParticleAll(i, particleDelegate));
        }
        public void ForEachParticleBoundary(SolverParticleDelegate particleDelegate)
        {
            Parallel.For(fluvio._Count.w, i => DoForEachParticleBoundary(i, particleDelegate));
        }
        public void ForEachParticlePair(SolverParticlePairDelegate particlePairDelegate)
        {
            if (m_ComputeShouldSync)
            {
                canUseFastIntegrationPath = false;
                GetBuffers(true);
            }
            
            Parallel.For(fluvio._Count.z, i => DoForEachParticlePair(i, particlePairDelegate));
        }
        public void ForEachParticleDynamic(FluvioComputeShader computeShader, int kernelIndex)
        {
            DispatchComputeShader(computeShader, kernelIndex, fluvio._Count.z);
        }
        public void ForEachParticle(FluvioComputeShader computeShader, int kernelIndex, bool isPlugin = false, bool suppressTimer = false)
        {
            DispatchComputeShader(computeShader, kernelIndex, fluvio._Count.y, isPlugin, false, suppressTimer);
        }
        void DoForEachParticleDynamic(int i, SolverParticleDelegate particleDelegate)
        {
            if (fluvio._Particle[i].lifetime.x <= 0)
                return;

            var fluidID = fluvio._Particle[i].id.x;
            
            var fluid = m_Fluids[fluidID];

            particleDelegate(fluid, i);
        }
        void DoForEachParticle(int i, SolverParticleDelegate particleDelegate)
        {
            var fluidID = fluvio._Particle[i].id.x;

            var fluid = m_Fluids[fluidID];

            particleDelegate(fluid, i);
        }
        void DoForEachParticleAll(int i, SolverParticleDelegate particleDelegate)
        {
            var particleArray = SolverUtility.GetParticleArray(i, fluvio._Count.y, fluvio._Particle, fluvio._BoundaryParticle);
            var particleIndex = SolverUtility.GetParticleArrayIndex(i, fluvio._Count.y);

            var fluidID = particleArray[particleIndex].id.x;

            var fluid = m_Fluids[fluidID];

            particleDelegate(fluid, i);
        }
        void DoForEachParticleBoundary(int i, SolverParticleDelegate particleDelegate)
        {
            var fluidID = fluvio._BoundaryParticle[i].id.x;

            var fluid = m_Fluids[fluidID];

            particleDelegate(fluid, i + fluvio._Count.y);
        }
        void DoForEachParticlePair(int i, SolverParticlePairDelegate particlePairDelegate)
        {
            if (fluvio._Particle[i].lifetime.x <= 0)
                return;

            var fluidID = fluvio._Particle[i].id.x;

            var fluidA = m_Fluids[fluidID];

            var stride = fluvio._Stride;

            for (int j = 0, c = fluvio._Particle[i].id.z; j < c; ++j)
            {
                var neighborIndex = fluvio._Neighbors[i * stride + j];

                if (neighborIndex >= fluvio._Count.z)
                    continue;

                fluidID = fluvio._Particle[neighborIndex].id.x;
                
                var fluidB = m_Fluids[fluidID];

                if (fluidB.fluidType != FluidType.Dynamic)
                    continue;

                particlePairDelegate(fluidA, fluidB, i, neighborIndex);
            }
        }
        #endregion
    }
}
