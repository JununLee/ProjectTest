// FluidPlugin.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Internal.ObjectModel;
using UnityEngine;

//! This namespace contains all built-in fluid plugins.
namespace Thinksquirrel.Fluvio.Plugins
{
    /// <summary>
    ///     Base class for fluid plugins.
    /// </summary>
    /// <remarks>
    ///     Fluid plugins are components that modify a fluid or a fluid group.
    ///     They can be displayed with a fluid, or as an independent component.
    /// </remarks>
    [ExecuteInEditMode]
    public abstract class FluidPlugin : FluvioMonoBehaviourBase, IFluidPlugin
    {
        #region Serialized Fields
        [SerializeField] FluidBase m_Fluid;
        [SerializeField] int m_Weight;
        [SerializeField, HideInInspector] bool m_MonoScriptInitialized;
        #endregion

        #region Static and Constant Fields
        internal const int kPluginWeightMultiplier = 5000;
        #endregion
        
        #region Instance Fields
        [NonSerialized] internal int _pluginID = -1;
        [NonSerialized] bool m_ResetWeight = true;
        #endregion

        #region Unity Methods
        /// <summary>
        ///     This is called by Unity when the plugin is enabled for the first time. Overriding classes MUST call base.Awake() to initialize the
        ///     plugin properly.
        /// </summary>
        /// <remarks>
        ///     Plugins should use OnEnablePlugin or OnResetPlugin instead.
        /// </remarks>
        protected virtual void Awake()
        {
            if (Application.isPlaying && !m_MonoScriptInitialized)
                Reset();
        }
        /// <summary>
        ///     This is called by Unity when the plugin is disabled. Overriding classes MUST call base.OnDisable() to remove the
        ///     plugin properly.
        /// </summary>
        /// <remarks>
        ///     Plugins should use OnDisablePlugin instead.
        /// </remarks>
        protected override void OnDisable()
        {
            base.OnDisable();
            DisablePlugin();

            if (!m_Fluid || _pluginID == -1) return;

            m_Fluid.RemovePluginInternal(this);
            _pluginID = -1;
        }
        /// <summary>
        ///     This is called by Unity when the plugin is enabled. Overriding classes MUST call base.OnEnable() to initialize the
        ///     plugin properly.
        /// </summary>
        /// <remarks>
        ///     Plugins should use OnEnablePlugin instead.
        /// </remarks>
        protected override sealed void OnEnable()
        {
            base.OnEnable();

            if (!gameObject || !gameObject.activeInHierarchy) return;
            if (!FluvioHelpers.FindAttachedFluid(m_Fluid, this)) return;

            if (_pluginID == -1)
                _pluginID = m_Fluid.AddPluginInternal(this);
            else
                EnablePlugin();
        }
        /// <summary>
        ///     This is called by Unity when the plugin is reset, or by Fluvio when the plugin is created for the first time. Overriding classes MUST call base.Reset() to initialize the
        ///     plugin properly.
        /// </summary>
        /// <remarks>
        ///     Plugins should use OnResetPlugin instead.
        /// </remarks>
        protected override sealed void Reset()
        {
            base.Reset();

            FluvioHelpers.FindAttachedFluid(m_Fluid, this);
            if (!m_MonoScriptInitialized && m_ResetWeight && _pluginID > 0)
            {
                m_Weight = _pluginID * kPluginWeightMultiplier;
                m_ResetWeight = false;
            }

            OnResetPlugin();

            m_MonoScriptInitialized = true;
        }
        #endregion

        #region Abstract, Virtual, and Override
        /// <summary>
        ///     Provides a reset method for the fluid plugin.
        /// </summary>
        protected virtual void OnResetPlugin() {}
        /// <summary>
        ///     Provides a disable method for the fluid plugin.
        /// </summary>
        protected virtual void OnDisablePlugin() {}
        /// <summary>
        ///     Provides an initialization method for the fluid plugin.
        /// </summary>
        protected virtual void OnEnablePlugin() {} 
        internal void DisablePlugin()
        {
            OnDisablePlugin();
        }
        internal void EnablePlugin()
        {
            OnEnablePlugin();
        }
        /// <summary>
        /// Returns true if the component should be visible in the editor (for example, under a visible foldout)
        /// </summary>
        protected bool isVisibleInEditor
        {
            get { return !fluid || fluid.gameObject != gameObject || (_editorFoldout && fluid.PluginsFoldoutVisible()); }
        }
        #endregion

        #region IFluidPlugin Implementation
        /// <summary>
        ///     Controls the fluid that this plugin belongs to.
        /// </summary>
        public FluidBase fluid
        {
            get { return m_Fluid; }
            set
            {
                if (m_Fluid != null)
                {
                    if (enabled)
                    {
                        m_Fluid.RemovePluginInternal(this);
                        _pluginID = -1;
                    }
                }

                if (value != null)
                {
                    if (enabled && gameObject && gameObject.activeInHierarchy) _pluginID = value.AddPluginInternal(this);
                    m_Fluid = value;
                }
            }
        }
        /// <summary>
        ///     Determines the display and execution order of a plugin.
        /// </summary>
        /// <remarks>
        ///     Note that this does not determine the execution order of plugins that use standard Unity functions like Update/LateUpdate.
        /// </remarks>
        public int weight
        {
            get { return m_Weight; }
            set { m_Weight = value; }
        }
        #endregion
    }
}
