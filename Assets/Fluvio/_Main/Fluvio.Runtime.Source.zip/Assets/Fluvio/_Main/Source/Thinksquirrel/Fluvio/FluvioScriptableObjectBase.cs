// FluvioScriptableObjectBase.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine;

namespace Thinksquirrel.Fluvio
{
    /// <summary>
    ///     ScriptableObject base class for all Fluvio components.
    /// </summary>
    public abstract class FluvioScriptableObjectBase : ScriptableObject
    {
        #region Awake, Destroy, Reset
#if !UNITY_5_0_PLUS
        [NonSerialized] int m_UniqueID = int.MinValue;
        [NonSerialized] static int m_UniqueIDPtr = int.MinValue;
        [NonSerialized] static readonly HashSet<int> s_ActiveObjects = new HashSet<int>();
        [NonSerialized] static readonly object s_IdentifierLock = new object();
#endif
        //! \cond PRIVATE
        [UsedImplicitly]
        protected virtual void OnEnable()
        {
            FluvioSettings.InitializeRuntimeHelper();
        }
        [UsedImplicitly]
        protected virtual void OnDisable() { }
        [UsedImplicitly]
        protected virtual void OnDestroy()
        {
#if !UNITY_5_0_PLUS
            if (m_UniqueID != int.MinValue)
            {
                s_ActiveObjects.Remove(m_UniqueID);
            }
#endif
        }
        [UsedImplicitly]
        protected virtual void Reset() { }
        //! \endcond

#if !UNITY_5_0_PLUS
        public static implicit operator bool (FluvioScriptableObjectBase exists)
        {
            return !CompareBaseFluvioObjects(exists, null);
        }

        public static bool operator ==(FluvioScriptableObjectBase x, FluvioScriptableObjectBase y)
        {
            return CompareBaseFluvioObjects(x, y);
        }

        public static bool operator !=(FluvioScriptableObjectBase x, FluvioScriptableObjectBase y)
        {
            return !CompareBaseFluvioObjects(x, y);
        }
        public override bool Equals(object o)
        {
            return CompareBaseFluvioObjects(this, o as FluvioScriptableObjectBase);
        }
        public override int GetHashCode()
        {
            
            if (m_UniqueID == int.MinValue)
            {
                lock (s_IdentifierLock)
                {
                    m_UniqueID = ++m_UniqueIDPtr;
                    s_ActiveObjects.Add(m_UniqueID);
                }
            }
            return m_UniqueID;
        }
    
        static bool CompareBaseFluvioObjects(FluvioScriptableObjectBase lhs, FluvioScriptableObjectBase rhs)
        {
            var lhsIsNull = ReferenceEquals(lhs, null);
            var rhsIsNull = ReferenceEquals(rhs, null);
            if (rhsIsNull && lhsIsNull) return true;
            if (rhsIsNull) return !s_ActiveObjects.Contains(lhs.GetHashCode());
            if (lhsIsNull) return !s_ActiveObjects.Contains(rhs.GetHashCode());
            return lhs.GetHashCode() == rhs.GetHashCode();
        }
#endif
        #endregion
    }
}
