// FluidColliderBaseInspector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using Thinksquirrel.Fluvio;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    public class FluidColliderBaseInspector : FluvioInspectorBase
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var prop = serializedObject.FindProperty("m_AttatchedCollider");

            if (!serializedObject.isEditingMultipleObjects)
            {
                var fluid = target as FluidColliderBase;
                if (FluvioMonoBehaviourBase.IsValid(fluid) && !fluid.parentFluid)
                {
                    var icon = EditorGUIUtility.IconContent("console.warnicon.sml",
                                                            "Fluid colliders must have a parent fluid attatched.");
                    icon.text = "Fluid colliders must have a parent fluid attatched.";
                    #if !UNITY_5_0_PLUS
                    var helpBox = typeof(EditorStyles).GetPropertyValue<GUIStyle>("helpBox");
                    #else
                    var helpBox = EditorStyles.helpBox;
                    #endif

                    EditorGUILayout.Separator();
                    GUILayout.Label(icon, helpBox);
                    EditorGUILayout.Separator();
                }
            }

            EditorGUILayout.PropertyField(prop, new GUIContent(ObjectNames.NicifyVariableName(prop.name)));
            serializedObject.ApplyModifiedProperties();

            var hasWheel = false;
            foreach (var targ in targets)
            {
                var col = targ as FluidColliderBase;
                if (!col) continue;
                var attatched = col.GetFieldValue("m_AttatchedCollider") as Component;
                if (!attatched) continue;
                if (attatched.gameObject != col.gameObject)
                {
                    col.SetFieldValue("m_AttatchedCollider", null);
                }
                else
                {
                    hasWheel = attatched is WheelCollider;
                }
            }
            
            //EditorGUI.BeginChangeCheck();
            //var isStatic = EditorGUILayout.Toggle("Is Static", fluid.fluidType != FluidType.Kinematic);
            //if (EditorGUI.EndChangeCheck())
            //{
            //    fluid.fluidType = isStatic ? FluidType.Static : FluidType.Kinematic;
            //}

            serializedObject.Update();

            prop = serializedObject.GetIterator();
            prop.Next(true);

            var enterChildren = true;

            while (prop.NextVisible(enterChildren))
            {
                // Initialize variables
                var label = new GUIContent(ObjectNames.NicifyVariableName(prop.name));
                var hide = false;

                // Get tooltip
                switch (prop.name)
                {
                    case "m_Script":
                    case "m_SolverEnabled":
                    case "m_EnableHardwareAcceleration":
                    case "m_Dimensions":
                    case "m_CullingType":
                    case "m_SmoothingDistance":
                    case "m_MinimumDensity":
                    case "m_Viscosity":
                    case "m_Turbulence":
                    case "m_SurfaceTension":
                    case "m_BuoyancyCoefficient":
                    case "m_SimulationScale":
                    case "m_AttatchedCollider":
                    case "m_WheelColliderThickness":
                        hide = true;
                        break;
                    case "m_BoundsType":
                        if (hasWheel)
                        {
                            // Move the wheel collider thickness field up
                            var wheelThicknessProp = serializedObject.FindProperty("m_WheelColliderThickness");
                            var wheelThicknessLabel = new GUIContent(ObjectNames.NicifyVariableName(wheelThicknessProp.name));
                            enterChildren = EditorGUILayout.PropertyField(wheelThicknessProp, wheelThicknessLabel);
                        }
                        break;
                    case "m_ColliderBounds":
                        var boundsType = serializedObject.FindProperty("m_BoundsType");
                        hide = !boundsType.hasMultipleDifferentValues && boundsType.enumValueIndex == 0;
                        break;
                    case "m_FillCollider":                        
                        foreach (var targ in targets)
                        {
                            var edge = targ.GetFieldValue("m_AttatchedCollider") as EdgeCollider2D;
                            var terrain = targ.GetFieldValue("m_AttatchedCollider") as TerrainCollider;

                            if (!edge && !terrain)
                            {
                                hide = false;
                                break;
                            }
                            hide = true;
                        }
                        break;
                    default:
                        label.tooltip = label.text;
                        break;
                }

                if (prop.isArray && !hide)
                {
                    hide = true;
                    var size = prop.arraySize;
                    enterChildren = EditorGUILayout.PropertyField(prop, label);
                    if (enterChildren)
                    {
                        EditorGUI.indentLevel++;
                        EditorGUILayout.PropertyField(prop.FindPropertyRelative("Array.size"));
                        var subLabel = new GUIContent();
                        for (var i = 0; i < size; ++i)
                        {
                            subLabel.text = "Element " + i;
                            subLabel.tooltip = "Element " + i;
                            EditorGUILayout.PropertyField(
                                prop.GetArrayElementAtIndex(Mathf.Clamp(i, 0, prop.arraySize - 1)), subLabel);
                        }
                        EditorGUI.indentLevel--;
                    }
                    enterChildren = false;
                }

                // Display
                if (hide) continue;
                enterChildren = EditorGUILayout.PropertyField(prop, label);
            }

            serializedObject.ApplyModifiedProperties();

            var count = 0;
            foreach (var targ in targets)
            {
                var fluid = targ as FluidColliderBase;
                if (fluid)
                {
                    count += fluid.GetActiveParticleCount();
                }
            }

            EditorGUILayout.LabelField(targets.Length > 1 ? "Total Particles" : "Particles", count.ToString());

            if (GUILayout.Button(targets.Length > 1 ? "Update colliders" : "Update collider"))
            {
                foreach (var targ in targets)
                {
                    var fluid = targ as FluidColliderBase;
                    if (fluid)
                    {
                        fluid.ForceColliderUpdate(true);
                    }
                }
                SceneView.RepaintAll();
                Repaint();
            }
        }
    }
}
