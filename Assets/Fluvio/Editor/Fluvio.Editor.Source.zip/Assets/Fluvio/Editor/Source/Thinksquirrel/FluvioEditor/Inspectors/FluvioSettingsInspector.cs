using System;
using System.Linq;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Internal;
using UnityEditor;
using UnityEngine;
using Cloo;

// ReSharper disable RedundantAssignment
// ReSharper disable ConditionIsAlwaysTrueOrFalse
// ReSharper disable HeuristicUnreachableCode
#pragma warning disable 162

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof(FluvioSettings))]
    public class FluvioSettingsInspector : FluvioInspectorBase
    {
        class Foldouts
        {
            public bool this[int index]
            {
                get { return EditorPrefs.GetBool("Thinksquirrel.FluvioEditor.FluvioSettingsFoldouts.Foldout" + index, false); }
                set { EditorPrefs.SetBool("Thinksquirrel.FluvioEditor.FluvioSettingsFoldouts.Foldout" + index, value); }
            }
        }
        Foldouts m_Foldouts = new Foldouts();

        bool m_UseIndexGridCached;
        int m_MaxGridSizeCached;
        int m_GridBucketSizeCached;
        int m_MaxGridSizeInput;
        int m_GridBucketSizeInput;
        bool m_ShouldSetConstants;

        protected override void OnEnable()
        {
            base.OnEnable();
            FluvioSettings.onReset += OnReset;
            EditorApplication.update += Update;
            m_MaxGridSizeInput = FluvioSettings.maxGridSize;
            m_GridBucketSizeInput = FluvioSettings.gridBucketSize;
        }

        protected override void OnDisable()
        {
            base.OnDisable();
            FluvioSettings.onReset -= OnReset;
            EditorApplication.update -= Update;
        }

        void Update()
        {
            if (m_ShouldSetConstants)
            {
                m_ShouldSetConstants = false;
                FluvioComputeShaderPostProcessor.SetConstants();
            }
        }

        void OnReset()
        {
            if (m_UseIndexGridCached != FluvioSettings.useIndexGrid || 
                m_MaxGridSizeCached != FluvioSettings.maxGridSize ||
                m_GridBucketSizeCached != FluvioSettings.gridBucketSize)
            {
                m_ShouldSetConstants = true;
            }
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var prop = serializedObject.GetIterator();
            prop.Next(true);

            var enterChildren = true;

            var openCLDeviceType = (int)FluvioSettings.openCLDesiredDeviceType;
            var shouldReloadOpenCL = false;

            EditorGUI.BeginChangeCheck();

            while (prop.NextVisible(enterChildren))
            {
                // Initialize variables
                var label = new GUIContent(ObjectNames.NicifyVariableName(prop.name));
                label.tooltip = label.text;
                var hide = false;
                var disabled = false;
                
                switch (prop.name)
                {
                    case "m_Script":
                        hide = true;
                        break;
                    case "m_UseIndexGrid":
                        hide = true;
                        EditorGUI.BeginChangeCheck();
                        bool newVal = EditorGUILayout.Toggle(label, prop.boolValue);
                        if (EditorGUI.EndChangeCheck())
                        {
                            if (prop.boolValue != newVal)
                            {
                                prop.boolValue = newVal;
                                m_ShouldSetConstants = true;
                            }
                        }
                        break;
                    case "m_MaxGridSize":
                    case "m_GridBucketSize":
                        hide = true;
                        disabled = !FluvioSettings.useIndexGrid;
                        EditorGUI.BeginDisabledGroup(disabled);
                        GUILayout.BeginHorizontal();
                        var bucketSizeProp = prop.name == "m_GridBucketSize";
                        var input = bucketSizeProp ? m_GridBucketSizeInput : m_MaxGridSizeInput;
                        input = EditorGUILayout.IntField(label, input);
                        if (bucketSizeProp)
                        {
                            m_GridBucketSizeInput = input;
                        }
                        else
                        {
                            m_MaxGridSizeInput = input;
                        }
                        EditorGUI.BeginDisabledGroup(prop.intValue == input);
                        if (GUILayout.Button("Apply", EditorStyles.miniButtonLeft, GUILayout.Width(50)))
                        {
                            prop.intValue = input;
                            m_ShouldSetConstants = true;
                        }
                        GUI.SetNextControlName(prop.name + "-Reset");
                        if (GUILayout.Button("Reset", EditorStyles.miniButtonRight, GUILayout.Width(50)))
                        {
                            if (bucketSizeProp)
                            {
                                m_GridBucketSizeInput = prop.intValue;
                            }
                            else
                            {
                                m_MaxGridSizeInput = prop.intValue;
                            }
                            GUI.FocusControl(prop.name + "-Reset");
                        }
                        EditorGUI.EndDisabledGroup();
                        GUILayout.EndHorizontal();
                        EditorGUI.EndDisabledGroup();
                        break;
                    case "m_DesiredHardwareAccelerationAPI":
                        label.text = label.text.Replace("Hardware", "HW");
                        break;
                    case "m_OpenCLDesiredDeviceType":
                        EditorGUILayout.Separator();
                        if (FluvioSettings.desiredComputeAPI != ComputeAPI.OpenCL)
                        {
                            var icon = EditorGUIUtility.IconContent("console.warnicon.sml", "The following settings will not have any effect unless OpenCL simulation is active.");
                            icon.text = "The following settings will not have any effect unless OpenCL simulation is active.";
#if !UNITY_5_0_PLUS
                            var helpBox = typeof(EditorStyles).GetPropertyValue<GUIStyle>("helpBox");
#else
                            var helpBox = EditorStyles.helpBox;
#endif

                            EditorGUILayout.Separator();
                            GUILayout.Label(icon, helpBox);
                            EditorGUILayout.Separator();
                        }
                        GUILayout.BeginHorizontal();
                        GUILayout.FlexibleSpace();
                        GUILayout.Label("OpenCL Settings", EditorStyles.boldLabel);
                        GUILayout.FlexibleSpace();
                        GUILayout.EndHorizontal();
                        label.text = "Desired Device Type";
                        break;
                    case "m_EnableOpenCLGPUOnOSX":
                        label.text = "Enable GPU on OS X";
                        break;
                    case "m_OpenCLPlatformBlacklist":
                        label.text = "Platform Blacklist";
                        break;
                    case "m_OpenCLDeviceBlacklist":
                        label.text = "Device Blacklist";
                        break;
                }

                // Display
                if (hide) continue;
                EditorGUI.BeginDisabledGroup(disabled);
                enterChildren = EditorGUILayout.PropertyField(prop, label);
                EditorGUI.EndDisabledGroup();
            }
            
            if (FluvioOpenCL.IsOpenCLAvailable())
            {
                var currentDevice = FluvioOpenCL.GetComputeContext().Devices[0];
                var foldoutIndex = 0;
                EditorGUILayout.Separator();
                GUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                GUILayout.Label("OpenCL Information", EditorStyles.boldLabel);
                GUILayout.FlexibleSpace();
                GUILayout.EndHorizontal();

                foreach (var platform in ComputePlatform.Platforms)
                {
                    var blacklisted = false;
                    foreach (var blacklistItem in FluvioSettings.openCLPlatformBlacklist)
                    {
                        if (blacklistItem.Contains(platform.Name))
                        {
                            blacklisted = true;
                            break;
                        }
                    }
                    
                    var isCurrentPlatform = Equals(currentDevice.Platform, platform);
                    if (blacklisted && isCurrentPlatform) shouldReloadOpenCL = true;

                    m_Foldouts[foldoutIndex] = EditorGUILayout.Foldout(m_Foldouts[foldoutIndex], platform.Name + (blacklisted ? " [Blacklisted]" : isCurrentPlatform ? " [Current Platform]" : string.Empty));

                    if (!m_Foldouts[foldoutIndex++])
                        continue;

                    EditorGUI.indentLevel++;                        
                    if (platform.Devices.Count > 0)
                    {
                        foreach (var device in platform.Devices)
                        {
                            if (device.Available && device.CompilerAvailable)
                            {
                                var blacklistedDevice = blacklisted;

                                if (!blacklistedDevice)
                                {
                                    foreach (var blacklistItem in FluvioSettings.openCLDeviceBlacklist)
                                    {
                                        if (blacklistItem.Contains(device.Name))
                                        {
                                            blacklistedDevice = true;
                                            break;
                                        }
                                    }
                                }

                                var isCurrentDevice = Equals(currentDevice, device);
                                if (blacklistedDevice && isCurrentDevice) shouldReloadOpenCL = true;

                                EditorGUILayout.SelectableLabel(device.Name + (blacklistedDevice ? " [Blacklisted]" : isCurrentDevice ? " [Current Device]" : string.Empty), EditorStyles.boldLabel);
                               
                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Version", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(device.VersionString, EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                GUILayout.EndHorizontal();

                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Type", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(device.Type.ToString().ToUpper(), EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                GUILayout.EndHorizontal();

                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Profile", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(device.Profile, EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                GUILayout.EndHorizontal();

                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Compute Units", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(device.MaxComputeUnits.ToString("D"), EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                GUILayout.EndHorizontal();

                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Memory", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(FormatBytes(device.GlobalMemorySize), EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                GUILayout.EndHorizontal();

                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Max Clock Frequency", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(device.MaxClockFrequency.ToString("## 'MHz'"), EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                GUILayout.EndHorizontal();

                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Extensions", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                var first = true;
                                foreach (var extension in device.Extensions)
                                {
                                    if (!first)
                                    {
                                        GUILayout.BeginHorizontal();
                                        EditorGUILayout.PrefixLabel(" ", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                    }
                                    EditorGUILayout.SelectableLabel(extension, EditorStyles.miniLabel, GUILayout.MaxHeight(16));
                                    GUILayout.EndHorizontal();
                                    first = false;
                                }
                            }
                            else
                            {
                                GUILayout.BeginHorizontal();
                                EditorGUILayout.PrefixLabel("Device or device compiler unavailable", EditorStyles.miniLabel, EditorStyles.miniLabel);
                                EditorGUILayout.SelectableLabel(" ", EditorStyles.miniLabel);
                                GUILayout.EndHorizontal();
                            }
                            EditorGUILayout.Separator();
                        }
                    }
                    else
                    {
                        GUILayout.BeginHorizontal();
                        EditorGUILayout.PrefixLabel("No devices found", EditorStyles.miniLabel, EditorStyles.miniLabel);
                        EditorGUILayout.SelectableLabel(" ", EditorStyles.miniLabel);
                        GUILayout.EndHorizontal();
                    }
                    EditorGUI.indentLevel--;
                }
            }

            if (EditorGUI.EndChangeCheck())
            {
                // Clamp
                var maxGridSize = serializedObject.FindProperty("m_MaxGridSize");
                var fixedDeltaTime = serializedObject.FindProperty("m_FixedDeltaTime");
                var maxDeltaTime = serializedObject.FindProperty("m_MaxDeltaTime");
                var solverIterations = serializedObject.FindProperty("m_SolverIterations");
                var desiredThreads = serializedObject.FindProperty("m_DesiredThreads");

                maxGridSize.intValue = Mathf.Clamp(maxGridSize.intValue, 16, 1024);
                fixedDeltaTime.floatValue = Mathf.Clamp(fixedDeltaTime.floatValue, 0.0001f, 10f);
                maxDeltaTime.floatValue = Mathf.Clamp(maxDeltaTime.floatValue, fixedDeltaTime.floatValue, float.MaxValue);
                solverIterations.intValue = Mathf.Clamp(solverIterations.intValue, 1, 20);
                desiredThreads.intValue = Mathf.Max(1, desiredThreads.intValue);                
            }

            if (FluvioOpenCL.IsOpenCLAvailable())
            {
                var deviceTypeEnumIndex = serializedObject.FindProperty("m_OpenCLDesiredDeviceType").enumValueIndex;
                if (shouldReloadOpenCL || openCLDeviceType != (int)Mathf.Pow(2, deviceTypeEnumIndex + 1))
                {
                    serializedObject.ApplyModifiedProperties();
                    var fluids = FluidBase.GetAllFluids();

                    foreach (var fluid in fluids)
                    {
                        if (fluid.parentFluid) continue;

                        if (fluid._solver != null)
                        {
                            fluid._solver.Dispose();
                        }
                    }
                    foreach (var shader in FluvioOpenCL._computeShaders)
                    {
                        shader.Cleanup();
                    }

                    FluvioOpenCL.ForceInitialize();
                    Repaint();
                    return;
                }
            }

            serializedObject.ApplyModifiedProperties();

            m_MaxGridSizeCached = FluvioSettings.maxGridSize;
            m_GridBucketSizeCached = FluvioSettings.gridBucketSize;
            m_UseIndexGridCached = FluvioSettings.useIndexGrid;
        }

        static string FormatBytes(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double b = bytes;
            var order = 0;
            while (b >= 1024 && order + 1 < sizes.Length)
            {
                order++;
                b = b / 1024;
            }

            return string.Format("{0:0.##} {1}", b, sizes[order]);
        }
    }  
}
