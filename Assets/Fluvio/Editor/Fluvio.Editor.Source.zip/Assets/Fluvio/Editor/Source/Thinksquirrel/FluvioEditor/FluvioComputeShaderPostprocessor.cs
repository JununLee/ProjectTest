using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Cloo;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Internal;
using UnityEditor;
using UnityEditor.Callbacks;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor
{
    [InitializeOnLoad]
    public class FluvioComputeShaderPostProcessor : AssetPostprocessor
    {
        internal static void ParseIncludesRecursive(string source, string path, StringBuilder sb)
        {
            using (var stringReader = new StringReader(source))
            {
                var line = stringReader.ReadLine();
                while (line != null)
                {
                    if (line.StartsWith("#include "))
                    {
                        var include = line.Substring(10, line.Length - 11);
                        var includePath = Path.Combine(Path.GetDirectoryName(path), include);
                        if (File.Exists(includePath))
                        {
                            var includeSrc = File.ReadAllText(includePath);
                            includeSrc = FluvioComputeShader.RemoveComments(includeSrc);
                            includeSrc = FluvioComputeShader.Minify(includeSrc);
                            sb.AppendLine();
                            ParseIncludesRecursive(includeSrc, includePath, sb);
                            sb.AppendLine();
                        }
                        else
                        {
                            sb.AppendLine(string.Format("#error \"Could not find include - {0}\"", includePath));
                        }
                    }
                    else
                    {
                        sb.AppendLine(line);
                    }
                    line = stringReader.ReadLine();
                }
            }
        }
        static string MakeRelative(string filePath, string referencePath)
        {
            var fileUri = new Uri(filePath);
            var referenceUri = new Uri(referencePath);
            return referenceUri.MakeRelativeUri(fileUri).ToString();
        }
        internal static void SetConstants()
        {
            var rootPath = new DirectoryInfo(Application.dataPath);

            var files = rootPath.GetFiles("FluvioCompute.cginc", SearchOption.AllDirectories);

            if (files.Length < 1) return;

            var fluvioCompute = files[0].FullName;

            var shaderSource = File.ReadAllText(fluvioCompute);
            var originalSource = shaderSource;

            var regex = new Regex(@"^.*#define FLUVIO_MAX_GRID_SIZE\W.*$", RegexOptions.Multiline);
            shaderSource = regex.Replace(shaderSource, "#define FLUVIO_MAX_GRID_SIZE " + FluvioSettings.maxGridSize);

            regex = new Regex(@"^.*#define FLUVIO_GRID_BUCKET_SIZE\W.*$", RegexOptions.Multiline);
            shaderSource = regex.Replace(shaderSource, "#define FLUVIO_GRID_BUCKET_SIZE " + FluvioSettings.gridBucketSize);

            regex = new Regex(@"^.*#define FLUVIO_GRID_LENGTH\W.*$", RegexOptions.Multiline);
            shaderSource = regex.Replace(shaderSource, "#define FLUVIO_GRID_LENGTH " + FluvioSettings.gridLength);
            
            regex = new Regex(@"^.*#define FLUVIO_USE_INDEX_GRID_.*$", RegexOptions.Multiline);
            shaderSource = regex.Replace(shaderSource, "#define FLUVIO_USE_INDEX_GRID_" + (FluvioSettings.useIndexGrid ? "ON" : "OFF"));

            if (originalSource != shaderSource)
            {
                File.WriteAllText(fluvioCompute, shaderSource);

                var relativePath = MakeRelative(fluvioCompute, rootPath.FullName);
                AssetDatabase.ImportAsset(relativePath);
            }
        }
        static float s_LastCheckTime = -5.0f;
        static void VerifyConstants()
        {
            // Detect scene change or other time resets
            if (s_LastCheckTime > Time.realtimeSinceStartup)
            {
                s_LastCheckTime = float.MinValue;
            }

            if (Time.realtimeSinceStartup - s_LastCheckTime > 5.0f)

            SetConstants();
            s_LastCheckTime = Time.realtimeSinceStartup;
        }        
        static FluvioComputeShaderPostProcessor()
        {
            EditorApplication.update += VerifyConstants;
        }

        [UsedImplicitly]
        static void OnPostprocessAllAssets(
            string[] importedAssets,
            string[] deletedAssets,
            string[] movedAssets,
            string[] movedFromAssetPaths)
        {
            for (var i = 0; i < importedAssets.Length; i++)
            {
                var assetPath = importedAssets[i];

                if (!assetPath.EndsWith("cl.txt") && !assetPath.EndsWith("cginc")) continue;

                var fullAssetPath = Path.GetDirectoryName(Path.Combine(Application.dataPath.Substring(0, Application.dataPath.Length - 7), assetPath));

                if (string.IsNullOrEmpty(fullAssetPath)) return;

                var importedShader = AssetDatabase.LoadAssetAtPath(assetPath, typeof(TextAsset)) as TextAsset;                

                // TODO: Only clear OpenCL errors
                ClearLog();

                var computeShaderObjs = AssetDatabase.FindAssets("t:FluvioComputeShader");
                
                for (var j = 0; j < computeShaderObjs.Length; ++j)
                {
                    var localPath = AssetDatabase.GUIDToAssetPath(computeShaderObjs[j]);
                    var cs = AssetDatabase.LoadAssetAtPath(localPath, typeof(FluvioComputeShader)) as FluvioComputeShader;
                    
                    if (!cs) continue;

                    var oclShader = cs.GetFieldValue<TextAsset>("m_OpenCLShader");

                    if (oclShader && importedShader && assetPath.EndsWith("cl.txt"))
                    {
                        var path = AssetDatabase.GetAssetPath(oclShader);
                        if (path != assetPath) continue;

                        cs.SetOpenCLIncludePath(localPath);
                        cs._hadCompilerError = false;
                        cs.CompileOpenCLProgram();
                        s_RanPreBuildTask = false;
                        // FluvioDebug.Log("Compiling due to OpenCL shader change in: " + path);
                    }
                    else
                    {
                        var unityNativeShader = cs.GetFieldValue<ComputeShader>("m_ComputeShader");

                        if (unityNativeShader) AssetDatabase.ImportAsset(AssetDatabase.GetAssetPath(unityNativeShader));
                        if (oclShader) AssetDatabase.ImportAsset(AssetDatabase.GetAssetPath(oclShader));

                        // FluvioDebug.Log("Reimporting due to include change: " + AssetDatabase.GetAssetPath(unityNativeShader) + " | " + AssetDatabase.GetAssetPath(oclShader));
                    }
                    EditorUtility.SetDirty(cs);
                }
            }
        }
        // TODO: Combine ClearLog duplication
        static void ClearLog()
        {
            // This simply does "LogEntries.Clear()" the long way:
            var logEntries = System.Type.GetType("UnityEditorInternal.LogEntries,UnityEditor.dll");
            var clearMethod = logEntries.GetMethod("Clear", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public);
            clearMethod.Invoke(null, null);
        }

        static bool s_RanPreBuildTask;
        [PostProcessScene]
        static void OnPostProcessScene()
        {
            if (!EditorApplication.isPlayingOrWillChangePlaymode)
            {
                if (s_RanPreBuildTask) return;
                s_RanPreBuildTask = true;
            }
            
            var computeShaderObjs = AssetDatabase.FindAssets("t:FluvioComputeShader");

            for (var j = 0; j < computeShaderObjs.Length; ++j)
            {
                var localPath = AssetDatabase.GUIDToAssetPath(computeShaderObjs[j]);
                var cs = AssetDatabase.LoadAssetAtPath(localPath, typeof(FluvioComputeShader)) as FluvioComputeShader;

                if (!cs) continue;                

                var oclShader = cs.GetFieldValue<TextAsset>("m_OpenCLShader");

                if (!oclShader) continue;

                // Only update paths when going into play mode in the editor
                if (EditorApplication.isPlayingOrWillChangePlaymode)
                {
                    cs.SetOpenCLIncludePath(localPath);
                    continue;
                }

                var fullAssetPath = Path.GetDirectoryName(Path.Combine(Application.dataPath.Substring(0, Application.dataPath.Length - 7), localPath));
                var includePaths = new List<string>();
                var includeSource = new List<string>();
                
                var source = oclShader.text;

                source = FluvioComputeShader.RemoveComments(source);
                source = FluvioComputeShader.Minify(source);

                using (var stringReader = new StringReader(source))
                {
                    var line = stringReader.ReadLine();
                    while (line != null)
                    {
                        if (line.StartsWith("#include "))
                        {
                            var include = line.Substring(10, line.Length - 11);
                            var includePath = Path.Combine(fullAssetPath, include);
                            if (File.Exists(includePath))
                            {
                                var includeSrc = File.ReadAllText(includePath);
                                includeSrc = FluvioComputeShader.RemoveComments(includeSrc);
                                includeSrc = FluvioComputeShader.Minify(includeSrc);

                                var sb = new StringBuilder();

                                ParseIncludesRecursive(includeSrc, includePath, sb);

                                includePaths.Add(include);
                                includeSource.Add(sb.ToString());
                            }
                        }
                        line = stringReader.ReadLine();
                    }
                }

                cs.SetOpenCLIncludes(includePaths.ToArray(), includeSource.ToArray());
            }
        }
        [PostProcessBuild]
        static void OnPostProcessBuild(BuildTarget target, string buildPath)
        {
            var computeShaderObjs = AssetDatabase.FindAssets("t:FluvioComputeShader");

            for (var j = 0; j < computeShaderObjs.Length; ++j)
            {
                var localPath = AssetDatabase.GUIDToAssetPath(computeShaderObjs[j]);
                AssetDatabase.ImportAsset(localPath);
            }
        }
    }
}
