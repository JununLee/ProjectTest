#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using System.Collections.Generic;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Internal;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof(FluidEffectLayer))]
    public class FluidEffectLayerInspector : FluvioInspectorBase
    {
        public override void OnInspectorGUI()
        {
            var content = new GUIContent("This component controls the rendering order of fluid effects, in relation to other opaque image effects.");
            #if !UNITY_5_0_PLUS
                var helpBox = typeof(EditorStyles).GetPropertyValue<GUIStyle>("helpBox");
            #else
                var helpBox = EditorStyles.helpBox;
            #endif

            EditorGUILayout.Separator();

            GUILayout.Label(content, helpBox);

            EditorGUILayout.Separator();

            EditorGUI.BeginDisabledGroup(true);
            var layer = (FluidEffectLayer)target;
            var effects = layer.GetFluidEffects();
            Array.Sort(effects, (a, b) => a.CompareTo(b));

            for (var i = 0; i < effects.Length; ++i)
            {
                var effect = effects[i];

                if (effect && effect._fluid)
                {
                    EditorGUILayout.ObjectField("Fluid " + i, effect._fluid, effect._fluid.GetType(), true);
                    var additionalRenderers = effect.additionalRenderers;

                    if (additionalRenderers != null && additionalRenderers.Length > 0)
                    {
                        EditorGUILayout.Separator();
                        EditorGUILayout.LabelField("Additional Renderers:", "");
                        EditorGUI.indentLevel++;
                        for (var j = 0; j < additionalRenderers.Length; ++j)
                        {
                            EditorGUILayout.ObjectField("Renderer " + j, additionalRenderers[j], typeof(Renderer), true);
                        }
                        EditorGUI.indentLevel--;
                    }
                }
            }

            EditorGUI.EndDisabledGroup();
        }
    }
}
