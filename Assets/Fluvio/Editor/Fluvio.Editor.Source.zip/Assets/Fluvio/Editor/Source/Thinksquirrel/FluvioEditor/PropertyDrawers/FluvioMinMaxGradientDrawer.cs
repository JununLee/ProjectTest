using System.Reflection;
using Thinksquirrel.Fluvio;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.PropertyDrawers
{
    [CustomPropertyDrawer(typeof (FluvioMinMaxGradient))]
    public class FluvioMinMaxGradientDrawer : FluvioPropertyDrawerBase
    {
        public override void OnGUI(Rect pos, SerializedProperty minMaxGradient, GUIContent label)
        {
            try
            {
                var state = (FluvioMinMaxGradientState)minMaxGradient.FindPropertyRelative("m_MinMaxState").enumValueIndex;
                var displayTwo = (int) state > 1;
                var shortHeight = pos.height <= 13f;

                var rect1 = pos;

                if (displayTwo && shortHeight)
                {
                    pos.height += GUILayoutUtility.GetRect(0.0f, pos.height).height;
                }

                var popupRect = GetPopupRect(rect1);
                var rect2 = PrefixLabel(SubtractPopupWidth(rect1), label);
                rect2.height = pos.height;
                switch (state)
                {
                    case FluvioMinMaxGradientState.Color:
                        ReflectionHelpers.GetEditorType("ModuleUI").Invoke("GUIColor", rect2.Param(), minMaxGradient.FindPropertyRelative("m_MaxColor").Param());
                        break;
                    case FluvioMinMaxGradientState.Gradient:
                        typeof(EditorGUI).Invoke("GradientField", rect2.Param(), minMaxGradient.FindPropertyRelative("m_MaxGradient").Param());
                        break;
                    case FluvioMinMaxGradientState.RandomBetweenTwoColors:
                        if (!shortHeight)  rect2.width *= 0.5f;
                        ReflectionHelpers.GetEditorType("ModuleUI").Invoke("GUIColor", rect2.Param(), minMaxGradient.FindPropertyRelative("m_MaxColor").Param());

                        if (shortHeight)
                            rect2.y += rect2.height;
                        else
                            rect2.x += rect2.width;

                        ReflectionHelpers.GetEditorType("ModuleUI").Invoke("GUIColor", rect2.Param(), minMaxGradient.FindPropertyRelative("m_MinColor").Param());
                        break;
                    case FluvioMinMaxGradientState.RandomBetweenTwoGradients:
                        if (!shortHeight) rect2.width *= 0.5f;
                        typeof(EditorGUI).Invoke("GradientField", rect2.Param(), minMaxGradient.FindPropertyRelative("m_MaxGradient").Param());
                        
                        if (shortHeight)
                            rect2.y += rect2.height;
                        else
                            rect2.x += rect2.width;
                        
                        typeof(EditorGUI).Invoke("GradientField", rect2.Param(), minMaxGradient.FindPropertyRelative("m_MinGradient").Param());
                        break;
                }

                if (displayTwo && shortHeight)
                    GUILayout.Space(pos.height*8f);

                GUIMMGradientPopUp(popupRect, minMaxGradient);
            }
            catch (TargetInvocationException e)
            {
                if (e.InnerException is ExitGUIException)
                    GUIUtility.ExitGUI();
            }
        }

        static void GUIMMGradientPopUp(Rect rect, SerializedProperty gradientProp)
        {
            if (!(bool)typeof(EditorGUI).Invoke("ButtonMouseDown", rect.Param(), GUIContent.none.Param(), FocusType.Passive.Param(), rect.height <= 13 ? ((GUIStyle)"ShurikenDropdown").Param() : EditorStyles.foldout.Param()))
                return;

            var popupContent = new[]
            {
                new GUIContent("Color"),
                new GUIContent("Gradient"),
                new GUIContent("Random Between Two Colors"),
                new GUIContent("Random Between Two Gradients")
            };

            var minMaxStates = new[]
            {
                0,
                1,
                2,
                3
            };

            var genericMenu = new GenericMenu();

            for (var i = 0; i < popupContent.Length; ++i)
            {
                genericMenu.AddItem(popupContent[i], gradientProp.FindPropertyRelative("m_MinMaxState").enumValueIndex == minMaxStates[i], SelectMinMaxGradientStateCallback, new GradientCallbackData(minMaxStates[i], gradientProp));
            }
            genericMenu.ShowAsContext();
            Event.current.Use();
        }

        static void SelectMinMaxGradientStateCallback(object userData)
        {
            var data = (GradientCallbackData) userData;

            data.gradientProp.FindPropertyRelative("m_MinMaxState").enumValueIndex = data.enumValueIndex;
            data.gradientProp.serializedObject.ApplyModifiedProperties();
        }

        struct GradientCallbackData
        {
            public int enumValueIndex;
            public SerializedProperty gradientProp;

            public GradientCallbackData(int enumValueIndex, SerializedProperty gradientProp)
            {
                this.enumValueIndex = enumValueIndex;
                this.gradientProp = gradientProp;
            }
        }
    }
}
