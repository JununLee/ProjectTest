#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
using System;
using Thinksquirrel.Fluvio;
using UnityEditor;
using UnityEngine;
using Thinksquirrel.FluvioEditor;
using Object = UnityEngine.Object;

#if UNITY_5_0_PLUS
namespace Thinksquirrel.FluvioEditor.Inspectors
{
#endif
    internal class FluidEffectShaderInspector
#if UNITY_5_0_PLUS
        : ShaderGUI
#else
        : MaterialEditor
#endif
    {
        public enum BlendMode
        {
            Opaque,
            Cutout,
            Transparent
        }

        class Styles
        {
            public GUIStyle optionsButton = "PaneOptions";
            public GUIContent uvSetLabel = new GUIContent("UV Set");
            
            public string emptyTootip = "";
            public string diffuseTooltip = "Diffuse (RGB) and Transparency (A)";
            public string specularMapTooltip = "Specular (RGB) and Smoothness (A)";
            public string metallicMapTooltip = "Metallic (R) and Smoothness (A)";
            public string normalMapTooltip = "Normal Map (RGB)";
            public string emissionTooltip = "Emission (RGB)";
            
            public string whiteSpaceString = " ";
        }
        static Styles s_Styles;

        MaterialProperty albedoMap;
        MaterialProperty albedoColor;
        MaterialProperty specularColorOrMetallic;
        MaterialProperty smoothness;
        MaterialProperty bumpMap;

#if UNITY_5_0_PLUS
        MaterialProperty specularOrMetallicMap;
        bool isSpecular;
        MaterialProperty bumpScale;
        MaterialProperty emissionScale;
        MaterialProperty emissionColor;
        MaterialProperty emissionMap;
        MaterialProperty vertexColorMode;
#endif
        MaterialProperty downsampleFactor;
        MaterialProperty blur;
        MaterialProperty blurBackground;
        MaterialProperty alphaCutoff;
        MaterialProperty alphaCutoff2;
        MaterialProperty specularScale;
        MaterialProperty tint;

        Object[] m_Materials = new Object[1];
#if UNITY_5_0_PLUS
        MaterialEditor m_MaterialEditor;
#else
        FluidEffectShaderInspector m_MaterialEditor;
#endif
        bool m_MaterialChanged;
        bool m_FirstTimeApply = true;
        const int k_SecondLevelIndentOffset = 2;
        
        float verticalSpacing
        {
            get { return 2; }
        }
        
        // Cache often used strings to prevent string allocs
        public void FindProperties(Material mat)
        {
            m_Materials[0] = mat;
            albedoMap = MaterialEditor.GetMaterialProperty(m_Materials, "_MainTex");
            albedoColor = MaterialEditor.GetMaterialProperty(m_Materials, "_Color");            
            smoothness = MaterialEditor.GetMaterialProperty(m_Materials, "_Glossiness");
            bumpMap = MaterialEditor.GetMaterialProperty(m_Materials, "_BumpMap");

#if UNITY_5_0_PLUS
            isSpecular = mat.shader.name.Contains("Specular");
            specularOrMetallicMap = isSpecular ? MaterialEditor.GetMaterialProperty(m_Materials, "_SpecGlossMap") : MaterialEditor.GetMaterialProperty(m_Materials, "_MetallicGlossMap");
            specularColorOrMetallic = isSpecular ? MaterialEditor.GetMaterialProperty(m_Materials, "_SpecColor") : MaterialEditor.GetMaterialProperty(m_Materials, "_Metallic");
            bumpScale = MaterialEditor.GetMaterialProperty(m_Materials, "_BumpScale");
            emissionScale = MaterialEditor.GetMaterialProperty(m_Materials, "_EmissionScaleUI");
            emissionColor = MaterialEditor.GetMaterialProperty(m_Materials, "_EmissionColorUI");
            emissionMap = MaterialEditor.GetMaterialProperty(m_Materials, "_EmissionMap");
            vertexColorMode = MaterialEditor.GetMaterialProperty(m_Materials, "_VertexColorMode");
#else
            specularColorOrMetallic = MaterialEditor.GetMaterialProperty(m_Materials, "_SpecColor");
#endif
            downsampleFactor = MaterialEditor.GetMaterialProperty(m_Materials, "_DownsampleFactorUI");
            blur = MaterialEditor.GetMaterialProperty(m_Materials, "_FluidBlurUI");
            blurBackground = MaterialEditor.GetMaterialProperty(m_Materials, "_FluidBlurBackgroundUI");
            alphaCutoff = MaterialEditor.GetMaterialProperty(m_Materials, "_Cutoff");
            alphaCutoff2 = MaterialEditor.GetMaterialProperty(m_Materials, "_Cutoff2");
            specularScale = MaterialEditor.GetMaterialProperty(m_Materials, "_FluidSpecularScaleUI");
            tint = MaterialEditor.GetMaterialProperty(m_Materials, "_FluidTintUI");
        }

#if UNITY_5_0_PLUS
        public override void OnGUI(MaterialEditor materialEditor, MaterialProperty[] properties)
#else
        public override void OnInspectorGUI()
#endif
        {
#if UNITY_5_0_PLUS
            m_MaterialEditor = materialEditor;
            var material = (Material) materialEditor.target;
#else
            if (!isVisible) return;

            var material = (Material)target;
            m_MaterialEditor = this;
#endif

            if (material.name.Contains("(Fluid Effect Copy)"))
            {
                var icon = EditorGUIUtility.IconContent("console.infoicon.sml", "This material has been duplicated by the Fluid Effect and cannot be edited.");
                icon.text = "This material has been duplicated by the Fluid Effect and cannot be edited.";
#if !UNITY_5_0_PLUS
                var helpBox = typeof(EditorStyles).GetPropertyValue<GUIStyle>("helpBox");
#else
                var helpBox = EditorStyles.helpBox;
#endif
                GUILayout.Label(icon, helpBox);
                EditorGUILayout.Separator();
            }

            FindProperties(material); // MaterialProperties can be animated so we do not cache them but fetch them every event to ensure animated values are updated correctly
            
            if (s_Styles == null)
                s_Styles = new Styles();

            // Use default labelWidth
            EditorGUIUtility.labelWidth = 0f;

            m_MaterialChanged = false;

            // Shader properties
            ShaderPropertiesGUI(material);

            // Save changes (if any)
            if (m_MaterialChanged)
                MaterialChanged(material);

            // Make sure that needed keywords are set up if we're switching some existing
            // material to a standard shader.
            if (m_FirstTimeApply)
            {
                FluidEffect.SetMaterialKeywords(material);
                m_FirstTimeApply = false;
            }
        }

        public void ShaderPropertiesGUI(Material material)
        {
            var r = EditorGUILayout.GetControlRect(true, 1);
            var startY = r.y;
            r.y += 5f;

            const float extraSpacing = 4f;
            EditorGUI.BeginChangeCheck();

            r.y += HeaderSection(r, "Primary Maps") + extraSpacing;
            r.y += DoAlbedoArea(r, albedoMap, albedoColor, material) + extraSpacing;
#if UNITY_5_0_PLUS
            r.y += DoSpecularOrMetallicArea(r, specularOrMetallicMap, specularColorOrMetallic, smoothness) + extraSpacing;               
            r.y += DoTextureAndFloatProperty(r, bumpMap, bumpScale, s_Styles.normalMapTooltip) + extraSpacing;
#else
            r.y += DoSpecularOrMetallicArea(r, null, specularColorOrMetallic, smoothness) + extraSpacing;
            r.y += TextureProperty(bumpMap, r, s_Styles.normalMapTooltip) + extraSpacing;
#endif
            m_MaterialChanged |= EditorGUI.EndChangeCheck();

            EditorGUI.BeginChangeCheck();

#if UNITY_5_0_PLUS
            r.y += DoEmissionArea(r, emissionMap, emissionColor, emissionScale) + extraSpacing;
            r.y += SettingsSection(r, albedoMap, vertexColorMode);
#else
            r.y += SettingsSection(r, albedoMap, null);
#endif
            r.y += HeaderSection(r, "Image Effect");
            r.y += ImageEffectSection(r, downsampleFactor, blur, blurBackground, alphaCutoff, alphaCutoff2, specularScale, tint);
            r.y += 12f;
            
            m_MaterialChanged |= EditorGUI.EndChangeCheck();

            // Reserve the area we used above (in the layout system)
            EditorGUILayout.GetControlRect(true, r.y - startY, EditorStyles.layerMaskField);
        }

        // Returns height used
        float HeaderSection(Rect r, string header)
        {
            var startY = r.y;
            r.height = EditorGUIUtility.singleLineHeight;
            GUI.Label(r, header, EditorStyles.boldLabel);
            r.y += r.height + 3f;
            return r.y - startY;
        }

        // Returns height used
        float SettingsSection(Rect r, MaterialProperty textureProperty, MaterialProperty vertexColorModeProperty)
        {
            var startY = r.y;
#if UNITY_5_0_PLUS
            r.height = EditorGUIUtility.singleLineHeight;
            m_MaterialEditor.ShaderProperty(r, vertexColorModeProperty, "Vertex Color Mode");
            r.y += r.height * 2 + 2;
#endif
            r.y += TextureScaleOffsetProperty(r, textureProperty);
            return r.y - startY;
        }

        float ImageEffectSection(Rect r, MaterialProperty downsampleFactorProperty, MaterialProperty blurProperty, MaterialProperty blurBackgroundProperty, MaterialProperty alphaCutoffProperty, MaterialProperty alphaCutoff2Property, MaterialProperty specularScaleProperty, MaterialProperty tintProperty)
        {
            var startY = r.y;
            r.height = EditorGUIUtility.singleLineHeight;
            m_MaterialEditor.ShaderProperty(r, downsampleFactorProperty, "Downsample Factor");
            r.y += r.height;
            m_MaterialEditor.ShaderProperty(r, blurProperty, "Blur Fluid");
            r.y += r.height;
            m_MaterialEditor.ShaderProperty(r, blurBackgroundProperty, "Blur Background");
            r.y += r.height;
            r.y += RangeFloatProperty(r, alphaCutoffProperty, "Alpha Cutoff");
            r.y += RangeFloatProperty(r, alphaCutoff2Property, "Shadow/Depth Alpha Cutoff");
            r.y += RangeFloatProperty(r, specularScaleProperty, "Fake Specular Effect");
            m_MaterialEditor.ShaderProperty(r, tintProperty, "Composite Tint");
            return r.y - startY;
        }

        float RangeFloatProperty(Rect r, MaterialProperty property, string label)
        {
#if !UNITY_5_0_PLUS
            r.width -= 56;
            m_MaterialEditor.ShaderProperty(r, property, label);
            r.x += r.width + 4;
            r.width = 52;
            m_MaterialEditor.FloatProperty(r, property, "");
#else
            m_MaterialEditor.ShaderProperty(r, property, label);
#endif
            return r.height;
        }
        // Returns height used
        float TextureProperty(MaterialProperty textureProp, Rect r, string tooltip, string name = "")
        {
            r.height = EditorGUIUtility.singleLineHeight;
            TexturePropertyMiniThumbnail(r, textureProp, textureProp == null ? name : textureProp.displayName, tooltip);
            return 27;
        }

        Texture TexturePropertyMiniThumbnail(Rect position, MaterialProperty prop, string label, string tooltip)
        {
#if UNITY_5_0_PLUS
            return m_MaterialEditor.TexturePropertyMiniThumbnail(position, prop, label, tooltip);
#else
            Rect thumbRect;
            Rect labelRect;
            GetRectsForMiniThumbnailField(position, out thumbRect, out labelRect);
            EditorGUI.HandlePrefixLabel(position, labelRect, new GUIContent(label, tooltip), 0, EditorStyles.label);
            Texture texture = prop == null ? null : TexturePropertyBody(thumbRect, prop);
            Rect rect = position;
            rect.y += position.height;
            rect.height = 27f;
            return texture;
#endif
        }

        float TextureScaleOffsetProperty(Rect position, MaterialProperty textureProperty)
        {
#if UNITY_5_0_PLUS
            return m_MaterialEditor.TextureScaleOffsetProperty(position, textureProperty);
#else
            EditorGUI.BeginChangeCheck();

            var scaleOffset = textureProperty.textureScaleAndOffset;
            Vector2 vector2_1 = new Vector2(scaleOffset.x, scaleOffset.y);
            Vector2 vector2_2 = new Vector2(scaleOffset.z, scaleOffset.w);
            float width = EditorGUIUtility.labelWidth;
            float left1 = position.x + width;
            float left2 = position.x + EditorGUI.indentLevel * 15f;
            Rect totalPosition = new Rect(left2, position.y, width, 16f);
            Rect position1 = new Rect(left1, position.y, position.width - width, 16f);
            EditorGUI.PrefixLabel(totalPosition, new GUIContent("Tiling"));
            Vector2 vector2_3 = EditorGUI.Vector2Field(position1, GUIContent.none, vector2_1);
            totalPosition.y += 16f;
            position1.y += 16f;
            EditorGUI.PrefixLabel(totalPosition, new GUIContent("Offset"));
            Vector2 vector2_4 = EditorGUI.Vector2Field(position1, GUIContent.none, vector2_2);
            var result = new Vector4(vector2_3.x, vector2_3.y, vector2_4.x, vector2_4.y);

            if (EditorGUI.EndChangeCheck())
                textureProperty.textureScaleAndOffset = result;

            return 32f;
#endif
        }

#if !UNITY_5_0_PLUS
        void GetRectsForMiniThumbnailField(Rect position, out Rect thumbRect, out Rect labelRect)
        {
            thumbRect = EditorGUI.IndentedRect(position);
            --thumbRect.y;
            thumbRect.height = 32f;
            thumbRect.width = 32f;
            float left = thumbRect.x + 34f;
            labelRect = new Rect(left, position.y, thumbRect.x + EditorGUIUtility.labelWidth - left, position.height);
        }

        Texture TexturePropertyBody(Rect position, MaterialProperty prop)
        {
            if (prop.type != MaterialProperty.PropType.Texture)
                throw new ArgumentException(string.Format("The MaterialProperty '{0}' should be of type 'Texture' (its type is '{1})'", (object)prop.name, (object)prop.type));
            Type objType;
            switch (prop.textureDimension)
            {
                case MaterialProperty.TexDim.Tex2D:
                    objType = typeof(Texture);
                    break;
                case MaterialProperty.TexDim.Tex3D:
                    objType = typeof(Texture3D);
                    break;
                case MaterialProperty.TexDim.Cube:
                    objType = typeof(Cubemap);
                    break;
                case MaterialProperty.TexDim.Any:
                    objType = typeof(Texture);
                    break;
                default:
                    objType = (System.Type)null;
                    break;
            }
            bool enabled = GUI.enabled;
            EditorGUI.BeginChangeCheck();
            if ((prop.flags & MaterialProperty.PropFlags.PerRendererData) != MaterialProperty.PropFlags.None)
                GUI.enabled = false;
            EditorGUI.showMixedValue = prop.hasMixedValue;                        
            Texture texture = EditorGUI.ObjectField(position, prop.textureValue, objType, false) as Texture;
            EditorGUI.showMixedValue = false;
            if (EditorGUI.EndChangeCheck())
                prop.textureValue = texture;
            GUI.enabled = enabled;
            return prop.textureValue;
        }        
#endif
        // Returns rect after EditorGUIUtility.labelWidth
        Rect GetRectAfterLabelWidth(Rect r)
        {
            return new Rect(r.x + EditorGUIUtility.labelWidth, r.y, r.width - EditorGUIUtility.labelWidth, EditorGUIUtility.singleLineHeight);
        }

        // Returns fixed rect based on EditorGUIUtility.fieldWidth
        Rect GetColorPropertyCustomRect(Rect r)
        {
            return new Rect(r.xMax - EditorGUIUtility.fieldWidth, r.y, EditorGUIUtility.fieldWidth, EditorGUIUtility.singleLineHeight);
        }

        // Returns height used + spacing
        float DoAlbedoArea(Rect r, MaterialProperty textureProp, MaterialProperty colorProp, Material material)
        {
            float startY = r.y;

            Rect colorRect = GetColorPropertyCustomRect(r);
            Rect textureRect = new Rect(r.x, r.y, r.width - colorRect.width, r.height);

            // Texture
            r.height = TextureProperty(textureProp, textureRect, s_Styles.diffuseTooltip);

            // Color
            m_MaterialEditor.ShaderProperty(colorRect, colorProp, string.Empty);

            return r.yMax - startY + verticalSpacing;
        }

        // Returns height used + spacing
        float DoSpecularOrMetallicArea(Rect r, MaterialProperty textureProp, MaterialProperty colorProp, MaterialProperty glossiness)
        {
            float startY = r.y;

            //string tooltip = textureProp.textureValue == null ? string.Empty : ;
#if !UNITY_5_0_PLUS
            r.height = TextureProperty(textureProp, r, s_Styles.specularMapTooltip);            
#else
            r.height = TextureProperty(textureProp, r, isSpecular ? s_Styles.specularMapTooltip : s_Styles.metallicMapTooltip);
#endif
            // If no texture then show color and glossiness slider
            if (textureProp == null || textureProp.textureValue == null)
            {
                // Color or range
                m_MaterialEditor.ShaderProperty(GetColorPropertyCustomRect(r), colorProp, string.Empty);

                r.y += r.height;// + 2;
                r.height -= 8;

                // Glossiness
                EditorGUI.indentLevel += k_SecondLevelIndentOffset;
#if !UNITY_5_0_PLUS
                r.x += 4;
                r.width -= 4;
#endif
                m_MaterialEditor.ShaderProperty(r, glossiness, glossiness.displayName);
                EditorGUI.indentLevel -= k_SecondLevelIndentOffset;
            }

            return r.yMax - startY + verticalSpacing;
        }
        
        // Returns height used + spacing
        float DoEmissionArea(Rect r, MaterialProperty textureProp, MaterialProperty colorProp,  MaterialProperty scaleProp)
        {
            float startY = r.y;
            Rect colorRect = GetColorPropertyCustomRect(r);
            r.width -= colorRect.width + 4;
            Rect textureRect = new Rect(r.x, r.y, r.width, r.height);

            // Texture
            r.height = TextureProperty(textureProp, textureRect, s_Styles.emissionTooltip);

            // Scalar
            DoInlineFloatProperty(r, scaleProp);

            // Color
            m_MaterialEditor.ShaderProperty(colorRect, colorProp, string.Empty);

            return r.yMax - startY + verticalSpacing;
        }

        // Returns height used + spacing
        float DoTextureAndFloatProperty(Rect r, MaterialProperty textureProp, MaterialProperty floatProp, string tooltip)
        {
            float startY = r.y;
            r.height = TextureProperty(textureProp, r, tooltip);
            if (textureProp.textureValue != null)
                DoInlineFloatProperty(r, floatProp);

            return r.yMax - startY + verticalSpacing;
        }

        void DoInlineFloatProperty(Rect r, MaterialProperty floatProp)
        {
            if (floatProp == null)
                return;

            Rect floatPropRect = GetRectAfterLabelWidth(r);
            float oldLabelWidth = EditorGUIUtility.labelWidth;
            string labelString = string.Empty;
            if (floatProp.type == MaterialProperty.PropType.Float)
            {
                // To be able to have a draggable area in front of the float field we need to ensure
                // the property has a label (here we use a whitespace) and adjust label width.
                // Float value dragging is implemented over the label area
                labelString = s_Styles.whiteSpaceString;
                EditorGUIUtility.labelWidth = floatPropRect.width - EditorGUIUtility.fieldWidth;
            }
            m_MaterialEditor.ShaderProperty(floatPropRect, floatProp, labelString);

            EditorGUIUtility.labelWidth = oldLabelWidth;
        }
        void MaterialChanged(Material material)
        {
#if UNITY_5_0_PLUS
            FluidEffect.SetMaterialKeywords(material);
#endif
            EditorUtility.SetDirty(material);
        }        
        /*
        static MaterialProperty GetMaterialProperty(string propertyName, MaterialProperty[] properties)
        {
            for (var i = 0; i < properties.Length; i++)
            {
                if (properties[i] != null && properties[i].name == propertyName)
                {
                    var prop = properties[i];
                    properties[i] = null;
                    return prop;
                }
            }
            // Outcommented while developing StandardShader
            FluvioDebug.LogError("Could not find MaterialProperty: '" + propertyName);
            return null;
        }
         */
    }
#if UNITY_5_0_PLUS
}
#endif