#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
#if UNITY_5_0_PLUS && !UNITY_5_0 && !UNITY_5_1 && !UNITY_5_2
#define UNITY_5_3_PLUS
#endif
using System;
using System.Collections.Generic;
using System.Linq;
using Thinksquirrel.Fluvio;
using Thinksquirrel.FluvioEditor.Inspectors;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Thinksquirrel.FluvioEditor
{
    [InitializeOnLoad]
    static class FluvioEditorUpdateManager
    {
        static readonly Type s_ParticleSystemEditorUtils;
        static bool s_WasPlaying;
        static bool s_FirstFrame = true;
        static float s_PeriodicUpdateTime;
        static float s_PeriodicUpdateInterval = 2.0f;
        static readonly List<Camera> s_SceneViewCameras = new List<Camera>();
        
        static FluvioEditorUpdateManager()
        {
            s_ParticleSystemEditorUtils = ReflectionHelpers.GetEditorType("ParticleSystemEditorUtils");
            EditorApplication.update += Update;
            EditorApplication.update += PeriodicUpdate;
        }

        static void GetSceneViews()
        {
            s_SceneViewCameras.Clear();
            
            foreach (var sceneViewObj in SceneView.sceneViews)
            {
                var sceneView = (SceneView) sceneViewObj;

                var useSceneFiltering = sceneView.Invoke<bool>("UseSceneFiltering");

                if (useSceneFiltering) continue;

                if (!sceneView.camera) continue;

                s_SceneViewCameras.Add(sceneView.camera);
            }
        }
       
        static void PeriodicUpdate()
        {
            // Detect scene change or other time resets
            if (s_PeriodicUpdateTime > Time.realtimeSinceStartup)
            {
                s_PeriodicUpdateTime = float.MinValue;
            }

            if (Time.realtimeSinceStartup - s_PeriodicUpdateTime < s_PeriodicUpdateInterval)
                return;

            s_PeriodicUpdateTime = Time.realtimeSinceStartup;

            var serializedInstance = Resources.Load("FluvioManager", typeof(FluvioSettings)) as FluvioSettings;
            if (!serializedInstance)
            {
                var instance = FluvioSettings.GetFluvioSettingsObject();
                serializedInstance = FluvioEditorHelpers.CreateProjectSettingsAsset(instance, "Resources", "FluvioManager.asset");
            }
            FluvioSettings.SetFluvioSettingsObject(serializedInstance);            

            FluvioSettings.GetInstance(false, false).SetFieldValue("m_SortingLayerUniqueIDs", typeof(InternalEditorUtility).GetPropertyValue<int[]>("sortingLayerUniqueIDs"));
        }
        static void Update()
        {
            var fluidsEnumerable = FluidBase.GetAllFluids();
            var fluids = fluidsEnumerable as IList<FluidBase> ?? fluidsEnumerable.ToList();
            
            GetSceneViews();
            
            var applicationIsPlaying = Application.isPlaying;
            
            var isPlaying = !applicationIsPlaying && IsPlaying();
            var isPaused = !applicationIsPlaying && IsPaused();
            var isStopped = !applicationIsPlaying && IsStopped();
            
            var selection = Selection.gameObjects;
            var stopAll = selection.Length == 1 && !Selection.activeGameObject.GetComponent<ParticleSystem>();

            foreach (var fluid in fluids)
            {
                // ------------------------------------
                // Fluid effect
                // ------------------------------------
                var fluidEffect = fluid.GetComponent<FluidEffect>();

                if (fluidEffect && fluidEffect.GetFieldValue<bool>("m_ShowInSceneView"))
                {
                    fluidEffect._sceneViewCameras.Clear();
                    fluidEffect._sceneViewCameras.AddRange(s_SceneViewCameras);
                }
                
                // ------------------------------------
                // Particle system
                // ------------------------------------
                var fluidParticleSystem = fluid as FluidParticleSystem;

                if (!fluidParticleSystem) continue;

#if !UNITY_5_3_PLUS
                FluidParticleSystemInspector.TestIsSubEmitter(fluidParticleSystem);
#endif

                if (applicationIsPlaying || !FluvioSettings.IsLiveEditEnabled())
                    continue;

                var playbackSpeed = s_ParticleSystemEditorUtils.GetPropertyValue<float>("editorSimulationSpeed");
                fluidParticleSystem.SetEditorPlaybackSpeed(playbackSpeed);

                var stopSystem = true;

                for (var i = 0; i < selection.Length; ++i)
                {
                    var gameObject = selection[i];

                    var t = gameObject.transform;

                    do
                    {
                        if (t.GetComponent<FluidParticleSystem>() == fluidParticleSystem)
                        {
                            stopSystem = false;
                        }
                        else
                        {
                            var transformChildren = t.GetComponentsInChildren<FluidParticleSystem>();

                            for (var j = 0; j < transformChildren.Length; ++j)
                            {
                                var transformChild = transformChildren[j];

                                if (transformChild == fluidParticleSystem)
                                {
                                    stopSystem = false;
                                    break;
                                }
                            }
                        }

                        if (!stopSystem)
                            break;

                        t = t.parent;
                    } while (t);

                    if (!stopSystem)
                        break;
                }

                var particleSystem = GetRoot(fluidParticleSystem.GetParticleSystem());

                if (s_FirstFrame)
                {  
                    var systems = particleSystem.GetComponentsInChildren<FluidParticleSystem>();

                    foreach (var system in systems)
                    {
                        if (system.fluidType == FluidType.Static)
                            system.GetParticleSystem().time = 0;
                    }
                }

                if (stopSystem || stopAll)
                {
                    particleSystem.Stop();
                    particleSystem.Pause();
                }
                else
                {
                    if (isStopped && s_WasPlaying)
                    {
                        particleSystem.Stop();
                        particleSystem.Clear();
                        s_WasPlaying = false;
                    }
                    else if (isPlaying && !s_WasPlaying)
                    {
                        particleSystem.Play();
                    }
                    else if (isPaused && s_WasPlaying)
                    {
                        particleSystem.Pause();
                        s_WasPlaying = false;
                    }
                }

                fluidParticleSystem.DoUpdate();
                fluidParticleSystem.DoLateUpdate();
            }

            s_WasPlaying = isPlaying;
            s_FirstFrame = false;
        }

        internal static ParticleSystem GetRoot(ParticleSystem system)
        {
            return (ParticleSystem)s_ParticleSystemEditorUtils.Invoke("GetRoot", system.Param());
        }
        internal static bool IsStopped()
        {
            return !s_ParticleSystemEditorUtils.GetPropertyValue<bool>("editorIsPlaying") && !s_ParticleSystemEditorUtils.GetPropertyValue<bool>("editorIsPaused") && !s_ParticleSystemEditorUtils.GetPropertyValue<bool>("editorIsScrubbing");
        }
        internal static bool IsPaused()
        {
            return !IsPlaying() && !IsStopped();
        }
        internal static bool IsPlaying()
        {
            return s_ParticleSystemEditorUtils.GetPropertyValue<bool>("editorIsPlaying");                    
        }
    }
}
