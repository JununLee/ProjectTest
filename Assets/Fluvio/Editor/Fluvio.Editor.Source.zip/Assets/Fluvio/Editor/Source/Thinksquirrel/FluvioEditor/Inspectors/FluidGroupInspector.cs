// FluidColliderBaseInspector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using Thinksquirrel.Fluvio;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof(FluidGroup))]
    public class FluidGroupBaseInspector : FluvioInspectorBase
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            var prop = serializedObject.GetIterator();
            prop.Next(true);

            var enterChildren = true;

            while (prop.NextVisible(enterChildren))
            {
                // Initialize variables
                var label = new GUIContent(ObjectNames.NicifyVariableName(prop.name));
                var hide = false;
                
                // Get tooltip
                switch (prop.name)
                {
                    case "m_Script":                    
                        hide = true;
                        break;
                    default:
                        label.tooltip = label.text;
                        break;
                }
                if (prop.isArray && !hide)
                {
                    hide = true;
                    var size = prop.arraySize;
                    enterChildren = EditorGUILayout.PropertyField(prop, label);
                    if (enterChildren)
                    {
                        EditorGUI.indentLevel++;
                        EditorGUI.BeginChangeCheck();
                        EditorGUILayout.PropertyField(prop.FindPropertyRelative("Array.size"));
                        if (EditorGUI.EndChangeCheck())
                        {
                            for (var i = size; i < prop.arraySize; ++i)
                            {
                                prop.GetArrayElementAtIndex(i).objectReferenceValue = null;
                            }
                        }
                        var subLabel = new GUIContent();
                        for (var i = 0; i < size; ++i)
                        {
                            subLabel.text = "Element " + i;
                            subLabel.tooltip = "Element " + i;
                            EditorGUILayout.PropertyField(prop.GetArrayElementAtIndex(Mathf.Clamp(i, 0, prop.arraySize - 1)), subLabel);
                        }                        
                        EditorGUI.indentLevel--;
                    }
                    enterChildren = false;
                }
                
                // Display
                if (!hide)
                {
                    enterChildren = EditorGUILayout.PropertyField(prop, label);
                }

                serializedObject.ApplyModifiedProperties();

                if (Event.current.type != EventType.Layout &&
                    Event.current.type != EventType.Repaint &&
                    Event.current.type != EventType.Used)
                {
                    var group = target as FluidGroup;

                    if (group)
                    {
                        group.ReloadFluidGroup();
                        EditorUtility.SetDirty(group);
                    }
                }
            }
        }
    }
}
