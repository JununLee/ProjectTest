using System;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.PropertyDrawers
{
    public class FluvioPropertyDrawerBase : PropertyDrawer
    {
        protected static Rect SubtractPopupWidth(Rect position)
        {
            position.width -= 14f;
            return position;
        }

        protected static Rect GetPopupRect(Rect position)
        {
            position.xMin = position.xMax - 13f;
            return position;
        }

        protected static Rect PrefixLabel(Rect totalPosition, GUIContent label)
        {
            var indent = typeof(EditorGUI).GetPropertyValue<float>("indent");
            var labelPosition = new Rect(totalPosition.x + indent, totalPosition.y, EditorGUIUtility.labelWidth - indent, totalPosition.height);
            var rect = new Rect(totalPosition.x + EditorGUIUtility.labelWidth, totalPosition.y, totalPosition.width - EditorGUIUtility.labelWidth, totalPosition.height);
            EditorGUI.HandlePrefixLabel(totalPosition, labelPosition, label, 0, EditorStyles.label);
            return rect;
        }

        protected static float FloatDraggable(Rect rect, SerializedProperty floatProp, float remap, float dragWidth)
        {
            return FloatDraggable(rect, floatProp, remap, dragWidth, "g7");
        }

        protected static float FloatDraggable(Rect rect, float floatValue, float remap, float dragWidth, string formatString)
        {
            var controlId = GUIUtility.GetControlID(1658656233, FocusType.Keyboard, rect);
            var dragHotZone = rect;
            dragHotZone.width = dragWidth;
            var position = rect;
            position.xMin += dragWidth;
            return (float)typeof(EditorGUI).Invoke("DoFloatField", typeof(EditorGUI).GetFieldValue("s_RecycledEditor").Param(), position.Param(), dragHotZone.Param(), controlId.Param(), (floatValue * remap).Param(), formatString.Param(), EditorStyles.numberField.Param(), true.Param()) / remap;
        }

        protected static float FloatDraggable(Rect rect, SerializedProperty floatProp, float remap, float dragWidth, string formatString)
        {
            var floatValue = floatProp.floatValue;
            var num = FloatDraggable(rect, floatValue, remap, dragWidth, formatString);
            if (Math.Abs(num - floatValue) > float.Epsilon)
                floatProp.floatValue = num;
            return num;
        }
    }
}
