// FluvioMenuItems.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
#if UNITY_5_0_PLUS && !UNITY_5_0 && !UNITY_5_1 && !UNITY_5_2
#define UNITY_5_3_PLUS
#endif
using System;
using System.IO;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Plugins;
using Thinksquirrel.FluvioEditor.EditorWindows;
using UnityEditor;
using UnityEngine;
#if UNITY_5_0_PLUS
using UnityEngine.Rendering;
#endif
using Object = UnityEngine.Object;

namespace Thinksquirrel.FluvioEditor
{
    public static class FluvioMenuItems
    {
        // This variable controls the location of Fluvio menu commands.
        // Do not include the "Fluvio" folder in the name.
        // No trailing slashes allowed!

        #region Static and Constant Fields
        public const string menuLocation = "GameObject";

        // This variable controls an alternate location of Fluvio menu commands.
        // Do not include the "Fluvio" folder in the name.
        // No trailing slashes allowed!
        public const string menuLocationAlt = "Tools/Thinksquirrel";

        // This variable controls the location of Fluvio menu windows.
        // Do not include the "Fluvio" folder in the name.
        // No trailing slashes allowed!
        public const string menuWindowLocation = "Window";

        // This variable controls an alternate location of Fluvio window commands.
        // Do not include the "Fluvio" folder in the name.
        // No trailing slashes allowed!
        public const string menuWindowLocationAlt = "Tools/Thinksquirrel";
        static Material s_FluidEffectMaterial;
        #endregion

        [MenuItem(menuWindowLocation + "/Fluvio/Reference Manual", false, 1201)]
        [MenuItem(menuWindowLocationAlt + "/Fluvio/Reference Manual", false, 1201)]
        internal static void HelpWindow()
        {
            Application.OpenURL(FluvioPreferences.ReferenceManualUrl());
        }
        [MenuItem(menuWindowLocation + "/Fluvio/Register Fluvio", false, 2000)]
        [MenuItem(menuWindowLocationAlt + "/Fluvio/Register Fluvio", false, 2000)]
        internal static void RegisterFluvio()
        {
            Application.OpenURL("https://thinksquirrel.com/product-registration");
        }
        [MenuItem(menuWindowLocation + "/Fluvio/Support Forum", false, 1202)]
        [MenuItem(menuWindowLocationAlt + "/Fluvio/Support Forum", false, 1202)]
        internal static void SupportForumWindow()
        {
            Application.OpenURL(FluvioEditorHelpers.SupportForumUrl());
        }
        [MenuItem(menuWindowLocation + "/Fluvio/Welcome", false, 1200)]
        [MenuItem(menuLocationAlt + "/Fluvio/Welcome", false, 1200)]
        internal static void WelcomeWindow()
        {
            EditorWindow.GetWindow<FluvioWelcomeWindow>(true, "Welcome to Fluvio");
        }
        [MenuItem(menuLocation + "/Fluid Particle System (Liquid)", false, 9)]
        [MenuItem(menuLocationAlt + "/Fluvio/Create Fluid Particle System (Liquid)", false)]
        [UsedImplicitly]
        static void CreateDefaultFluidLiquid()
        {
            var newFluid = new GameObject("Fluid Particle System");
            var is2D = EditorSettings.defaultBehaviorMode == EditorBehaviorMode.Mode2D;
            if (SceneView.lastActiveSceneView)
            {
                newFluid.transform.position = SceneView.lastActiveSceneView.pivot;
                is2D = SceneView.lastActiveSceneView.in2DMode;
            }
            newFluid.transform.rotation = Quaternion.Euler(-90, 0, 0);
            var fluid = newFluid.AddComponent<FluidParticleSystem>();
            if (is2D) fluid.dimensions = SimulationDimensions.Fluid2D;
            EditorUtility.SetDirty(fluid);

            var particleSystem = fluid.GetParticleSystem();
            particleSystem.startSize = fluid.smoothingDistance;

            var rend = particleSystem.GetComponent<ParticleSystemRenderer>();
            rend.sharedMaterial = fluidEffectMaterial;
            rend.receiveShadows = false; // TODO
            rend.useLightProbes = false;
#if UNITY_5_0_PlUS
            rend.reflectionProbeUsage = ReflectionProbeUsage.Off;
#endif

            var serializedObject = new SerializedObject(particleSystem);
            
#if UNITY_5_3_PLUS
            // Use surface lighting model
            var fluidEffect = newFluid.AddComponent<FluidEffect>();
            if (!is2D)
            {
                particleSystem.startSize *= 1.5f;
                serializedObject.Update();
                serializedObject.FindProperty("InitialModule.rotation3D").boolValue = true;
                fluidEffect.SetFieldValue("m_OverrideNormals", false);

                rend.renderMode = ParticleSystemRenderMode.Mesh;
                var tempGo = GameObject.CreatePrimitive(PrimitiveType.Quad);
                var quad = tempGo.GetComponent<MeshFilter>().sharedMesh;
                rend.mesh = quad;
                Object.DestroyImmediate(tempGo);
            }
#else
            newFluid.AddComponent<FluidEffect>();
#endif

            // Change gravity modifier
            serializedObject.FindProperty("InitialModule.gravityModifier").floatValue = 1.0f;

            // Change emission
            serializedObject.FindProperty("EmissionModule.rate.scalar").floatValue = 100f;

            // Change collision module
#if UNITY_5_3_PLUS
            serializedObject.FindProperty("CollisionModule.m_Dampen.scalar").floatValue = 0.0f;
            serializedObject.FindProperty("CollisionModule.m_Bounce.scalar").floatValue = 1.0f;
#else
            serializedObject.FindProperty("CollisionModule.dampen").floatValue = 0.0f;
            serializedObject.FindProperty("CollisionModule.bounce").floatValue = 1.0f;
#endif
            serializedObject.FindProperty("CollisionModule.minKillSpeed").floatValue = FluvioSettings.kEpsilon;

            // Change cone size
            serializedObject.FindProperty("ShapeModule.radius").floatValue = 0.1f;

            // Size by density
            var sizeCurve = AnimationCurve.EaseInOut(0.0f, 1.0f, 1.0f, 0.25f);
            var sizeByDensity = newFluid.AddComponent<SizeByDensity>();
            sizeByDensity.size.scalar = fluid.smoothingDistance * 2.5f;
            sizeByDensity.size.maxCurve = sizeCurve;
            sizeByDensity.size.minMaxState = FluvioMinMaxCurveState.Curve;
            var range = sizeByDensity.range;
            range.y *= 4.0f;
            sizeByDensity.range = range;

            serializedObject.ApplyModifiedProperties();

            Selection.activeGameObject = newFluid;
        }
        [MenuItem(menuLocation + "/Fluid Particle System (Gas)", false, 10)]
        [MenuItem(menuLocationAlt + "/Fluvio/Create Fluid Particle System (Gas)", false)]
        [UsedImplicitly]
        static void CreateDefaultFluidGas()
        {
            var newFluid = new GameObject("Fluid Particle System");
            var is2D = EditorSettings.defaultBehaviorMode == EditorBehaviorMode.Mode2D;
            if (SceneView.lastActiveSceneView)
            {
                newFluid.transform.position = SceneView.lastActiveSceneView.pivot;
                is2D = SceneView.lastActiveSceneView.in2DMode;
            }
            newFluid.transform.rotation = Quaternion.Euler(-90, 0, 0);
            var fluid = newFluid.AddComponent<FluidParticleSystem>();
            if (is2D) fluid.dimensions = SimulationDimensions.Fluid2D;
            fluid.viscosity = 9.0f;
            fluid.buoyancyCoefficient = 0.001f;
            fluid.gasConstant = 0.1f;
            EditorUtility.SetDirty(fluid);

            var particleSystem = fluid.GetParticleSystem();
            particleSystem.startSize = fluid.smoothingDistance;

            var rend = particleSystem.GetComponent<Renderer>();
            rend.receiveShadows = false; // TODO
            rend.useLightProbes = false;
#if UNITY_5_0_PlUS
            rend.reflectionProbeUsage = ReflectionProbeUsage.Off;            
#endif

            var serializedObject = new SerializedObject(particleSystem);

            // Change gravity modifier
            serializedObject.FindProperty("InitialModule.gravityModifier").floatValue = 0.04f;

            // Change emission
            serializedObject.FindProperty("EmissionModule.rate.scalar").floatValue = 100f;

            // Change collision module
#if UNITY_5_3_PLUS
            serializedObject.FindProperty("CollisionModule.m_Dampen.scalar").floatValue = 0.0f;
            serializedObject.FindProperty("CollisionModule.m_Bounce.scalar").floatValue = 1.0f;
#else
            serializedObject.FindProperty("CollisionModule.dampen").floatValue = 0.0f;
            serializedObject.FindProperty("CollisionModule.bounce").floatValue = 1.0f;
#endif
            serializedObject.FindProperty("CollisionModule.minKillSpeed").floatValue = FluvioSettings.kEpsilon;

            // Change cone size
            serializedObject.FindProperty("ShapeModule.radius").floatValue = 0.1f;

            // Color over lifetime
            var colorGradient = new Gradient();

            var colorKeys = new GradientColorKey[2];
            var alphaKeys = new GradientAlphaKey[3];

            colorKeys[0] = new GradientColorKey(Color.white, 0.0f);
            colorKeys[1] = new GradientColorKey(Color.white, 1.0f);

            alphaKeys[0] = new GradientAlphaKey(0, 0.0f);
            alphaKeys[1] = new GradientAlphaKey(1, 0.1f);
            alphaKeys[2] = new GradientAlphaKey(0, 1.0f);

            colorGradient.colorKeys = colorKeys;
            colorGradient.alphaKeys = alphaKeys;

            serializedObject.FindProperty("ColorModule.enabled").boolValue = true;
            serializedObject.FindProperty("ColorModule.gradient.maxGradient").SetPropertyValue("gradientValue", colorGradient); // Need to use reflection here
            serializedObject.FindProperty("ColorModule.gradient.minMaxState").intValue = 1;

            // Size over lifetime
            //var sizeCurve = AnimationCurve.Linear(0.0f, 0.1f, 1.0f, 1.0f);
            //sizeCurve.preWrapMode = WrapMode.Clamp;
            //sizeCurve.postWrapMode = WrapMode.Clamp;
            //serializedObject.FindProperty("SizeModule.enabled").boolValue = true;
            //serializedObject.FindProperty("SizeModule.curve.scalar").floatValue = 10.0f;
            //serializedObject.FindProperty("SizeModule.curve.maxCurve").animationCurveValue = sizeCurve;
            //serializedObject.FindProperty("SizeModule.curve.minMaxState").intValue = 1;

            // Size by density
            var sizeCurve = AnimationCurve.EaseInOut(0.0f, 1.0f, 1.0f, 0.25f);
            var sizeByDensity = newFluid.AddComponent<SizeByDensity>();            
            sizeByDensity.size.scalar = fluid.smoothingDistance*4.0f;
            sizeByDensity.size.maxCurve = sizeCurve;
            sizeByDensity.size.minMaxState = FluvioMinMaxCurveState.Curve;
            var range = sizeByDensity.range;
            range.y *= 4.0f;
            sizeByDensity.range = range;

            serializedObject.ApplyModifiedProperties();

            Selection.activeGameObject = newFluid;
        }
        [MenuItem(menuLocationAlt + "/Fluvio/Convert To Fluid", false)]
        [MenuItem("CONTEXT/ParticleSystem/[Fluvio] Convert To Fluid", false)]
        [UsedImplicitly]
        static void ConvertToFluid()
        {
            Undo.AddComponent<FluidParticleSystem>(Selection.activeGameObject);
        }
        [MenuItem(menuLocationAlt + "/Fluvio/Convert To Fluid", true)]
        [UsedImplicitly]
        static bool ConvertToFluidValidate(MenuCommand command)
        {
            var go = Selection.activeGameObject;
            return go && go.GetComponent<ParticleSystem>() && !go.GetComponent<FluidParticleSystem>();
        }
        [MenuItem("Edit/Project Settings/Fluvio")]
        [MenuItem(menuLocationAlt + "/Fluvio/Fluvio Project Settings")]
        [UsedImplicitly]
        static void OpenFluvioSettings()
        {
            var serializedInstance = Resources.Load("FluvioManager", typeof(FluvioSettings)) as FluvioSettings;
            if (!serializedInstance)
            {
                var instance = FluvioSettings.GetFluvioSettingsObject();
                serializedInstance = FluvioEditorHelpers.CreateProjectSettingsAsset(instance, "Resources", "FluvioManager.asset");
            }
            FluvioSettings.SetFluvioSettingsObject(serializedInstance);
            Selection.activeObject = serializedInstance;
        }
        [MenuItem("Assets/Create/Fluvio/Fluid Particle Plugin", false, 90)]
        [UsedImplicitly]
        static void CreateFluidParticlePlugin()
        {
            var pluginPath = "Assets";
            foreach (var obj in Selection.GetFiltered(typeof(Object), SelectionMode.Assets))
            {
                pluginPath = AssetDatabase.GetAssetPath(obj);
                if (File.Exists(pluginPath))
                {
                    pluginPath = Path.GetDirectoryName(pluginPath);
                }
                break;
            }
            
            // Create compute shader
            var root = Application.dataPath.Substring(0, Application.dataPath.Length - 7) + "/";
            Directory.CreateDirectory(root + "Assets/Fluvio-ProjectSettings/Resources/CustomPlugins");
            AssetDatabase.Refresh();
            var uniqueName = CreateFluvioComputeShader("Assets/Fluvio-ProjectSettings/Resources/CustomPlugins", "NewFluidParticlePlugin", false);

            var path = pluginPath + "/" + "NewFluidParticlePlugin.cs";
            path = AssetDatabase.GenerateUniqueAssetPath(path);

            var pluginSource =
@"using UnityEngine;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Plugins;

public class <PluginName> : FluidParticlePlugin
{
    protected override void OnEnablePlugin()
    {
        // Set the plugin's compute shader and kernel here.
        // Compute shader files can be found in the Fluvio-ProjectSettings/Resources/CustomPlugins folder by default.
        SetComputeShader(FluvioComputeShader.Find(""CustomPlugins/<FluvioComputeShader>""), ""OnUpdatePlugin"");
    }
    protected override void OnSetComputeShaderVariables()
    {
        // Set compute shader variables here.

        // float myFloat = 10.0f;
        // Vector4[] myBuffer = new Vector4[10];
        // SetComputePluginValue(0, myFloat);
        // SetComputePluginBuffer(1, myBuffer, true);
    }
    protected override void OnUpdatePlugin(SolverData solverData, int particleIndex)
    {
        // Main C# plugin code goes here. This runs on multiple threads, so most Unity API calls are not allowed.
    }
}";
            pluginSource = pluginSource.Replace("<PluginName>", Path.GetFileNameWithoutExtension(path));
            pluginSource = pluginSource.Replace("<FluvioComputeShader>", uniqueName);

            File.WriteAllText(root + path, pluginSource);

            AssetDatabase.ImportAsset(path);
            AssetDatabase.Refresh();
        }
        [MenuItem("Assets/Create/Fluvio/Fluid Particle Pair Plugin", false, 91)]
        [UsedImplicitly]
        static void CreateFluidParticlePairPlugin()
        {
            var pluginPath = "Assets";
            foreach (var obj in Selection.GetFiltered(typeof(Object), SelectionMode.Assets))
            {
                pluginPath = AssetDatabase.GetAssetPath(obj);
                if (File.Exists(pluginPath))
                {
                    pluginPath = Path.GetDirectoryName(pluginPath);
                }
                break;
            }

            var root = Application.dataPath.Substring(0, Application.dataPath.Length - 7) + "/";
            Directory.CreateDirectory(root + "Assets/Fluvio-ProjectSettings/Resources/CustomPlugins");
            AssetDatabase.Refresh();
            var uniqueName = CreateFluvioComputeShader("Assets/Fluvio-ProjectSettings/Resources/CustomPlugins", "NewFluidParticlePairPlugin", true);

            var path = pluginPath + "/" + "NewFluidParticlePairPlugin.cs";
            path = AssetDatabase.GenerateUniqueAssetPath(path);

            var pluginSource =
@"using UnityEngine;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Plugins;

public class <PluginName> : FluidParticlePairPlugin
{
    protected override void OnEnablePlugin()
    {
        // Set the plugin's compute shader and kernel here.
        // Compute shader files can be found in the Fluvio-ProjectSettings/Resources/CustomPlugins folder by default.
        SetComputeShader(FluvioComputeShader.Find(""CustomPlugins/<FluvioComputeShader>""), ""OnUpdatePlugin"");
    }
    protected override void OnSetComputeShaderVariables()
    {
        // Set compute shader variables here.

        // float myFloat = 10.0f;
        // Vector4[] myBuffer = new Vector4[10];
        // SetComputePluginValue(0, myFloat);
        // SetComputePluginBuffer(1, myBuffer, true);
    }
    protected override void OnUpdatePlugin(SolverData solverData, int particleIndex, int neighborIndex)
    {
        // Main C# plugin code goes here. This runs on multiple threads, so most Unity API calls are not allowed.
    }
}";
            pluginSource = pluginSource.Replace("<PluginName>", Path.GetFileNameWithoutExtension(path));
            pluginSource = pluginSource.Replace("<FluvioComputeShader>", uniqueName);

            File.WriteAllText(root + path, pluginSource);

            AssetDatabase.ImportAsset(path);
            AssetDatabase.Refresh();
        }

        static string CreateFluvioComputeShader(string prefixPath, string pluginName, bool isPairPlugin)
        {
            var path = prefixPath + "/" + pluginName;
            path = AssetDatabase.GenerateUniqueAssetPath(path);

            var uniqueName = Path.GetFileNameWithoutExtension(path);

            var guid = AssetDatabase.CreateFolder(path, path.Substring(path.LastIndexOf("/", StringComparison.Ordinal) + 1));
            path = AssetDatabase.GUIDToAssetPath(guid);

            var mainPath = path + "/_MainAsset.asset";
            mainPath = AssetDatabase.GenerateUniqueAssetPath(mainPath);

            var computeShaderPath = path + "/ComputeShader.compute";
            computeShaderPath = AssetDatabase.GenerateUniqueAssetPath(computeShaderPath);

            var openclPath = path + "/OpenCLShader.cl.txt";
            openclPath = AssetDatabase.GenerateUniqueAssetPath(openclPath);

            var cgincPath = path + "/ComputeShader.cginc";
            cgincPath = AssetDatabase.GenerateUniqueAssetPath(cgincPath);

            var mainShader = ScriptableObject.CreateInstance<FluvioComputeShader>();

            var shaderFileText = "// Editing this file is not recommended.\n" +
                                 "// Instead, edit " + Path.GetFileName(cgincPath) + ".\n" +
                                 "#pragma kernel OnUpdatePlugin\n" +
                                 "#include \"" + Path.GetFileName(cgincPath) + "\"";

            var cgincFileText =
@"// ---------------------------------------------------------------------------------------
// Custom plugin properties
// ---------------------------------------------------------------------------------------

// #define FLUVIO_PLUGIN_DATA_0 float
// #define FLUVIO_PLUGIN_DATA_RW_1 float4

// ---------------------------------------------------------------------------------------
// Main include
// ---------------------------------------------------------------------------------------

// If the location of this shader or FluvioCompute.cginc is changed,
// change this to the RELATIVE path to the new include.
# include <FluvioCompute.cginc>

// ---------------------------------------------------------------------------------------
// Main plugin
// ---------------------------------------------------------------------------------------

FLUVIO_KERNEL(OnUpdatePlugin)
{  
    int particleIndex = get_global_id(0);

	if (FluvioShouldUpdatePlugin(particleIndex))
    {" + (isPairPlugin ? @"
        for(EachNeighbor(particleIndex, neighborIndex))
        {
            if (FluvioShouldUpdatePluginNeighbor(neighborIndex))
            {
                // Main plugin code goes here.
            }
        }
    }
}" : @"
        // Main plugin code goes here.
    }
}");
            var fluvioComputePaths = AssetDatabase.FindAssets("FluvioCompute");
            Uri fluvioComputeUri = null;
            foreach (var computeGuid in fluvioComputePaths)
            {
                var fluvioComputePath = AssetDatabase.GUIDToAssetPath(computeGuid);

                if (!fluvioComputePath.EndsWith(".cginc"))
                    continue;

                fluvioComputeUri = new Uri(new FileInfo(fluvioComputePath).FullName, UriKind.Absolute);
          }

            if (fluvioComputeUri != null)
            {
                var cgincUri = new Uri(new FileInfo(cgincPath).FullName, UriKind.Absolute);

                var relativeInclude = Uri.UnescapeDataString(cgincUri.MakeRelativeUri(fluvioComputeUri).ToString());

                cgincFileText = cgincFileText.Replace("<FluvioCompute.cginc>", "\"" + relativeInclude  + "\"");
            }

            File.WriteAllText(computeShaderPath, shaderFileText);
            File.WriteAllText(openclPath, shaderFileText);
            File.WriteAllText(cgincPath, cgincFileText);

            AssetDatabase.Refresh();
            AssetDatabase.CreateAsset(mainShader, mainPath);

            AssetDatabase.ImportAsset(mainPath);
            AssetDatabase.ImportAsset(computeShaderPath);
            AssetDatabase.ImportAsset(openclPath);
            AssetDatabase.ImportAsset(cgincPath);

            var computeShader = (ComputeShader) AssetDatabase.LoadAssetAtPath(computeShaderPath, typeof (ComputeShader));
            mainShader.SetFieldValue("m_ComputeShader", computeShader);

            var openclShader = (TextAsset) AssetDatabase.LoadAssetAtPath(openclPath, typeof (TextAsset));            
            mainShader.SetFieldValue("m_OpenCLShader", openclShader);
            
            EditorUtility.SetDirty(mainShader);
            
            AssetDatabase.Refresh();

            return uniqueName;
        }

        internal static Material fluidEffectMaterial
        {
            get
            {
                if (s_FluidEffectMaterial == null)
                {
                    var guids = AssetDatabase.FindAssets("Default-Fluvio t:Material");

                    foreach (var guid in guids)
                    {
                        var path = AssetDatabase.GUIDToAssetPath(guid);
                        var mat = AssetDatabase.LoadAssetAtPath(path, typeof(Material)) as Material;

                        if (!mat || !mat.name.StartsWith("Default-Fluvio")) continue;
                        s_FluidEffectMaterial = mat;
                        s_FluidEffectMaterial.hideFlags |= HideFlags.NotEditable;
                        if (!s_FluidEffectMaterial.shader || s_FluidEffectMaterial.shader.name == "Hidden/InternalErrorShader")
                        {
#if UNITY_5_0_PLUS
                            s_FluidEffectMaterial.shader = Shader.Find("Fluvio/Fluid Effect");
#else
                            s_FluidEffectMaterial.shader = Shader.Find("Fluvio/Fluid Effect (4.x)");
#endif
                        }
                        FluidEffect.SetMaterialKeywords(s_FluidEffectMaterial);
                        return s_FluidEffectMaterial;
                    }
                }

                if (s_FluidEffectMaterial == null)
                {
                    Texture mainTex = null, bumpMap = null;

                    var guids = AssetDatabase.FindAssets("Default-Fluvio t:Texture");
                    
                    foreach (var guid in guids)
                    {
                        var path = AssetDatabase.GUIDToAssetPath(guid);
                        var tex = AssetDatabase.LoadAssetAtPath(path, typeof(Texture)) as Texture;

                        if (!tex) continue;

                        switch (tex.name)
                        {
                            case "Default-Fluvio":
                                mainTex = tex;
                                tex.hideFlags |= HideFlags.NotEditable;
                                break;
                            case "Default-Fluvio-NormalMap":
                                bumpMap = tex;
                                tex.hideFlags |= HideFlags.NotEditable;
                                break;
                        }

                        break;
                    }

                    guids = AssetDatabase.FindAssets("Default-Fluvio-NormalMap t:Texture");

                    foreach (var guid in guids)
                    {
                        var path = AssetDatabase.GUIDToAssetPath(guid);
                        var tex = AssetDatabase.LoadAssetAtPath(path, typeof(Texture)) as Texture;

                        if (!tex) continue;

                        switch (tex.name)
                        {
                            case "Default-Fluvio":
                                mainTex = tex;
                                tex.hideFlags |= HideFlags.NotEditable;
                                break;
                            case "Default-Fluvio-NormalMap":
                                bumpMap = tex;
                                tex.hideFlags |= HideFlags.NotEditable;
                                break;
                        }

                        break;
                    }

#if UNITY_5_0_PLUS
                    var mat =
                        new Material(Shader.Find("Fluvio/Fluid Effect"))
                        {
                            name = "Default-Fluvio"
                        };
#else
                    var mat =
                        new Material(Shader.Find("Fluvio/Fluid Effect (4.x)"))
                        {
                            name = "Default-Fluvio"
                        };
#endif
                    if (mainTex && mat.HasProperty("_MainTex")) mat.SetTexture("_MainTex", mainTex);
                    if (bumpMap && mat.HasProperty("_BumpMap")) mat.SetTexture("_BumpMap", bumpMap);
                    
                    s_FluidEffectMaterial = mat;
                    FluvioEditorHelpers.CreateAsset(mat, "Defaults", "Default-Fluvio.mat");
                }

                FluidEffect.SetMaterialKeywords(s_FluidEffectMaterial);
                s_FluidEffectMaterial.hideFlags |= HideFlags.NotEditable;
                return s_FluidEffectMaterial;
            }
        }   
    }
}
