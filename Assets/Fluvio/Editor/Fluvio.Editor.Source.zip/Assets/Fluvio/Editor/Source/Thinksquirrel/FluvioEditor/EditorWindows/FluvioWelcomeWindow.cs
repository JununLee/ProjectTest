// FluvioFirstRunWindow.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System.Xml.Serialization;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Internal;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.EditorWindows
{
    public class FluvioWelcomeWindow : EditorWindow
    {
        #region Instance Fields
        [SerializeField] Vector2 m_Dimensions = new Vector2(1000, 392);
        [SerializeField] GUIContent m_Logo;
        [SerializeField] GUIContent m_Facebook;
        [SerializeField] GUIContent m_Twitter;
        [SerializeField] GUIContent m_GooglePlus;
        [SerializeField] GUIContent m_YouTube;
        [SerializeField] GUIStyle m_BoxStyle;
        [SerializeField] GUIStyle m_LabelStyle;
        [SerializeField] GUIStyle m_ToggleStyle;
        [SerializeField] GUIStyle m_VideoStyle;
        [SerializeField] MovieTexture m_MovieTexture;
        [SerializeField] WWW m_WWW;
        [SerializeField] string m_LoadingText;
        [SerializeField] bool m_PositionSet;
        [SerializeField] GUISkin m_CachedSkin;
        #endregion

        #region Static and Constant Fields
        const string k_GettingStartedUrl = "https://s3.amazonaws.com/thinksquirrel-static/fluvio-getting-started.ogg";
        #endregion

        #region Unity Methods
        [UsedImplicitly]
        void OnEnable()
        {
            if (m_MovieTexture == null || !m_MovieTexture.isReadyToPlay)
                DownloadGettingStartedVideo();

            if (!m_PositionSet)
            {
                float w = Screen.currentResolution.width;
                float h = Screen.currentResolution.height;

                var r = new Rect(
                    (w*.5f) - (m_Dimensions.x*.5f),
                    (h*.5f) - (m_Dimensions.y*.5f),
                    m_Dimensions.x,
                    m_Dimensions.y);

                position = r;
                minSize = m_Dimensions;
                maxSize = m_Dimensions;
                m_PositionSet = true;
            }

            EditorApplication.update += Repaint;
        }
        [UsedImplicitly]
        void OnDestroy()
        {
            EditorApplication.update -= Repaint;
        }

        [UsedImplicitly]
        void OnGUI()
        {
            if (m_Logo == null || m_Facebook == null || m_Twitter == null || m_GooglePlus == null || m_YouTube == null)
            {
                var guids = AssetDatabase.FindAssets("fluvio_");

                foreach (var guid in guids)
                {
                    var tex = AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(guid), typeof (Texture)) as Texture;

                    if (!tex)
                        continue;

                    switch (tex.name)
                    {
                        case "fluvio_logo":
                            m_Logo = new GUIContent(tex);
                            break;
                        case "fluvio_social_facebook":
                            m_Facebook = new GUIContent(string.Empty, tex);
                            break;
                        case "fluvio_social_twitter":
                            m_Twitter = new GUIContent(string.Empty, tex);
                            break;
                        case "fluvio_social_googleplus":
                            m_GooglePlus = new GUIContent(string.Empty, tex);
                            break;
                        case "fluvio_social_youtube":
                            m_YouTube = new GUIContent(string.Empty, tex);
                            break;
                    }
                }

                if (m_Logo == null) m_Logo = GUIContent.none;
                if (m_Facebook == null) m_Facebook = GUIContent.none;
                if (m_Twitter == null) m_Twitter = GUIContent.none;
                if (m_GooglePlus == null) m_GooglePlus = GUIContent.none;
                if (m_YouTube == null) m_YouTube = GUIContent.none;                
            }

            if (GUI.skin != m_CachedSkin)
            {
                m_BoxStyle = null;
                m_LabelStyle = null;
                m_ToggleStyle = null;
                m_VideoStyle = null;
                m_CachedSkin = GUI.skin;
            }

            if (m_BoxStyle == null)
            {
                m_BoxStyle = new GUIStyle(GUIStyle.none)
                {
                    stretchWidth = true,
                    stretchHeight = true,
                    fixedWidth = 0,
                    fixedHeight = 0,
                    border = new RectOffset(0, 0, 0, 0),
                    padding = new RectOffset(0, 0, 0, 0),
                    margin = new RectOffset(0, 0, 0, 0)
                };
            }

            if (m_LabelStyle == null)
            {
                m_LabelStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    wordWrap = true
                };
            }

            if (m_ToggleStyle == null)
            {
                var shurikenToggle = (GUIStyle) "ShurikenToggle";

                m_ToggleStyle = new GUIStyle(shurikenToggle)
                {
                    font = EditorStyles.miniLabel.font,
                    fontSize = EditorStyles.miniLabel.fontSize,
                    contentOffset = new Vector2(13, -1),
                    active = { background = shurikenToggle.active.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    hover = { background = shurikenToggle.hover.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    normal = { background = shurikenToggle.normal.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    focused = { background = shurikenToggle.focused.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    onActive = { background = shurikenToggle.onActive.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    onHover = { background = shurikenToggle.onHover.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    onNormal = { background = shurikenToggle.onNormal.background, textColor = EditorStyles.miniLabel.normal.textColor },
                    onFocused = { background = shurikenToggle.onFocused.background, textColor = EditorStyles.miniLabel.normal.textColor },
                };
            }

            if (m_VideoStyle == null)
            {
                m_VideoStyle = new GUIStyle(GUIStyle.none)
                {
                    fontSize = EditorStyles.miniLabel.fontSize,
                    fontStyle = EditorStyles.miniLabel.fontStyle,
                    active = EditorStyles.miniLabel.active,
                    hover = EditorStyles.miniLabel.hover,
                    normal = EditorStyles.miniLabel.normal,
                    onActive = EditorStyles.miniLabel.onActive,
                    onHover = EditorStyles.miniLabel.onHover,
                    onNormal = EditorStyles.miniLabel.onNormal
                };
            }

            GUILayout.BeginVertical();
                GUILayout.FlexibleSpace();
                GUILayout.BeginHorizontal();
                    var col = FluvioColors.s_FluidColor;
                    col.a = 0.75f;
                    GUI.backgroundColor = col;
                    GUILayout.BeginVertical(m_BoxStyle);
                    GUI.backgroundColor = Color.white;

                        GUILayout.FlexibleSpace();
            
                        // Logo
                        GUILayout.Space(-32);
                        GUILayout.BeginHorizontal(GUILayout.Height(128));
                            GUILayout.FlexibleSpace();
                            GUILayout.Label(m_Logo);
                            GUILayout.FlexibleSpace();                            
                        GUILayout.EndHorizontal();
                        GUILayout.Space(-32);

                        GUILayout.FlexibleSpace();
            
                        // Welcome message
                        GUILayout.BeginHorizontal();
                            GUILayout.FlexibleSpace();
                            
                                GUILayout.Label(string.Format("Thank you for installing {0}!", VersionInfo.license), EditorStyles.largeLabel);                                
            
                            GUILayout.FlexibleSpace();
                        GUILayout.EndHorizontal();

                        EditorGUILayout.Separator();

                        GUILayout.BeginHorizontal();
                            GUILayout.FlexibleSpace();

                            #pragma warning disable 162                            
                            // ReSharper disable once ConditionIsAlwaysTrueOrFalse
                            // ReSharper disable once RedundantIfElseBlock                                            
                            // ReSharper disable HeuristicUnreachableCode                                            
                            if (!VersionInfo.isProEdition)
                            {
                                GUILayout.Label("Upgrade to Fluvio");
                                if (VersionInfo.isFreeEdition)
                                {
                                    GUI.color = new Color(0, .5f, .75f, 1);
                                    GUILayout.Space(-4f);
                                    if (GUILayout.Button("Standard", EditorStyles.whiteLabel))
                                        Application.OpenURL("com.unity3d.kharma:" + FluvioEditorHelpers.ContentLinkStandard());
                                    GUI.color = Color.white;
                                    GUILayout.Space(-4f);
                                    GUILayout.Label("or");
                                }
                                GUI.color = new Color(0, .5f, .75f, 1);
                                GUILayout.Space(-4f);
                                if (GUILayout.Button("Professional", EditorStyles.whiteLabel))
                                    Application.OpenURL("com.unity3d.kharma:" + FluvioEditorHelpers.ContentLinkPro());
                                GUI.color = Color.white;
                            }
                            else
                            {
                                GUILayout.Label("");
                            }
                            // ReSharper restore HeuristicUnreachableCode
                            #pragma warning restore 162

                            GUILayout.FlexibleSpace();
                        GUILayout.EndHorizontal();

                        EditorGUILayout.Separator();
                        
                        GUILayout.BeginHorizontal();
                            GUILayout.FlexibleSpace();
                            GUILayout.BeginVertical();

                                // Links
                                if (DrawButton("Download Drivers", "Download OpenCL drivers"))
                                {
                                    Application.OpenURL("https://support.thinksquirrel.com/hc/en-us/articles/204662628");
                                }
                                if (DrawButton("Explore Fluvio", "Get Fluvio Examples and Selections"))
                                {
                                    Application.OpenURL(FluvioEditorHelpers.SearchLink());
                                }                                                   
                                if (DrawButton("Community", "Browse the Fluvio community")) FluvioMenuItems.SupportForumWindow();
                                if (DrawButton("Rate this package", "Rate this package in the Asset Store")) Application.OpenURL("com.unity3d.kharma:" + FluvioEditorHelpers.ContentLink());                                
                                if (DrawButton("Subscribe", "Subscribe for product updates")) Application.OpenURL("https://www.thinksquirrel.com/#subscribe");
                                if (DrawButton("Help", "Browse through the Reference Manual")) FluvioMenuItems.HelpWindow();
                                
                                GUILayout.FlexibleSpace();

                                EditorGUI.BeginChangeCheck();
                                var toggle = DrawToggle(EditorPrefs.GetBool("Thinksquirrel.FluvioEditor.WelcomeWindow", true), "Show this window on startup");

                                if (EditorGUI.EndChangeCheck())
                                    EditorPrefs.SetBool("Thinksquirrel.FluvioEditor.WelcomeWindow", toggle);

                                GUILayout.FlexibleSpace();                            
                            GUILayout.EndVertical();
                            GUILayout.FlexibleSpace();
                        GUILayout.EndHorizontal();
                        GUILayout.FlexibleSpace();

                        DrawSocialMediaIcons();

                    GUILayout.EndVertical();

                    GUILayout.BeginVertical(GUILayout.ExpandWidth(true));
                        GUILayout.FlexibleSpace();
                        
                            var rect = GUILayoutUtility.GetRect(640, 400);
                           
                            if (m_MovieTexture != null && m_MovieTexture.isReadyToPlay)
                            {
                                var content = new GUIContent(m_MovieTexture);
                                GUI.color = m_MovieTexture.isPlaying ? Color.white : Color.white*0.5f;
                                if (GUI.Button(rect, content, m_VideoStyle))
                                {
                                    if (!m_MovieTexture.isPlaying)
                                    {
                                        m_MovieTexture.Play();
                                    }
                                    else
                                    {
                                        m_MovieTexture.Pause();
                                    }
                                }
                                GUI.color = Color.white;
                            }
                            else
                            {
                                GUI.Label(rect, m_LoadingText, m_VideoStyle);
                            }

                        GUILayout.FlexibleSpace();
                    GUILayout.EndVertical();
                GUILayout.EndHorizontal();
                GUILayout.FlexibleSpace();
            GUILayout.EndVertical();
        }
        #endregion

        static void ReopenWindow()
        {
            EditorApplication.update -= ReopenWindow;
            FluvioMenuItems.WelcomeWindow();
        }
        void UpdateWWW()
        {
            if (!string.IsNullOrEmpty(m_WWW.error))
            {
                m_LoadingText = "Error downloading video: " + m_WWW.error;
                EditorApplication.update -= UpdateWWW;            
                return;
            }

            if (m_WWW.progress > 0)
                m_LoadingText = string.Format("Loading video... {0:P2}", m_WWW.progress);

            if (m_MovieTexture == null || !m_MovieTexture.isReadyToPlay) return;

            m_LoadingText = string.Empty;
            EditorApplication.update -= UpdateWWW;
            m_MovieTexture.loop = true;
            m_MovieTexture.Play();
        }
        void DownloadGettingStartedVideo()
        {
            // Start download
	        m_WWW = new WWW(k_GettingStartedUrl);

	        // Make sure the movie is ready to start before we start playing
	        m_MovieTexture = m_WWW.movie;

            EditorApplication.update += UpdateWWW;
        }
        bool DrawButton(string label, string description)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(4);
            var col = FluvioColors.s_FluidColor;
            col.a = 1.0f;
            GUI.backgroundColor = col;
            var result = GUILayout.Button(label, EditorStyles.toolbarButton, GUILayout.Width(116), GUILayout.Height(24));
            GUI.backgroundColor = Color.white;
            GUILayout.BeginVertical();
            GUILayout.Space(-1);
            GUILayout.Label(description, m_LabelStyle);
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();

            return result;
        }

        bool DrawToggle(bool value, string label)
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            var toggle = GUILayout.Toggle(value, label, m_ToggleStyle);
            GUILayout.Space(16);
            GUILayout.EndHorizontal();
            
            return toggle;
        }

        void DrawSocialMediaIcons()
        {
            var col = FluvioColors.s_FluidColor;
            col.a = 1.0f;
            GUI.backgroundColor = col;
            GUILayout.BeginHorizontal(EditorStyles.toolbar, GUILayout.ExpandWidth(true));
            GUILayout.FlexibleSpace();
            var col2 = Color.white;
            col2.a = 0.65f;
            GUI.contentColor = col2;
            if (GUILayout.Button(m_Facebook, EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) Application.OpenURL("https://www.facebook.com/thinksquirrel");
            if (GUILayout.Button(m_Twitter, EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) Application.OpenURL("https://www.twitter.com/thinksquirrel");
            if (GUILayout.Button(m_GooglePlus, EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) Application.OpenURL("https://plus.google.com/+thinksquirrel");
            if (GUILayout.Button(m_YouTube, EditorStyles.toolbarButton, GUILayout.ExpandWidth(false))) Application.OpenURL("https://www.youtube.com/thinksquirrel");
            GUI.contentColor = Color.white;
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUI.backgroundColor = Color.white;
            GUILayout.Space(7);            
        }
    }
}
