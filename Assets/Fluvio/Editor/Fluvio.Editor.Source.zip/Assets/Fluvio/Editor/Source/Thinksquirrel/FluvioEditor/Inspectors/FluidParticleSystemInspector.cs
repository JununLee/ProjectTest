// FluidParticleSystemInspector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
#if UNITY_5_0_PLUS && !UNITY_5_0 && !UNITY_5_1 && !UNITY_5_2
#define UNITY_5_3_PLUS
#endif
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio.Plugins;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof (FluidParticleSystem))]
    public class FluidParticleSystemInspector : FluvioInspectorBase
    {
        #region Instance Fields
        [NonSerialized] readonly Dictionary<FluvioMonoBehaviourBase, Editor> m_ComponentEditors = new Dictionary<FluvioMonoBehaviourBase, Editor>();
        [NonSerialized] readonly static Dictionary<string, SerializedFluvioMinMaxCurve> s_CachedCurves = new Dictionary<string, SerializedFluvioMinMaxCurve>();
        [NonSerialized] readonly List<FluidPlugin> m_Plugins = new List<FluidPlugin>();
        [NonSerialized] FluidPlugin[] m_AllPlugins;
        [NonSerialized] FluidParticleSystem m_FluidParticleSystem;
        [NonSerialized] SerializedObject m_FluidParticleSystemSerialized;
        [NonSerialized] FluidEffect m_FluidEffect;
        [NonSerialized] SerializedObject m_FluidEffectSerialized;
        [NonSerialized] Editor m_FluidEffectEditor;
        [NonSerialized] GameObject m_GameObject;
        [NonSerialized] Array m_Modules;
        [NonSerialized] object m_ParticleEffectUI;
        [NonSerialized] object m_ParticleSystemUI;
        [NonSerialized] ParticleSystem m_ParticleSystem;
        [NonSerialized] ParticleSystemRenderer m_ParticleSystemRenderer;
        [NonSerialized] SerializedObject m_ParticleSystemRendererSerialized;
        [NonSerialized] SerializedObject m_ParticleSystemSerialized;
        [NonSerialized] EditorWindow m_ParticleSystemWindow;
        [NonSerialized] bool m_ParticleSystemWindowVisibilitySet;
        [NonSerialized] bool m_ParticleSystemWindowWasVisible;
        [NonSerialized] bool m_Persistent;
        [NonSerialized] GUIContent m_WindowTitle = new GUIContent("Particle Effect");
#if !UNITY_5_3_PLUS
        [NonSerialized] bool m_IsSubEmitter;
        [NonSerialized] float m_ScaleFactor = 1.0f;
#endif
        #endregion

        class SerializedFluvioMinMaxCurve
        {
            public SerializedProperty mmCurve;
            public SerializedProperty minCurve;
            public SerializedProperty maxCurve;
        }
        internal object particleEffectUI
        {
            get { return m_ParticleEffectUI; }
        }
        static void GetParams(SerializedFluvioMinMaxCurve mmCurveData, out SerializedProperty mmCurve, out Parameter minCurve, out Parameter maxCurve)
        {
            mmCurveData.mmCurve.serializedObject.Update();
            mmCurveData.minCurve.serializedObject.Update();
            mmCurveData.maxCurve.serializedObject.Update();

            mmCurve = mmCurveData.mmCurve;
            maxCurve = mmCurveData.maxCurve.Param();
            var state = (FluvioMinMaxCurveState)mmCurve.FindPropertyRelative("m_MinMaxState").enumValueIndex;
            minCurve = state == FluvioMinMaxCurveState.RandomBetweenTwoCurves
                ? mmCurveData.minCurve.Param()
                : new Parameter(null, typeof(SerializedProperty));
        }
        internal void FindMinMaxCurve(int instanceID, string path, out bool visible, out SerializedProperty mmCurve, out Parameter minCurve, out Parameter maxCurve)
        {
            visible = false;
            mmCurve = null;
            minCurve = new Parameter(null, typeof(SerializedProperty));
            maxCurve = new Parameter(null, typeof(SerializedProperty));

            if (s_CachedCurves == null || string.IsNullOrEmpty(path) || target == null || serializedObject == null || !target)
                return;

            SerializedFluvioMinMaxCurve mmCurveData;

            if (s_CachedCurves.TryGetValue(instanceID + "." + path, out mmCurveData))
            {
                GetParams(mmCurveData, out mmCurve, out minCurve, out maxCurve);
                
                var so = mmCurve.serializedObject;
                var fps = so.targetObject as FluidParticleSystem;
                visible = fps ? fps.enabled : so.FindProperty("m_Enabled").boolValue && so.FindProperty("m_EditorFoldout").boolValue;
                
                return;
            }
            if (instanceID == target.GetInstanceID())
            {
                mmCurve = serializedObject.FindProperty(path);

                if (mmCurve != null)
                {
                    visible = ((FluidParticleSystem) target).enabled;
                    mmCurveData = new SerializedFluvioMinMaxCurve
                    {
                        mmCurve = mmCurve,
                        maxCurve = mmCurve.FindPropertyRelative("m_MaxCurve"),
                        minCurve = mmCurve.FindPropertyRelative("m_MinCurve")
                    };
                    s_CachedCurves.Add(instanceID + "." + path, mmCurveData);
                    GetParams(mmCurveData, out mmCurve, out minCurve, out maxCurve);
                    return;
                }
            }

            for (var i = 0; i < m_Plugins.Count; ++i)
            {
                var plugin = m_Plugins[i];

                if (!plugin)
                    continue;
                
                if (plugin.GetInstanceID() != instanceID)
                    continue;

                Editor pluginEditor;
                if (!m_ComponentEditors.TryGetValue(plugin, out pluginEditor)) continue;
                
                var so = pluginEditor.GetFieldValue<SerializedObject>("m_SerializedObject");
                if (so == null) continue;
                
                mmCurve = so.FindProperty(path);
                if (mmCurve == null) continue;
                
                visible = so.FindProperty("m_Enabled").boolValue && so.FindProperty("m_EditorFoldout").boolValue;
                mmCurveData = new SerializedFluvioMinMaxCurve
                {
                    mmCurve = mmCurve,
                    maxCurve = mmCurve.FindPropertyRelative("m_MaxCurve"),
                    minCurve = mmCurve.FindPropertyRelative("m_MinCurve")
                }; 
                s_CachedCurves.Add(instanceID + "." + path, mmCurveData);
                GetParams(mmCurveData, out mmCurve, out minCurve, out maxCurve);
                return;
            }
        }
        #region Static and Constant Fields
        readonly static Dictionary<Object, SerializedObject> s_SerializedObjectCache = new Dictionary<Object, SerializedObject>();
        static Type[] s_PluginTypes;
        static string[] s_PluginTypeStrings;
        #endregion

        #region Unity Methods
        //! \cond PRIVATE
        protected override void OnEnable()
        {
            base.OnEnable();

            if (!target)
                return;

            m_Persistent = EditorUtility.IsPersistent(target);

            if (s_PluginTypes == null)
            {
                var pluginTypes = 
                    (AppDomain.CurrentDomain.GetAssemblies()
                        .SelectMany(assembly => assembly.GetTypes(), (pAssembly, pType) => new { assembly = pAssembly, type = pType })
                        .Where(assemblyInfo => typeof (FluidPlugin).IsAssignableFrom(assemblyInfo.type) && !assemblyInfo.type.IsAbstract && assemblyInfo.type != typeof (FluidPlugin))
                        .Select(assemblyInfo => assemblyInfo.type)).OrderBy(type => type.FullName)
                    .ToList();
                
                pluginTypes.Insert(0, null);

                s_PluginTypes = pluginTypes.ToArray();

                s_PluginTypeStrings =
                    s_PluginTypes
                        .Select(type => type == null ? "- Select a plugin -" : ObjectNames.NicifyVariableName(type.Name))
                        .ToArray();
            }

            m_AllPlugins = Resources.FindObjectsOfTypeAll<FluidPlugin>();

            var fluid = (FluidParticleSystem) target;

            // TODO: When changing hide flags, repaint

            for (var i = 0; i < m_AllPlugins.Length; ++i)
            {
                var plugin = m_AllPlugins[i];

                if (EditorUtility.IsPersistent(plugin) != m_Persistent) continue;

                if (!fluid.gameObject.activeInHierarchy)
                {
                    if (plugin.fluid == fluid || (!plugin.fluid && plugin.gameObject == fluid.gameObject))
                    {
                        m_Plugins.Add(plugin);
                        m_ComponentEditors.Add(plugin, CreateEditor(plugin));
                        if (plugin.gameObject == fluid.gameObject)
                            plugin.hideFlags |= HideFlags.HideInInspector;
                        else
                            plugin.hideFlags &= ~HideFlags.HideInInspector;
                    }
                }
                else if (FluvioHelpers.FindAttachedFluid(plugin.fluid, plugin) && plugin.fluid == fluid &&
                         !m_ComponentEditors.ContainsKey(plugin))
                {
                    if (plugin.gameObject == fluid.gameObject)
                        plugin.hideFlags |= HideFlags.HideInInspector;
                    else
                        plugin.hideFlags &= ~HideFlags.HideInInspector;

                    m_Plugins.Add(plugin);
                    m_ComponentEditors.Add(plugin, CreateEditor(plugin));
                }
                else
                    plugin.hideFlags &= ~HideFlags.HideInInspector;
            }

            EditorApplication.update += InspectorUpdate;
            if (!m_Persistent)
            {
                SceneView.onSceneGUIDelegate += OnSceneViewGUI;

#if !UNITY_5_3_PLUS
                m_IsSubEmitter = TestIsSubEmitter(fluid);
                if (m_IsSubEmitter) return;
#endif

                var particleSystemEditorUtils = ReflectionHelpers.GetEditorType("ParticleSystemEditorUtils");
                var f = fluid.parentFluid ? (FluidParticleSystem) fluid.parentFluid : fluid;

                if (Application.isPlaying) return;

                var root = (ParticleSystem) particleSystemEditorUtils.Invoke("GetRoot", f.GetParticleSystem().Param());
                
                if (!root) return;
                foreach (var system in root.GetComponentsInChildren<ParticleSystem>())
                    system.Play();
                
                Repaint();
            }           
        }
        protected override void OnDestroy()
        {
            m_ParticleEffectUI = null;

            if (m_ParticleSystemWindow)
            {
                var window = m_ParticleSystemWindow;
                if (m_ParticleSystemWindowVisibilitySet)
                {
                    window.SetFieldValue("m_IsVisible", m_ParticleSystemWindowWasVisible);
                }
            }

            base.OnDestroy();
            EditorApplication.update -= InspectorUpdate;
            SceneView.onSceneGUIDelegate -= OnSceneViewGUI;

            if (m_GameObject)
            {
                m_FluidParticleSystem = m_GameObject.GetComponent<FluidParticleSystem>();

                if (!m_FluidParticleSystem)
                {
                    var plugins = m_GameObject.GetComponentsInChildren<FluidPlugin>(true);
                    for (var i = plugins.Length - 1; i >= 0; --i)
                    {
                        var p = plugins[i];

                        if (p && p.gameObject == m_GameObject)
                        {
                            DestroyImmediate(p);
                        }
                    }
                    if (m_FluidEffect)
                        DestroyImmediate(m_FluidEffect);
                }
            }
        }
        //! \endcond
#if !UNITY_5_3_PLUS
        internal static bool TestIsSubEmitter(FluidParticleSystem fluid)
        {
            var parents = FluvioHelpers.GetComponentsUpwards<ParticleSystem>(fluid);
            var ps = fluid.GetComponent<ParticleSystem>();
            var isSubEmitter = false;
            var isNotPlaying = !Application.isPlaying;

            foreach (var parent in parents)
            {
                SerializedObject so;
                if (!s_SerializedObjectCache.TryGetValue(parent, out so))
                {
                    so = new SerializedObject(parent);
                    s_SerializedObjectCache.Add(parent, so);
                }
                else if (so == null)
                {
                    so = new SerializedObject(parent);
                    s_SerializedObjectCache[parent] = so;
                }

                so.Update();

                var prop1 = so.FindProperty("SubModule.subEmitterBirth");
                var prop2 = so.FindProperty("SubModule.subEmitterBirth1");
                var prop3 = so.FindProperty("SubModule.subEmitterCollision");
                var prop4 = so.FindProperty("SubModule.subEmitterCollision1");
                var prop5 = so.FindProperty("SubModule.subEmitterDeath");
                var prop6 = so.FindProperty("SubModule.subEmitterDeath1");

                var system1 = prop1.objectReferenceValue;
                var system2 = prop2.objectReferenceValue;
                var system3 = prop3.objectReferenceValue;
                var system4 = prop4.objectReferenceValue;
                var system5 = prop5.objectReferenceValue;
                var system6 = prop6.objectReferenceValue;

                isSubEmitter |=
                    system1 == ps ||
                    system2 == ps ||
                    system3 == ps ||
                    system4 == ps ||
                    system5 == ps ||
                    system6 == ps;

                var fps1 = system1 ? ((ParticleSystem)system1).GetComponent<FluidParticleSystem>() : null;
                var fps2 = system2 ? ((ParticleSystem)system2).GetComponent<FluidParticleSystem>() : null;
                var fps3 = system3 ? ((ParticleSystem)system3).GetComponent<FluidParticleSystem>() : null;
                var fps4 = system4 ? ((ParticleSystem)system4).GetComponent<FluidParticleSystem>() : null;
                var fps5 = system5 ? ((ParticleSystem)system5).GetComponent<FluidParticleSystem>() : null;
                var fps6 = system6 ? ((ParticleSystem)system6).GetComponent<FluidParticleSystem>() : null;

                const string errorString = "Sub emitter fluids cannot have parent emitters that are also fluids, due to Unity bug #658934";
                var parentIsFps = parent.GetComponent<FluidParticleSystem>();
                if (fps1 && parentIsFps)
                {
                    FluvioDebug.LogError(errorString, fps1);
                    prop1.objectReferenceValue = null;
                }
                if (fps2 && parentIsFps)
                {
                    FluvioDebug.LogError(errorString, fps2);
                    prop2.objectReferenceValue = null;
                }
                if (fps3 && parentIsFps)
                {
                    FluvioDebug.LogError(errorString, fps3);
                    prop3.objectReferenceValue = null;
                }
                if (fps4 && parentIsFps)
                {
                    FluvioDebug.LogError(errorString, fps4);
                    prop4.objectReferenceValue = null;
                }
                if (fps5 && parentIsFps)
                {
                    FluvioDebug.LogError(errorString, fps5);
                    prop5.objectReferenceValue = null;
                }
                if (fps6 && parentIsFps)
                {
                    FluvioDebug.LogError(errorString, fps6);
                    prop6.objectReferenceValue = null;
                }

                if (fps1)
                    fps1.SetFieldValue("m_IsSubEmitterEditor", isNotPlaying);
                if (fps2)
                    fps2.SetFieldValue("m_IsSubEmitterEditor", isNotPlaying);
                if (fps3)
                    fps3.SetFieldValue("m_IsSubEmitterEditor", isNotPlaying);
                if (fps4)
                    fps4.SetFieldValue("m_IsSubEmitterEditor", isNotPlaying);
                if (fps5)
                    fps5.SetFieldValue("m_IsSubEmitterEditor", isNotPlaying);
                if (fps6)
                    fps6.SetFieldValue("m_IsSubEmitterEditor", isNotPlaying);

                so.ApplyModifiedProperties();
            }
            fluid.SetFieldValue("m_IsSubEmitterEditor", isSubEmitter && isNotPlaying);

            return isSubEmitter && isNotPlaying;
        }
#endif
#endregion

        #region Abstract, Virtual, and Override
        public override GUIContent GetPreviewTitle()
        {
            return new GUIContent("Fluid Particle System Curves");
        }
        public override bool HasPreviewGUI()
        {
            return m_ParticleEffectUI != null;
        }
        public override void OnInspectorGUI()
        {
            if (m_ParticleSystemUI == null || m_ParticleEffectUI == null)
                return;

            ChangeEditorStyles();

            var width = ReflectionHelpers.GetRuntimeType("GUIClip").GetPropertyValue<Rect>("visibleRect").width - 18f;

            m_Modules = m_ParticleSystemUI.GetFieldValue<Array>("m_Modules");
            var length = m_Modules.Length;

            var texts = GetTexts("ParticleSystemUI");

            GUILayout.Space(4);

            var style = new GUIStyle(ReflectionHelpers.GetEditorType("ParticleSystemStyles")
                                                      .Invoke("Get")
                                                      .GetFieldValue<GUIStyle>("effectBgStyle"))
            {
                stretchHeight = false
            };

            GUILayout.BeginVertical(style);
            EditorGUIUtility.labelWidth = -4f;
            EditorGUILayout.BeginVertical();

            //if (!m_FluidParticleSystem.useGPUParticleSystem)
            {
                for (var i = 0; i < length; ++i)
                {
                    m_ParticleSystemSerialized.Update();
                    if (m_ParticleSystemRendererSerialized != null) m_ParticleSystemRendererSerialized.Update();

                    try
                    {
                        Module(m_ParticleSystemUI, m_Modules, m_Modules.GetValue(i), i, width, false, DrawModule, i == 0, texts);
                    }
                    catch (TargetInvocationException e)
                    {
                        if (e.InnerException is ExitGUIException)
                            GUIUtility.ExitGUI();
                    }

                    m_ParticleSystemSerialized.ApplyModifiedProperties();
                    if (m_ParticleSystemRendererSerialized != null)
                        m_ParticleSystemRendererSerialized.ApplyModifiedProperties();

                    // Fluvio modules
                    if (i == 2 && (fluidSettingsModule || physicalPropertiesModule || pluginsModule))
                    {
                        Module(m_ParticleSystemUI, m_Modules, m_Modules.GetValue(0), -1, width, false, DrawFluvioModules, false,
                               texts);
                    }
                }
            }
            /*else
            {
 
                for (var i = 0; i < length; ++i)
                {
                    var disabled = false;
                    switch (i)
                    {
                        case 12:
                        case 13:
                        case 14:
                            disabled = true;
                            break;
                    }
                    m_ParticleSystemSerialized.Update();
                    if (m_ParticleSystemRendererSerialized != null) m_ParticleSystemRendererSerialized.Update();

                    try
                    {
                        Module(m_ParticleSystemUI, m_Modules, m_Modules.GetValue(i), i, width, disabled, DrawModule, i == 0, texts);
                    }
                    catch (TargetInvocationException e)
                    {
                        if (e.InnerException is ExitGUIException)
                            GUIUtility.ExitGUI();
                    }

                    m_ParticleSystemSerialized.ApplyModifiedProperties();
                    if (m_ParticleSystemRendererSerialized != null)
                        m_ParticleSystemRendererSerialized.ApplyModifiedProperties();

                    // Fluvio modules
                    if (i == 2)
                    {
                        Module(m_ParticleSystemUI, m_Modules, m_Modules.GetValue(0), -1, width, false, DrawFluvioModules, false,
                               texts);
                    }
                }
            }*/

            GUILayout.Space(-1f);
            EditorGUILayout.EndVertical();
            GUILayout.EndVertical();
            
            ResetEditorStyles();

            GUILayout.BeginHorizontal();
            
            GUILayout.FlexibleSpace();

            var particleSystemEditorUtils = ReflectionHelpers.GetEditorType("ParticleSystemEditorUtils");
            var particleEffectUIType = m_ParticleEffectUI.GetType();

            particleSystemEditorUtils.SetPropertyValue("editorResimulation",
                                                       GUILayout.Toggle(
                                                           particleSystemEditorUtils.GetPropertyValue<bool>(
                                                               "editorResimulation"), "Resimulate",
                                                           EditorStyles.toggle));

            particleEffectUIType.SetFieldValue("m_ShowWireframe", GUILayout.Toggle(particleEffectUIType.GetFieldValue<bool>("m_ShowWireframe"), "Wireframe", EditorStyles.toggle));
            GUILayout.EndHorizontal();
        }
        public override void OnPreviewGUI(Rect r, GUIStyle background)
        {
            var curvesToRemove = new HashSet<string>();
            foreach (var kvp in s_CachedCurves)
            {
                var serializedCurve = kvp.Value;

                if (serializedCurve.minCurve.serializedObject.targetObject)
                {
                    serializedCurve.minCurve.serializedObject.Update();
                    serializedCurve.maxCurve.serializedObject.Update();
                    serializedCurve.mmCurve.serializedObject.Update();
                }
                else
                {
                    curvesToRemove.Add(kvp.Key);
                }
            }

            // TODO: Remove destroyed curves from curve editor
            foreach (var toRemove in curvesToRemove)
                s_CachedCurves.Remove(toRemove);

            if (m_ParticleEffectUI != null)
            {
                m_ParticleEffectUI.Invoke("GetParticleSystemCurveEditor").Invoke("OnGUI", r.Param());
            }

            foreach (var kvp in s_CachedCurves)
            {
                var serializedCurve = kvp.Value;

                if (serializedCurve.minCurve.serializedObject.targetObject)
                {
                    serializedCurve.minCurve.serializedObject.ApplyModifiedProperties();
                    serializedCurve.maxCurve.serializedObject.ApplyModifiedProperties();
                    serializedCurve.mmCurve.serializedObject.ApplyModifiedProperties();
                }
                else
                {
                    curvesToRemove.Add(kvp.Key);
                }
            }

            // TODO: Remove destroyed curves from curve editor
            foreach (var toRemove in curvesToRemove)
                s_CachedCurves.Remove(toRemove);
        }
        #endregion

        bool CheckClickModules(Array modules, int index, bool foldout)
        {
            var button = Event.current.button;
            if (button == 1)
            {
                // TODO: Cache
                var menu = new GenericMenu();
                menu.AddItem(new GUIContent("Remove"), false, HideFluvioModule, index);
                menu.ShowAsContext();
                return !foldout;
            }
            
            if (!Event.current.control) return foldout;
            for (var j = 0; j < modules.Length; j++)
            {
                var moduleUI2 = modules.GetValue(j);
                if (moduleUI2 != null && moduleUI2.GetPropertyValue<bool>("visibleUI"))
                {
                    moduleUI2.SetPropertyValue("foldout", foldout);
                }
            }

            m_FluidParticleSystemSerialized.Update();
            m_FluidParticleSystemSerialized.FindProperty("m_FluidSettingsFoldoutEditor").boolValue = foldout;
            m_FluidParticleSystemSerialized.FindProperty("m_PhysicalPropertiesFoldoutEditor").boolValue = foldout;
            m_FluidParticleSystemSerialized.FindProperty("m_PluginsFoldoutEditor").boolValue = foldout;
            m_FluidParticleSystemSerialized.ApplyModifiedProperties();
            return foldout;
        }
        static void HideFluvioModule(object userData)
        {
            var index = (int) userData;

            switch (index)
            {
                case 0:
                    fluidSettingsModule = false;
                    break;
                case 1:
                    physicalPropertiesModule = false;
                    break;
                case 2:
                    pluginsModule = false;
                    break;
            }
        }
        void DrawFluvioModules(object module, SerializedObject so)
        {
            so.Update();
            var fluid = (FluidParticleSystem)so.targetObject;
            
            var subFluid = false;
            foreach (var t in so.targetObjects)
            {
                var f = t as FluidBase;

                if (FluvioHelpers.FindSubFluidParent(f) == null) continue;
                
                subFluid = true;
                break;
            }

            var col = FluvioColors.s_FluidColor;
            col.a = 1;
            var foldoutStyle = new GUIStyle("ShurikenModuleTitle") {stretchWidth = true };
            
            var fluidSettingsFoldout = m_FluidParticleSystemSerialized.FindProperty("m_FluidSettingsFoldoutEditor");
            var physicalPropertiesFoldout = m_FluidParticleSystemSerialized.FindProperty("m_PhysicalPropertiesFoldoutEditor");
            var pluginsFoldout = m_FluidParticleSystemSerialized.FindProperty("m_PluginsFoldoutEditor");

            if (fluidSettingsModule || showAllModules)
            {
                GUI.backgroundColor = col;
                EditorGUI.BeginChangeCheck();
                fluidSettingsFoldout.boolValue = ModuleFoldout(fluidSettingsFoldout.boolValue, "[Fluvio] Fluid Settings", foldoutStyle);
                if (EditorGUI.EndChangeCheck())
                {
                    fluidSettingsFoldout.boolValue = CheckClickModules(module as Array, 0, fluidSettingsFoldout.boolValue);
                }
                GUI.backgroundColor = Color.white;

                if (fluidSettingsFoldout.boolValue)
                {
                    GUILayout.Space(-4f);

                    if (subFluid)
                    {
                        var icon = EditorGUIUtility.IconContent("console.infoicon.sml",
                                                                "Sub-fluid currently selected. Some options are not available.");
                        icon.text = "Sub-fluid currently selected.";
                        GUILayout.BeginHorizontal();
                        GUILayout.Label(icon, EditorStyles.miniLabel);
                        GUI.backgroundColor = col;
                        if (GUILayout.Button("Select parent", EditorStyles.miniButton, GUILayout.Width(100)))
                            Selection.activeGameObject = fluid.parentFluid.gameObject;
                        GUI.backgroundColor = Color.white;
                        GUILayout.EndHorizontal();

#if !UNITY_5_3_PLUS
                        if (m_IsSubEmitter)
                        {
                            var subEmitterIcon = EditorGUIUtility.IconContent("console.infoicon.sml", "Fluid is a sub emitter - edit mode is disabled.");
                            subEmitterIcon.text = "Fluid is a sub emitter - edit mode is disabled.";
                            GUILayout.Label(subEmitterIcon, EditorStyles.miniLabel);
                        }
#endif
                        PropertyField(so.FindProperty("m_FluidType"));
                        
                        EditorGUI.BeginDisabledGroup(true);
                        Toggle(fluid.solverEnabled, "Solver Enabled");
                        Toggle(fluid.enableHardwareAcceleration, string.Format("HW Acceleration [{0}]", FluvioSettings.GetCurrentDeviceName(FluvioSettings.GetCurrentComputeAPI())));
                        EnumPopup(fluid.dimensions, "Dimensions");
                        EnumPopup(fluid.cullingType, "Culling Type");                        
                        FloatField(fluid.prewarmTimeScale, "Prewarm Time Scale");
                        FloatField(fluid.simulationScale, "Simulation Scale");
#if !UNITY_5_3_PLUS
                        GUILayout.BeginHorizontal();
                        FloatField(m_ScaleFactor, "Scale Particle Systems");
                        GUI.backgroundColor = col;
                        GUILayout.Button("Apply", EditorStyles.miniButton, GUILayout.Width(60f));
                        GUI.backgroundColor = Color.white;
                        GUILayout.EndHorizontal();
#endif
                        EditorGUI.EndDisabledGroup();
                        
                    }
                    else
                    {
#if !UNITY_5_3_PLUS
                        if (m_IsSubEmitter)
                        {                         
                            var subEmitterIcon = EditorGUIUtility.IconContent("console.infoicon.sml", "Fluid is a sub emitter - edit mode is disabled.");
                            subEmitterIcon.text = "Fluid is a sub emitter - edit mode is disabled.";
                            GUILayout.Label(subEmitterIcon, EditorStyles.miniLabel);
                        }
#endif
                        PropertyField(so.FindProperty("m_FluidType"));
                        PropertyField(so.FindProperty("m_SolverEnabled"));
                        
                        #pragma warning disable 429
                        #pragma warning disable 162
                        // ReSharper disable UnreachableCode
                        // ReSharper disable RedundantLogicalConditionalExpressionOperand
                        // ReSharper disable ConditionIsAlwaysTrueOrFalse

                        PropertyField(so.FindProperty("m_EnableHardwareAcceleration"), string.Format("HW Acceleration [{0}]", FluvioSettings.GetCurrentDeviceName(FluvioSettings.GetCurrentComputeAPI())));
                        
                        // ReSharper restore ConditionIsAlwaysTrueOrFalse
                        // ReSharper restore RedundantLogicalConditionalExpressionOperand
                        // ReSharper restore UnreachableCode                                                
                        #pragma warning restore 162
                        #pragma warning restore 429

                        PropertyField(so.FindProperty("m_Dimensions"));
                        PropertyField(so.FindProperty("m_CullingType"));
                        PropertyField(so.FindProperty("m_PrewarmTimeScale"));
                        PropertyField(so.FindProperty("m_SimulationScale"));
#if !UNITY_5_3_PLUS
                        GUILayout.BeginHorizontal();
                        m_ScaleFactor = FloatField(m_ScaleFactor, "Scale Particle Systems");
                        GUI.backgroundColor = col;
                        if (GUILayout.Button("Apply", EditorStyles.miniButton, GUILayout.Width(60f)))
                        {
                            so.ApplyModifiedProperties();
                            if (m_ParticleSystemSerialized != null) m_ParticleSystemSerialized.ApplyModifiedProperties();
                            var objects = new List<Object>();
                            var ps = fluid.GetParticleSystem();
                            objects.Add(ps);
                            for (var i = 0; i < fluid.subFluidCount; ++i)
                            {
                                var sub = fluid.GetSubFluid(i) as FluidParticleSystem;

                                if (!sub) continue;
                                ps = sub.GetParticleSystem();
                                if (ps) objects.Add(ps);
                            }
                            Undo.RecordObjects(objects.ToArray(), "Scale particle systems");
                            ScaleParticleSystems(fluid, m_ScaleFactor);
                            for(var i = 0; i < objects.Count; ++i)
                                EditorUtility.SetDirty(objects[i]);
                            so.Update();
                            if (m_ParticleSystemSerialized != null) m_ParticleSystemSerialized.Update();
                            m_ScaleFactor = 1.0f;
                            Repaint();
                        }
                        GUI.backgroundColor = Color.white;
                        GUILayout.EndHorizontal();
#endif
                    }

                    GUILayout.Space(6f);
                }
            }

            GUILayout.Space(-2f);

            if (physicalPropertiesModule || showAllModules)
            {
                GUI.backgroundColor = col;
                EditorGUI.BeginChangeCheck();
                physicalPropertiesFoldout.boolValue = ModuleFoldout(physicalPropertiesFoldout.boolValue, "[Fluvio] Physical Properties",
                                                          foldoutStyle);
                if (EditorGUI.EndChangeCheck())
                {
                    physicalPropertiesFoldout.boolValue = CheckClickModules(module as Array, 1, physicalPropertiesFoldout.boolValue);
                }
                GUI.backgroundColor = Color.white;

                if (physicalPropertiesFoldout.boolValue)
                {
                    GUILayout.Space(-4f);

                    if (subFluid)
                    {
                        var icon = EditorGUIUtility.IconContent("console.infoicon.sml",
                                                                "Sub-fluid currently selected. Some options are not available.");
                        icon.text = "Sub-fluid currently selected.";
                        GUILayout.BeginHorizontal();
                        GUILayout.Label(icon, EditorStyles.miniLabel);
                        GUI.backgroundColor = col;
                        if (GUILayout.Button("Select parent", EditorStyles.miniButton, GUILayout.Width(100)))
                            Selection.activeGameObject = fluid.parentFluid.gameObject;
                        GUI.backgroundColor = Color.white;
                        GUILayout.EndHorizontal();
                        
                        EditorGUI.BeginDisabledGroup(true);
                        FloatField(fluid.smoothingDistance, "Smoothing Distance");
                        EditorGUI.EndDisabledGroup();
                    }
                    else
                    {
                        PropertyField(so.FindProperty("m_SmoothingDistance"));
                    }
                    PropertyField(so.FindProperty("m_ParticleMass"));
                    PropertyField(so.FindProperty("m_Density"));
                    PropertyField(so.FindProperty("m_MinimumDensity"));
                    PropertyField(so.FindProperty("m_Viscosity"));
                    PropertyField(so.FindProperty("m_Turbulence"));
                    PropertyField(so.FindProperty("m_SurfaceTension"));
                    PropertyField(so.FindProperty("m_GasConstant"));
                    PropertyField(so.FindProperty("m_BuoyancyCoefficient"));
                    EditorGUI.BeginDisabledGroup(m_ParticleSystemSerialized == null || !m_ParticleSystemSerialized.FindProperty("CollisionModule.enabled").boolValue || !m_ParticleSystemSerialized.FindProperty("CollisionModule.collisionMessages").boolValue);
                    PropertyField(so.FindProperty("m_CollisionForceModifier"));
                    EditorGUI.EndDisabledGroup();
                    GUILayout.Space(6f);
                }
            }

            GUILayout.Space(-2f);

            if (pluginsModule || showAllModules)
            {
                GUI.backgroundColor = col;
                EditorGUI.BeginChangeCheck();
                pluginsFoldout.boolValue = ModuleFoldout(pluginsFoldout.boolValue, "[Fluvio] Fluid Plugins", foldoutStyle);
                if (EditorGUI.EndChangeCheck())
                {
                    pluginsFoldout.boolValue = CheckClickModules(module as Array, 2, pluginsFoldout.boolValue);
                }
                GUI.backgroundColor = Color.white;

                if (pluginsFoldout.boolValue)
                {
                    GUILayout.Space(-4f);

                    m_Plugins.Sort((a, b) =>
                    {
                        var c = b.weight.CompareTo(a.weight);
                        return c == 0 ? b.GetInstanceID().CompareTo(a.GetInstanceID()) : c;
                    });
                        
                    for (var i = m_Plugins.Count - 1; i >= 0; --i)
                    {
                        var p = m_Plugins[i];

                        if ((Object)p && (EditorUtility.IsPersistent(p) == m_Persistent))
                        {
                            PluginField(
                                p,
                                i <= 0 ? null : m_Plugins[i - 1],
                                i >= m_Plugins.Count - 1 ? null : m_Plugins[i + 1],
                                i <= 1 ? null : m_Plugins[i - 2],
                                i >= m_Plugins.Count - 2 ? null : m_Plugins[i + 2],
                                p.gameObject == fluid.gameObject);
                        }
                        else
                        {
                            m_Plugins.RemoveAt(i);
                        }
                    }
                    var rect = GetControlRect(13);
                    rect = PrefixLabel(rect, new GUIContent("Create New Plugin"));
                    EditorGUI.BeginChangeCheck();
                    var newValue = EditorGUI.Popup(rect, 0, s_PluginTypeStrings, "ShurikenPopUp");
                    if (EditorGUI.EndChangeCheck() && newValue != 0)
                    {
                        var c = (FluvioMonoBehaviourBase) Undo.AddComponent(fluid.gameObject, s_PluginTypes[newValue]);
                        if (m_ComponentEditors.ContainsKey(c))
                        {
                            m_ComponentEditors[c] = CreateEditor(c);
                        }
                        else
                        {
                            m_ComponentEditors.Add(c, CreateEditor(c));
                            m_Plugins.Add((FluidPlugin) c);
                        }
                        c.hideFlags |= HideFlags.HideInInspector;
                        Repaint();
                    }

                    GUILayout.Space(6f);
                }
            }

            GUILayout.Space(-6);

            so.ApplyModifiedProperties();
        }
        static void ScaleParticleSystems(FluidParticleSystem rootFluid, float scaleFactor)
        {
            if (rootFluid) DoScale(rootFluid.GetParticleSystem(), scaleFactor);

            for (var i = 0; i < rootFluid.subFluidCount; ++i)
            {
                var subFluid = rootFluid.GetSubFluid(i) as FluidParticleSystem;

                if (subFluid) DoScale(subFluid.GetParticleSystem(), scaleFactor);
            }
        }
        static void DoScale(ParticleSystem system, float scaleFactor)
        {
            if (!system)
                return;

            SerializedObject so;
            if (!s_SerializedObjectCache.TryGetValue(system, out so))
            {
                so = new SerializedObject(system);
            }
            else if (so == null)
            {
                so = new SerializedObject(system);
                s_SerializedObjectCache[system] = so;
            }

            so.FindProperty("InitialModule.startSpeed.scalar").floatValue *= scaleFactor;
            so.FindProperty("InitialModule.startSize.scalar").floatValue *= scaleFactor;
            so.FindProperty("ShapeModule.radius").floatValue *= scaleFactor;
            so.FindProperty("ShapeModule.length").floatValue *= scaleFactor;
            so.FindProperty("ShapeModule.boxX").floatValue *= scaleFactor;
            so.FindProperty("ShapeModule.boxY").floatValue *= scaleFactor;
            so.FindProperty("ShapeModule.boxZ").floatValue *= scaleFactor;

            so.ApplyModifiedProperties();
        }
        void DrawFluidEffectModule()
        {
            // ReSharper disable once RedundantLogicalConditionalExpressionOperand
            if (!m_FluidEffect)
            {
                m_FluidEffect = m_FluidParticleSystem.GetComponent<FluidEffect>();
                if (!m_FluidEffect)
                {
                    m_FluidEffect = m_FluidParticleSystem.gameObject.AddComponent<FluidEffect>();
                    m_FluidEffect.enabled = false;
                }
                m_FluidEffect.hideFlags |= HideFlags.HideInInspector;

                if (m_FluidEffectEditor == null)
                {
                    m_FluidEffectEditor = CreateEditor(m_FluidEffect);
                }

                if (m_FluidEffectSerialized == null)
                {
                    m_FluidEffectSerialized = m_FluidEffectEditor.serializedObject;
                }
            }

            // TODO: Undo functionality breaks when using a serialized property here
            m_FluidEffect.enabled = Toggle(m_FluidEffect.enabled, "Use Fluid Effect");
            
            EditorGUI.BeginDisabledGroup(!m_FluidEffect.enabled);

            DrawInspector(m_FluidEffectEditor);
            
            m_FluidEffect.Validate();

            if (m_FluidEffect.enabled)
            {
                m_ParticleSystemRendererSerialized.FindProperty("m_SortMode").intValue = 1;

                foreach (var renderer in m_FluidEffect.additionalRenderers)
                {
                    var particleSystemRenderer = renderer as ParticleSystemRenderer;
                    if (!particleSystemRenderer) continue;

                    SerializedObject so;
                    if (!s_SerializedObjectCache.TryGetValue(particleSystemRenderer, out so))
                    {
                        so = new SerializedObject(particleSystemRenderer);
                    }
                    else if (so == null)
                    {
                        so = new SerializedObject(particleSystemRenderer);
                        s_SerializedObjectCache[particleSystemRenderer] = so;
                    }

                    so.FindProperty("m_SortMode").intValue = 1;
                    so.ApplyModifiedProperties();
                }
            }
            if (m_FluidEffect.enabled && !m_FluidEffect.materialIsValid)
            {
                var icon = EditorGUIUtility.IconContent("console.warnicon.sml",
                                                                "The current material is not valid for the fluid effect. Please use a fluid effect shader.");
                icon.text = "The current material is not valid for the fluid effect. Please use a fluid effect shader.";
#if !UNITY_5_0_PLUS
                var helpBox = typeof(EditorStyles).GetPropertyValue<GUIStyle>("helpBox");
#else
                var helpBox = EditorStyles.helpBox;
#endif
                GUILayout.Label(icon, helpBox);
                if (m_ParticleSystemRenderer)
                {
                    GUILayout.BeginHorizontal();
                    GUILayout.FlexibleSpace();
                    if (GUILayout.Button("Fix Now", EditorStyles.miniButton, GUILayout.Width(100)))
                    {
                        if (!m_ParticleSystemRenderer.sharedMaterial || m_ParticleSystemRenderer.sharedMaterial.name == "Default-Fluvio" || (m_ParticleSystemRenderer.sharedMaterial.hideFlags & HideFlags.NotEditable) != 0)
                        {
                            Undo.RecordObject(m_ParticleSystemRenderer, "Inspector");
                            m_ParticleSystemRenderer.sharedMaterial = FluvioMenuItems.fluidEffectMaterial;
                            EditorUtility.SetDirty(m_ParticleSystemRenderer);
                        }
                        else
                        {
                            #if UNITY_5_0_PLUS
                            var shader = Shader.Find("Fluvio/Fluid Effect");
                            #else
                            var shader = Shader.Find("Fluvio/Fluid Effect (4.x)");
                            #endif
                            if (shader)
                            {
                                Undo.RecordObject(m_ParticleSystemRenderer.sharedMaterial, "Assign shader");
                                m_ParticleSystemRenderer.sharedMaterial.shader = shader;
                                EditorUtility.SetDirty(m_ParticleSystemRenderer.sharedMaterial);
                                // BUG - workaround for Unity bug 667378
                                // TODO: Verify (should've been fixed in Unity 5.1)
                                ActiveEditorTracker.sharedTracker.ForceRebuild();
                                GUIUtility.ExitGUI();
                            }
                            else
                            {
                                FluvioDebug.LogError("Could not find default fluid effect material!", m_FluidParticleSystem);
                            }

                        }

                    }
                    GUILayout.EndHorizontal();
                }
            }
            EditorGUI.EndDisabledGroup();
        }

        static void DrawModule(object module, SerializedObject so)
        {
            if (module == null)
                return;

            module.Invoke("OnInspectorGUI", so.targetObject.Param()); 
        }
        void EmitterMenuCallback(object obj)
        {
            if (obj == null)
                EditorGUIUtility.PingObject(m_ParticleSystem);
            else
            {
                obj.Invoke("ResetModules");
                obj.Invoke("ApplyProperties");
                SynchronizeParticleSystem();
            }
        }
        static object GetTexts(string typeName)
        {
            var moduleType = ReflectionHelpers.GetEditorType(typeName);
            var texts = moduleType.GetFieldValue("s_Texts");

            if (texts == null)
            {
                var type = moduleType.GetFieldType("s_Texts");
                texts = type.Create();
                moduleType.SetFieldValue("s_Texts", texts);
            }

            return texts;
        }
        void InspectorUpdate()
        {
            if (!m_FluidParticleSystem)
            {
                m_FluidParticleSystem = (FluidParticleSystem)target;

                if (m_FluidParticleSystem)
                {
                    m_GameObject = m_FluidParticleSystem.gameObject;
                }
            }

            if (!m_FluidParticleSystem)
                return;

            if (m_FluidParticleSystemSerialized == null)
            {
                if (!s_SerializedObjectCache.TryGetValue(m_FluidParticleSystem, out m_FluidEffectSerialized))
                {
                    m_FluidEffectSerialized = new SerializedObject(m_FluidParticleSystem);
                }
                else if (m_FluidEffectSerialized == null)
                {
                    m_FluidEffectSerialized = new SerializedObject(m_FluidParticleSystem);
                    s_SerializedObjectCache[m_FluidParticleSystem] = m_FluidParticleSystemSerialized;
                }

                m_FluidParticleSystemSerialized = new SerializedObject(m_FluidParticleSystem);
            }
            if (!m_ParticleSystem)
            {
                m_ParticleSystem = m_FluidParticleSystem.GetParticleSystem();
            }

            if (m_ParticleEffectUI == null)
            {
                var windowType = ReflectionHelpers.GetEditorType("ParticleSystemWindow");

                var windows = Resources.FindObjectsOfTypeAll(windowType);

                for (int i = 0, l = windows.Length; i < l; i++)
                {
                    var window = windows[i];
                    m_ParticleEffectUI = window.GetFieldValue("m_ParticleEffectUI");
                    if (m_ParticleEffectUI != null)
                    {
                        m_ParticleSystemWindow = window as EditorWindow;
                        break;
                    }
                }
            }

            if (m_ParticleEffectUI == null)
            {
                var particleSystemInspector = CreateEditor(m_ParticleSystem);
                particleSystemInspector.Invoke("Init", true.Param());
                m_ParticleEffectUI = particleSystemInspector.GetFieldValue("m_ParticleEffectUI");
                particleSystemInspector.SetFieldValue("m_ParticleEffectUI", null);
                particleSystemInspector.Invoke("OnDisable");
                DestroyImmediate(particleSystemInspector);
            }

            if (m_ParticleEffectUI == null)
                return;

            m_ParticleSystemUI = m_ParticleEffectUI.Invoke("GetParticleSystemUIForParticleSystem",
                                                                m_ParticleSystem.Param());

            if (m_ParticleSystemUI == null)
                return;

            if (m_ParticleSystemSerialized == null || m_ParticleSystemRendererSerialized == null)
            {
                m_ParticleSystemSerialized = m_ParticleSystemUI.GetFieldValue<SerializedObject>("m_ParticleSystemSerializedObject");

                var minMaxStates = new List<SerializedProperty>();
                var iterator = m_ParticleSystemSerialized.GetIterator();

                while (iterator.Next(true))
                {
                    if (iterator.name.Contains("minMaxState"))
                        minMaxStates.Add(iterator);
                }
            }

            if (m_ParticleSystemRendererSerialized == null || !m_ParticleSystemRendererSerialized.targetObject)
            {
                m_ParticleSystemRendererSerialized =
                    m_ParticleSystemUI.GetFieldValue<SerializedObject>("m_RendererSerializedObject");
            }

            if (!m_FluidEffect)
            {
                m_FluidEffect = m_FluidParticleSystem.GetComponent<FluidEffect>();
                if (!m_FluidEffect)
                {
                    m_FluidEffect = m_FluidParticleSystem.gameObject.AddComponent<FluidEffect>();
                    m_FluidEffect.enabled = false;
                }
                m_FluidEffect.hideFlags |= HideFlags.HideInInspector;

                if (m_FluidEffectEditor == null)
                {
                    m_FluidEffectEditor = CreateEditor(m_FluidEffect);
                }

                if (m_FluidEffectSerialized == null)
                {
                    m_FluidEffectSerialized = m_FluidEffectEditor.serializedObject;
                }
            }

            var rendererProp = m_ParticleSystemRendererSerialized != null ? m_ParticleSystemRendererSerialized.FindProperty("m_Enabled") : null;
            var effectProp = m_FluidEffectSerialized.FindProperty("m_Enabled");
            if ((rendererProp == null || !rendererProp.boolValue) && effectProp.boolValue)
            {
                effectProp.boolValue = false;
                m_FluidEffectSerialized.ApplyModifiedProperties();
                //m_FluidEffect.Invoke("SyncEffect");
            }
            
            if (!m_ParticleSystemRenderer)
            {
                m_ParticleSystemRenderer = m_ParticleSystemRendererSerialized != null
                    ? m_ParticleSystemRendererSerialized.targetObject as ParticleSystemRenderer : null;
            }

            SynchronizeParticleSystem();
            m_ParticleSystemSerialized.ApplyModifiedProperties();
        }
        void Module(object particleSystemUi, Array modules, object module, int index, float width, bool disabled,
                    Action<object, SerializedObject> moduleDrawDelegate, bool initial, object particleSystemTexts)
        {
            if (module == null)
                return;

            var isFluvio = index < 0;

            if (!isFluvio)
                module.Invoke("Init");

            var styles = ReflectionHelpers.GetEditorType("ParticleSystemStyles").Invoke("Get");

            var text = m_FluidParticleSystem.gameObject.name;
            var flag = Event.current.type == EventType.Repaint;
            var flag2 = initial;
            var guiContent = new GUIContent();
            var rect = new Rect();
            var style = new GUIStyle();

            if (isFluvio || module.GetPropertyValue<bool>("visibleUI") || flag2)
            {
                rect = GUILayoutUtility.GetRect(width, isFluvio ? 0.0f : flag2 ? 25.0f : 15.0f);
                style = styles.GetFieldValue<GUIStyle>(flag2 ? "emitterHeaderStyle" : "moduleHeaderStyle");
            }
            if (isFluvio || module.GetPropertyValue<bool>("foldout"))
            {
                EditorGUI.BeginDisabledGroup(!isFluvio && !module.GetPropertyValue<bool>("enabled"));
                var position = EditorGUILayout.BeginVertical(styles.GetFieldValue<GUIStyle>("modulePadding"));

                if (flag2)
                {
                    position.height += 8f;
                }
                if (isFluvio && index == -1)
                {
                    var col = FluvioColors.s_FluidColor;
                    col.a = 1;
                    GUI.color = col;
                    position.y += 2f;
                    position.height -= 4f;
                }
                else
                {
                    position.y -= 4f;
                    position.height += 4f;
                }
                GUI.Label(position, GUIContent.none, styles.GetFieldValue<GUIStyle>("moduleBgStyle"));
                GUI.color = Color.white;
                if (index == modules.Length - 1)
                {
                    DrawFluidEffectModule();
                    EditorGUILayout.Separator();
                    EditorGUILayout.Separator();                    
                }
                if (disabled)
                {
                    EditorGUI.BeginChangeCheck();
                    disabled = !Toggle(GetEditFallbackProperties(index), "[Fluvio] Edit fallback-only settings");
                    if (EditorGUI.EndChangeCheck())
                    {
                        SetEditFallbackProperties(index, !disabled);    
                    }
                }
                EditorGUI.BeginDisabledGroup(disabled);
                EditorGUI.BeginChangeCheck();
                moduleDrawDelegate(isFluvio ? modules : module, isFluvio ? m_FluidParticleSystemSerialized : m_ParticleSystemSerialized);
                if (EditorGUI.EndChangeCheck() && index == modules.Length - 1)
                {
                    //FluidEffect.SyncRenderersEditor();                    
                }
                EditorGUI.EndDisabledGroup();
                EditorGUILayout.EndVertical();
                EditorGUI.EndDisabledGroup();
            }
            if (!isFluvio && flag2)
            {
                var particleSystemRenderer = m_ParticleSystemRenderer;
                const float num = 21f;
                var position2 = new Rect(rect.x + 4f, rect.y + 2f, num, num);
                if (flag && particleSystemRenderer != null)
                {
                    var flag3 = false;
                    var num2 = 0;
                    var rendererModuleUI = modules.GetValue(modules.Length - 1);
                    if (rendererModuleUI != null)
                    {   
                        if (rendererModuleUI.Invoke<bool>("IsMeshEmitter"))
                        {
                            if (particleSystemRenderer.mesh != null)
                            {
                                num2 = particleSystemRenderer.mesh.GetInstanceID();
                            }
                        }
                        else
                        {
                            if (particleSystemRenderer.sharedMaterial != null)
                            {
                                num2 = particleSystemRenderer.sharedMaterial.GetInstanceID();
                            }
                        }
                        if (typeof (EditorUtility).Invoke<bool>("IsDirty", num2.Param()))
                        {
                            typeof (AssetPreview).Invoke("ClearTemporaryAssetPreviews");
                        }
                    }
                    if (num2 != 0)
                    {
                        var assetPreview = typeof (AssetPreview).Invoke<Texture2D>("GetAssetPreview", num2.Param());
                        if (assetPreview != null)
                        {
                            GUI.DrawTexture(position2, assetPreview, ScaleMode.StretchToFill, true);
                            flag3 = true;
                        }
                    }
                    if (!flag3)
                    {
                        GUI.Label(position2, GUIContent.none, styles.GetFieldValue<GUIStyle>("moduleBgStyle"));
                    }
                }
                if (typeof (EditorGUI).Invoke<bool>("ButtonMouseDown", position2.Param(), GUIContent.none.Param(),
                                                    FocusType.Passive.Param(), GUIStyle.none.Param()))
                {
                    if (EditorGUI.actionKey)
                    {
                        var list = new List<int>();
                        var instanceID = m_ParticleSystem.gameObject.GetInstanceID();
                        list.AddRange(Selection.instanceIDs);
                        if (!list.Contains(instanceID) || list.Count != 1)
                        {
                            if (list.Contains(instanceID))
                            {
                                list.Remove(instanceID);
                            }
                            else
                            {
                                list.Add(instanceID);
                            }
                        }
                        Selection.instanceIDs = list.ToArray();
                    }
                    else
                    {
                        Selection.instanceIDs = new int[0];
                        Selection.activeInstanceID = m_ParticleSystem.gameObject.GetInstanceID();
                    }
                }
            }
            var position3 = new Rect(rect.x + 2f, rect.y + 1f, 13f, 13f);
            if (!isFluvio)
            {
                if (!flag2 && GUI.Button(position3, GUIContent.none, GUIStyle.none))
                {
                    module.SetPropertyValue("enabled", !module.GetPropertyValue<bool>("enabled"));
                    if (index == modules.Length - 1)
                    {
                        //FluidEffect.SyncRenderersEditor();
                    }                    
                }
            }
            var position4 = new Rect(rect.x + rect.width - 10f, rect.y + rect.height - 10f, 10f, 10f);
            var position5 = new Rect(position4.x - 4f, position4.y - 4f, position4.width + 4f, position4.height + 4f);
            var position6 = new Rect(position4.x - 23f, position4.y - 3f, 16f, 16f);
            var addModules = particleSystemTexts.GetFieldValue("addModules");
            if (!isFluvio && flag2 &&
                typeof (EditorGUI).Invoke<bool>("ButtonMouseDown", position5.Param(), addModules.Param(),
                                                FocusType.Passive.Param(), GUIStyle.none.Param()))
            {
                ShowAddModuleMenu(particleSystemUi, modules);
            }
            if (!string.IsNullOrEmpty(text))
            {
                guiContent.text = ((!flag2)
                    ? isFluvio ? "Fluvio" : index == modules.Length - 1 ? "Renderer/Fluid Effect" : module.GetPropertyValue<string>("displayName")
                    : text);                
            }
            else
            {
                guiContent.text = isFluvio ? "Fluvio" : module.GetPropertyValue<string>("displayName");
            }
            guiContent.tooltip = module.GetPropertyValue<string>("toolTip");

            var flag4 = isFluvio || GUI.Toggle(rect, module.GetPropertyValue<bool>("foldout"), guiContent, style);

            if (!isFluvio && flag4 != module.GetPropertyValue<bool>("foldout"))
            {
                var button = Event.current.button;
                if (button != 0)
                {
                    if (button == 1)
                    {
                        if (flag2)
                        {
                            ShowEmitterMenu(particleSystemUi);
                        }
                        else if (index != modules.Length - 1)
                        {
                            particleSystemUi.Invoke("ShowModuleMenu", index.Param());
                        }
                    }
                }
                else
                {
                    var foldout = !module.GetPropertyValue<bool>("foldout");
                    if (Event.current.control)
                    {
                        for (var j = 0; j < modules.Length; j++)
                        {
                            var moduleUI2 = modules.GetValue(j);
                            if (moduleUI2 != null && moduleUI2.GetPropertyValue<bool>("visibleUI"))
                            {
                                moduleUI2.SetPropertyValue("foldout", foldout);
                            }
                        }

                        m_FluidParticleSystemSerialized.Update();
                        m_FluidParticleSystemSerialized.FindProperty("m_FluidSettingsFoldoutEditor").boolValue = foldout;
                        m_FluidParticleSystemSerialized.FindProperty("m_PhysicalPropertiesFoldoutEditor").boolValue = foldout;
                        m_FluidParticleSystemSerialized.FindProperty("m_PluginsFoldoutEditor").boolValue = foldout;
                        m_FluidParticleSystemSerialized.ApplyModifiedProperties();
                    }
                    else
                    {
                        module.SetPropertyValue("foldout", foldout);
                    }
                }
            }
            if (!isFluvio && !flag2)
            {
                GUI.Toggle(position3, module.GetPropertyValue<bool>("enabled"), GUIContent.none,
                           styles.GetFieldValue<GUIStyle>("checkmark"));
            }
            if (!isFluvio && flag && flag2)
            {
                GUI.Label(position4, GUIContent.none, styles.GetFieldValue<GUIStyle>("plus"));
            }
            var supportsCullingText = particleSystemTexts.GetFieldValue<GUIContent>("supportsCullingText");
            supportsCullingText.tooltip =
                ReflectionHelpers.GetEditorType("ParticleSystemUI").GetFieldValue<string>("m_SupportsCullingText");
            if (!isFluvio && flag2 && supportsCullingText.tooltip != null)
            {
                GUI.Label(position6, supportsCullingText);
            }
            if (!isFluvio && module.GetPropertyValue<bool>("visibleUI"))
            {
                GUILayout.Space(1f);
            }
        }
        static bool ModuleFoldout(bool foldout, string content, GUIStyle style)
        {
            var position = GUILayoutUtility.GetRect(new GUIContent(content), style);
            position.y -= 3;
            position.x -= 3;
            position.width += 6;
            return GUI.Toggle(position, foldout, content, style);
        }
        void PluginField(FluidPlugin plugin, FluidPlugin previous, FluidPlugin next, FluidPlugin previous2, FluidPlugin next2, bool sameObject)
        {
            var content =
                new GUIContent(string.Format("{0}{1}", ObjectNames.NicifyVariableName(plugin.GetType().Name),
                                             sameObject ? string.Empty : string.Format(" ({0})", plugin.name)));

            var position = EditorGUILayout.GetControlRect(true, sameObject ? 16 : 14);
            var checkboxPosition = position;

            checkboxPosition.width = 13;
            position.x += 17;
            position.width -= 19;
            position.y -= 1;
            
            var col = FluvioColors.s_FluidColor;
            col.a = 1;
            
            GUI.backgroundColor = col * .85f;

            Editor pluginEditor;

            if (m_ComponentEditors.ContainsKey(plugin))
            {
                pluginEditor = m_ComponentEditors[plugin];

                if (!pluginEditor)
                {
                    pluginEditor = CreateEditor(plugin);
                    m_ComponentEditors[plugin] = pluginEditor;
                }
            }
            else
            {
                pluginEditor = CreateEditor(plugin);
                m_ComponentEditors.Add(plugin, pluginEditor);
            }

            var so = pluginEditor.serializedObject;
            
            var foldout = so.FindProperty("m_EditorFoldout");
            var enabled = so.FindProperty("m_Enabled");

            var fold = foldout.boolValue;

            var objectDisabled = !sameObject && !plugin.gameObject.activeInHierarchy;

            if (objectDisabled) content.text += " [Disabled]";

            GUI.color = objectDisabled ? Color.white * .75f : Color.white;
            
            if (GUI.Button(position, content, "ShurikenModuleTitle"))
            {
                switch (Event.current.button)
                {
                    case 0:
                        foldout.boolValue = !foldout.boolValue;
                        break;
                    case 1:
                        ShowPluginMenu(plugin, previous, next, previous2, next2, sameObject);
                        break;
                }
            }

            GUI.backgroundColor = Color.white;

            var en = EditorGUI.Toggle(checkboxPosition, enabled.boolValue, "ShurikenToggle");

            if (fold != foldout.boolValue)
                so.ApplyModifiedProperties();

            if (foldout.boolValue)
            {
                GUI.color = objectDisabled ? Color.white * .75f : Color.white;
            
                EditorGUILayout.Separator();

                DrawInspector(pluginEditor);

                EditorGUILayout.Separator();
            }

            if (enabled.boolValue != en)
            {
                enabled.boolValue = en;
                so.ApplyModifiedProperties();
            }
            
            GUILayout.Space(2);
            GUI.color = Color.white;
        }
        static void DrawInspector(Editor inspector)
        {
            inspector.serializedObject.Update();
            var prop = inspector.serializedObject.GetIterator();
            prop.Next(true);

            var enterChildren = true;

            while (prop.NextVisible(enterChildren))
            {
                // Initialize variables
                var label = new GUIContent(ObjectNames.NicifyVariableName(prop.name));
                var hide = false;
                
                // Get tooltip
                switch (prop.name)
                {
                    case "m_Script":
                        hide = true;
                        break;
                    case "m_Weight":
                        hide = true;
                        break;
                    default:
                        label.tooltip = label.text;
                        break;
                }

                if (prop.isArray && !hide)
                {
                    hide = true;
                    var size = prop.arraySize;
                    enterChildren = PropertyField(prop, label);
                    if (enterChildren)
                    {
                        EditorGUI.indentLevel++;
                        PropertyField(prop.FindPropertyRelative("Array.size"));
                        var subLabel = new GUIContent();
                        for (var i = 0; i < size; ++i)
                        {
                            subLabel.text = "Element " + i;
                            subLabel.tooltip = "Element " + i;
                            PropertyField(prop.GetArrayElementAtIndex(Mathf.Clamp(i, 0, prop.arraySize - 1)), subLabel);
                        }
                        EditorGUI.indentLevel--;
                    }
                    enterChildren = false;
                }

                // Display
                if (hide) continue;
                enterChildren = PropertyField(prop, label);              
            }

            inspector.serializedObject.ApplyModifiedProperties();            
        }
        [UsedImplicitly]
        void OnSceneGUI()
        {
            if (m_Persistent || !m_FluidParticleSystem)
                return;

            if (m_ParticleEffectUI != null)
            {
                m_ParticleEffectUI.Invoke("OnSceneGUI");
            }
            if (FluvioMonoBehaviourBase.IsValid(m_FluidParticleSystem))
            {
                foreach (var editor in m_ComponentEditors.Values)
                {
                    var fluvioMonoBehaviourBase = editor.target as FluvioMonoBehaviourBase;

                    if (editor && fluvioMonoBehaviourBase && fluvioMonoBehaviourBase.GetFieldValue<bool>("m_EditorFoldout"))
                    {
                        if (editor.GetMethod("OnSceneGUI") != null)
                        {
                            editor.Invoke("OnSceneGUI");
                        }
                    }
                }
            }
        }
        void OnSceneViewGUI(SceneView sceneView)
        {
            if (m_Persistent)
                return;

            if (FluvioMonoBehaviourBase.IsValid(m_FluidParticleSystem))
            {
                var callback =
                    Delegate.CreateDelegate(
                        ReflectionHelpers.GetEditorType("SceneViewOverlay").NestedType("WindowFunction"), this,
                        "OnSceneViewWindow");
                var windowOption =
                    ReflectionHelpers.GetEditorType("SceneViewOverlay")
                                     .NestedType("WindowDisplayOption")
                                     .GetFieldValue("OneWindowPerTitle");
                
                ReflectionHelpers.GetEditorType("SceneViewOverlay")
                                 .Invoke("Window", m_WindowTitle.Param(), callback.Param(), 400.Param(),
                                         windowOption.Param());                
            }
        }
        [UsedImplicitly]
        void OnSceneViewWindow(Object obj, SceneView sceneView)
        {
            var fluid = m_FluidParticleSystem.parentFluid
                ? (FluidParticleSystem)m_FluidParticleSystem.parentFluid
                : m_FluidParticleSystem;

            var particleSystemEditorUtils = ReflectionHelpers.GetEditorType("ParticleSystemEditorUtils");
            var particleSystem = (ParticleSystem)particleSystemEditorUtils.Invoke("GetRoot", fluid.GetParticleSystem().Param());
            var editorIsPlaying = particleSystemEditorUtils.GetPropertyValue<bool>("editorIsPlaying");

            // No scrubbing support
            particleSystemEditorUtils.SetPropertyValue("editorIsScrubbing", false);

            GUILayout.BeginHorizontal();
            if (GUILayout.Button(editorIsPlaying && !Application.isPlaying ? "Pause" : "Simulate", "ButtonLeft"))
            {
                if (Application.isPlaying)
                {
                    var fps = fluid;

                    if (fps.fluidType != FluidType.Static)
                    {
                        particleSystem.Clear(false);
                        particleSystem.time = 0;
                        particleSystem.Play(false);
                    }

                    foreach (var childSystem in particleSystem.GetComponentsInChildren<ParticleSystem>())
                    {
                        fps = childSystem.GetComponent<FluidParticleSystem>();

                        if (fps && fps.fluidType == FluidType.Static) continue;
                        
                        childSystem.Clear(false);
                        childSystem.time = 0;
                        childSystem.Play(false);
                    }
                }
                else
                {
                    if (editorIsPlaying)
                    {
                        particleSystem.Pause(false);

                        foreach (var childSystem in particleSystem.GetComponentsInChildren<ParticleSystem>())
                        {
                            childSystem.Pause(false);
                        }
                    }
                    else
                    {
                        particleSystem.Play(false);

                        foreach (var childSystem in particleSystem.GetComponentsInChildren<ParticleSystem>())
                        {
                            childSystem.Play(false);
                        }
                    }
                }
                Repaint();
            }
            if (GUILayout.Button("Stop", "ButtonRight"))
            {
                if (Application.isPlaying)
                {
                    var fps = fluid;

                    if (fps.fluidType != FluidType.Static)
                    {
                        particleSystem.Clear(false);
                        particleSystem.time = 0;
                        particleSystem.Pause(false);
                    }

                    foreach (var childSystem in particleSystem.GetComponentsInChildren<ParticleSystem>())
                    {
                        fps = childSystem.GetComponent<FluidParticleSystem>();

                        if (fps && fps.fluidType == FluidType.Static) continue;

                        childSystem.Clear(false);
                        childSystem.time = 0;
                        childSystem.Pause(false);
                    }
                }
                else
                {
                    particleSystem.Stop();
                    particleSystem.Pause();
                    particleSystem.Clear();
                    particleSystem.time = 0;

                    foreach (var childSystem in particleSystem.GetComponentsInChildren<ParticleSystem>())
                    {
                        childSystem.Stop();
                        childSystem.Pause();
                        childSystem.Clear();
                        childSystem.time = 0;
                    }
                }
                Repaint();
            }
            GUILayout.EndHorizontal();

#if !UNITY_5_0_PLUS
            var helpBox = typeof(EditorStyles).GetPropertyValue<GUIStyle>("helpBox");
#else
            var helpBox = EditorStyles.helpBox;
#endif
            GUILayout.BeginHorizontal();
            GUILayout.Label("Controlled by Fluvio", helpBox);
            GUILayout.EndHorizontal();
            
            if (Application.isPlaying) return;

            var str = typeof(EditorGUI).GetFieldValue<string>("kFloatFieldFormatString");
            typeof(EditorGUI).SetFieldValue("kFloatFieldFormatString", "f2");
            particleSystemEditorUtils.SetPropertyValue("editorSimulationSpeed", Mathf.Clamp(EditorGUILayout.FloatField("Playback Speed", particleSystemEditorUtils.GetPropertyValue<float>("editorSimulationSpeed")), 0.0f, 10f));
            typeof(EditorGUI).SetFieldValue("kFloatFieldFormatString", str);
            EditorGUILayout.LabelField("Playback Time", particleSystemEditorUtils.GetPropertyValue<float>("editorPlaybackTime").ToString("f2"));
        }

        [MenuItem("CONTEXT/FluidParticleSystem/Copy Component"), UsedImplicitly]
        static void CopyComponent()
        {
            // TODO: Copy/paste FluidParticleSystem
        }
        [MenuItem("CONTEXT/FluidParticleSystem/Copy Component", true), UsedImplicitly]
        static bool CopyComponentValidate(MenuCommand command)
        {
            // TODO: Copy/paste FluidParticleSystem
            return false;
        }
        [MenuItem("CONTEXT/FluidParticleSystem/Paste Component As New"), UsedImplicitly]
        static void PasteComponentAsNew()
        {
            // TODO: Copy/paste FluidParticleSystem
        }
        [MenuItem("CONTEXT/FluidParticleSystem/Paste Component As New", true), UsedImplicitly]
        static bool PasteComponentAsNewValidate(MenuCommand command)
        {
            // TODO: Copy/paste FluidParticleSystem
            return false;
        }
        [MenuItem("CONTEXT/FluidParticleSystem/Paste Component Values"), UsedImplicitly]
        static void PasteComponentValues()
        {
            // TODO: Copy/paste FluidParticleSystem
        }
        [MenuItem("CONTEXT/FluidParticleSystem/Paste Component Values", true), UsedImplicitly]
        static bool PasteComponentValuesValidate(MenuCommand command)
        {
            // TODO: Copy/paste FluidParticleSystem
            return false;
        }
        void ShowPluginMenu(FluidPlugin plugin, FluidPlugin previous, FluidPlugin next, FluidPlugin previous2, FluidPlugin next2, bool sameObject)
        {
            // TODO: Cache
            var genericMenu = new GenericMenu();
            var moveUp = new GUIContent("Move Up");
            var moveDown = new GUIContent("Move Down");
            var reset = new GUIContent("Reset");
            var removeSelect = new GUIContent(sameObject ? "Remove" : "Select Object");
            
            if (next)
            {
                var nextPlugins = new[] { plugin, next, next2 };
                genericMenu.AddItem(moveUp, false, MoveUp, nextPlugins);
            }
            else
                genericMenu.AddDisabledItem(moveUp);

            if (previous)
            {
                var previousPlugins = new[] { plugin, previous, previous2 };
                genericMenu.AddItem(moveDown, false, MoveDown, previousPlugins);
            }
            else
                genericMenu.AddDisabledItem(moveDown);

            genericMenu.AddSeparator(string.Empty);

            genericMenu.AddItem(reset, false, ResetPlugin, plugin);
            if (sameObject)
                genericMenu.AddItem(removeSelect, false, RemovePlugin, plugin);
            else
                genericMenu.AddItem(removeSelect, false, SelectPlugin, plugin);
            
            genericMenu.ShowAsContext();
            Event.current.Use();
        }
        static void MoveDown(object userData)
        {
            var plugins = (FluidPlugin[])userData;
            var plugin = plugins[0];
            var previous = plugins[1];
            var previous2 = plugins[2];

            Undo.RecordObject(plugin, "Move Down");
            plugin.weight = (previous2
                ? (Mathf.Abs(previous2.weight - previous.weight) < 2 ? previous.weight + 2 : (int) Mathf.Lerp(previous2.weight, previous.weight, .5f))
                : previous.weight + FluidPlugin.kPluginWeightMultiplier);
            EditorUtility.SetDirty(plugin);
        }
        static void MoveUp(object userData)
        {
            var plugins = (FluidPlugin[])userData;
            var plugin = plugins[0];
            var next = plugins[1];
            var next2 = plugins[2];

            Undo.RecordObject(plugin, "Move Up");
            plugin.weight = (next2
                ? (Mathf.Abs(next2.weight - next.weight) < 2 ? next.weight - 2 : (int) Mathf.Lerp(next.weight, next2.weight, .5f))
                : next.weight - FluidPlugin.kPluginWeightMultiplier);
            EditorUtility.SetDirty(plugin);
        }
        void ResetPlugin(object userData)
        {
            var plugin = (FluidPlugin) userData;

            Undo.RecordObject(plugin, string.Format("Reset {0} {1}", plugin.name, plugin.GetType().Name));
            plugin.Invoke("Reset");
            typeof(Editor).GetTypeInAssembly("UnityEditorInternal.AnimationCurvePreviewCache").Invoke("ClearCache");
            typeof(Editor).GetTypeInAssembly("UnityEditorInternal.GradientPreviewCache").Invoke("ClearCache");
            EditorUtility.SetDirty(plugin);
            Editor pluginEditor;
            if (m_ComponentEditors.TryGetValue(plugin, out pluginEditor))
            {
                pluginEditor.serializedObject.Update();
                pluginEditor.Repaint();
            }
            Repaint();
        }
        static FluidPlugin s_PluginToRemove;
        static void RemovePlugin(object userData)
        {
            var plugin = (FluidPlugin)userData;

            s_PluginToRemove = plugin;

            EditorApplication.update += DoRemovePlugin;
        }
        static void DoRemovePlugin()
        {
            Undo.DestroyObjectImmediate(s_PluginToRemove);            
            s_PluginToRemove = null;
            EditorApplication.update -= DoRemovePlugin;
        }
        static void SelectPlugin(object userData)
        {
            var plugin = (FluidPlugin)userData;

            Selection.activeGameObject = plugin.gameObject;
        }
        void ShowAddModuleMenu(object particleSystemUi, Array modules)
        {
            var genericMenu = new GenericMenu();
            var moduleNames = particleSystemUi.GetFieldValue<string[]>("s_ModuleNames");
            var method = particleSystemUi.GetMethod("AddModuleCallback");
            var callback =
                (GenericMenu.MenuFunction2)
                    Delegate.CreateDelegate(typeof (GenericMenu.MenuFunction2), particleSystemUi, method);
            GenericMenu.MenuFunction2 fluvioMenuCallback = FluvioMenuCallback;
            for (var i = 0; i < moduleNames.Length; i++)
            {
                var module = modules.GetValue(i);
                
                if (module == null || !module.GetPropertyValue<bool>("visibleUI"))
                {
                    genericMenu.AddItem(new GUIContent(moduleNames[i]), false, callback, i);
                }
                else
                {
                    genericMenu.AddDisabledItem(new GUIContent(moduleNames[i]));
                }

                if (i != 2) continue;

                if (showAllModules || fluidSettingsModule)
                    genericMenu.AddDisabledItem(new GUIContent("[Fluvio] Fluid Settings"));
                else
                    genericMenu.AddItem(new GUIContent("[Fluvio] Fluid Settings"), false, fluvioMenuCallback, 0);

                if (showAllModules || physicalPropertiesModule)
                    genericMenu.AddDisabledItem(new GUIContent("[Fluvio] Physical Properties"));
                else
                    genericMenu.AddItem(new GUIContent("[Fluvio] Physical Properties"), false, fluvioMenuCallback, 1);
                
                if (showAllModules || pluginsModule)
                    genericMenu.AddDisabledItem(new GUIContent("[Fluvio] Fluid Plugins"));
                else
                    genericMenu.AddItem(new GUIContent("[Fluvio] Fluid Plugins"), false, fluvioMenuCallback, 2);
            }
            genericMenu.AddSeparator(string.Empty);
            genericMenu.AddItem(new GUIContent("Show All Modules"), showAllModules, ToggleShowAllModules, particleSystemUi);
            genericMenu.ShowAsContext();
            Event.current.Use();
        }
        static void FluvioMenuCallback(object data)
        {
            var ind = (int) data;
            switch (ind)
            {
                case 0:
                    fluidSettingsModule = true;
                    break;
                case 1:
                    physicalPropertiesModule = true;
                    break;
                case 2:
                    pluginsModule = true;
                    break;
            }
        }
        void ToggleShowAllModules(object particleSystemUi)
        {
            var particleEffectUi = m_ParticleEffectUI;
            if (particleEffectUi != null)
            {
                particleEffectUi.Invoke("SetAllModulesVisible", (!showAllModules).Param());
            }
        }
        void ShowEmitterMenu(object particleSystemUi)
        {
            var genericMenu = new GenericMenu();
            genericMenu.AddItem(new GUIContent("Show Location"), false, EmitterMenuCallback, null);
            genericMenu.AddSeparator(string.Empty);
            genericMenu.AddItem(new GUIContent("Reset"), false, EmitterMenuCallback, particleSystemUi);
            genericMenu.ShowAsContext();
            Event.current.Use();
        }
        void SynchronizeParticleSystem()
        {
            // ------------------------------------
            // Editing fluid particle systems using the separate particle system window is not supported
            // ------------------------------------
            if (!m_ParticleSystemWindow)
                m_ParticleSystemWindow =
                    ReflectionHelpers.GetEditorType("ParticleSystemWindow").GetFieldValue("s_Instance") as EditorWindow;

            if (!m_ParticleSystemWindowVisibilitySet && m_ParticleSystemWindow)
            {
                // ReSharper disable AssignNullToNotNullAttribute
                // ReSharper disable PossibleNullReferenceException
                m_ParticleSystemWindowWasVisible = (bool) m_ParticleSystemWindow.GetFieldValue("m_IsVisible");
                m_ParticleSystemWindow.SetFieldValue("m_Target", null);
                m_ParticleSystemWindow.SetFieldValue("m_ParticleEffectUI", null);
                m_ParticleSystemWindow.SetFieldValue("m_IsVisible", false);
                m_ParticleSystemWindow.Repaint();
                // ReSharper restore PossibleNullReferenceException
                // ReSharper restore AssignNullToNotNullAttribute

                m_ParticleSystemWindowVisibilitySet = true;
            }

            // ------------------------------------
            // Sub emitters, sorting fudge, and prewarm
            // ------------------------------------
            m_FluidParticleSystemSerialized.Update();

#if !UNITY_5_3_PLUS
            var subEmitterArray = m_FluidParticleSystemSerialized.FindProperty("m_SubEmitters");
            
            var prop1 = m_ParticleSystemSerialized.FindProperty("SubModule.subEmitterBirth");
            var prop2 = m_ParticleSystemSerialized.FindProperty("SubModule.subEmitterBirth1");
            var prop3 = m_ParticleSystemSerialized.FindProperty("SubModule.subEmitterCollision");
            var prop4 = m_ParticleSystemSerialized.FindProperty("SubModule.subEmitterCollision1");
            var prop5 = m_ParticleSystemSerialized.FindProperty("SubModule.subEmitterDeath");
            var prop6 = m_ParticleSystemSerialized.FindProperty("SubModule.subEmitterDeath1");

            var system1 = prop1.objectReferenceValue as ParticleSystem;
            var system2 = prop2.objectReferenceValue as ParticleSystem;
            var system3 = prop3.objectReferenceValue as ParticleSystem;
            var system4 = prop4.objectReferenceValue as ParticleSystem;
            var system5 = prop5.objectReferenceValue as ParticleSystem;
            var system6 = prop6.objectReferenceValue as ParticleSystem;

            subEmitterArray.GetArrayElementAtIndex(0).objectReferenceValue = system1;
            subEmitterArray.GetArrayElementAtIndex(1).objectReferenceValue = system2;
            subEmitterArray.GetArrayElementAtIndex(2).objectReferenceValue = system3;
            subEmitterArray.GetArrayElementAtIndex(3).objectReferenceValue = system4;
            subEmitterArray.GetArrayElementAtIndex(4).objectReferenceValue = system5;
            subEmitterArray.GetArrayElementAtIndex(5).objectReferenceValue = system6;

            var sortingFudge = m_FluidParticleSystemSerialized.FindProperty("m_SortingFudge");

            var sortingFudgeProp = m_ParticleSystemRendererSerialized.FindProperty("m_SortingFudge");

            sortingFudge.floatValue = sortingFudgeProp.floatValue;            
#endif
            var prewarm = m_FluidParticleSystemSerialized.FindProperty("m_Prewarm");
            var prewarmProp = m_ParticleSystemSerialized.FindProperty("prewarm");

            prewarm.boolValue = prewarmProp.boolValue;

            m_FluidParticleSystemSerialized.ApplyModifiedProperties();

            /*
            //For debugging
            var iterator = m_ParticleSystemSerialized.GetIterator();

            while (iterator.Next(true))
            {
                FluvioDebug.Log(iterator.propertyPath + " | " + iterator.propertyType);
            }
            */
        }
        static bool GetEditFallbackProperties(int index)
        {
            return EditorPrefs.GetBool(string.Format("Thinksquirrel.FluvioEditor.EditFallbackProperties-{0}", index), false);
        }
        static void SetEditFallbackProperties(int index, bool value)
        {
            EditorPrefs.SetBool(string.Format("Thinksquirrel.FluvioEditor.EditFallbackProperties-{0}", index), value);
        }
        static bool fluidSettingsModule
        {
            get { return EditorPrefs.GetBool("Thinksquirrel.FluvioEditor.Modules.FluidSettingsModule", true); }
            set { EditorPrefs.SetBool("Thinksquirrel.FluvioEditor.Modules.FluidSettingsModule", value); }
        }
        static bool physicalPropertiesModule
        {
            get { return EditorPrefs.GetBool("Thinksquirrel.FluvioEditor.Modules.PhysicalPropertiesModule", true); }
            set { EditorPrefs.SetBool("Thinksquirrel.FluvioEditor.Modules.PhysicalPropertiesModule", value); }
        }
        static bool pluginsModule
        {
            get { return EditorPrefs.GetBool("Thinksquirrel.FluvioEditor.Modules.PluginsModule", true); }
            set { EditorPrefs.SetBool("Thinksquirrel.FluvioEditor.Modules.PluginsModule", value); }
        }
        static bool showAllModules
        {
            get { return EditorPrefs.GetBool("ParticleSystemShowAllModules", true); }
        }
    }
}
