using System;
using System.Collections.Generic;
using Cloo;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Internal;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof(FluvioComputeShader))]
    public class FluvioComputeShaderInspector : FluvioInspectorBase
    {
        List<GUIContent[]> m_ErrorLogParsed;
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var prop = serializedObject.GetIterator();
            prop.Next(true);

            var enterChildren = true;

            var computeShader = (FluvioComputeShader) target;
            var openCLShaderProp = serializedObject.FindProperty("m_OpenCLShader");
            var openCLShader = openCLShaderProp.objectReferenceValue;

            EditorGUI.BeginChangeCheck();

            while (prop.NextVisible(enterChildren))
            {
                // Initialize variables
                var label = new GUIContent(ObjectNames.NicifyVariableName(prop.name));
                var hide = false;

                // Get tooltip
                switch (prop.name)
                {
                    case "m_Script":
                        hide = true;
                        break;
                    case "m_ComputeShader":
                        label.text = "Compute Shader";
                        label.tooltip = label.text;
                        break;
                    case "m_OpenCLShader":
                        label.text = "OpenCL Shader";
                        label.tooltip = label.text;
                        break;
                    default:
                        label.tooltip = label.text;
                        break;
                }

                // Display
                if (hide) continue;
                enterChildren = EditorGUILayout.PropertyField(prop, label);
            }

            if (EditorGUI.EndChangeCheck())
            {
                var newOpenCLShader = openCLShaderProp.objectReferenceValue;

                if (newOpenCLShader != null)
                {
                    var path = AssetDatabase.GetAssetPath(newOpenCLShader);

                    // Invalid path, set shader to null
                    if (!path.EndsWith(".cl.txt"))
                    {
                        FluvioDebug.LogError(
                            "Invalid OpenCL compute shader. OpenCL compute shaders must end with .cl.txt", this);
                        openCLShaderProp.objectReferenceValue = null;
                        newOpenCLShader = null;
                    }
                }

                // Shader was changed, trigger a recompile
                if (newOpenCLShader != openCLShader)
                {
                    computeShader.SetFieldValue("m_ShouldCompile", true);
                    computeShader.CompileOpenCLProgram();
                }
            }

            serializedObject.ApplyModifiedProperties();

            var fluvioComputeShader = (FluvioComputeShader) target;

            var errorLog = fluvioComputeShader.GetInspectorLog();

            var nativeComputeShader = serializedObject.FindProperty("m_ComputeShader").objectReferenceValue;
            
            EditorGUILayout.Separator();

            EditorGUI.BeginDisabledGroup(Application.isPlaying);
            if (GUILayout.Button("Compile for all platforms/devices", EditorStyles.miniButton))
            {
                errorLog.Clear();
                ClearLog();

                if (nativeComputeShader)
                {
                    AssetDatabase.ImportAsset(AssetDatabase.GetAssetPath(nativeComputeShader), ImportAssetOptions.ForceSynchronousImport);

                    var so = new SerializedObject(nativeComputeShader);
                    var errors = so.FindProperty("errors");
                    for (var i = 0; i < errors.arraySize; ++i)
                    {
                        var arrayProp = errors.GetArrayElementAtIndex(i);
                        var message = arrayProp.FindPropertyRelative("message").stringValue;
                        if (message.Contains("your compute shader was not comp")) continue;
                        var line = arrayProp.FindPropertyRelative("line").intValue;
                        var warning = arrayProp.FindPropertyRelative("warning").boolValue;
                        var error = arrayProp.FindPropertyRelative("programError").boolValue;                        
                        var errorString = string.Format("{0}:0: {1}: {2} : {3} : {4}", line, warning ? "warning" : error ? "error" : "info", message, string.Format("Unity Compute Shader - {0}", SystemInfo.graphicsDeviceVersion), SystemInfo.graphicsDeviceName);
                        errorLog.Add(errorString);
                    }
                }

                foreach (var platform in ComputePlatform.Platforms)
                {
                    foreach (var device in platform.Devices)
                    {
                        FluvioOpenCL.ForceInitialize(device);
                        fluvioComputeShader.CompileOpenCLProgram();
                    }
                }
            }
            EditorGUI.EndDisabledGroup();

            if (m_ErrorLogParsed == null)
            {
                m_ErrorLogParsed = new List<GUIContent[]>();
            }
            else
            {
                m_ErrorLogParsed.Clear();
            }

            foreach (var error in errorLog)
            {
                try
                {
                    // Split error
                    // Item 0: line
                    // Item 1: column
                    // Item 2: error/warning
                    // Item 3: message
                    // Item 4: Platform
                    // Item 5: Device
                    var errorSplit = error.Split(':');
                    var isError = errorSplit[2].Contains("error");
                    var iconName = isError ? "console.erroricon.sml" : "console.warnicon.sml";
                    var content = new GUIContent(EditorGUIUtility.IconContent(iconName, error))
                    {
                        text = string.Format("{0}{1}{2}",
                                             isError ? "<color=red>" : string.Empty,
                                             errorSplit[3],
                                             isError ? "</color>" : string.Empty)
                    };
                    m_ErrorLogParsed.Add(new[]
                    {new GUIContent(string.Format("{0}|{1}", errorSplit[4], errorSplit[5])), content});
                }
                catch (Exception e)
                {
                    FluvioDebug.LogException(e);
                    var content = new GUIContent(EditorGUIUtility.IconContent("console.infoicon.sml", error))
                    {
                        text = error
                    };
                    m_ErrorLogParsed.Add(new[] {new GUIContent("Unknown Platform|Unknown Device"), content});
                }
            }

            var style = new GUIStyle(EditorStyles.miniLabel) {richText = true};
            var lastPlatform = "";
            var lastDevice = "";
            foreach (var item in m_ErrorLogParsed)
            {
                var split = item[0].text.Split('|');
                var platform = split[0];
                var device = split[1];

                if (lastPlatform != platform)
                {
                    GUILayout.Label(platform, EditorStyles.boldLabel);
                    EditorGUILayout.Separator();
                }
                GUILayout.BeginHorizontal();
                if (lastPlatform != platform || lastDevice != device)
                {
                    EditorGUILayout.PrefixLabel(device, EditorStyles.miniLabel, style);
                }
                else
                {
                    EditorGUILayout.PrefixLabel(" ", EditorStyles.miniLabel, style);
                }
                EditorGUILayout.LabelField(GUIContent.none, item[1], style);
                GUILayout.EndHorizontal();
                lastPlatform = platform;
                lastDevice = device;
            }
        }
        // TODO: Combine ClearLog duplication
        static void ClearLog()
        {
            // This simply does "LogEntries.Clear()" the long way:
            var logEntries = Type.GetType("UnityEditorInternal.LogEntries,UnityEditor.dll");
            var clearMethod = logEntries.GetMethod("Clear", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public);
            clearMethod.Invoke(null, null);
        }
    }  
}
