// FluvioEditorHelpers.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

//! \cond PRIVATE
#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif
#if UNITY_5_0_PLUS && !UNITY_5_0 && !UNITY_5_1 && !UNITY_5_2
#define UNITY_5_3_PLUS
#endif
#pragma warning disable 429
#pragma warning disable 162
// ReSharper disable ConditionIsAlwaysTrueOrFalse
// ReSharper disable HeuristicUnreachableCode
// ReSharper disable UnreachableCode
using System.Text;
using JetBrains.Annotations;            
using System;
using System.IO;
using System.Reflection;
using Thinksquirrel.Fluvio.Internal;
using Thinksquirrel.Fluvio;
using UnityEditor;
#if UNITY_5_3_PLUS
using UnityEditor.SceneManagement;
#endif
using UnityEngine;
using Object = UnityEngine.Object;

namespace Thinksquirrel.FluvioEditor
{
    public static class FluvioEditorHelpers
    {
        #region Static and Constant Fields
        const string k_NumberPattern = " ({0})";
        #endregion

        #region Public API
        public static T CreateAsset<T>(T obj, string folder, string fileName) where T : Object
        {
            string path;

            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                path = Application.dataPath.Replace("/", "\\") + "\\Fluvio\\" + folder;
            }
            else
            {
                path = Application.dataPath + "/Fluvio/" + folder;
            }
            Directory.CreateDirectory(path);

            var path2 = "Assets/Fluvio/" + folder + "/" + fileName;

            var currentObj = AssetDatabase.LoadAssetAtPath(path2, typeof(T)) as T;
            if (currentObj)
            {
                EditorUtility.CopySerialized(obj, currentObj);
                AssetDatabase.Refresh();
            }
            else
            {
                AssetDatabase.CreateAsset(obj, path2);
                AssetDatabase.Refresh();
                currentObj = obj;
            }

            return currentObj;
        }
        public static T CreateProjectSettingsAsset<T>(T obj, string folder, string fileName) where T : Object
        {
            string path;

            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                path = Application.dataPath.Replace("/", "\\") + "\\Fluvio-ProjectSettings\\" + folder;
            }
            else
            {
                path = Application.dataPath + "/Fluvio-ProjectSettings/" + folder;
            }
            Directory.CreateDirectory(path);

            var path2 = "Assets/Fluvio-ProjectSettings/" + folder + "/" + fileName;

            var currentObj = AssetDatabase.LoadAssetAtPath(path2, typeof(T)) as T;
            if (currentObj)
            {
                EditorUtility.CopySerialized(obj, currentObj);
                AssetDatabase.Refresh();
            }
            else
            {
                AssetDatabase.CreateAsset(obj, path2);
                AssetDatabase.Refresh();
                currentObj = obj;
            }

            return currentObj;
        }
        public static string ReadProjectSettingsTextFile(string folder, string extension)
        {
            string path;
            string path2;
            string result = null;

            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                path = Application.dataPath.Replace("/", "\\") + "\\Fluvio-ProjectSettings\\" + folder;
                Directory.CreateDirectory(path);

                path2 = EditorUtility.OpenFilePanel("Open File", "Assets/Fluvio-ProjectSettings/" + folder, extension);

                if (!string.IsNullOrEmpty(path2))
                    result = File.ReadAllText(path2);
            }
            else
            {
                path = Application.dataPath + "/Fluvio-ProjectSettings/" + folder;
                Directory.CreateDirectory(path);

                path2 = EditorUtility.OpenFilePanel("Open File", "Assets/Fluvio-ProjectSettings/" + folder, extension);

                if (!string.IsNullOrEmpty(path2))
                    result = File.ReadAllText(path2);
            }

            AssetDatabase.Refresh();
            return result;
        }
        public static void RegisterUndo(string name, params Object[] objects)
        {
            if (objects != null && objects.Length > 0)
            {
                Undo.RecordObjects(objects, name);
                foreach (var obj in objects)
                {
                    if (obj == null) continue;
                    EditorUtility.SetDirty(obj);
                }
            }
        }
        public static void WriteProjectSettingsTextFile(string obj, string folder, string fileName, string extension)
        {
            string path;
            string path2;
            string uniqueName;

            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                path = Application.dataPath.Replace("/", "\\") + "\\Fluvio-ProjectSettings\\" + folder;
                Directory.CreateDirectory(path);

                uniqueName = NextAvailableFilename(path + "\\" + fileName);
                path2 = EditorUtility.SaveFilePanel("Save File", "Assets/Fluvio-ProjectSettings/" + folder,
                                                    Path.GetFileName(uniqueName), extension);

                if (!string.IsNullOrEmpty(path2))
                    File.WriteAllText(path2, obj);
            }
            else
            {
                path = Application.dataPath + "/Fluvio-ProjectSettings/" + folder;
                Directory.CreateDirectory(path);

                uniqueName = NextAvailableFilename(path + "/" + fileName);
                path2 = EditorUtility.SaveFilePanel("Save File", "Assets/Fluvio-ProjectSettings/" + folder,
                                                    Path.GetFileName(uniqueName), extension);

                if (!string.IsNullOrEmpty(path2))
                    File.WriteAllText(path2, obj);
            }

            AssetDatabase.Refresh();
        }
        #endregion

        static string GetNextFilename(string pattern)
        {
            var tmp = string.Format(pattern, 1);
            if (tmp == pattern)
                throw new ArgumentException("The pattern must include an index place-holder", "pattern");

            if (!File.Exists(tmp))
                return tmp; // short-circuit if no matches

            int min = 1, max = 2; // min is inclusive, max is exclusive/untested

            while (File.Exists(string.Format(pattern, max)))
            {
                min = max;
                max *= 2;
            }

            while (max != min + 1)
            {
                var pivot = (max + min)/2;
                if (File.Exists(string.Format(pattern, pivot)))
                    min = pivot;
                else
                    max = pivot;
            }

            return string.Format(pattern, max);
        }
        static string NextAvailableFilename(string path)
        {
            // Shortcut if already available
            if (!File.Exists(path))
                return path;

            // If path has extension then insert the number pattern just before the extension and return next filename
            return Path.HasExtension(path) ? GetNextFilename(path.Insert(path.LastIndexOf(Path.GetExtension(path), StringComparison.Ordinal), k_NumberPattern)) : GetNextFilename(path + k_NumberPattern);

            // Otherwise just append the pattern to the path and return next filename
        }

        public static string ReferenceManualUrl()
        {
            return "https://docs.thinksquirrel.com/fluvio/" + VersionInfo.version + "/reference/";
        }
        public static string SupportForumUrl()
        {
            return "https://support.thinksquirrel.com/hc/communities/public/topics/200145254-Fluvio";
        }
        public static string ArchiveUrl()
        {
            return "https://docs.thinksquirrel.com/fluvio/archives/" + VersionInfo.version + ".zip";
        }
        public static string ComponentUrl(Type type, bool includeBaseUrl = true)
        {
            var fullTypeName = type.ToString();
            var names = fullTypeName.Split('.');
            fullTypeName = names[names.Length - 1];
            var sb = new StringBuilder();
            sb.Append(fullTypeName.ToLowerInvariant());
            sb.Append(".html");

            return includeBaseUrl ? string.Format("{0}{1}", ReferenceManualUrl(), sb) : sb.ToString();
        }
        public static string ScriptingUrl(Type type, bool includeBaseUrl = true)
        {
            var fullTypeName = type.ToString();
            fullTypeName = fullTypeName.Replace(".", "_1_1_");
            var sb = new StringBuilder();
            sb.Append("class_");
            sb.Append(HumanizeString(fullTypeName).Replace(' ', '_').ToLowerInvariant());
            sb.Append(".html");

            return includeBaseUrl ? string.Format("{0}{1}", ReferenceManualUrl(), sb) : sb.ToString();
        }
        public static string ContentLink()
        {
            return VersionInfo.isFreeEdition ? ContentLinkFree() : VersionInfo.isProEdition ? ContentLinkPro() : ContentLinkStandard();
        }
        public static string ContentLinkPro()
        {
            return "content/1019";
        }
        public static string ContentLinkStandard()
        {
            return "content/2866";
        }
        public static string ContentLinkFree()
        {
            return "content/2888";
        }
        public static string SearchLink()
        {
            return "https://www.assetstore.unity3d.com/en/#!/search/page=1/sortby=relevance/query=Fluvio&publisher:Thinksquirrel&size:5-100000";
        }
        static string HumanizeString(string input)
        {
            var sb = new StringBuilder();

            var last = char.MinValue;
            foreach (var c in input)
            {
                if (char.IsLower(last) &&
                    char.IsUpper(c))
                {
                    sb.Append(' ');
                }

                sb.Append(c);

                last = c;
            }
            return sb.ToString();
        }
    }
}

// Helper class for JavaScript installation
[InitializeOnLoad]
static class JavaScriptInstaller
{
    #region Constructors
    static JavaScriptInstaller()
    {
        if (EditorPrefs.GetBool("Thinksquirrel.FluvioEditor.InstallForJavaScript", false))
            EditorApplication.update += DoJavaScriptInstaller;

        EditorPrefs.DeleteKey("Thinksquirrel.FluvioEditor.InstallForJavaScript");
    }
    #endregion

    static void DoJavaScriptInstaller()
    {
        EditorApplication.update -= DoJavaScriptInstaller;

        var isWindows = Application.platform == RuntimePlatform.WindowsEditor;

        // Get paths
        var dataPath = isWindows ? Application.dataPath.Replace("/", "\\") : Application.dataPath;
        var plugins = Path.Combine(dataPath, "Plugins");
        var pluginsFluvio = Path.Combine(plugins, "Fluvio");
        const string fluvioMainRel = "Assets/Fluvio/_Main/";
        const string pluginsFluvioRel = "Assets/Plugins/Fluvio/";

        // Delete any old Fluvio DLL files in the plugins folder
        if (Directory.Exists(pluginsFluvio))
        {
            var del = false;

            foreach (var file in Directory.GetFiles(pluginsFluvio, "Fluvio.Runtime*", SearchOption.AllDirectories))
            {
                del = true;
                File.Delete(file);
            }

            if (del)
                AssetDatabase.Refresh();
        }

        // Check to see if the plugins folder exists
        if (!Directory.Exists(plugins))
        {
            AssetDatabase.CreateFolder("Assets", "Plugins");
        }

        // Check to see if the Fluvio folder exists under the plugins folder
        if (!Directory.Exists(pluginsFluvio))
        {
            AssetDatabase.CreateFolder("Assets/Plugins", "Fluvio");
        }

        var error = AssetDatabase.MoveAsset(fluvioMainRel + "Fluvio.Runtime.dll", pluginsFluvioRel + "Fluvio.Runtime.dll");

        if (!string.IsNullOrEmpty(error))
        {
            Debug.LogError("Unable to move Fluvio.Runtime.dll: " + error);
        }

        error = AssetDatabase.MoveAsset(fluvioMainRel + "Fluvio.Runtime.xml", pluginsFluvioRel + "Fluvio.Runtime.xml");

        if (!string.IsNullOrEmpty(error))
        {
            Debug.LogError("Unable to move Fluvio.Runtime.xml: " + error);
        }

        AssetDatabase.Refresh();
    }
}

// Helper class for loading example scenes
[InitializeOnLoad]
static class ExampleSceneLoader
{
    static string s_SceneName;

    #region Constructors
    static ExampleSceneLoader()
    {
        if (EditorPrefs.HasKey("Thinksquirrel.FluvioEditor.OpenExampleScene"))
            EditorApplication.update += DoOpenExampleScene;

        s_SceneName = EditorPrefs.GetString("Thinksquirrel.FluvioEditor.OpenExampleScene");
        EditorPrefs.DeleteKey("Thinksquirrel.FluvioEditor.OpenExampleScene");
    }
    #endregion

    static void DoOpenExampleScene()
    {
        EditorApplication.update -= DoOpenExampleScene;

        #if UNITY_5_3_PLUS
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        #else
        if (!EditorApplication.SaveCurrentSceneIfUserWantsTo()) return;
        #endif

        var sceneName = s_SceneName;

        var scenes = AssetDatabase.FindAssets(sceneName, new[] {"Assets/Fluvio Examples"});

        foreach (var guid in scenes)
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);

            if (!path.EndsWith(".unity") || !Path.GetFileNameWithoutExtension(path).Contains(sceneName)) continue;

            #if UNITY_5_3_PLUS
            EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
            #else
            EditorApplication.OpenScene(path);
            #endif
            break;
        }
    }
}

static class FluvioBatchMode
{
    static bool CheckLog(bool clear)
    {
        var assembly = Assembly.GetAssembly(typeof (SceneView));
        var logEntries = assembly.GetType("UnityEditorInternal.LogEntries");

        if (clear)
        {
            logEntries.GetMethod("Clear").Invoke(new object(), null);
        }

        var count = (int) logEntries.GetMethod("GetCount").Invoke(new object(), null);

        return count == 0;
    }

    [UsedImplicitly]
    static void ExportPackageInternal()
    {
#if UNITY_5_3_PLUS
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
#else
        EditorApplication.NewScene();
#endif

        if (!CheckLog(true))
        {
            Debug.LogError(string.Format("[{0}] Compilation errors present! Aborting...", typeof (FluvioBatchMode).Name));
            EditorApplication.Exit(1);
            return;            
        }

        var packagePaths = new[]
        {        
#if FLUVIO_EXAMPLES || FLUVIO_SELECTIONS
                "Assets/Fluvio Shared/Common",
                "Assets/Fluvio Shared/VersionSpecific/Common",
#endif
#if !FLUVIO_EXAMPLES && !FLUVIO_SELECTIONS
                "Assets/Fluvio/_Main/Fluvio.Runtime.dll",
                "Assets/Fluvio/_Main/Fluvio.Runtime.xml",
                "Assets/Fluvio/Editor/Fluvio.Editor.dll",
                "Assets/Plugins/Android/libs",
                "Assets/Fluvio/_Main/PlatformSource"
#elif FLUVIO_EXAMPLES_PAINT
                "Assets/Fluvio Examples/Common",
                "Assets/Fluvio Examples/Paint/Common",
                "Assets/Fluvio Examples/VersionSpecific/Common",
                "Assets/Fluvio Examples/VersionSpecific/Paint"
#elif FLUVIO_EXAMPLES_THREE
                "Assets/Fluvio Examples/Common",
                "Assets/Fluvio Examples/Three/Common",
                "Assets/Fluvio Examples/VersionSpecific/Common",
                "Assets/Fluvio Examples/VersionSpecific/Three"
#elif FLUVIO_EXAMPLES_WATERFALL
                "Assets/Fluvio Examples/Common",
                "Assets/Fluvio Examples/Waterfall/Common",
                "Assets/Fluvio Examples/VersionSpecific/Common",
                "Assets/Fluvio Examples/VersionSpecific/Waterfall"
#elif FLUVIO_SELECTIONS_FOUNTAINS
                "Assets/Fluvio Selections/Common",
                "Assets/Fluvio Selections/Fountains/Common",
                "Assets/Fluvio Selections/VersionSpecific/Common",
                "Assets/Fluvio Selections/VersionSpecific/Fountains"
#endif
        };

        string packageName, asInstaller, edition;
        
        // ReSharper disable once RedundantAssignment
        if (VersionInfo.isProEdition)
        {
            packageName = "FluvioPro";
            asInstaller = "ASInstaller_FluvioPro";
            edition = "Fluvio Pro";
        }
        else if (VersionInfo.isFreeEdition)
        {
            packageName = "FluvioFree";
            asInstaller = "ASInstaller_FluvioFree";
            edition = "Fluvio Free";
        }
        else
        {
            packageName = "FluvioStandard";
            asInstaller = "ASInstaller_FluvioStandard";
            edition = "Fluvio";
        }

#if FLUVIO_EXAMPLES_PAINT
        packageName = "FluvioExamplesPaint";
        asInstaller = "ASInstaller_FluvioExamplesPaint";
        edition = "Fluvio Examples: Paint";
#elif FLUVIO_EXAMPLES_THREE
        packageName = "FluvioExamplesThree";
        asInstaller = "ASInstaller_FluvioExamplesThree";        
        edition = "Fluvio Examples: Three";
#elif FLUVIO_EXAMPLES_WATERFALL
        packageName = "FluvioExamplesWaterfall";
        asInstaller = "ASInstaller_FluvioExamplesWaterfall";        
        edition = "Fluvio Examples: Waterfall";
#elif FLUVIO_SELECTIONS_FOUNTAINS
        packageName = "FluvioSelectionsFountains";
        asInstaller = "ASInstaller_FluvioSelectionsFountains";
        edition = "Fluvio Selections: Fountains";
#endif

        var name = string.Format("{0}.unitypackage", packageName);

#if UNITY_5_3_PLUS
        const string platform = "5.3.0";
#elif UNITY_5_0_PLUS
        const string platform = "5.0.0";
#else
        const string platform = "4.6.0";
#endif

        var finalProjectRoot =
            new DirectoryInfo(Path.Combine(Application.dataPath, "../../../AssetStoreProjects")).FullName;

        var finalProjectPath = Path.Combine(Path.Combine(finalProjectRoot, platform), edition.Replace(":", "-"));
        
        var dataPathFinal = Path.Combine(finalProjectPath, "Assets");
        var destinationPath = Path.Combine(dataPathFinal, asInstaller);

        AssetDatabase.ExportPackage(packagePaths, Path.Combine(destinationPath, name), ExportPackageOptions.Recurse);
        
        // Remove plugins path
        var pluginsPath = Path.Combine(dataPathFinal, "Plugins").Replace('\\', '/');
        var pluginsMetaPath = Path.Combine(dataPathFinal, "Plugins.meta").Replace('\\', '/');

        if (Directory.Exists(pluginsPath)) Directory.Delete(pluginsPath, true);
        if (File.Exists(pluginsMetaPath)) File.Delete(pluginsMetaPath);

        // Remove examples/selections paths
        var examplesPath = Path.Combine(dataPathFinal, "Fluvio Examples").Replace('\\', '/');
        var examplesMetaPath = Path.Combine(dataPathFinal, "Fluvio Examples.meta").Replace('\\', '/');
        var selectionsPath = Path.Combine(dataPathFinal, "Fluvio Selections").Replace('\\', '/');
        var selectionsMetaPath = Path.Combine(dataPathFinal, "Fluvio Selections.meta").Replace('\\', '/');
        var sharedPath = Path.Combine(dataPathFinal, "Fluvio Shared").Replace('\\', '/');
        var sharedMetaPath = Path.Combine(dataPathFinal, "Fluvio Shared.meta").Replace('\\', '/');
        
        if (Directory.Exists(examplesPath)) Directory.Delete(examplesPath, true);
        if (File.Exists(examplesMetaPath)) File.Delete(examplesMetaPath);
        if (Directory.Exists(selectionsPath)) Directory.Delete(selectionsPath, true);
        if (File.Exists(selectionsMetaPath)) File.Delete(selectionsMetaPath);
        if (Directory.Exists(sharedPath)) Directory.Delete(sharedPath, true);
        if (File.Exists(sharedMetaPath)) File.Delete(sharedMetaPath);

        // Examples/Selections: Remove Fluvio path
#if FLUVIO_EXAMPLES || FLUVIO_SELECTIONS
        var fluvioPath = Path.Combine(dataPathFinal, "Fluvio").Replace('\\', '/');
        var fluvioMetaPath = Path.Combine(dataPathFinal, "Fluvio.meta").Replace('\\', '/');

        if (Directory.Exists(fluvioPath)) Directory.Delete(fluvioPath, true);
        if (File.Exists(fluvioMetaPath)) File.Delete(fluvioMetaPath);
#else
        // Remove default materials
        var defaultMatPath =
            Path.Combine(Path.Combine(Path.Combine(dataPathFinal, "Fluvio"), "Defaults"), "Default-Fluvio.mat")
                .Replace('\\', '/');
        var defaultMatMetaPath =
            Path.Combine(Path.Combine(Path.Combine(dataPathFinal, "Fluvio"), "Defaults"), "Default-Fluvio.mat.meta")
                .Replace('\\', '/');
        
        if (File.Exists(defaultMatPath)) File.Delete(defaultMatPath);
        if (File.Exists(defaultMatMetaPath)) File.Delete(defaultMatMetaPath);
        
        // Remove fluid effect shader for different platforms
        var shaderPath = new DirectoryInfo(Path.Combine(Path.Combine(Path.Combine(dataPathFinal, "Fluvio"), "Shaders"), "FluidEffect").Replace('\\', '/'));
        var shaderFiles = shaderPath.GetFiles("*FluidEffect*", SearchOption.AllDirectories);

        foreach (var shaderFile in shaderFiles)
        {
#if UNITY_5_0_PLUS
            if (!shaderFile.Name.Contains("4x")) continue;
#else
            if (
                !shaderFile.Name.Contains("Specular") && 
                !shaderFile.Name.Contains("Metal") && 
                shaderFile.Name != "FluidEffect.cginc" &&
                shaderFile.Name != "FluidEffectShadow.cginc")
            {
                continue;
            }
#endif
            if (shaderFile.Exists)
            {
                shaderFile.Delete();
                var metaFile = new FileInfo(shaderFile.FullName + ".meta");
                if (metaFile.Exists) metaFile.Delete();
            }
        }

        if (!VersionInfo.isProEdition)
        {
            // Preprocess compute shaders
            var computeShaderPath = new DirectoryInfo(Path.Combine(dataPathFinal, "Fluvio").Replace('\\', '/'));
            var computeshaderIncludes = computeShaderPath.GetFiles("*.cginc", SearchOption.AllDirectories);

            foreach (var computeShaderInclude in computeshaderIncludes)
            {
                if (!computeShaderInclude.Exists)
                    continue;

                var dir = computeShaderInclude.Directory.Name;
                
                if (dir == "Includes" || dir == "FluidMixer" || dir == "FluidTouch")
                    continue;

                var path = computeShaderInclude.FullName;
                var source = File.ReadAllText(path);
                source = FluvioComputeShader.RemoveComments(source);
                source = FluvioComputeShader.Minify(source);
                File.WriteAllText(computeShaderInclude.FullName, source);
            }
        }
#endif
        if (CheckLog(false)) return;

        Debug.LogError(string.Format("[{0}] Errors present! Aborting...", typeof (FluvioBatchMode).Name));
        EditorApplication.Exit(1);
    }
}
//! \endcond