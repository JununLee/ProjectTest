// FluidCollider2DInspector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using Thinksquirrel.Fluvio;
using UnityEditor;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof (FluidCollider2D))]
    [CanEditMultipleObjects]
    public class FluidCollider2DInspector : FluidColliderBaseInspector {}
}
