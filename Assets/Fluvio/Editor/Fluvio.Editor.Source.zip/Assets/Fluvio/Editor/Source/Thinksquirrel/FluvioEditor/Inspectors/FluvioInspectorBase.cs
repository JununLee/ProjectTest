// FluvioInspectorBase.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

#if !UNITY_4_6 && !UNITY_4_7
#define UNITY_5_0_PLUS
#endif

using System;
using System.Collections.Generic;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    public abstract class FluvioInspectorBase : Editor
    {
        #region Awake, Destroy, Reset
        #if !UNITY_5_0_PLUS
        [NonSerialized] int m_UniqueID = int.MinValue;
        [NonSerialized] static int m_UniqueIDPtr = int.MinValue;
        [NonSerialized] static readonly HashSet<int> s_ActiveObjects = new HashSet<int>();
        [NonSerialized] static readonly object s_IdentifierLock = new object();
        #endif
        //! \cond PRIVATE
        [UsedImplicitly]
        protected virtual void OnEnable()
        {
            FluvioSettings.InitializeRuntimeHelper();
        }
        [UsedImplicitly]
        protected virtual void OnDisable() { }
        [UsedImplicitly]
        protected virtual void OnDestroy()
        {
            #if !UNITY_5_0_PLUS
            if (m_UniqueID != int.MinValue)
            {
                s_ActiveObjects.Remove(m_UniqueID);
            }
            #endif
        }
        [UsedImplicitly]
        protected virtual void Reset() { }
        //! \endcond

#if !UNITY_5_0_PLUS
        public static implicit operator bool (FluvioInspectorBase exists)
        {
            return !CompareBaseFluvioObjects(exists, null);
        }

        public static bool operator ==(FluvioInspectorBase x, FluvioInspectorBase y)
        {
            return CompareBaseFluvioObjects(x, y);
        }

        public static bool operator !=(FluvioInspectorBase x, FluvioInspectorBase y)
        {
            return !CompareBaseFluvioObjects(x, y);
        }
        public override bool Equals(object o)
        {
            return CompareBaseFluvioObjects(this, o as FluvioInspectorBase);
        }
        public override int GetHashCode()
        {
            
            if (m_UniqueID == int.MinValue)
            {
                lock (s_IdentifierLock)
                {
                    m_UniqueID = ++m_UniqueIDPtr;
                    s_ActiveObjects.Add(m_UniqueID);
                }
            }
            return m_UniqueID;
        }
    
        static bool CompareBaseFluvioObjects(FluvioInspectorBase lhs, FluvioInspectorBase rhs)
        {
            var lhsIsNull = ReferenceEquals(lhs, null);
            var rhsIsNull = ReferenceEquals(rhs, null);
            if (rhsIsNull && lhsIsNull) return true;
            if (rhsIsNull) return !s_ActiveObjects.Contains(lhs.GetHashCode());
            if (lhsIsNull) return !s_ActiveObjects.Contains(rhs.GetHashCode());
            return lhs.GetHashCode() == rhs.GetHashCode();
        }
#endif
        #endregion
        // Analysis disable ConvertToAutoProperty

        #region Static and Constant Fields
        static readonly float[] s_Vector3Floats = new float[3];
        static readonly string[] s_XYZLabels = {"X  ", "Y  ", "Z  "};
        const int k_FieldHeight = 13;
        #endregion

        #region Public API
        public static Vector3 Vector3Field(Rect position, Vector3 value, GUIStyle labelStyle, GUIStyle style)
        {
            s_Vector3Floats[0] = value.x;
            s_Vector3Floats[1] = value.y;
            s_Vector3Floats[2] = value.z;
            position.height = 16;
            EditorGUI.BeginChangeCheck();
            MultiFloatField(position, s_XYZLabels, s_Vector3Floats, 13, labelStyle, style);
            if (EditorGUI.EndChangeCheck())
            {
                value.x = s_Vector3Floats[0];
                value.y = s_Vector3Floats[1];
                value.z = s_Vector3Floats[2];
            }
            return value;
        }
        #endregion

        protected static Rect GetControlRect(int height)
        {
            var guiStyle = new GUIStyle {margin = new RectOffset(0, 0, 2, 2)};
            return GUILayoutUtility.GetRect(0, k_FieldHeight, guiStyle);
        }
        protected static Rect PrefixLabel(Rect totalPosition, GUIContent label)
        {
            var labelPosition = new Rect(totalPosition.x + editorGUIIndent, totalPosition.y,
                                         EditorGUIUtility.labelWidth - editorGUIIndent, k_FieldHeight);
            var result = new Rect(totalPosition.x + EditorGUIUtility.labelWidth, totalPosition.y,
                                  totalPosition.width - EditorGUIUtility.labelWidth, totalPosition.height);
            EditorGUI.HandlePrefixLabel(totalPosition, labelPosition, label, 0, "ShurikenLabel");
            return result;
        }
        protected static bool PropertyField(SerializedProperty property)
        {
            return PropertyField(property, ObjectNames.NicifyVariableName(property.name));
        }
        protected static bool PropertyField(Rect r, SerializedProperty property)
        {
            return PropertyField(r, property, ObjectNames.NicifyVariableName(property.name));
        }
        protected static bool PropertyField(SerializedProperty property, string label)
        {
            return PropertyField(property, new GUIContent(label));
        }
        protected static bool PropertyField(Rect r, SerializedProperty property, string label)
        {
            return PropertyField(r, property, new GUIContent(label));
        }
        protected static bool PropertyField(SerializedProperty property, GUIContent label)
        {
            return PropertyField(GetControlRect(k_FieldHeight), property, label);
        }
        protected static bool PropertyField(Rect r, SerializedProperty property, GUIContent label)
        {
            var rect = r;         
            // HACK: Vector field minor visual fixes
            if (r.height <= k_FieldHeight + Vector3.kEpsilon)
            {
                var smallWidth = Screen.width < 333;

                if (smallWidth && property.propertyType == SerializedPropertyType.Vector2 ||
                    property.propertyType == SerializedPropertyType.Vector3 ||
                    property.propertyType == SerializedPropertyType.Vector4)
                {
                    GUILayoutUtility.GetRect(0, k_FieldHeight);
                }

                // Vector2 extended width
                if (!smallWidth && property.propertyType == SerializedPropertyType.Vector2)
                {
                    var lastRect = GUILayoutUtility.GetLastRect();
                    var propRect = PrefixLabel(rect, label);
                    rect.width += (lastRect.width/3f) - 13f;
                    return EditorGUI.PropertyField(propRect, property, GUIContent.none);
                }
            }
            return EditorGUI.PropertyField(rect, property, label);
        }
        protected static Enum EnumPopup(Enum selected, string label)
        {
            return EnumPopup(selected, new GUIContent(label));
        }
        protected static Enum EnumPopup(Enum selected, GUIContent label)
        {
            var rect = GetControlRect(k_FieldHeight);
            var result = EditorGUI.EnumPopup(rect, label, selected);
            return result;
        }
        protected static float FloatField(float value, string label)
        {
            return FloatField(value, new GUIContent(label));
        }
        protected static float FloatField(float value, GUIContent label)
        {
            var rect = GetControlRect(k_FieldHeight);
            var result = EditorGUI.FloatField(rect, label, value);
            return result;
        }
        protected static bool Toggle(bool value, string label)
        {
            return Toggle(value, new GUIContent(label));
        }
        protected static bool Toggle(bool value, GUIContent label)
        {
            var rect = GetControlRect(k_FieldHeight);
            var result = EditorGUI.Toggle(rect, label, value);
            return result;
        }
        protected static void ChangeEditorStyles()
        {
            // HACK: Changing default editor styles
            var editorStyles = typeof(EditorStyles).GetFieldValue("s_Current");
            
            var toggle = GetStyle("ShurikenToggle");
            var labelStyle = GetStyle("ShurikenLabel");
            var textField = GetStyle("ShurikenValue");
            var foldout = new GUIStyle(GetStyle("Foldout"))
            {
                font = labelStyle.font, 
                fontSize = labelStyle.fontSize
            };
            foldout.contentOffset = new Vector2(12, foldout.contentOffset.y);
            foldout.padding.left = 2;
            var popup = GetStyle("ShurikenPopUp");
            var objectField = GetStyle("ShurikenObjectField");

            editorStyles.SetFieldValue("m_Toggle", toggle);
            editorStyles.SetFieldValue("m_Label", labelStyle);
            editorStyles.SetFieldValue("m_TextField", textField);
            editorStyles.SetFieldValue("m_NumberField", textField);
            editorStyles.SetFieldValue("m_Foldout", foldout);
            editorStyles.SetFieldValue("m_Popup", popup);
            editorStyles.SetFieldValue("m_ObjectField", objectField);
        }
        protected static void ResetEditorStyles()
        {
            // HACK: Changing default editor styles
            var editorStyles = typeof(EditorStyles).GetFieldValue("s_Current");
            
            editorStyles.Invoke("InitSharedStyles");
        }
        static GUIStyle GetStyle(string styleName)
        {
            return GUI.skin.FindStyle(styleName) ?? EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector).FindStyle(styleName);
        }
        static void MultiFloatField(Rect position, string[] subLabels, float[] values, float labelWidth,
                                    GUIStyle labelStyle, GUIStyle style)
        {
            var num = values.Length;
            position.x += 13;
            position.width -= 13*num;
            var num2 = (position.width - (float) (num - 1)*2)/num;
            var position2 = new Rect(position) {width = num2};
            var labelWidth2 = EditorGUIUtility.labelWidth;
            var indentLevel = EditorGUI.indentLevel;
            EditorGUIUtility.labelWidth = labelWidth;
            EditorGUI.indentLevel = 0;
            for (var i = 0; i < values.Length; i++)
            {
                var position3 = position2;
                position3.x -= 13;
                position3.width = 13;
                EditorGUI.LabelField(position3, subLabels[i], labelStyle);

                values[i] = EditorGUI.FloatField(position2, values[i], style);
                position2.x += num2 + 15;
            }
            EditorGUIUtility.labelWidth = labelWidth2;
            EditorGUI.indentLevel = indentLevel;
        }
        [MenuItem("CONTEXT/FluvioMonoBehaviourBase/[Fluvio] API Reference")]
        [MenuItem("CONTEXT/FluvioInspectorBase/[Fluvio] API Reference")]
        [UsedImplicitly]
        static void OpenAPIReference(MenuCommand command)
        {
            Application.OpenURL(FluvioPreferences.ScriptingUrl(command.context.GetType()));
        }
        [MenuItem("CONTEXT/FluvioMonoBehaviourBase/[Fluvio] Help")]
        [MenuItem("CONTEXT/FluvioInspectorBase/[Fluvio] Help")]
        [UsedImplicitly]
        static void OpenHelp(MenuCommand command)
        {
            Application.OpenURL(FluvioPreferences.ComponentUrl(command.context.GetType()));
        }        
        static float editorGUIIndent
        {
            get { return (float) EditorGUI.indentLevel*15; }
        }
    }
}
