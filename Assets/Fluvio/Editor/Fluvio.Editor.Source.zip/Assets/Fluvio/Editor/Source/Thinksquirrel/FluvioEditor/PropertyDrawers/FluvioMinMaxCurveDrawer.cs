using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using JetBrains.Annotations;
using Thinksquirrel.Fluvio;
using Thinksquirrel.Fluvio.Plugins;
using Thinksquirrel.FluvioEditor.Inspectors;
using UnityEditor;
using UnityEngine;
using Keyframe = UnityEngine.Keyframe;
using Object = UnityEngine.Object;

namespace Thinksquirrel.FluvioEditor.PropertyDrawers
{
    [CustomPropertyDrawer(typeof(FluvioMinMaxCurve))]
    public class FluvioMinMaxCurveDrawer : FluvioPropertyDrawerBase
    {
        static readonly Rect s_SignedRange = new Rect(0.0f, -1.0f, 1.0f, 2.0f);
        static readonly Rect s_UnsignedRange = new Rect(0.0f, 0.0f, 1.0f, 1.0f);

        SerializedProperty m_Scalar;
        SerializedProperty m_Curve;
        SerializedProperty m_Min;
        SerializedProperty m_Max;
        Editor m_Inspector;
        object m_CurveEditor;

        public override void OnGUI(Rect pos, SerializedProperty mmCurve, GUIContent label)
        {
            try
            {
                var state = (FluvioMinMaxCurveState)mmCurve.FindPropertyRelative("m_MinMaxState").enumValueIndex;
                var shortHeight = pos.height <= 13f;

                var rect1 = pos;

                var popupRect = GetPopupRect(rect1);
                rect1 = SubtractPopupWidth(rect1);
                var position = PrefixLabel(rect1, label);
                position.height = pos.height;

                switch (state)
                {
                    case FluvioMinMaxCurveState.Constant:
                        var constant = mmCurve.FindPropertyRelative("m_MaxConstant");
                        constant.floatValue = FloatDraggable(rect1, constant, 1.0f, EditorGUIUtility.labelWidth);
                        break;
                    case FluvioMinMaxCurveState.RandomBetweenTwoConstants:
                        position.width = (position.width - 20.0f) * 0.5f;
                        var minConstant = mmCurve.FindPropertyRelative("m_MinConstant");
                        var maxConstant = mmCurve.FindPropertyRelative("m_MaxConstant");
                        position.xMin -= 20f;
                        EditorGUI.BeginChangeCheck();
                        var min = FloatDraggable(position, minConstant, 1.0f, 20.0f, "g5");
                        if (EditorGUI.EndChangeCheck()) minConstant.floatValue = min;
                        position.x += position.width;
                        EditorGUI.BeginChangeCheck();
                        var max = FloatDraggable(position, maxConstant, 1.0f, 20.0f, "g5");
                        if (EditorGUI.EndChangeCheck()) maxConstant.floatValue = max;
                        break;
                    default:
                        if (shortHeight)
                        {
                            var ranges = mmCurve.FindPropertyRelative("m_IsSigned").boolValue ? s_SignedRange : s_UnsignedRange;
                            var minCurve = state != FluvioMinMaxCurveState.RandomBetweenTwoCurves ? null : mmCurve.FindPropertyRelative("m_MinCurve");
                            GUICurveField(position, mmCurve, mmCurve.FindPropertyRelative("m_MaxCurve"), minCurve, GetCurveColor(), ranges, OnCurveAreaMouseDown);
                        }
                        else
                        {
                            var twoCurves = state == FluvioMinMaxCurveState.RandomBetweenTwoCurves;
                            position.width *= twoCurves ? 0.33f : 0.5f;
                            EditorGUI.PropertyField(position, mmCurve.FindPropertyRelative("m_MaxCurve"), GUIContent.none);
                            if (twoCurves)
                            {
                                position.x += position.width;
                                EditorGUI.PropertyField(position, mmCurve.FindPropertyRelative("m_MinCurve"), GUIContent.none);
                            }                            
                            position.x += position.width;
                            var scalar = mmCurve.FindPropertyRelative("m_Scalar");
                            EditorGUI.BeginChangeCheck();
                            var sc = FloatDraggable(position, scalar, 1.0f, 20.0f, "g5");
                            if (EditorGUI.EndChangeCheck()) scalar.floatValue = sc;
                        }
                        break;
                }

                GUIMMCurvePopUp(popupRect, mmCurve);
            }
            catch (TargetInvocationException e)
            {
                if (e.InnerException is ExitGUIException)
                {
                    GUIUtility.ExitGUI();
                }
            }
        }

        delegate bool CurveFieldMouseDownCallback(SerializedProperty mmCurve, int button, Rect drawRect, Rect curveRanges);

        static void GUICurveField(Rect position, SerializedProperty mmCurve, SerializedProperty maxCurve, SerializedProperty minCurve, Color color, Rect ranges, CurveFieldMouseDownCallback mouseDownCallback)
        {
            var controlId = GUIUtility.GetControlID(1321321231, EditorGUIUtility.native, position);
            var current = Event.current;
            switch (current.GetTypeForControl(controlId))
            {
                case EventType.MouseDown:
                    if (!position.Contains(current.mousePosition) || mouseDownCallback == null || !mouseDownCallback(mmCurve, current.button, position, ranges))
                        break;
                    current.Use();
                    break;
                case EventType.Repaint:
                    EditorGUIUtility.DrawRegionSwatch(position, maxCurve, minCurve, color, typeof(EditorGUI).GetFieldValue<Color>("kCurveBGColor"), ranges);
                    typeof(EditorStyles).GetPropertyValue<GUIStyle>("colorPickerBox").Draw(position, GUIContent.none, controlId, false);
                    break;
            }
        }
        bool OnCurveAreaMouseDown(SerializedProperty mmCurve, int button, Rect drawRect, Rect curveRanges)
        {
            if (button == 0)
            {
                ToggleCurveInEditor(mmCurve);
                return true;
            }

            // TODO: Copy/paste
            return false;
        }
        void ToggleCurveInEditor(SerializedProperty mmCurve)
        {
            if (mmCurve == null || mmCurve.serializedObject == null || mmCurve.serializedObject.targetObject == null || !mmCurve.serializedObject.targetObject)
                return;

            var obj = mmCurve.serializedObject.targetObject as FluvioMonoBehaviourBase;

            if (obj == null || !obj)
                return;

            var t = obj.GetType();

            FluidParticleSystem fluid = null;

            if (typeof (FluidParticleSystem).IsAssignableFrom(t))
                fluid = obj as FluidParticleSystem;
            else if (typeof (FluidPlugin).IsAssignableFrom(t))
            {
                var plugin = obj as FluidPlugin;

                if (plugin != null && plugin)
                    fluid = plugin.fluid as FluidParticleSystem;
            }

            if (fluid == null || !fluid)
                return;

            var editors = Resources.FindObjectsOfTypeAll<Editor>();

            if (editors == null)
                return;

            // TODO: Multiple curve inspectors open at once
            foreach (var editor in editors)
            {
                if (editor == null || !editor)
                    continue;
                
                var inspector = editor as FluidParticleSystemInspector;

                if (inspector == null || !inspector)
                    continue;

                if (inspector.target == null || inspector.target != fluid)
                    continue;
                
                var particleEffectUI = inspector.particleEffectUI;

                if (particleEffectUI == null)
                    continue;

                bool visible;
                Parameter minCurve, maxCurve;
                SerializedProperty curve;

                inspector.FindMinMaxCurve(obj.GetInstanceID(), mmCurve.propertyPath, out visible, out curve, out minCurve, out maxCurve);
                
                if (curve == null) 
                    continue;

                var systemCurveEditor = particleEffectUI.Invoke("GetParticleSystemCurveEditor");

                if (systemCurveEditor == null)
                    continue;

                m_CurveEditor = systemCurveEditor;
                m_Curve = curve;
                m_Max = (SerializedProperty)maxCurve.obj;
                m_Min = (SerializedProperty)minCurve.obj;
                m_Inspector = inspector;

                if ((bool)systemCurveEditor.Invoke("IsAdded", minCurve, maxCurve))
                {
                    systemCurveEditor.Invoke("RemoveCurve", minCurve, maxCurve);
                }
                else
                {
                    systemCurveEditor.Invoke("AddCurve", CreateCurveData(curve, minCurve, maxCurve, fluid, ((Color)systemCurveEditor.Invoke("GetAvailableColor")), visible));
                }
            }
        }
        public Color GetCurveColor()
        {
            if (m_CurveEditor != null && m_Max != null)
            {
                var index = m_CurveEditor.Invoke<int>("FindIndex", m_Max.Param());
                var addedCurves = (IList) m_CurveEditor.GetFieldValue("m_AddedCurves");

                if (index >= 0 && index < addedCurves.Count)
                    return addedCurves[index].GetFieldValue<Color>("m_Color");
            }

            return new Color(0.8f, 0.8f, 0.8f, 0.7f);
        }

        Parameter CreateCurveData(SerializedProperty mmCurve, Parameter minCurve, Parameter maxCurve, Object system, Color color, bool visible)
        {
            var uniqueName = system.GetInstanceID() + "." + mmCurve.GetHashCode() + "." + mmCurve.name;

            // NOTE: This is in the root namespace
            var CurveData = typeof(Editor).GetTypeInAssembly("ParticleSystemCurveEditor").NestedType("CurveData");

            var getAxisScalarsCallbackType = ReflectionHelpers.GetEditorType("CurveWrapper").NestedType("GetAxisScalarsCallback");
            var setAxisScalarsCallbackType = ReflectionHelpers.GetEditorType("CurveWrapper").NestedType("SetAxisScalarsCallback");

            var getAxisScalarsCallback = Delegate.CreateDelegate(getAxisScalarsCallbackType, this, "GetAxisScalars");
            var setAxisScalarsCallback = Delegate.CreateDelegate(setAxisScalarsCallbackType, this, "SetAxisScalars");

            m_Scalar = mmCurve.FindPropertyRelative("m_Scalar");

            var displayName = string.Format("{0} ({1})", mmCurve.GetPropertyValue<string>("displayName"), ObjectNames.NicifyVariableName(mmCurve.serializedObject.targetObject.GetType().Name));

            // Parameters:
            // string name, GUIContent displayName, SerializedProperty min, SerializedProperty max, Color color, bool signedRange, CurveWrapper.GetAxisScalarsCallback getAxisScalars, CurveWrapper.SetAxisScalarsCallback setAxisScalars, bool visible)
            var isSigned = mmCurve.FindPropertyRelative("m_IsSigned").boolValue;
            return new Parameter(
                CurveData.Create(uniqueName.Param(), new GUIContent(displayName).Param(), minCurve, maxCurve, color.Param(), isSigned.Param(), getAxisScalarsCallback.Param(), setAxisScalarsCallback.Param(), visible.Param()),
                CurveData);
        }

        [UsedImplicitly]
        Vector2 GetAxisScalars()
        {
            return new Vector2(1.0f, m_Scalar.floatValue * 1.0f);
        }
        
        [UsedImplicitly]
        void SetAxisScalars(Vector2 newAxisScalars)
        {
            m_Scalar.floatValue = newAxisScalars.y;
            m_Scalar.serializedObject.ApplyModifiedProperties();
        }

        void GUIMMCurvePopUp(Rect rect, SerializedProperty curveProp)
        {
            if (!(bool)typeof(EditorGUI).Invoke("ButtonMouseDown", rect.Param(), GUIContent.none.Param(), FocusType.Passive.Param(), rect.height <= 13 ? ((GUIStyle)"ShurikenDropdown").Param() : EditorStyles.foldout.Param()))
                return;

            var popupContent = new[]
            {
                new GUIContent("Constant"),
                new GUIContent("Curve"),
                new GUIContent("Random Between Two Constants"),
                new GUIContent("Random Between Two Curves")
            };

            var minMaxStates = new[]
            {
                0,
                1,
                2,
                3
            };

            var genericMenu = new GenericMenu();

            for (var i = 0; i < popupContent.Length; ++i)
            {
                genericMenu.AddItem(popupContent[i], curveProp.FindPropertyRelative("m_MinMaxState").enumValueIndex == minMaxStates[i], SelectMinMaxCurveStateCallback, new CurveCallbackData(minMaxStates[i], curveProp));
            }
            genericMenu.ShowAsContext();
            Event.current.Use();
        }

        void SelectMinMaxCurveStateCallback(object userData)
        {
            var data = (CurveCallbackData)userData;
            var curve = m_Curve ?? data.curveProp;

            var minMaxProp = curve.FindPropertyRelative("m_MinMaxState");
            var oldValue = minMaxProp.enumValueIndex;
            var newValue = data.enumValueIndex;

            if (oldValue != newValue)
            {
                var initCurve = data.enumValueIndex % 2 != 0;
                var min = m_Min == null ? new Parameter(null, typeof (SerializedProperty)) : m_Min.Param();
                if (m_Curve != null && m_CurveEditor != null && (bool)m_CurveEditor.Invoke("IsAdded", min, m_Max.Param()))
                {
                    ToggleCurveInEditor(m_Curve);                    
                }

                var oldState = (FluvioMinMaxCurveState) oldValue;
                var newState = (FluvioMinMaxCurveState) newValue;

                switch (newState)
                {
                    case FluvioMinMaxCurveState.Constant:
                        InitConstant(curve, oldState);
                        break;
                    case FluvioMinMaxCurveState.Curve:
                        InitCurve(curve, oldState);
                        break;
                    case FluvioMinMaxCurveState.RandomBetweenTwoConstants:
                        InitRandomBetweenTwoConstants(curve, oldState);
                        break;
                    case FluvioMinMaxCurveState.RandomBetweenTwoCurves:
                        InitRandomBetweenTwoCurves(curve, oldState);
                        break;
                }

                typeof(Editor).GetTypeInAssembly("UnityEditorInternal.AnimationCurvePreviewCache").Invoke("ClearCache");

                minMaxProp.enumValueIndex = newValue;
                curve.serializedObject.ApplyModifiedProperties();
                
                if (initCurve)
                {
                    if (m_Curve != null) m_Curve.serializedObject.Update();
                    ToggleCurveInEditor(curve);
                }
            }
            if (m_Inspector) m_Inspector.Repaint();
        }
        static float GetMaxKeyValue(IList<Keyframe> keys, bool isSigned)
        {
            var max = float.MinValue;
            for (var i = 0; i < keys.Count; ++i)
            {
                var val = Mathf.Clamp(keys[i].value, isSigned ? -1.0f : 0.0f, 1.0f);
                if (val > max) max = val;
            }

            return max;
        }

        static float GetAverageKeyValue(IList<Keyframe> keys, bool isSigned)
        {
            var total = 0.0f;
            for (var i = 0; i < keys.Count; ++i)
            {
                total += Mathf.Clamp(keys[i].value, isSigned ? -1.0f : 0.0f, 1.0f);
            }

            return total/keys.Count;
        }
        static void InitConstant(SerializedProperty curve, FluvioMinMaxCurveState oldState)
        {
            switch (oldState)
            {
                case FluvioMinMaxCurveState.Curve:
                case FluvioMinMaxCurveState.RandomBetweenTwoCurves:
                case FluvioMinMaxCurveState.RandomBetweenTwoConstants:
                    curve.FindPropertyRelative("m_Scalar").floatValue *= GetMaxKeyValue(curve.FindPropertyRelative("m_MaxCurve").animationCurveValue.keys, curve.FindPropertyRelative("m_IsSigned").boolValue);
                    break;
            }
            SetCurveConstant(curve.FindPropertyRelative("m_MinCurve"), 1.0f);
            SetCurveConstant(curve.FindPropertyRelative("m_MaxCurve"), 1.0f);
        }
        static void InitRandomBetweenTwoConstants(SerializedProperty curve, FluvioMinMaxCurveState oldState)
        {
            curve.FindPropertyRelative("m_MinConstant").floatValue = GetAverageKeyValue(curve.FindPropertyRelative("m_MinCurve").animationCurveValue.keys, curve.FindPropertyRelative("m_IsSigned").boolValue) * curve.FindPropertyRelative("m_Scalar").floatValue;
            switch (oldState)
            {
                case FluvioMinMaxCurveState.Constant:
                    curve.FindPropertyRelative("m_MaxConstant").floatValue = curve.FindPropertyRelative("m_Scalar").floatValue;
                    break;
                case FluvioMinMaxCurveState.Curve:
                case FluvioMinMaxCurveState.RandomBetweenTwoCurves:
                    curve.FindPropertyRelative("m_MaxConstant").floatValue = GetAverageKeyValue(curve.FindPropertyRelative("m_MaxCurve").animationCurveValue.keys, curve.FindPropertyRelative("m_IsSigned").boolValue) * curve.FindPropertyRelative("m_Scalar").floatValue;
                    break;
            }
        }
        static void InitCurve(SerializedProperty curve, FluvioMinMaxCurveState oldState)
        {
            switch (oldState)
            {
                case FluvioMinMaxCurveState.Constant:
                    SetCurveConstant(curve.FindPropertyRelative("m_MaxCurve"), GetNormalizedValueFromScalar(curve));
                    break;
            }
        }
        static void InitRandomBetweenTwoCurves(SerializedProperty curve, FluvioMinMaxCurveState oldState)
        {
            switch (oldState)
            {
                case FluvioMinMaxCurveState.Constant:
                    SetCurveConstant(curve.FindPropertyRelative("m_MaxCurve"), GetNormalizedValueFromScalar(curve));
                    break;
            }
        }
        static void SetCurveConstant(SerializedProperty curve, float constant)
        {
            var keys = new[] { new Keyframe(0.0f, constant), new Keyframe(1.0f, constant) };
            curve.animationCurveValue.keys = keys;
        }

        static float GetNormalizedValueFromScalar(SerializedProperty curve)
        {
            var scalar = curve.FindPropertyRelative("m_Scalar").floatValue;

            if (scalar < 0.0f)
                return -1.0f;
            return scalar > 0.0f ? 1.0f : 0.0f;
        }
        struct CurveCallbackData
        {
            public int enumValueIndex;
            public SerializedProperty curveProp;

            public CurveCallbackData(int enumValueIndex, SerializedProperty curveProp)
            {
                this.enumValueIndex = enumValueIndex;
                this.curveProp = curveProp;
            }
        }
    }
}
