// FluidColliderInspector.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using Thinksquirrel.Fluvio;
using UnityEditor;

namespace Thinksquirrel.FluvioEditor.Inspectors
{
    [CustomEditor(typeof (FluidCollider))]
    [CanEditMultipleObjects]
    public class FluidColliderInspector : FluidColliderBaseInspector {}
}
