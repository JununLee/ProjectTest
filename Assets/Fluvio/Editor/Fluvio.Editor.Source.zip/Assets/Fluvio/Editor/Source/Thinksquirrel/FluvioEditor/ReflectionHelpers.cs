// ReflectionHelpers.cs
// Copyright (c) 2011-2015 Thinksquirrel Software, LLC.

using System;
using System.Linq;
using System.Reflection;
using JetBrains.Annotations;
using UnityEditor;

namespace Thinksquirrel.FluvioEditor
{

    #region Parameters
    struct Parameter
    {
        #region Public API
        public object obj;
        public Type parameterType;
        public Parameter(Object obj)
        {
            this.obj = obj;
            parameterType = obj == null ? typeof (object) : obj.GetType();
        }
        public Parameter(Object obj, Type type)
        {
            this.obj = obj;
            parameterType = type;
        }
        #endregion
    }
    #endregion

    static class ReflectionHelpers
    {
        internal static T Cast<T>([NotNull] this object obj)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            var type = typeof (T);
            return (T) Cast(obj, type);
        }
        internal static object Cast([NotNull] this object obj, [NotNull] Type type)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (type == null) throw new ArgumentNullException("type");
            if (type.IsEnum)
            {
                return Enum.ToObject(type, obj);
            }
            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
            {
                return Convert.ChangeType(obj, Nullable.GetUnderlyingType(type));
            }
            return Convert.ChangeType(obj, type);
        }
        internal static Type GetEditorType([NotNull] string typeName)
        {
            if (typeName == null) throw new ArgumentNullException("typeName");
            return GetTypeInAssembly(typeof (Editor), string.Format("UnityEditor.{0}", typeName));
        }
        internal static FieldInfo GetField([NotNull] this object obj, [NotNull] string fieldName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (fieldName == null) throw new ArgumentNullException("fieldName");

            var t = obj.GetType();

            while (t != null)
            {
                var candidate = t.GetField(fieldName,
                                BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                BindingFlags.Public);

                if (candidate != null) return candidate;
                t = t.BaseType;
            }
            return null;

        }
        internal static Type GetFieldType([NotNull] this Type type, [NotNull] string fieldName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (fieldName == null) throw new ArgumentNullException("fieldName");

            var t = type;

            while (t != null)
            {
                var candidate = t.GetField(fieldName,
                                BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                BindingFlags.Public);

                if (candidate != null) return candidate.FieldType;
                t = t.BaseType;
            }
            return null;
        }
        internal static Type GetFieldType([NotNull] this object obj, [NotNull] string fieldName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            return GetFieldType(obj.GetType(), fieldName);
        }
        internal static object GetFieldValue([NotNull] this Type type, [NotNull] string fieldName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            return GetFieldValue<object>(type, null, fieldName);
        }
        internal static T GetFieldValue<T>([NotNull] this Type type, [NotNull] string fieldName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            return GetFieldValue<T>(type, null, fieldName);
        }
        internal static object GetFieldValue([NotNull] this object obj, [NotNull] string fieldName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            return GetFieldValue<object>(obj.GetType(), obj, fieldName);
        }
        internal static T GetFieldValue<T>([NotNull] this object obj, [NotNull] string fieldName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            return GetFieldValue<T>(obj.GetType(), obj, fieldName);
        }
        internal static MethodInfo GetMethod([NotNull] this object obj, [NotNull] string methodName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (methodName == null) throw new ArgumentNullException("methodName");

            var t = obj.GetType();

            while (t != null)
            {
                var candidate = t.GetMethod(methodName,
                                            BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                            BindingFlags.Public);

                if (candidate != null) return candidate;
                t = t.BaseType;
            }

            return null;
        }
        internal static PropertyInfo GetProperty([NotNull] this object obj, [NotNull] string propertyName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (propertyName == null) throw new ArgumentNullException("propertyName");

            var t = obj.GetType();

            while (t != null)
            {
                var candidate = t.GetProperty(propertyName,
                                   BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                   BindingFlags.Public);

                if (candidate != null) return candidate;
                t = t.BaseType;
            }
            return null;
        }
        internal static Type GetPropertyType([NotNull] this Type type, [NotNull] string propertyName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (propertyName == null) throw new ArgumentNullException("propertyName");

            var t = type;

            while (t != null)
            {
                var candidate = t.GetProperty(propertyName,
                                              BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                              BindingFlags.Public);

                if (candidate != null) return candidate.PropertyType;
                t = t.BaseType;
            }
            return null;
        }
        internal static Type GetPropertyType([NotNull] this object obj, [NotNull] string propertyName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            return GetPropertyType(obj.GetType(), propertyName);
        }
        internal static object GetPropertyValue([NotNull] this Type type, [NotNull] string propertyName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            return GetPropertyValue<object>(type, null, propertyName);
        }
        internal static T GetPropertyValue<T>([NotNull] this Type type, [NotNull] string propertyName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            return GetPropertyValue<T>(type, null, propertyName);
        }
        internal static object GetPropertyValue([NotNull] this object obj, [NotNull] string propertyName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            return GetPropertyValue<object>(obj.GetType(), obj, propertyName);
        }
        internal static T GetPropertyValue<T>([NotNull] this object obj, [NotNull] string propertyName)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            return GetPropertyValue<T>(obj.GetType(), obj, propertyName);
        }
        internal static Type GetRuntimeType([NotNull] string typeName)
        {
            if (typeName == null) throw new ArgumentNullException("typeName");
            return GetTypeInAssembly(typeof (UnityEngine.Object), string.Format("UnityEngine.{0}", typeName));
        }
        internal static Type GetTypeInAssembly([NotNull] this Type type, [NotNull] string typeName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (typeName == null) throw new ArgumentNullException("typeName");
            return type.Assembly.GetType(typeName);
        }
        internal static object Invoke([NotNull] this Type type, [NotNull] string methodName, params Parameter[] parameters)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (methodName == null) throw new ArgumentNullException("methodName");
            return Invoke<object>(type, null, methodName, parameters);
        }
        internal static T Invoke<T>([NotNull] this Type type, [NotNull] string methodName, params Parameter[] parameters)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (methodName == null) throw new ArgumentNullException("methodName");
            return Invoke<T>(type, null, methodName, parameters);
        }
        internal static object Invoke([NotNull] this object obj, [NotNull] string methodName, params Parameter[] parameters)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (methodName == null) throw new ArgumentNullException("methodName");
            return Invoke<object>(obj.GetType(), obj, methodName, parameters);
        }
        internal static T Invoke<T>([NotNull] this object obj, [NotNull] string methodName, params Parameter[] parameters)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (methodName == null) throw new ArgumentNullException("methodName");
            return Invoke<T>(obj.GetType(), obj, methodName, parameters);
        }
        internal static Type NestedType([NotNull] this Type type, [NotNull] string typeName)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (typeName == null) throw new ArgumentNullException("typeName");
            return type.GetNestedType(typeName,
                                      BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                      BindingFlags.Public);
        }
        internal static Parameter Param([NotNull] this object obj)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            return new Parameter(obj);
        }
        internal static void SetFieldValue([NotNull] this Type type, [NotNull] string fieldName, object value)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            SetFieldValue(type, null, fieldName, value);
        }
        internal static void SetFieldValue([NotNull] this object obj, [NotNull] string fieldName, object value)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (fieldName == null) throw new ArgumentNullException("fieldName");
            SetFieldValue(obj.GetType(), obj, fieldName, value);
        }
        internal static void SetPropertyValue([NotNull] this Type type, [NotNull] string propertyName, object value)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            SetPropertyValue(type, null, propertyName, value);
        }
        internal static void SetPropertyValue([NotNull] this object obj, [NotNull] string propertyName, object value)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (propertyName == null) throw new ArgumentNullException("propertyName");
            SetPropertyValue(obj.GetType(), obj, propertyName, value);
        }
        internal static object Create(this Type type, params Parameter[] parameters)
        {
            return Create<object>(type, parameters);
        }
        internal static T Create<T>([NotNull] this Type type, params Parameter[] parameters)
        {
            if (type == null) throw new ArgumentNullException("type");
            return
                (T)
                    type.GetConstructor(
                        BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null,
                        parameters.Select(p => p.parameterType).ToArray(), null)
                        .Invoke(parameters.Select(p => p.obj).ToArray());
        }
        static T GetFieldValue<T>(Type type, object obj, string fieldName)
        {
            var t = type;

            while (t != null)
            {
                var candidate = t.GetField(fieldName,
                                  BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                  BindingFlags.Public);

                if (candidate != null) return (T)candidate.GetValue(obj);
                t = t.BaseType;
            }
            return default(T);
        }
        static T GetPropertyValue<T>(Type type, object obj, string propertyName)
        {
            var t = type;

            while (t != null)
            {
                var candidate = t.GetProperty(propertyName,
                                              BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                              BindingFlags.Public);

                if (candidate != null) return (T)candidate.GetValue(obj, null);
                t = t.BaseType;
            }

            return default(T);
        }
        static T Invoke<T>(Type type, object obj, string methodName, params Parameter[] parameters)
        {
            var t = type;

            while (t != null)
            {
                var candidate = t.GetMethod(methodName,
                                            BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                            BindingFlags.Public, null, parameters.Select(p => p.parameterType).ToArray(),
                                            null);

                if (candidate != null) return (T)candidate.Invoke(obj, parameters.Select(p => p.obj).ToArray());
                t = t.BaseType;
            }

            return default(T);
        }
        static void SetFieldValue(Type type, object obj, string fieldName, object value)
        {
            var t = type;

            while (t != null)
            {
                var candidate = t.GetField(fieldName,
                                           BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                           BindingFlags.Public);
                if (candidate != null)
                {
                    candidate.SetValue(obj, value);
                    return;
                }
                t = t.BaseType;
            }
        }
        static void SetPropertyValue(Type type, object obj, string propertyName, object value)
        {
            var t = type;

            while (t != null)
            {
                var candidate = t.GetProperty(propertyName,
                                              BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic |
                                              BindingFlags.Public);

                if (candidate != null)
                {
                    candidate.SetValue(obj, value, null);
                    return;
                }
                t = t.BaseType;
            }
        }
    }
}
